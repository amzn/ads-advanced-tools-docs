import boto3 
import json
import requests
import pickle
import pandas as pd

## Get Secrets
def get_secret(secret_name, region_name, source = 'secret manager'):

    if source == 'local':
        # Retrieve Creds from local path cred/access.json
        with open('creds/access.json', 'rb') as handle:
            secret_cred = pickle.load(handle)
        
    else:
        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=region_name
        )

        try:
            get_secret_value_response = client.get_secret_value(
                SecretId=secret_name
            )
        except ClientError as e:
            # For a list of exceptions thrown, see
            # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
            raise e
        
        secret_cred = json.loads(get_secret_value_response['SecretString'])

        
    print("Secrets retrieved!!!")
    
    return secret_cred

def refresh_access_token(url, Clientid, Clientsecret, refresh_token):
    refresh_body = {"grant_type": "refresh_token",
                 "client_id": Clientid,
               "client_secret": Clientsecret,
               "refresh_token": refresh_token}

    r = requests.post(url, data = refresh_body)

    if r.ok:
        access_token = r.json()['access_token']
        print("Token refreshed successfully")
        
        return access_token
    else:
        print('Response Code is: ', r)
        print('Error message is: ', r.text)
        raise Exception("Access token failed to refresh")
        
        
def loop_through_pagination(url, headers, firstJsonElement):
    print("starting function")
    counter = 0
    df = pd.DataFrame()
    r = requests.get(url, headers = headers)
    
    if r.ok:
        df = pd.concat([df, pd.DataFrame(r.json()[firstJsonElement])])
        
        if (r.json()['nextToken'] is None) or (r.json()['nextToken'] == ''):
            print("No Next Token")
            nextToken = None
        else:
            print("Next Token")
            nextToken = r.json()['nextToken']
            
        while nextToken is not None:
            r = requests.get(url + '?nextToken=' + nextToken, headers = headers)
            
            if r.ok:
                df = pd.concat([df, pd.DataFrame(r.json()[firstJsonElement])])

                if (r.json()['nextToken'] is None) or (r.json()['nextToken'] == ''):
                    print("No Next Token")
                    nextToken = None 
                    
                else:
                    nextToken = r.json()['nextToken']
                    
            else:
                raise Exception("API Failed")
            counter = counter + 1
            time.sleep(1)
            print("Loop number: ", counter)
    else:
        print(r.text)
        raise Exception("API Failed") 
    
    
    return df