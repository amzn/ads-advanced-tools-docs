"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignRdsStack = void 0;
const cdk = require("aws-cdk-lib");
const ec2 = require("aws-cdk-lib/aws-ec2");
const rds = require("aws-cdk-lib/aws-rds");
const iam = require("aws-cdk-lib/aws-iam");
const ssm = require("aws-cdk-lib/aws-ssm");
class CampaignRdsStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        // Create VPC with PRIVATE subnets only (no public subnets for security)
        // IMPORTANT: DNS hostnames and DNS support are REQUIRED for AgentCore VPC endpoints
        // Using 172.31.0.0/16 CIDR to avoid conflicts with existing 10.x subnets
        this.vpc = new ec2.Vpc(this, 'CampaignVPC', {
            ipAddresses: ec2.IpAddresses.cidr('172.31.0.0/16'),
            availabilityZones: ['us-east-1c', 'us-east-1d'], // Use the names that map to use1-az1, use1-az2
            natGateways: 0,
            // Enable DNS for VPC endpoint resolution (required by AgentCore)
            enableDnsHostnames: true,
            enableDnsSupport: true,
            subnetConfiguration: [
                {
                    cidrMask: 24,
                    name: 'private',
                    subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
                },
            ],
        });
        // VPC Endpoints for AWS services (no NAT Gateway needed)
        this.vpc.addInterfaceEndpoint('SSMEndpoint', {
            service: ec2.InterfaceVpcEndpointAwsService.SSM,
        });
        this.vpc.addInterfaceEndpoint('SecretsManagerEndpoint', {
            service: ec2.InterfaceVpcEndpointAwsService.SECRETS_MANAGER,
        });
        this.vpc.addInterfaceEndpoint('BedrockAgentCoreEndpoint', {
            service: new ec2.InterfaceVpcEndpointService(`com.amazonaws.${this.region}.bedrock-agentcore`, 443),
        });
        this.vpc.addInterfaceEndpoint('EcrApiEndpoint', {
            service: ec2.InterfaceVpcEndpointAwsService.ECR,
        });
        this.vpc.addInterfaceEndpoint('EcrDkrEndpoint', {
            service: ec2.InterfaceVpcEndpointAwsService.ECR_DOCKER,
        });
        this.vpc.addGatewayEndpoint('S3Endpoint', {
            service: ec2.GatewayVpcEndpointAwsService.S3,
        });
        this.vpc.addInterfaceEndpoint('CloudWatchLogsEndpoint', {
            service: ec2.InterfaceVpcEndpointAwsService.CLOUDWATCH_LOGS,
        });
        // Additional VPC Endpoints for SSM Session Manager
        this.vpc.addInterfaceEndpoint('SSMMessagesEndpoint', {
            service: ec2.InterfaceVpcEndpointAwsService.SSM_MESSAGES,
        });
        this.vpc.addInterfaceEndpoint('EC2MessagesEndpoint', {
            service: ec2.InterfaceVpcEndpointAwsService.EC2_MESSAGES,
        });
        // Database access instance (for setup and maintenance via SSM Session Manager)
        const dbAccessSecurityGroup = new ec2.SecurityGroup(this, 'DbAccessSecurityGroup', {
            vpc: this.vpc,
            description: 'Security group for database access instance',
            allowAllOutbound: true,
        });
        const dbAccessRole = new iam.Role(this, 'DbAccessRole', {
            assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'),
            managedPolicies: [
                iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMManagedInstanceCore'),
            ],
        });
        const dbAccessInstance = new ec2.Instance(this, 'DbAccessInstance', {
            vpc: this.vpc,
            vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
            instanceType: ec2.InstanceType.of(ec2.InstanceClass.T3, ec2.InstanceSize.MICRO),
            machineImage: ec2.MachineImage.latestAmazonLinux2023(),
            securityGroup: dbAccessSecurityGroup,
            role: dbAccessRole,
        });
        // Install PostgreSQL client on database access instance
        dbAccessInstance.userData.addCommands('yum update -y', 'yum install -y postgresql15');
        // Security group for MCP Server (AgentCore Runtime)
        this.mcpServerSecurityGroup = new ec2.SecurityGroup(this, 'MCPServerSecurityGroup', {
            vpc: this.vpc,
            description: 'Security group for MCP Server on AgentCore Runtime',
            allowAllOutbound: true,
        });
        // Security group for RDS
        this.dbSecurityGroup = new ec2.SecurityGroup(this, 'DatabaseSecurityGroup', {
            vpc: this.vpc,
            description: 'Security group for Campaign RDS instance',
            allowAllOutbound: true,
        });
        // Allow PostgreSQL access from MCP Server security group only
        this.dbSecurityGroup.addIngressRule(this.mcpServerSecurityGroup, ec2.Port.tcp(5432), 'Allow PostgreSQL access from MCP Server');
        // Allow PostgreSQL access from database access instance
        this.dbSecurityGroup.addIngressRule(dbAccessSecurityGroup, ec2.Port.tcp(5432), 'Allow PostgreSQL access from database access instance');
        // Create RDS instance in private subnet
        this.database = new rds.DatabaseInstance(this, 'CampaignDatabase', {
            engine: rds.DatabaseInstanceEngine.postgres({
                version: rds.PostgresEngineVersion.VER_15,
            }),
            instanceType: ec2.InstanceType.of(ec2.InstanceClass.T3, ec2.InstanceSize.MICRO),
            vpc: this.vpc,
            vpcSubnets: {
                subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
            },
            securityGroups: [this.dbSecurityGroup],
            databaseName: 'campaigndb',
            allocatedStorage: 20,
            storageType: rds.StorageType.GP3,
            credentials: rds.Credentials.fromGeneratedSecret('dbadmin'),
            backupRetention: cdk.Duration.days(7),
            deleteAutomatedBackups: true,
            removalPolicy: cdk.RemovalPolicy.SNAPSHOT,
            deletionProtection: false,
            publiclyAccessible: false, // Private database
            storageEncrypted: true,
            preferredBackupWindow: '03:00-04:00',
            preferredMaintenanceWindow: 'sun:04:00-sun:05:00',
            enablePerformanceInsights: true,
            performanceInsightRetention: rds.PerformanceInsightRetention.DEFAULT,
            monitoringInterval: cdk.Duration.seconds(60),
            cloudwatchLogsExports: ['postgresql', 'upgrade'],
            autoMinorVersionUpgrade: false,
        });
        // Store only essential outputs in Parameter Store
        // Note: Use Fn.join for subnet IDs to ensure proper CloudFormation resolution
        new ssm.StringParameter(this, 'PrivateSubnetIdsParam', {
            parameterName: '/campaign/private-subnet-ids',
            stringValue: cdk.Fn.join(',', this.vpc.selectSubnets({
                subnetType: ec2.SubnetType.PRIVATE_ISOLATED
            }).subnetIds),
        });
        new ssm.StringParameter(this, 'MCPServerSecurityGroupIdParam', {
            parameterName: '/campaign/mcp-sg-id',
            stringValue: this.mcpServerSecurityGroup.securityGroupId,
        });
        new ssm.StringParameter(this, 'DBEndpointParam', {
            parameterName: '/campaign/db-endpoint',
            stringValue: this.database.dbInstanceEndpointAddress,
        });
        new ssm.StringParameter(this, 'DBSecretArnParam', {
            parameterName: '/campaign/db-secret-arn',
            stringValue: this.database.secret?.secretArn || 'N/A',
        });
        new ssm.StringParameter(this, 'DbAccessInstanceIdParam', {
            parameterName: '/campaign/db-access-instance-id',
            stringValue: dbAccessInstance.instanceId,
        });
    }
}
exports.CampaignRdsStack = CampaignRdsStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmRzLXN0YWNrLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmRzLXN0YWNrLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLG1DQUFtQztBQUNuQywyQ0FBMkM7QUFDM0MsMkNBQTJDO0FBQzNDLDJDQUEyQztBQUMzQywyQ0FBMkM7QUFHM0MsTUFBYSxnQkFBaUIsU0FBUSxHQUFHLENBQUMsS0FBSztJQU03QyxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXNCO1FBQzlELEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXhCLHdFQUF3RTtRQUN4RSxvRkFBb0Y7UUFDcEYseUVBQXlFO1FBQ3pFLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDMUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztZQUNsRCxpQkFBaUIsRUFBRSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsRUFBRywrQ0FBK0M7WUFDakcsV0FBVyxFQUFFLENBQUM7WUFDZCxpRUFBaUU7WUFDakUsa0JBQWtCLEVBQUUsSUFBSTtZQUN4QixnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLG1CQUFtQixFQUFFO2dCQUNuQjtvQkFDRSxRQUFRLEVBQUUsRUFBRTtvQkFDWixJQUFJLEVBQUUsU0FBUztvQkFDZixVQUFVLEVBQUUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0I7aUJBQzVDO2FBQ0Y7U0FDRixDQUFDLENBQUM7UUFFSCx5REFBeUQ7UUFDekQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLEVBQUU7WUFDM0MsT0FBTyxFQUFFLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxHQUFHO1NBQ2hELENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsd0JBQXdCLEVBQUU7WUFDdEQsT0FBTyxFQUFFLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxlQUFlO1NBQzVELENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsMEJBQTBCLEVBQUU7WUFDeEQsT0FBTyxFQUFFLElBQUksR0FBRyxDQUFDLDJCQUEyQixDQUMxQyxpQkFBaUIsSUFBSSxDQUFDLE1BQU0sb0JBQW9CLEVBQ2hELEdBQUcsQ0FDSjtTQUNGLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLEVBQUU7WUFDOUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxHQUFHO1NBQ2hELENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLEVBQUU7WUFDOUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxVQUFVO1NBQ3ZELENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFO1lBQ3hDLE9BQU8sRUFBRSxHQUFHLENBQUMsNEJBQTRCLENBQUMsRUFBRTtTQUM3QyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLHdCQUF3QixFQUFFO1lBQ3RELE9BQU8sRUFBRSxHQUFHLENBQUMsOEJBQThCLENBQUMsZUFBZTtTQUM1RCxDQUFDLENBQUM7UUFFSCxtREFBbUQ7UUFDbkQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxxQkFBcUIsRUFBRTtZQUNuRCxPQUFPLEVBQUUsR0FBRyxDQUFDLDhCQUE4QixDQUFDLFlBQVk7U0FDekQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxxQkFBcUIsRUFBRTtZQUNuRCxPQUFPLEVBQUUsR0FBRyxDQUFDLDhCQUE4QixDQUFDLFlBQVk7U0FDekQsQ0FBQyxDQUFDO1FBRUgsK0VBQStFO1FBQy9FLE1BQU0scUJBQXFCLEdBQUcsSUFBSSxHQUFHLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUNqRixHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUc7WUFDYixXQUFXLEVBQUUsNkNBQTZDO1lBQzFELGdCQUFnQixFQUFFLElBQUk7U0FDdkIsQ0FBQyxDQUFDO1FBRUgsTUFBTSxZQUFZLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDdEQsU0FBUyxFQUFFLElBQUksR0FBRyxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDO1lBQ3hELGVBQWUsRUFBRTtnQkFDZixHQUFHLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDLDhCQUE4QixDQUFDO2FBQzNFO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQ2xFLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRztZQUNiLFVBQVUsRUFBRSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFO1lBQzNELFlBQVksRUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztZQUMvRSxZQUFZLEVBQUUsR0FBRyxDQUFDLFlBQVksQ0FBQyxxQkFBcUIsRUFBRTtZQUN0RCxhQUFhLEVBQUUscUJBQXFCO1lBQ3BDLElBQUksRUFBRSxZQUFZO1NBQ25CLENBQUMsQ0FBQztRQUVILHdEQUF3RDtRQUN4RCxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUNuQyxlQUFlLEVBQ2YsNkJBQTZCLENBQzlCLENBQUM7UUFFRixvREFBb0Q7UUFDcEQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksR0FBRyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7WUFDbEYsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHO1lBQ2IsV0FBVyxFQUFFLG9EQUFvRDtZQUNqRSxnQkFBZ0IsRUFBRSxJQUFJO1NBQ3ZCLENBQUMsQ0FBQztRQUVILHlCQUF5QjtRQUN6QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksR0FBRyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDMUUsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHO1lBQ2IsV0FBVyxFQUFFLDBDQUEwQztZQUN2RCxnQkFBZ0IsRUFBRSxJQUFJO1NBQ3ZCLENBQUMsQ0FBQztRQUVILDhEQUE4RDtRQUM5RCxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FDakMsSUFBSSxDQUFDLHNCQUFzQixFQUMzQixHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFDbEIseUNBQXlDLENBQzFDLENBQUM7UUFFRix3REFBd0Q7UUFDeEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQ2pDLHFCQUFxQixFQUNyQixHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFDbEIsdURBQXVELENBQ3hELENBQUM7UUFFRix3Q0FBd0M7UUFDeEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDakUsTUFBTSxFQUFFLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxRQUFRLENBQUM7Z0JBQzFDLE9BQU8sRUFBRSxHQUFHLENBQUMscUJBQXFCLENBQUMsTUFBTTthQUMxQyxDQUFDO1lBQ0YsWUFBWSxFQUFFLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUMvQixHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFDcEIsR0FBRyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQ3ZCO1lBQ0QsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHO1lBQ2IsVUFBVSxFQUFFO2dCQUNWLFVBQVUsRUFBRSxHQUFHLENBQUMsVUFBVSxDQUFDLGdCQUFnQjthQUM1QztZQUNELGNBQWMsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDdEMsWUFBWSxFQUFFLFlBQVk7WUFDMUIsZ0JBQWdCLEVBQUUsRUFBRTtZQUNwQixXQUFXLEVBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHO1lBQ2hDLFdBQVcsRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQztZQUMzRCxlQUFlLEVBQUUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3JDLHNCQUFzQixFQUFFLElBQUk7WUFDNUIsYUFBYSxFQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUMsUUFBUTtZQUN6QyxrQkFBa0IsRUFBRSxLQUFLO1lBQ3pCLGtCQUFrQixFQUFFLEtBQUssRUFBRyxtQkFBbUI7WUFDL0MsZ0JBQWdCLEVBQUUsSUFBSTtZQUN0QixxQkFBcUIsRUFBRSxhQUFhO1lBQ3BDLDBCQUEwQixFQUFFLHFCQUFxQjtZQUNqRCx5QkFBeUIsRUFBRSxJQUFJO1lBQy9CLDJCQUEyQixFQUFFLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxPQUFPO1lBQ3BFLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUM1QyxxQkFBcUIsRUFBRSxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUM7WUFDaEQsdUJBQXVCLEVBQUUsS0FBSztTQUMvQixDQUFDLENBQUM7UUFFSCxrREFBa0Q7UUFDbEQsOEVBQThFO1FBQzlFLElBQUksR0FBRyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsdUJBQXVCLEVBQUU7WUFDckQsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxXQUFXLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDO2dCQUNuRCxVQUFVLEVBQUUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0I7YUFDNUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztTQUNkLENBQUMsQ0FBQztRQUVILElBQUksR0FBRyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsK0JBQStCLEVBQUU7WUFDN0QsYUFBYSxFQUFFLHFCQUFxQjtZQUNwQyxXQUFXLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLGVBQWU7U0FDekQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxHQUFHLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUMvQyxhQUFhLEVBQUUsdUJBQXVCO1lBQ3RDLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLHlCQUF5QjtTQUNyRCxDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQ2hELGFBQWEsRUFBRSx5QkFBeUI7WUFDeEMsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsSUFBSSxLQUFLO1NBQ3RELENBQUMsQ0FBQztRQUVILElBQUksR0FBRyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUseUJBQXlCLEVBQUU7WUFDdkQsYUFBYSxFQUFFLGlDQUFpQztZQUNoRCxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsVUFBVTtTQUN6QyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUE1TEQsNENBNExDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgY2RrIGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCAqIGFzIGVjMiBmcm9tICdhd3MtY2RrLWxpYi9hd3MtZWMyJztcbmltcG9ydCAqIGFzIHJkcyBmcm9tICdhd3MtY2RrLWxpYi9hd3MtcmRzJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCAqIGFzIHNzbSBmcm9tICdhd3MtY2RrLWxpYi9hd3Mtc3NtJztcbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuXG5leHBvcnQgY2xhc3MgQ2FtcGFpZ25SZHNTdGFjayBleHRlbmRzIGNkay5TdGFjayB7XG4gIHB1YmxpYyByZWFkb25seSBkYXRhYmFzZTogcmRzLkRhdGFiYXNlSW5zdGFuY2U7XG4gIHB1YmxpYyByZWFkb25seSB2cGM6IGVjMi5WcGM7XG4gIHB1YmxpYyByZWFkb25seSBkYlNlY3VyaXR5R3JvdXA6IGVjMi5TZWN1cml0eUdyb3VwO1xuICBwdWJsaWMgcmVhZG9ubHkgbWNwU2VydmVyU2VjdXJpdHlHcm91cDogZWMyLlNlY3VyaXR5R3JvdXA7XG4gIFxuICBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wcz86IGNkay5TdGFja1Byb3BzKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCBwcm9wcyk7XG5cbiAgICAvLyBDcmVhdGUgVlBDIHdpdGggUFJJVkFURSBzdWJuZXRzIG9ubHkgKG5vIHB1YmxpYyBzdWJuZXRzIGZvciBzZWN1cml0eSlcbiAgICAvLyBJTVBPUlRBTlQ6IEROUyBob3N0bmFtZXMgYW5kIEROUyBzdXBwb3J0IGFyZSBSRVFVSVJFRCBmb3IgQWdlbnRDb3JlIFZQQyBlbmRwb2ludHNcbiAgICAvLyBVc2luZyAxNzIuMzEuMC4wLzE2IENJRFIgdG8gYXZvaWQgY29uZmxpY3RzIHdpdGggZXhpc3RpbmcgMTAueCBzdWJuZXRzXG4gICAgdGhpcy52cGMgPSBuZXcgZWMyLlZwYyh0aGlzLCAnQ2FtcGFpZ25WUEMnLCB7XG4gICAgICBpcEFkZHJlc3NlczogZWMyLklwQWRkcmVzc2VzLmNpZHIoJzE3Mi4zMS4wLjAvMTYnKSxcbiAgICAgIGF2YWlsYWJpbGl0eVpvbmVzOiBbJ3VzLWVhc3QtMWMnLCAndXMtZWFzdC0xZCddLCAgLy8gVXNlIHRoZSBuYW1lcyB0aGF0IG1hcCB0byB1c2UxLWF6MSwgdXNlMS1hejJcbiAgICAgIG5hdEdhdGV3YXlzOiAwLFxuICAgICAgLy8gRW5hYmxlIEROUyBmb3IgVlBDIGVuZHBvaW50IHJlc29sdXRpb24gKHJlcXVpcmVkIGJ5IEFnZW50Q29yZSlcbiAgICAgIGVuYWJsZURuc0hvc3RuYW1lczogdHJ1ZSxcbiAgICAgIGVuYWJsZURuc1N1cHBvcnQ6IHRydWUsXG4gICAgICBzdWJuZXRDb25maWd1cmF0aW9uOiBbXG4gICAgICAgIHtcbiAgICAgICAgICBjaWRyTWFzazogMjQsXG4gICAgICAgICAgbmFtZTogJ3ByaXZhdGUnLFxuICAgICAgICAgIHN1Ym5ldFR5cGU6IGVjMi5TdWJuZXRUeXBlLlBSSVZBVEVfSVNPTEFURUQsXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH0pO1xuXG4gICAgLy8gVlBDIEVuZHBvaW50cyBmb3IgQVdTIHNlcnZpY2VzIChubyBOQVQgR2F0ZXdheSBuZWVkZWQpXG4gICAgdGhpcy52cGMuYWRkSW50ZXJmYWNlRW5kcG9pbnQoJ1NTTUVuZHBvaW50Jywge1xuICAgICAgc2VydmljZTogZWMyLkludGVyZmFjZVZwY0VuZHBvaW50QXdzU2VydmljZS5TU00sXG4gICAgfSk7XG5cbiAgICB0aGlzLnZwYy5hZGRJbnRlcmZhY2VFbmRwb2ludCgnU2VjcmV0c01hbmFnZXJFbmRwb2ludCcsIHtcbiAgICAgIHNlcnZpY2U6IGVjMi5JbnRlcmZhY2VWcGNFbmRwb2ludEF3c1NlcnZpY2UuU0VDUkVUU19NQU5BR0VSLFxuICAgIH0pO1xuXG4gICAgdGhpcy52cGMuYWRkSW50ZXJmYWNlRW5kcG9pbnQoJ0JlZHJvY2tBZ2VudENvcmVFbmRwb2ludCcsIHtcbiAgICAgIHNlcnZpY2U6IG5ldyBlYzIuSW50ZXJmYWNlVnBjRW5kcG9pbnRTZXJ2aWNlKFxuICAgICAgICBgY29tLmFtYXpvbmF3cy4ke3RoaXMucmVnaW9ufS5iZWRyb2NrLWFnZW50Y29yZWAsXG4gICAgICAgIDQ0M1xuICAgICAgKSxcbiAgICB9KTtcblxuICAgIHRoaXMudnBjLmFkZEludGVyZmFjZUVuZHBvaW50KCdFY3JBcGlFbmRwb2ludCcsIHtcbiAgICAgIHNlcnZpY2U6IGVjMi5JbnRlcmZhY2VWcGNFbmRwb2ludEF3c1NlcnZpY2UuRUNSLFxuICAgIH0pO1xuXG4gICAgdGhpcy52cGMuYWRkSW50ZXJmYWNlRW5kcG9pbnQoJ0VjckRrckVuZHBvaW50Jywge1xuICAgICAgc2VydmljZTogZWMyLkludGVyZmFjZVZwY0VuZHBvaW50QXdzU2VydmljZS5FQ1JfRE9DS0VSLFxuICAgIH0pO1xuXG4gICAgdGhpcy52cGMuYWRkR2F0ZXdheUVuZHBvaW50KCdTM0VuZHBvaW50Jywge1xuICAgICAgc2VydmljZTogZWMyLkdhdGV3YXlWcGNFbmRwb2ludEF3c1NlcnZpY2UuUzMsXG4gICAgfSk7XG5cbiAgICB0aGlzLnZwYy5hZGRJbnRlcmZhY2VFbmRwb2ludCgnQ2xvdWRXYXRjaExvZ3NFbmRwb2ludCcsIHtcbiAgICAgIHNlcnZpY2U6IGVjMi5JbnRlcmZhY2VWcGNFbmRwb2ludEF3c1NlcnZpY2UuQ0xPVURXQVRDSF9MT0dTLFxuICAgIH0pO1xuXG4gICAgLy8gQWRkaXRpb25hbCBWUEMgRW5kcG9pbnRzIGZvciBTU00gU2Vzc2lvbiBNYW5hZ2VyXG4gICAgdGhpcy52cGMuYWRkSW50ZXJmYWNlRW5kcG9pbnQoJ1NTTU1lc3NhZ2VzRW5kcG9pbnQnLCB7XG4gICAgICBzZXJ2aWNlOiBlYzIuSW50ZXJmYWNlVnBjRW5kcG9pbnRBd3NTZXJ2aWNlLlNTTV9NRVNTQUdFUyxcbiAgICB9KTtcblxuICAgIHRoaXMudnBjLmFkZEludGVyZmFjZUVuZHBvaW50KCdFQzJNZXNzYWdlc0VuZHBvaW50Jywge1xuICAgICAgc2VydmljZTogZWMyLkludGVyZmFjZVZwY0VuZHBvaW50QXdzU2VydmljZS5FQzJfTUVTU0FHRVMsXG4gICAgfSk7XG5cbiAgICAvLyBEYXRhYmFzZSBhY2Nlc3MgaW5zdGFuY2UgKGZvciBzZXR1cCBhbmQgbWFpbnRlbmFuY2UgdmlhIFNTTSBTZXNzaW9uIE1hbmFnZXIpXG4gICAgY29uc3QgZGJBY2Nlc3NTZWN1cml0eUdyb3VwID0gbmV3IGVjMi5TZWN1cml0eUdyb3VwKHRoaXMsICdEYkFjY2Vzc1NlY3VyaXR5R3JvdXAnLCB7XG4gICAgICB2cGM6IHRoaXMudnBjLFxuICAgICAgZGVzY3JpcHRpb246ICdTZWN1cml0eSBncm91cCBmb3IgZGF0YWJhc2UgYWNjZXNzIGluc3RhbmNlJyxcbiAgICAgIGFsbG93QWxsT3V0Ym91bmQ6IHRydWUsXG4gICAgfSk7XG5cbiAgICBjb25zdCBkYkFjY2Vzc1JvbGUgPSBuZXcgaWFtLlJvbGUodGhpcywgJ0RiQWNjZXNzUm9sZScsIHtcbiAgICAgIGFzc3VtZWRCeTogbmV3IGlhbS5TZXJ2aWNlUHJpbmNpcGFsKCdlYzIuYW1hem9uYXdzLmNvbScpLFxuICAgICAgbWFuYWdlZFBvbGljaWVzOiBbXG4gICAgICAgIGlhbS5NYW5hZ2VkUG9saWN5LmZyb21Bd3NNYW5hZ2VkUG9saWN5TmFtZSgnQW1hem9uU1NNTWFuYWdlZEluc3RhbmNlQ29yZScpLFxuICAgICAgXSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGRiQWNjZXNzSW5zdGFuY2UgPSBuZXcgZWMyLkluc3RhbmNlKHRoaXMsICdEYkFjY2Vzc0luc3RhbmNlJywge1xuICAgICAgdnBjOiB0aGlzLnZwYyxcbiAgICAgIHZwY1N1Ym5ldHM6IHsgc3VibmV0VHlwZTogZWMyLlN1Ym5ldFR5cGUuUFJJVkFURV9JU09MQVRFRCB9LFxuICAgICAgaW5zdGFuY2VUeXBlOiBlYzIuSW5zdGFuY2VUeXBlLm9mKGVjMi5JbnN0YW5jZUNsYXNzLlQzLCBlYzIuSW5zdGFuY2VTaXplLk1JQ1JPKSxcbiAgICAgIG1hY2hpbmVJbWFnZTogZWMyLk1hY2hpbmVJbWFnZS5sYXRlc3RBbWF6b25MaW51eDIwMjMoKSxcbiAgICAgIHNlY3VyaXR5R3JvdXA6IGRiQWNjZXNzU2VjdXJpdHlHcm91cCxcbiAgICAgIHJvbGU6IGRiQWNjZXNzUm9sZSxcbiAgICB9KTtcblxuICAgIC8vIEluc3RhbGwgUG9zdGdyZVNRTCBjbGllbnQgb24gZGF0YWJhc2UgYWNjZXNzIGluc3RhbmNlXG4gICAgZGJBY2Nlc3NJbnN0YW5jZS51c2VyRGF0YS5hZGRDb21tYW5kcyhcbiAgICAgICd5dW0gdXBkYXRlIC15JyxcbiAgICAgICd5dW0gaW5zdGFsbCAteSBwb3N0Z3Jlc3FsMTUnXG4gICAgKTtcblxuICAgIC8vIFNlY3VyaXR5IGdyb3VwIGZvciBNQ1AgU2VydmVyIChBZ2VudENvcmUgUnVudGltZSlcbiAgICB0aGlzLm1jcFNlcnZlclNlY3VyaXR5R3JvdXAgPSBuZXcgZWMyLlNlY3VyaXR5R3JvdXAodGhpcywgJ01DUFNlcnZlclNlY3VyaXR5R3JvdXAnLCB7XG4gICAgICB2cGM6IHRoaXMudnBjLFxuICAgICAgZGVzY3JpcHRpb246ICdTZWN1cml0eSBncm91cCBmb3IgTUNQIFNlcnZlciBvbiBBZ2VudENvcmUgUnVudGltZScsXG4gICAgICBhbGxvd0FsbE91dGJvdW5kOiB0cnVlLFxuICAgIH0pO1xuXG4gICAgLy8gU2VjdXJpdHkgZ3JvdXAgZm9yIFJEU1xuICAgIHRoaXMuZGJTZWN1cml0eUdyb3VwID0gbmV3IGVjMi5TZWN1cml0eUdyb3VwKHRoaXMsICdEYXRhYmFzZVNlY3VyaXR5R3JvdXAnLCB7XG4gICAgICB2cGM6IHRoaXMudnBjLFxuICAgICAgZGVzY3JpcHRpb246ICdTZWN1cml0eSBncm91cCBmb3IgQ2FtcGFpZ24gUkRTIGluc3RhbmNlJyxcbiAgICAgIGFsbG93QWxsT3V0Ym91bmQ6IHRydWUsXG4gICAgfSk7XG5cbiAgICAvLyBBbGxvdyBQb3N0Z3JlU1FMIGFjY2VzcyBmcm9tIE1DUCBTZXJ2ZXIgc2VjdXJpdHkgZ3JvdXAgb25seVxuICAgIHRoaXMuZGJTZWN1cml0eUdyb3VwLmFkZEluZ3Jlc3NSdWxlKFxuICAgICAgdGhpcy5tY3BTZXJ2ZXJTZWN1cml0eUdyb3VwLFxuICAgICAgZWMyLlBvcnQudGNwKDU0MzIpLFxuICAgICAgJ0FsbG93IFBvc3RncmVTUUwgYWNjZXNzIGZyb20gTUNQIFNlcnZlcidcbiAgICApO1xuXG4gICAgLy8gQWxsb3cgUG9zdGdyZVNRTCBhY2Nlc3MgZnJvbSBkYXRhYmFzZSBhY2Nlc3MgaW5zdGFuY2VcbiAgICB0aGlzLmRiU2VjdXJpdHlHcm91cC5hZGRJbmdyZXNzUnVsZShcbiAgICAgIGRiQWNjZXNzU2VjdXJpdHlHcm91cCxcbiAgICAgIGVjMi5Qb3J0LnRjcCg1NDMyKSxcbiAgICAgICdBbGxvdyBQb3N0Z3JlU1FMIGFjY2VzcyBmcm9tIGRhdGFiYXNlIGFjY2VzcyBpbnN0YW5jZSdcbiAgICApO1xuXG4gICAgLy8gQ3JlYXRlIFJEUyBpbnN0YW5jZSBpbiBwcml2YXRlIHN1Ym5ldFxuICAgIHRoaXMuZGF0YWJhc2UgPSBuZXcgcmRzLkRhdGFiYXNlSW5zdGFuY2UodGhpcywgJ0NhbXBhaWduRGF0YWJhc2UnLCB7XG4gICAgICBlbmdpbmU6IHJkcy5EYXRhYmFzZUluc3RhbmNlRW5naW5lLnBvc3RncmVzKHtcbiAgICAgICAgdmVyc2lvbjogcmRzLlBvc3RncmVzRW5naW5lVmVyc2lvbi5WRVJfMTUsXG4gICAgICB9KSxcbiAgICAgIGluc3RhbmNlVHlwZTogZWMyLkluc3RhbmNlVHlwZS5vZihcbiAgICAgICAgZWMyLkluc3RhbmNlQ2xhc3MuVDMsXG4gICAgICAgIGVjMi5JbnN0YW5jZVNpemUuTUlDUk9cbiAgICAgICksXG4gICAgICB2cGM6IHRoaXMudnBjLFxuICAgICAgdnBjU3VibmV0czoge1xuICAgICAgICBzdWJuZXRUeXBlOiBlYzIuU3VibmV0VHlwZS5QUklWQVRFX0lTT0xBVEVELFxuICAgICAgfSxcbiAgICAgIHNlY3VyaXR5R3JvdXBzOiBbdGhpcy5kYlNlY3VyaXR5R3JvdXBdLFxuICAgICAgZGF0YWJhc2VOYW1lOiAnY2FtcGFpZ25kYicsXG4gICAgICBhbGxvY2F0ZWRTdG9yYWdlOiAyMCxcbiAgICAgIHN0b3JhZ2VUeXBlOiByZHMuU3RvcmFnZVR5cGUuR1AzLFxuICAgICAgY3JlZGVudGlhbHM6IHJkcy5DcmVkZW50aWFscy5mcm9tR2VuZXJhdGVkU2VjcmV0KCdkYmFkbWluJyksXG4gICAgICBiYWNrdXBSZXRlbnRpb246IGNkay5EdXJhdGlvbi5kYXlzKDcpLFxuICAgICAgZGVsZXRlQXV0b21hdGVkQmFja3VwczogdHJ1ZSxcbiAgICAgIHJlbW92YWxQb2xpY3k6IGNkay5SZW1vdmFsUG9saWN5LlNOQVBTSE9ULFxuICAgICAgZGVsZXRpb25Qcm90ZWN0aW9uOiBmYWxzZSxcbiAgICAgIHB1YmxpY2x5QWNjZXNzaWJsZTogZmFsc2UsICAvLyBQcml2YXRlIGRhdGFiYXNlXG4gICAgICBzdG9yYWdlRW5jcnlwdGVkOiB0cnVlLFxuICAgICAgcHJlZmVycmVkQmFja3VwV2luZG93OiAnMDM6MDAtMDQ6MDAnLFxuICAgICAgcHJlZmVycmVkTWFpbnRlbmFuY2VXaW5kb3c6ICdzdW46MDQ6MDAtc3VuOjA1OjAwJyxcbiAgICAgIGVuYWJsZVBlcmZvcm1hbmNlSW5zaWdodHM6IHRydWUsXG4gICAgICBwZXJmb3JtYW5jZUluc2lnaHRSZXRlbnRpb246IHJkcy5QZXJmb3JtYW5jZUluc2lnaHRSZXRlbnRpb24uREVGQVVMVCxcbiAgICAgIG1vbml0b3JpbmdJbnRlcnZhbDogY2RrLkR1cmF0aW9uLnNlY29uZHMoNjApLFxuICAgICAgY2xvdWR3YXRjaExvZ3NFeHBvcnRzOiBbJ3Bvc3RncmVzcWwnLCAndXBncmFkZSddLFxuICAgICAgYXV0b01pbm9yVmVyc2lvblVwZ3JhZGU6IGZhbHNlLFxuICAgIH0pO1xuXG4gICAgLy8gU3RvcmUgb25seSBlc3NlbnRpYWwgb3V0cHV0cyBpbiBQYXJhbWV0ZXIgU3RvcmVcbiAgICAvLyBOb3RlOiBVc2UgRm4uam9pbiBmb3Igc3VibmV0IElEcyB0byBlbnN1cmUgcHJvcGVyIENsb3VkRm9ybWF0aW9uIHJlc29sdXRpb25cbiAgICBuZXcgc3NtLlN0cmluZ1BhcmFtZXRlcih0aGlzLCAnUHJpdmF0ZVN1Ym5ldElkc1BhcmFtJywge1xuICAgICAgcGFyYW1ldGVyTmFtZTogJy9jYW1wYWlnbi9wcml2YXRlLXN1Ym5ldC1pZHMnLFxuICAgICAgc3RyaW5nVmFsdWU6IGNkay5Gbi5qb2luKCcsJywgdGhpcy52cGMuc2VsZWN0U3VibmV0cyh7XG4gICAgICAgIHN1Ym5ldFR5cGU6IGVjMi5TdWJuZXRUeXBlLlBSSVZBVEVfSVNPTEFURURcbiAgICAgIH0pLnN1Ym5ldElkcyksXG4gICAgfSk7XG5cbiAgICBuZXcgc3NtLlN0cmluZ1BhcmFtZXRlcih0aGlzLCAnTUNQU2VydmVyU2VjdXJpdHlHcm91cElkUGFyYW0nLCB7XG4gICAgICBwYXJhbWV0ZXJOYW1lOiAnL2NhbXBhaWduL21jcC1zZy1pZCcsXG4gICAgICBzdHJpbmdWYWx1ZTogdGhpcy5tY3BTZXJ2ZXJTZWN1cml0eUdyb3VwLnNlY3VyaXR5R3JvdXBJZCxcbiAgICB9KTtcblxuICAgIG5ldyBzc20uU3RyaW5nUGFyYW1ldGVyKHRoaXMsICdEQkVuZHBvaW50UGFyYW0nLCB7XG4gICAgICBwYXJhbWV0ZXJOYW1lOiAnL2NhbXBhaWduL2RiLWVuZHBvaW50JyxcbiAgICAgIHN0cmluZ1ZhbHVlOiB0aGlzLmRhdGFiYXNlLmRiSW5zdGFuY2VFbmRwb2ludEFkZHJlc3MsXG4gICAgfSk7XG5cbiAgICBuZXcgc3NtLlN0cmluZ1BhcmFtZXRlcih0aGlzLCAnREJTZWNyZXRBcm5QYXJhbScsIHtcbiAgICAgIHBhcmFtZXRlck5hbWU6ICcvY2FtcGFpZ24vZGItc2VjcmV0LWFybicsXG4gICAgICBzdHJpbmdWYWx1ZTogdGhpcy5kYXRhYmFzZS5zZWNyZXQ/LnNlY3JldEFybiB8fCAnTi9BJyxcbiAgICB9KTtcblxuICAgIG5ldyBzc20uU3RyaW5nUGFyYW1ldGVyKHRoaXMsICdEYkFjY2Vzc0luc3RhbmNlSWRQYXJhbScsIHtcbiAgICAgIHBhcmFtZXRlck5hbWU6ICcvY2FtcGFpZ24vZGItYWNjZXNzLWluc3RhbmNlLWlkJyxcbiAgICAgIHN0cmluZ1ZhbHVlOiBkYkFjY2Vzc0luc3RhbmNlLmluc3RhbmNlSWQsXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==