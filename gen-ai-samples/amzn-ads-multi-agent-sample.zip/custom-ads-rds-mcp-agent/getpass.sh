#!/bin/bash

# Get the secret ARN from Parameter Store
SECRET_ARN=$(aws ssm get-parameter --name /campaign/db-secret-arn --query 'Parameter.Value' --output text)

echo "Secret ARN: $SECRET_ARN"
echo ""

# Get the secret value from Secrets Manager
echo "Database Credentials:"
aws secretsmanager get-secret-value --secret-id "$SECRET_ARN" --query 'SecretString' --output text | jq '.'