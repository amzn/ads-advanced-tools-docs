#!/usr/bin/env python3
"""Test deployed LangGraph Agent"""

import boto3
import json
import uuid
from botocore.config import Config

# Agent ARN from deployment
boto_config = Config(
    connect_timeout=5,
    read_timeout=10,
    retries={'max_attempts': 1}
)
ssm_client = boto3.client('ssm', region_name='us-east-1', config=boto_config)
AGENT_ARN = ssm_client.get_parameter(Name='/campaign/agent-runtime-arn')['Parameter']['Value']

def test_agent(prompt: str):
    """Call the deployed agent"""
    client = boto3.client('bedrock-agentcore', region_name='us-east-1')
    
    # Generate unique session ID (must be 33+ chars)
    session_id = f"test-session-{uuid.uuid4()}"
    
    payload = json.dumps({"prompt": prompt})
    
    print(f"Calling agent with prompt: {prompt}")
    print(f"Session ID: {session_id}\n")
    
    response = client.invoke_agent_runtime(
        agentRuntimeArn=AGENT_ARN,
        runtimeSessionId=session_id,
        payload=payload
    )
    
    response_body = response['response'].read()
    response_data = json.loads(response_body)
    
    print("Agent Response:")
    print(json.dumps(response_data, indent=2))
    return response_data


if __name__ == "__main__":
    
    print("Test : Query specific campaign")
    print("="*60)
    test_agent("Show me details of campaign with ID 1")
