#!/usr/bin/env python3
"""Test raw MCP tool call to see full response"""
import boto3
import requests
import json

ssm = boto3.client('ssm', region_name='us-east-1')
params = ssm.get_parameters(Names=['/campaign/gateway-url', '/campaign/gateway-client-id', '/campaign/gateway-user-pool-id'])
param_dict = {p['Name']: p['Value'] for p in params['Parameters']}

gateway_url = param_dict['/campaign/gateway-url']
client_id = param_dict['/campaign/gateway-client-id']
pool_id = param_dict['/campaign/gateway-user-pool-id']
client_secret = ssm.get_parameter(Name='/campaign/gateway-client-secret', WithDecryption=True)['Parameter']['Value']

domain = pool_id.replace('_', '').lower()
token_url = f"https://{domain}.auth.us-east-1.amazoncognito.com/oauth2/token"
token_resp = requests.post(token_url, auth=(client_id, client_secret),
    headers={'Content-Type': 'application/x-www-form-urlencoded'},
    data={'grant_type': 'client_credentials', 'scope': 'campaign-gateway/invoke'}, timeout=10)
token = token_resp.json()['access_token']

# Query all campaigns
payload = {
    "jsonrpc": "2.0", "id": 1, "method": "tools/call",
    "params": {"name": "campaign-mcp-server-target___execute_query", "arguments": {"query": "SELECT * FROM campaign"}}
}
resp = requests.post(gateway_url, headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"}, json=payload, timeout=30)
result = resp.json()

print("=== Raw MCP Response ===")
print(json.dumps(result, indent=2))

# Check content items
tool_result = result.get('result', {})
content = tool_result.get('content', [])
print(f"\n=== Content items: {len(content)} ===")
for i, item in enumerate(content):
    print(f"\nItem {i}: type={item.get('type')}")
    text = item.get('text', '')
    print(f"  Length: {len(text)} chars")
    print(f"  Preview: {text[:500]}")
