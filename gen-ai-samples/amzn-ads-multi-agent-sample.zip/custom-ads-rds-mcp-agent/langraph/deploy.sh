#!/bin/bash
set -e

echo "Deploying agent with A2A protocol..."

agentcore configure \
    --entrypoint agent.py \
    --requirements-file requirements.txt \
    --name campaign_agent_v2 \
    --region us-east-1 \
    --protocol A2A \
    --deployment-type container \
    --disable-memory \
    --non-interactive

agentcore deploy

sleep 5

RUNTIME_INFO=$(agentcore status --verbose 2>/dev/null)
RUNTIME_ARN=$(echo "$RUNTIME_INFO" | tr -d '\n' | grep -o '"agent_arn": "[^"]*"' | cut -d'"' -f4)
aws ssm put-parameter --name /campaign/agent-runtime-arn --value "$RUNTIME_ARN" --type String --overwrite
echo "✅ Runtime ARN saved: $RUNTIME_ARN"

echo "=== Step 7: Add IAM Permissions ==="
RUNTIME_INFO=$(agentcore status --verbose 2>/dev/null)
ROLE_ARN=$(echo "$RUNTIME_INFO" | tr -d '\n' | grep -o '"execution_role": "[^"]*"' | cut -d'"' -f4)
ROLE_NAME=$(echo "$ROLE_ARN" | awk -F'/' '{print $NF}')
echo "Role Name: $ROLE_NAME"

# Create inline policy for ECR access (required for container deployment)
cat > /tmp/agent-ecr-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage"
      ],
      "Resource": "*"
    }
  ]
}
EOF

aws iam put-role-policy \
    --role-name $ROLE_NAME \
    --policy-name AgentECRAccess \
    --policy-document file:///tmp/agent-ecr-policy.json

echo "✅ ECR permissions added!"

# Create inline policy for SSM and Secrets Manager access
cat > /tmp/agent-ssm-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ssm:GetParameter",
        "ssm:GetParameters"
      ],
      "Resource": "arn:aws:ssm:us-east-1:*:parameter/campaign/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue"
      ],
      "Resource": "arn:aws:secretsmanager:us-east-1:*:secret:*"
    }
  ]
}
EOF

aws iam put-role-policy \
    --role-name $ROLE_NAME \
    --policy-name AgentServerSSMAccess \
    --policy-document file:///tmp/agent-ssm-policy.json

echo "✅ IAM permissions added!"

echo "✓ Deployment complete!"
