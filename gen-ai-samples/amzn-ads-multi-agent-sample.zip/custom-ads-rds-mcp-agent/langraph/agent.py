#!/usr/bin/env python3
"""
LangGraph Agent calling MCP Server via AgentCore Gateway
"""

import boto3
import requests
import logging
from typing import Dict, Any, Optional
from fastapi import FastAPI, Request as FastAPIRequest
import uvicorn
from langchain_aws import ChatBedrock
from langgraph.prebuilt import create_react_agent
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage
from pydantic import Field, create_model
import json
import os

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = FastAPI()

# Global agent (lazy init)
_agent = None
_mcp_client = None
_tools = None

# Agent configuration
AGENT_NAME = "RDS Campaign Agent"
AGENT_DESCRIPTION = "Database operations for campaign data - list tables, execute queries, describe schema"
AGENTCORE_RUNTIME_URL = os.environ.get('AGENTCORE_RUNTIME_URL', 'http://127.0.0.1:9000/')


class MCPGatewayClient:
    """MCP Gateway client"""
    
    def __init__(self):
        self.gateway_url = None
        self.token = None
        self._initialized = False
    
    def _ensure_initialized(self):
        if self._initialized:
            return
        
        logger.info("Initializing MCP Gateway client...")
        
        try:
            ssm = boto3.client('ssm', region_name='us-east-1')
            
            logger.info("Fetching SSM parameters...")
            params = ssm.get_parameters(
                Names=[
                    '/campaign/gateway-url',
                    '/campaign/gateway-client-id',
                    '/campaign/gateway-user-pool-id'
                ]
            )
            param_dict = {p['Name']: p['Value'] for p in params['Parameters']}
            
            self.gateway_url = param_dict['/campaign/gateway-url']
            client_id = param_dict['/campaign/gateway-client-id']
            gateway_pool_id = param_dict['/campaign/gateway-user-pool-id']
            
            logger.info(f"Gateway URL: {self.gateway_url}")
            logger.info(f"User Pool ID: {gateway_pool_id}")
            
            client_secret = ssm.get_parameter(
                Name='/campaign/gateway-client-secret',
                WithDecryption=True
            )['Parameter']['Value']
            
            # Get OAuth token
            domain = gateway_pool_id.replace('_', '').lower()
            token_url = f"https://{domain}.auth.us-east-1.amazoncognito.com/oauth2/token"
            
            logger.info(f"Getting OAuth token from: {token_url}")
            response = requests.post(
                token_url,
                auth=(client_id, client_secret),
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                data={'grant_type': 'client_credentials', 'scope': 'campaign-gateway/invoke'},
                timeout=10
            )
            
            if response.status_code != 200:
                logger.error(f"Failed to get OAuth token: {response.status_code} - {response.text}")
                raise Exception(f"Failed to get token: {response.text}")
            
            self.token = response.json()['access_token']
            logger.info("Successfully obtained OAuth token")
            self._initialized = True
            
        except Exception as e:
            logger.error(f"Failed to initialize MCP Gateway client: {e}", exc_info=True)
            raise
    
    def list_tools(self):
        self._ensure_initialized()
        logger.info(f"Listing tools from MCP Gateway: {self.gateway_url}")
        
        try:
            # MCP uses JSON-RPC 2.0 format
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/list",
                "params": {}
            }
            
            response = requests.post(
                self.gateway_url,
                headers={"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"},
                json=payload,
                timeout=10
            )
            
            logger.info(f"MCP Gateway list_tools response status: {response.status_code}")
            
            if response.status_code != 200:
                logger.error(f"Failed to list tools: {response.status_code} - {response.text}")
                raise Exception(f"Failed to list tools: {response.text}")
            
            result = response.json()
            
            # Check for JSON-RPC error
            if 'error' in result:
                logger.error(f"MCP Gateway returned error: {result['error']}")
                raise Exception(f"MCP Gateway error: {result['error']}")
            
            # Extract tools from JSON-RPC result
            tools = result.get('result', {}).get('tools', [])
            logger.info(f"MCP Gateway returned {len(tools)} tools: {[t.get('name') for t in tools]}")
            return tools
            
        except Exception as e:
            logger.error(f"Error listing tools from MCP Gateway: {e}", exc_info=True)
            raise
    
    def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> str:
        self._ensure_initialized()
        
        try:
            # MCP uses JSON-RPC 2.0 format
            payload = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": tool_name,
                    "arguments": arguments
                }
            }
            
            response = requests.post(
                self.gateway_url,
                headers={"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"},
                json=payload,
                timeout=60
            )
            
            if response.status_code != 200:
                logger.error(f"Failed to call tool: {response.status_code} - {response.text}")
                raise Exception(f"Failed to call tool: {response.text}")
            
            result = response.json()
            
            # Check for JSON-RPC error
            if 'error' in result:
                logger.error(f"MCP Gateway returned error: {result['error']}")
                raise Exception(f"MCP Gateway error: {result['error']}")
            
            # Extract result from JSON-RPC response
            tool_result = result.get('result', {})
            
            # Handle different response formats
            # Collect ALL text content items (MCP returns one per row)
            if 'content' in tool_result and isinstance(tool_result['content'], list):
                text_parts = []
                for item in tool_result['content']:
                    if item.get('type') == 'text':
                        text_parts.append(item.get('text', ''))
                if text_parts:
                    return "\n".join(text_parts)
            
            return str(tool_result)
            
        except Exception as e:
            logger.error(f"Error calling tool {tool_name}: {e}", exc_info=True)
            raise


def create_tools(mcp_client: MCPGatewayClient):
    """Create LangChain tools from MCP tools"""
    try:
        logger.info("Fetching tools from MCP Gateway...")
        mcp_tools = mcp_client.list_tools()
        logger.info(f"MCP Gateway returned {len(mcp_tools)} tools")
        
        if not mcp_tools:
            logger.error("MCP Gateway returned empty tool list!")
            return []
        
        langchain_tools = []
        
        for mcp_tool in mcp_tools:
            tool_name = mcp_tool['name']
            tool_desc = mcp_tool.get('description', f'MCP tool: {tool_name}')
            input_schema = mcp_tool.get('inputSchema', {})
            
            # Skip the special search tool
            if tool_name == 'x_amz_bedrock_agentcore_search':
                logger.info(f"Skipping special tool: {tool_name}")
                continue
            
            logger.info(f"Creating tool: {tool_name}")
            logger.info(f"  Input schema: {input_schema}")
            
            def make_tool(name, desc, schema):
                # Create a dynamic tool based on the input schema
                required_params = schema.get('required', [])
                properties = schema.get('properties', {})
                
                # Build parameter description
                param_desc = []
                for param_name, param_info in properties.items():
                    param_type = param_info.get('type', 'string')
                    param_description = param_info.get('description', '')
                    required = ' (required)' if param_name in required_params else ' (optional)'
                    param_desc.append(f"{param_name} ({param_type}){required}: {param_description}")
                
                full_desc = f"{desc}\n\nParameters:\n" + "\n".join(param_desc) if param_desc else desc
                
                # Create Pydantic model for the tool's input schema
                from pydantic import Field, create_model
                from typing import Optional
                
                # Build fields for Pydantic model
                fields = {}
                for param_name, param_info in properties.items():
                    param_type_str = param_info.get('type', 'string')
                    param_description = param_info.get('description', '')
                    is_required = param_name in required_params
                    
                    # Map JSON schema types to Python types
                    if param_type_str == 'string':
                        python_type = str
                    elif param_type_str == 'integer':
                        python_type = int
                    elif param_type_str == 'number':
                        python_type = float
                    elif param_type_str == 'boolean':
                        python_type = bool
                    else:
                        python_type = str
                    
                    # Make optional if not required
                    if not is_required:
                        python_type = Optional[python_type]
                        fields[param_name] = (python_type, Field(default=None, description=param_description))
                    else:
                        fields[param_name] = (python_type, Field(description=param_description))
                
                # Create Pydantic model if there are fields
                if fields:
                    args_schema = create_model(f"{name}_args", **fields)
                else:
                    args_schema = None
                
                @tool(description=full_desc, args_schema=args_schema)
                def mcp_tool_wrapper(**kwargs) -> str:
                    """Dynamic MCP tool wrapper that accepts keyword arguments"""
                    try:
                        logger.info(f"Calling MCP tool: {name} with args: {kwargs}")
                        result = mcp_client.call_tool(name, kwargs)
                        logger.info(f"MCP tool {name} returned: {str(result)[:100]}...")
                        return result
                    except Exception as e:
                        logger.error(f"Error calling MCP tool {name}: {e}")
                        return f"Error: {str(e)}"
                
                # Set the name after creation
                mcp_tool_wrapper.name = name
                return mcp_tool_wrapper
            
            langchain_tools.append(make_tool(tool_name, tool_desc, input_schema))
        
        logger.info(f"Successfully created {len(langchain_tools)} LangChain tools")
        return langchain_tools
        
    except Exception as e:
        logger.error(f"Failed to create tools from MCP Gateway: {e}", exc_info=True)
        return []


def _initialize_agent():
    """Lazy initialization"""
    global _agent, _mcp_client, _tools
    
    if _agent is not None:
        return _agent
    
    logger.info("Initializing agent...")
    
    try:
        _mcp_client = MCPGatewayClient()
        logger.info("MCP Gateway client created")
        
        _tools = create_tools(_mcp_client)
        logger.info(f"Created {len(_tools)} tools from MCP Gateway")
        
        if len(_tools) == 0:
            logger.warning("WARNING: No tools were loaded from MCP Gateway!")
            logger.warning("Agent will not have access to campaign database functions")
        else:
            logger.info(f"Available tools: {[t.name for t in _tools]}")
        
        llm = ChatBedrock(
            model_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0",  # US inference profile
            region_name="us-east-1",
            model_kwargs={"temperature": 0.1}
        )
        
        system_prompt = """You are a helpful AI assistant with access to a campaign database via SQL tools.

IMPORTANT GUIDELINES:
- When asked to list or show campaigns, always use SELECT * FROM campaign (no LIMIT unless the user asks for a specific number).
- The database may return multiple rows. Always present ALL results to the user.
- Use the describe_table tool first if you're unsure about column names.
- Use the list_tables tool to discover available tables.
- Write clean SQL queries. The execute_query tool only supports read-only (SELECT) queries.
- Present results in a clear, formatted way."""
        _agent = create_react_agent(llm, _tools, prompt=system_prompt)
        
        logger.info("Agent ready")
        return _agent
        
    except Exception as e:
        logger.error(f"Failed to initialize agent: {e}", exc_info=True)
        raise


def extract_message_text(body: dict) -> str:
    """Extract text from request"""
    if "prompt" in body:
        return body["prompt"]
    message = body.get("params", {}).get("message", {})
    for part in message.get("parts", []):
        if "text" in part:
            return part["text"]
    return message.get("text", "")


def format_a2a_response(text: str, request_id) -> dict:
    """Format response as A2A JSON-RPC"""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "status": {
                "message": {
                    "role": "assistant",
                    "parts": [{"kind": "text", "text": text}]
                }
            }
        }
    }


def create_agent_card_skill(tool) -> dict:
    """Create agent card skill from tool"""
    return {
        "id": tool.name,
        "name": tool.name.replace('_', ' ').title(),
        "description": tool.description,
        "tags": ["database", "campaign", "sql"],
        "examples": [f"Use {tool.name}"],
        "inputModes": ["text/plain"],
        "outputModes": ["text/plain"]
    }


@app.get("/.well-known/agent-card.json")
def agent_card():
    """Agent card endpoint for A2A discovery"""
    # Initialize agent to get tools (lazy) - this will populate _tools
    try:
        _initialize_agent()
    except Exception as e:
        logger.error(f"Failed to initialize agent for agent card: {e}")
        # Return card with no skills if initialization fails
        return {
            "protocolVersions": ["0.3"],
            "name": AGENT_NAME,
            "description": f"{AGENT_DESCRIPTION} (initialization pending)",
            "supportedInterfaces": [{"url": AGENTCORE_RUNTIME_URL, "protocolBinding": "JSONRPC"}],
            "version": "1.0.0",
            "capabilities": {"streaming": False, "pushNotifications": False},
            "defaultInputModes": ["text/plain"],
            "defaultOutputModes": ["text/plain"],
            "skills": []
        }
    
    return {
        "protocolVersions": ["0.3"],
        "name": AGENT_NAME,
        "description": f"{AGENT_DESCRIPTION} with {len(_tools) if _tools else 0} tools",
        "supportedInterfaces": [{"url": AGENTCORE_RUNTIME_URL, "protocolBinding": "JSONRPC"}],
        "version": "1.0.0",
        "capabilities": {"streaming": False, "pushNotifications": False},
        "defaultInputModes": ["text/plain"],
        "defaultOutputModes": ["text/plain"],
        "skills": [create_agent_card_skill(tool) for tool in (_tools or [])]
    }


@app.get("/")
async def root():
    """Health check endpoint"""
    return {"status": "ok"}


@app.get("/ping")
async def ping():
    """Ping endpoint for AgentCore health checks"""
    return {"status": "ok"}


@app.post("/")
async def invoke_endpoint(request: FastAPIRequest):
    """Main endpoint"""
    try:
        body = await request.json()
        text = extract_message_text(body)
        
        logger.info(f"Request: {text[:100]}...")
        
        agent = _initialize_agent()
        result = await agent.ainvoke({"messages": [HumanMessage(content=text)]})
        response_text = result["messages"][-1].content if result.get("messages") else "No response"
        
        logger.info(f"Response: {response_text[:100]}...")
        
        # Return appropriate format
        if "method" not in body:
            return {"response": response_text}  # Simple format
        else:
            return format_a2a_response(response_text, body.get("id"))  # A2A format
        
    except Exception as e:
        logger.error(f"Error: {e}")
        return {"error": str(e)}


if __name__ == "__main__":
    logger.info("Starting Campaign Agent on port 9000...")
    # Pre-initialize agent on startup to populate tools for agent card
    try:
        logger.info("Pre-initializing agent...")
        _initialize_agent()
        logger.info(f"Agent pre-initialized with {len(_tools) if _tools else 0} tools")
    except Exception as e:
        logger.error(f"Failed to pre-initialize agent: {e}")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=9000,
        log_level="info"
    )
