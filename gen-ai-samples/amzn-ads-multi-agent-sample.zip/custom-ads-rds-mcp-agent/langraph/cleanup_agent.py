#!/usr/bin/env python3
"""
Cleanup LangGraph Agent Runtime from AgentCore
"""

import boto3
import sys

def cleanup_agent():
    """Remove AgentCore Runtime"""
    
    agent_name = "campaign_agent"
    region = "us-east-1"
    
    print(f"Cleaning up agent: {agent_name}")
    
    client = boto3.client('bedrock-agentcore', region_name=region)
    
    # Step 1: Get agent ARN from config
    try:
        print("\n1. Reading agent configuration...")
        import yaml
        with open('.bedrock_agentcore.yaml', 'r') as f:
            config = yaml.safe_load(f)
        
        agent_config = config['agents'].get(agent_name)
        if not agent_config:
            print(f"❌ Agent {agent_name} not found in config")
            return
        
        agent_arn = agent_config['bedrock_agentcore']['agent_arn']
        print(f"✓ Found agent ARN: {agent_arn}")
        
    except Exception as e:
        print(f"❌ Failed to read config: {e}")
        return
    
    # Step 2: Delete Runtime
    try:
        print("\n2. Deleting AgentCore Runtime...")
        client.delete_agent_runtime(agentRuntimeArn=agent_arn)
        print("✓ Runtime deleted")
        
    except client.exceptions.ResourceNotFoundException:
        print("⚠️  Runtime not found (may already be deleted)")
    except Exception as e:
        print(f"❌ Failed to delete runtime: {e}")
        return
    
    # Step 3: Remove from config file
    try:
        print("\n3. Updating configuration file...")
        del config['agents'][agent_name]
        
        if config.get('default_agent') == agent_name:
            config['default_agent'] = None
        
        with open('.bedrock_agentcore.yaml', 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        
        print("✓ Configuration updated")
        
    except Exception as e:
        print(f"⚠️  Failed to update config: {e}")
    
    print("\n✅ Cleanup complete!")


if __name__ == "__main__":
    cleanup_agent()

