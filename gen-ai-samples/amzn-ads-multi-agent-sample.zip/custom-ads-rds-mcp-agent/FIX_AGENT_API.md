# Fix: RDS Agent Showing 0 Skills

## Problem
The RDS Campaign Agent was showing 0 skills in its agent card, even though the MCP Gateway was configured correctly and the MCP server was deployed.

## Root Cause
The RDS agent was using the **wrong LangGraph API**:
- **Incorrect**: `from langgraph.prebuilt import create_react_agent`
- **Correct**: `from langchain.agents import create_agent`

The working agents (custom-ads-a2a-agent and mcp-ads-a2a-agent) all use `create_agent` from `langchain.agents`, not `create_react_agent` from `langgraph.prebuilt`.

## Changes Made

### 1. Updated Import Statement
**File**: `custom-ads-rds-mcp-agent/langraph/agent.py`

```python
# BEFORE
from langgraph.prebuilt import create_react_agent

# AFTER
from langchain.agents import create_agent
```

### 2. Updated Agent Creation
**File**: `custom-ads-rds-mcp-agent/langraph/agent.py`

```python
# BEFORE
system_prompt = """You are a helpful AI assistant with access to campaign database tools."""
_agent = create_react_agent(llm, _tools, prompt=system_prompt)

# AFTER
system_prompt = """You are a helpful AI assistant with access to campaign database tools."""

# Bind system message to LLM
llm_with_system = llm.bind(system=[{"type": "text", "text": system_prompt}])

# Create agent with recursion_limit
_agent = create_agent(llm_with_system, _tools).with_config(recursion_limit=15)
```

## Why This Matters

The `create_agent` API from `langchain.agents`:
1. Properly integrates with the A2A protocol
2. Correctly exposes tools in the agent card
3. Follows the same pattern as all working agents
4. Uses the modern LangChain agent API with system message binding

The `create_react_agent` from `langgraph.prebuilt`:
1. Is an older/different API
2. May not properly expose tools for A2A discovery
3. Uses a different parameter structure (`prompt=` instead of binding)

## Next Steps

1. **Redeploy the RDS agent**:
   ```bash
   cd custom-ads-rds-mcp-agent/langraph
   ./deploy.sh
   ```

2. **Wait for deployment to complete** (check with `agentcore status --verbose`)

3. **Test the agent card**:
   ```bash
   python check_rds_skills.py
   ```

4. **Verify skills are now showing** (should see > 0 skills)

## Expected Result

After redeployment, the RDS agent should:
- Show the correct number of skills (matching the number of MCP tools)
- Be discoverable by the orchestrator
- Properly expose all MCP Gateway tools in its agent card

## Related Files
- `custom-ads-rds-mcp-agent/langraph/agent.py` - Main agent implementation
- `custom-ads-rds-mcp-agent/langraph/deploy.sh` - Deployment script
- `check_rds_skills.py` - Helper script to verify skills
