#!/usr/bin/env python3
"""
Create AgentCore Gateway for MCP Server
Based on: https://github.com/awslabs/amazon-bedrock-agentcore-samples
"""

import boto3
import json
import time

REGION = boto3.Session().region_name
ssm = boto3.client('ssm', region_name=REGION)
gateway_client = boto3.client('bedrock-agentcore-control', region_name=REGION)

print("=== Step 1: Get MCP Runtime Configuration ===")
runtime_user_pool_id = ssm.get_parameter(Name='/campaign/mcp-runtime-user-pool-id')['Parameter']['Value']
runtime_client_id = ssm.get_parameter(Name='/campaign/mcp-runtime-client-id')['Parameter']['Value']
runtime_discovery_url = ssm.get_parameter(Name='/campaign/mcp-runtime-discovery-url')['Parameter']['Value']

print(f"Runtime User Pool ID: {runtime_user_pool_id}")
print(f"Runtime Client ID: {runtime_client_id}")

print("\n=== Step 2: Create Gateway Cognito Pool ===") # gateway pool is to protect gateway and will be used when agent is calling agentcore gateway
# Reuse the same utility functions
def get_or_create_user_pool(cognito, USER_POOL_NAME):
    response = cognito.list_user_pools(MaxResults=60)
    for pool in response["UserPools"]:
        if pool["Name"] == USER_POOL_NAME:
            return pool["Id"]
    
    created = cognito.create_user_pool(PoolName=USER_POOL_NAME)
    user_pool_id = created["UserPool"]["Id"]
    user_pool_id_without_underscore_lc = user_pool_id.replace("_", "").lower()
    cognito.create_user_pool_domain(
        Domain=user_pool_id_without_underscore_lc,
        UserPoolId=user_pool_id
    )
    return user_pool_id

def get_or_create_resource_server(cognito, user_pool_id, RESOURCE_SERVER_ID, RESOURCE_SERVER_NAME, SCOPES):
    try:
        cognito.describe_resource_server(UserPoolId=user_pool_id, Identifier=RESOURCE_SERVER_ID)
        return RESOURCE_SERVER_ID
    except cognito.exceptions.ResourceNotFoundException:
        cognito.create_resource_server(
            UserPoolId=user_pool_id,
            Identifier=RESOURCE_SERVER_ID,
            Name=RESOURCE_SERVER_NAME,
            Scopes=SCOPES
        )
        return RESOURCE_SERVER_ID

def get_or_create_m2m_client(cognito, user_pool_id, CLIENT_NAME, RESOURCE_SERVER_ID, SCOPES):
    response = cognito.list_user_pool_clients(UserPoolId=user_pool_id, MaxResults=60)
    for client in response["UserPoolClients"]:
        if client["ClientName"] == CLIENT_NAME:
            describe = cognito.describe_user_pool_client(UserPoolId=user_pool_id, ClientId=client["ClientId"])
            return client["ClientId"], describe["UserPoolClient"]["ClientSecret"]
    
    created = cognito.create_user_pool_client(
        UserPoolId=user_pool_id,
        ClientName=CLIENT_NAME,
        GenerateSecret=True,
        AllowedOAuthFlows=["client_credentials"],
        AllowedOAuthScopes=SCOPES,
        AllowedOAuthFlowsUserPoolClient=True,
        SupportedIdentityProviders=["COGNITO"],
        ExplicitAuthFlows=["ALLOW_REFRESH_TOKEN_AUTH"]
    )
    return created["UserPoolClient"]["ClientId"], created["UserPoolClient"]["ClientSecret"]

# Create Gateway Cognito pool
cognito = boto3.client("cognito-idp", region_name=REGION)
GW_USER_POOL_NAME = "campaign-gateway-pool"
GW_RESOURCE_SERVER_ID = "campaign-gateway"
GW_RESOURCE_SERVER_NAME = "Campaign Gateway"
GW_CLIENT_NAME = "campaign-gateway-client"
GW_SCOPES = [{"ScopeName": "invoke", "ScopeDescription": "Invoke gateway"}]

gw_scope_names = [f"{GW_RESOURCE_SERVER_ID}/{scope['ScopeName']}" for scope in GW_SCOPES]
gw_scope_string = " ".join(gw_scope_names)

gw_user_pool_id = get_or_create_user_pool(cognito, GW_USER_POOL_NAME)
print(f"Gateway User Pool ID: {gw_user_pool_id}")

get_or_create_resource_server(cognito, gw_user_pool_id, GW_RESOURCE_SERVER_ID, GW_RESOURCE_SERVER_NAME, GW_SCOPES)
gw_client_id, gw_client_secret = get_or_create_m2m_client(cognito, gw_user_pool_id, GW_CLIENT_NAME, GW_RESOURCE_SERVER_ID, gw_scope_names)

gw_cognito_discovery_url = f'https://cognito-idp.{REGION}.amazonaws.com/{gw_user_pool_id}/.well-known/openid-configuration'
print(f"Gateway Client ID: {gw_client_id}")
print(f"Gateway Discovery URL: {gw_cognito_discovery_url}")

print("\n=== Step 3: Create IAM Role for Gateway ===")
iam_client = boto3.client('iam')
account_id = boto3.client("sts").get_caller_identity()["Account"]
gateway_role_name = "campaign-gateway-role"

role_policy = {
    "Version": "2012-10-17",
    "Statement": [{
        "Effect": "Allow",
        "Action": [
            "bedrock-agentcore:*",
            "bedrock:*",
            "iam:PassRole",
            "secretsmanager:GetSecretValue",
            "lambda:InvokeFunction"
        ],
        "Resource": "*"
    }]
}

assume_role_policy = {
    "Version": "2012-10-17",
    "Statement": [{
        "Effect": "Allow",
        "Principal": {"Service": "bedrock-agentcore.amazonaws.com"},
        "Action": "sts:AssumeRole",
        "Condition": {
            "StringEquals": {"aws:SourceAccount": account_id},
            "ArnLike": {"aws:SourceArn": f"arn:aws:bedrock-agentcore:{REGION}:{account_id}:*"}
        }
    }]
}

try:
    role_response = iam_client.create_role(
        RoleName=gateway_role_name,
        AssumeRolePolicyDocument=json.dumps(assume_role_policy)
    )
    time.sleep(10)
    print(f"Created IAM role: {gateway_role_name}")
except iam_client.exceptions.EntityAlreadyExistsException:
    role_response = iam_client.get_role(RoleName=gateway_role_name)
    print(f"Using existing IAM role: {gateway_role_name}")

iam_client.put_role_policy(
    RoleName=gateway_role_name,
    PolicyName="GatewayPolicy",
    PolicyDocument=json.dumps(role_policy)
)

gateway_role_arn = role_response['Role']['Arn']
print(f"Gateway Role ARN: {gateway_role_arn}")

print("\n=== Step 4: Create Gateway ===")
auth_config = {
    "customJWTAuthorizer": {
        "allowedClients": [gw_client_id],
        "discoveryUrl": gw_cognito_discovery_url
    }
}

create_response = gateway_client.create_gateway(
    name='campaign-gateway',
    roleArn=gateway_role_arn,
    protocolType='MCP',
    protocolConfiguration={
        'mcp': {
            'supportedVersions': ['2025-03-26'],
            'searchType': 'SEMANTIC'
        }
    },
    authorizerType='CUSTOM_JWT',
    authorizerConfiguration=auth_config,
    description='Campaign MCP Gateway'
)

gateway_id = create_response["gatewayId"]
gateway_url = create_response["gatewayUrl"]

print(f"\n✅ Gateway created successfully!")
print(f"Gateway ID: {gateway_id}")
print(f"Gateway URL: {gateway_url}")

# Save to Parameter Store
print("\n=== Step 5: Save Gateway Configuration ===")
ssm.put_parameter(Name='/campaign/gateway-id', Value=gateway_id, Type='String', Overwrite=True)
ssm.put_parameter(Name='/campaign/gateway-url', Value=gateway_url, Type='String', Overwrite=True)
ssm.put_parameter(Name='/campaign/gateway-user-pool-id', Value=gw_user_pool_id, Type='String', Overwrite=True)
ssm.put_parameter(Name='/campaign/gateway-client-id', Value=gw_client_id, Type='String', Overwrite=True)
ssm.put_parameter(Name='/campaign/gateway-client-secret', Value=gw_client_secret, Type='SecureString', Overwrite=True)
ssm.put_parameter(Name='/campaign/gateway-scope', Value=gw_scope_string, Type='String', Overwrite=True)

print("✅ Configuration saved to Parameter Store")
