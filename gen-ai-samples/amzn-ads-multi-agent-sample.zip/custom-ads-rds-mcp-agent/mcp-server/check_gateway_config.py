#!/usr/bin/env python3
"""
Check Gateway Configuration - including VPC settings
"""

import boto3
import json

REGION = boto3.Session().region_name
ssm = boto3.client('ssm', region_name=REGION)
gateway_client = boto3.client('bedrock-agentcore-control', region_name=REGION)

print("=== Checking Gateway Configuration ===\n")

# Get gateway ID
gateway_id = ssm.get_parameter(Name='/campaign/gateway-id')['Parameter']['Value']
print(f"Gateway ID: {gateway_id}")

# Get gateway details
try:
    response = gateway_client.get_gateway(gatewayIdentifier=gateway_id)
    
    # Print raw response to see structure
    print(f"\nRaw API Response Keys: {list(response.keys())}")
    print(f"\nFull Response:")
    print(json.dumps(response, indent=2, default=str))
    
    # Extract gateway data - handle both nested and flat structures
    if 'gateway' in response:
        gateway = response['gateway']
    elif 'name' in response:
        # Response is flat, use it directly
        gateway = response
    else:
        print("\n❌ Unexpected response structure")
        print("Available keys:", list(response.keys()))
        exit(1)
    
    print(f"\n=== Gateway Details ===")
    print(f"Gateway Name: {gateway.get('name')}")
    print(f"Gateway ID: {gateway.get('gatewayId', gateway_id)}")
    print(f"Status: {gateway.get('status')}")
    print(f"Gateway URL: {gateway.get('gatewayUrl')}")
    print(f"Protocol: {gateway.get('protocolType')}")
    
    # Check VPC configuration
    vpc_config = gateway.get('vpcConfiguration')
    if vpc_config:
        print(f"\n✅ Gateway HAS VPC Configuration:")
        print(f"  Subnet IDs: {vpc_config.get('subnetIds')}")
        print(f"  Security Group IDs: {vpc_config.get('securityGroupIds')}")
    else:
        print(f"\n❌ Gateway does NOT have VPC Configuration")
        print(f"   This means the gateway cannot reach MCP servers in private VPCs")
    
except Exception as e:
    print(f"\n❌ Error getting gateway details: {e}")
    import traceback
    traceback.print_exc()
