#!/usr/bin/env python3
"""
Test MCP Runtime directly to see if it's responding with tools
"""

import boto3
import json
import requests
import base64

REGION = boto3.Session().region_name
ssm = boto3.client('ssm', region_name=REGION)
cognito = boto3.client('cognito-idp', region_name=REGION)

print("=== Step 1: Get Configuration ===")
runtime_arn = ssm.get_parameter(Name='/campaign/mcp-runtime-arn')['Parameter']['Value']
runtime_client_id = ssm.get_parameter(Name='/campaign/mcp-runtime-client-id')['Parameter']['Value']
runtime_client_secret = ssm.get_parameter(Name='/campaign/mcp-runtime-client-secret', WithDecryption=True)['Parameter']['Value']
runtime_user_pool_id = ssm.get_parameter(Name='/campaign/mcp-runtime-user-pool-id')['Parameter']['Value']

print(f"Runtime ARN: {runtime_arn}")
print(f"User Pool ID: {runtime_user_pool_id}")
print(f"Client ID: {runtime_client_id}")

# Build MCP server endpoint URL
encoded_arn = runtime_arn.replace(':', '%3A').replace('/', '%2F')
agent_url = f'https://bedrock-agentcore.{REGION}.amazonaws.com/runtimes/{encoded_arn}/invocations?qualifier=DEFAULT'

print(f"MCP Server URL: {agent_url}")

print("\n=== Step 2: Get OAuth Token ===")
# Get OAuth token
user_pool_id_without_underscore_lc = runtime_user_pool_id.replace("_", "").lower()
token_url = f'https://{user_pool_id_without_underscore_lc}.auth.{REGION}.amazoncognito.com/oauth2/token'

# Prepare credentials
credentials = f"{runtime_client_id}:{runtime_client_secret}"
encoded_credentials = base64.b64encode(credentials.encode()).decode()

token_response = requests.post(
    token_url,
    headers={
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Basic {encoded_credentials}'
    },
    data={
        'grant_type': 'client_credentials',
        'scope': 'campaign-mcp-runtime/invoke'
    }
)

if token_response.status_code != 200:
    print(f"❌ Failed to get token: {token_response.status_code}")
    print(token_response.text)
    exit(1)

access_token = token_response.json()['access_token']
print("✅ Got OAuth token")

print("\n=== Step 3: Call MCP Runtime - List Tools ===")
# Call the MCP runtime to list tools
mcp_request = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/list",
    "params": {}
}

response = requests.post(
    agent_url,
    headers={
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'Authorization': f'Bearer {access_token}'
    },
    json=mcp_request
)

print(f"Response Status: {response.status_code}")
print(f"Response Content-Type: {response.headers.get('Content-Type')}")
print(f"\nResponse Body (raw):")
print(response.text)

if response.status_code == 200:
    # Parse SSE (Server-Sent Events) format
    lines = response.text.strip().split('\n')
    for line in lines:
        if line.startswith('data: '):
            data = line[6:]  # Remove 'data: ' prefix
            try:
                result = json.loads(data)
                if 'result' in result and 'tools' in result['result']:
                    tools = result['result']['tools']
                    print(f"\n✅ MCP Runtime returned {len(tools)} tools:")
                    for tool in tools:
                        print(f"  - {tool['name']}: {tool.get('description', 'No description')}")
                else:
                    print(f"\nParsed data: {json.dumps(result, indent=2)}")
            except json.JSONDecodeError:
                print(f"Non-JSON data: {data}")
else:
    print(f"\n❌ Failed to call MCP runtime")
