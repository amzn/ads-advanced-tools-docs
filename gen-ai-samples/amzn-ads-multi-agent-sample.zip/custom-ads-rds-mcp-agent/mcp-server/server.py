#!/usr/bin/env python3
"""Amazon Ads Campaign MCP Server - PostgreSQL integration for campaign data analysis"""

from mcp.server.fastmcp import FastMCP
from typing import Annotated, List, Dict, Any
from pydantic import Field
import asyncpg
import boto3
import json
from botocore.exceptions import ClientError
from botocore.config import Config

# Initialize the FastMCP server with correct configuration for AgentCore Runtime
mcp = FastMCP(host="0.0.0.0", stateless_http=True)

# Configure boto3 with shorter timeouts and fewer retries
boto_config = Config(
    connect_timeout=5,
    read_timeout=10,
    retries={'max_attempts': 1}
)

# Initialize AWS clients
ssm_client = boto3.client('ssm', region_name='us-east-1', config=boto_config)
secrets_client = boto3.client('secretsmanager', region_name='us-east-1', config=boto_config)

def get_db_credentials():
    """
    Fetch database credentials from Parameter Store and Secrets Manager.
    Uses parameters created by the RDS stack.
    """
    try:
        # Get DB endpoint from Parameter Store
        db_endpoint = ssm_client.get_parameter(Name='/campaign/db-endpoint')['Parameter']['Value']
        
        # Get secret ARN from Parameter Store
        secret_arn = ssm_client.get_parameter(Name='/campaign/db-secret-arn')['Parameter']['Value']
        
        # Fetch secret from Secrets Manager
        secret_response = secrets_client.get_secret_value(SecretId=secret_arn)
        secret = json.loads(secret_response['SecretString'])
        
        # Build connection string with SSL
        connection_string = (
            f"postgresql://{secret['username']}:{secret['password']}"
            f"@{db_endpoint}:5432/campaigndb?sslmode=require"
        )
        return connection_string
        
    except ClientError as e:
        raise Exception(f"Failed to retrieve database credentials: {e}")
    except Exception as e:
        raise Exception(f"Error getting database credentials: {e}")


@mcp.tool()
async def list_tables() -> List[str]:
    """List all tables in the connected PostgreSQL database"""
    connection_string = get_db_credentials()
    conn = await asyncpg.connect(connection_string, timeout=30)  # Increase timeout to 30s
    try:
        query = """
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
        """
        rows = await conn.fetch(query)
        return [row['table_name'] for row in rows]
    finally:
        await conn.close()


@mcp.tool()
async def describe_table(
    table_name: Annotated[str, Field(description="Name of the table to describe")]
) -> List[Dict[str, Any]]:
    """Get column information for a specific table"""
    connection_string = get_db_credentials()
    conn = await asyncpg.connect(connection_string, timeout=30)
    try:
        query = """
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_schema = 'public' AND table_name = $1
            ORDER BY ordinal_position
        """
        rows = await conn.fetch(query, table_name)
        return [dict(row) for row in rows]
    finally:
        await conn.close()


@mcp.tool()
async def execute_query(
    query: Annotated[str, Field(description="SQL query to execute (read-only)")]
) -> List[Dict[str, Any]]:
    """Execute a read-only SQL query against the PostgreSQL database"""
    # Basic check to prevent write operations
    query_lower = query.lower().strip()
    if any(query_lower.startswith(op) for op in ['insert', 'update', 'delete', 'drop', 'alter', 'create']):
        raise ValueError("Only read-only queries are allowed")
    
    connection_string = get_db_credentials()
    conn = await asyncpg.connect(connection_string, timeout=30)
    try:
        rows = await conn.fetch(query)
        return [dict(row) for row in rows]
    finally:
        await conn.close()


# Run the server
if __name__ == "__main__":
    mcp.run(transport="streamable-http")
