#!/usr/bin/env python3
"""
Setup Cognito authentication for MCP Server Runtime
Based on: https://github.com/awslabs/amazon-bedrock-agentcore-samples
"""

import os
import sys
import boto3

# Add utils from tutorial (download separately or inline the functions)
# For now, inline the required functions

def get_or_create_user_pool(cognito, USER_POOL_NAME):
    response = cognito.list_user_pools(MaxResults=60)
    for pool in response["UserPools"]:
        if pool["Name"] == USER_POOL_NAME:
            return pool["Id"]
    
    print('Creating new user pool')
    created = cognito.create_user_pool(PoolName=USER_POOL_NAME)
    user_pool_id = created["UserPool"]["Id"]
    
    # Create domain for OAuth
    user_pool_id_without_underscore_lc = user_pool_id.replace("_", "").lower()
    cognito.create_user_pool_domain(
        Domain=user_pool_id_without_underscore_lc,
        UserPoolId=user_pool_id
    )
    print("Domain created as well")
    return created["UserPool"]["Id"]

def get_or_create_resource_server(cognito, user_pool_id, RESOURCE_SERVER_ID, RESOURCE_SERVER_NAME, SCOPES):
    try:
        cognito.describe_resource_server(
            UserPoolId=user_pool_id,
            Identifier=RESOURCE_SERVER_ID
        )
        return RESOURCE_SERVER_ID
    except cognito.exceptions.ResourceNotFoundException:
        print('Creating new resource server')
        cognito.create_resource_server(
            UserPoolId=user_pool_id,
            Identifier=RESOURCE_SERVER_ID,
            Name=RESOURCE_SERVER_NAME,
            Scopes=SCOPES
        )
        return RESOURCE_SERVER_ID

def get_or_create_m2m_client(cognito, user_pool_id, CLIENT_NAME, RESOURCE_SERVER_ID, SCOPES=None):
    response = cognito.list_user_pool_clients(UserPoolId=user_pool_id, MaxResults=60)
    for client in response["UserPoolClients"]:
        if client["ClientName"] == CLIENT_NAME:
            describe = cognito.describe_user_pool_client(
                UserPoolId=user_pool_id,
                ClientId=client["ClientId"]
            )
            return client["ClientId"], describe["UserPoolClient"]["ClientSecret"]
    
    print('Creating new m2m client')
    if SCOPES is None:
        SCOPES = [f"{RESOURCE_SERVER_ID}/invoke"]
    
    created = cognito.create_user_pool_client(
        UserPoolId=user_pool_id,
        ClientName=CLIENT_NAME,
        GenerateSecret=True,
        AllowedOAuthFlows=["client_credentials"],
        AllowedOAuthScopes=SCOPES,
        AllowedOAuthFlowsUserPoolClient=True,
        SupportedIdentityProviders=["COGNITO"],
        ExplicitAuthFlows=["ALLOW_REFRESH_TOKEN_AUTH"]
    )
    return created["UserPoolClient"]["ClientId"], created["UserPoolClient"]["ClientSecret"]

# Main setup: create runtime pool to protect MCP server, it will be used when gateway is calling mcp server
REGION = os.environ.get('AWS_DEFAULT_REGION', boto3.Session().region_name)
USER_POOL_NAME = "campaign-mcp-runtime-pool"
RESOURCE_SERVER_ID = "campaign-mcp-runtime"
RESOURCE_SERVER_NAME = "Campaign MCP Runtime"
CLIENT_NAME = "campaign-mcp-runtime-client"
SCOPES = [
    {
        "ScopeName": "invoke",
        "ScopeDescription": "Invoke MCP server"
    }
]

scope_names = [f"{RESOURCE_SERVER_ID}/{scope['ScopeName']}" for scope in SCOPES]
scope_string = " ".join(scope_names)

cognito = boto3.client("cognito-idp", region_name=REGION)
ssm = boto3.client("ssm", region_name=REGION)

print("=== Creating or retrieving Cognito resources ===")
runtime_user_pool_id = get_or_create_user_pool(cognito, USER_POOL_NAME)
print(f"User Pool ID: {runtime_user_pool_id}")

get_or_create_resource_server(cognito, runtime_user_pool_id, RESOURCE_SERVER_ID, RESOURCE_SERVER_NAME, SCOPES)
print("Resource server ensured.")

runtime_client_id, runtime_client_secret = get_or_create_m2m_client(
    cognito, runtime_user_pool_id, CLIENT_NAME, RESOURCE_SERVER_ID, scope_names
)

print(f"Client ID: {runtime_client_id}")

# Get discovery URL
runtime_cognito_discovery_url = f'https://cognito-idp.{REGION}.amazonaws.com/{runtime_user_pool_id}/.well-known/openid-configuration'
print(f"Discovery URL: {runtime_cognito_discovery_url}")
print(f"Scope: {scope_string}")

# Save to Parameter Store
print("\n=== Saving to Parameter Store ===")
ssm.put_parameter(Name="/campaign/mcp-runtime-user-pool-id", Value=runtime_user_pool_id, Type="String", Overwrite=True)
ssm.put_parameter(Name="/campaign/mcp-runtime-client-id", Value=runtime_client_id, Type="String", Overwrite=True)
ssm.put_parameter(Name="/campaign/mcp-runtime-client-secret", Value=runtime_client_secret, Type="SecureString", Overwrite=True)
ssm.put_parameter(Name="/campaign/mcp-runtime-discovery-url", Value=runtime_cognito_discovery_url, Type="String", Overwrite=True)
ssm.put_parameter(Name="/campaign/mcp-runtime-scope", Value=scope_string, Type="String", Overwrite=True)

print("✅ Cognito configuration saved to Parameter Store")
