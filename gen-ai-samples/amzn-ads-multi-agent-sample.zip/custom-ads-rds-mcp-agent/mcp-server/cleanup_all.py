#!/usr/bin/env python3
"""
Cleanup script to remove all Campaign MCP Server resources
Run this to start fresh
"""

import boto3
import sys
import time

def get_ssm_parameter(name):
    """Get parameter from SSM, return None if not found"""
    ssm = boto3.client('ssm', region_name='us-east-1')
    try:
        response = ssm.get_parameter(Name=name)
        return response['Parameter']['Value']
    except ssm.exceptions.ParameterNotFound:
        return None
    except Exception as e:
        print(f"Error getting parameter {name}: {e}")
        return None

def remove_gateway_target():
    """Step 1: Remove MCP Server target from Gateway"""
    print("\n" + "="*60)
    print("Step 1: Remove Gateway Target")
    print("="*60)
    
    gateway_id = get_ssm_parameter('/campaign/gateway-id')
    runtime_id = get_ssm_parameter('/campaign/mcp-runtime-id')
    
    if not gateway_id:
        print("⚠️  Gateway ID not found in SSM. Skipping.")
        return
    
    if not runtime_id:
        print("⚠️  Runtime ID not found in SSM. Skipping.")
        return
    
    print(f"Gateway ID: {gateway_id}")
    print(f"Runtime ID: {runtime_id}")
    
    client = boto3.client('bedrock-agentcore-control', region_name='us-east-1')
    
    try:
        # List targets to find the target ID
        response = client.list_gateway_targets(gatewayIdentifier=gateway_id)
        
        # The key is 'items'
        targets = response.get('items', [])
        
        print(f"Found {len(targets)} targets")
        
        target_id = None
        for target in targets:
            print(f"  - {target.get('name')} (ID: {target.get('targetId')})")
            target_id = target.get('targetId')
            break  # Remove the first target (should only be one)
        
        if not target_id:
            print("⚠️  No targets found in Gateway.")
            return
        
        print(f"\nRemoving target: {target_id}")
        
        client.delete_gateway_target(
            gatewayIdentifier=gateway_id,
            targetId=target_id
        )
        
        print("✅ Gateway target removed successfully!")
        
    except Exception as e:
        print(f"❌ Error removing Gateway target: {e}")

def remove_gateway():
    """Step 2: Remove AgentCore Gateway"""
    print("\n" + "="*60)
    print("Step 2: Remove Gateway")
    print("="*60)
    
    gateway_id = get_ssm_parameter('/campaign/gateway-id')
    
    if not gateway_id:
        print("⚠️  Gateway ID not found in SSM. Skipping.")
        return
    
    print(f"Gateway ID: {gateway_id}")
    
    client = boto3.client('bedrock-agentcore-control', region_name='us-east-1')
    
    try:
        print("Deleting Gateway...")
        
        client.delete_gateway(gatewayIdentifier=gateway_id)
        
        print("✅ Gateway removed successfully!")
        
    except Exception as e:
        print(f"❌ Error removing Gateway: {e}")

def remove_runtime():
    """Step 3: Remove AgentCore Runtime"""
    print("\n" + "="*60)
    print("Step 3: Remove AgentCore Runtime")
    print("="*60)
    
    runtime_id = get_ssm_parameter('/campaign/mcp-runtime-id')
    
    if not runtime_id:
        print("⚠️  Runtime ID not found in SSM. Skipping.")
        return
    
    print(f"Runtime ID: {runtime_id}")
    
    client = boto3.client('bedrock-agentcore-control', region_name='us-east-1')
    
    try:
        print("Deleting Runtime...")
        
        client.delete_agent_runtime(agentRuntimeId=runtime_id)
        
        print("✅ Runtime removed successfully!")
        
    except Exception as e:
        print(f"❌ Error removing Runtime: {e}")

def remove_identity_credential_provider():
    """Step 4: Remove Identity Credential Provider"""
    print("\n" + "="*60)
    print("Step 4: Remove Identity Credential Provider")
    print("="*60)
    
    provider_arn = get_ssm_parameter('/campaign/gateway-credential-provider-arn')
    
    if not provider_arn:
        print("⚠️  Credential Provider ARN not found in SSM. Skipping.")
        return
    
    # Extract provider name from ARN
    provider_name = provider_arn.split('/')[-1]
    print(f"Provider Name: {provider_name}")
    
    client = boto3.client('bedrock-agentcore-control', region_name='us-east-1')
    
    try:
        print("Deleting Identity Credential Provider...")
        
        client.delete_oauth2_credential_provider(name=provider_name)
        
        print("✅ Identity Credential Provider removed successfully!")
        
    except Exception as e:
        print(f"❌ Error removing Identity Credential Provider: {e}")

def remove_runtime_cognito():
    """Step 5: Remove Runtime Cognito User Pool"""
    print("\n" + "="*60)
    print("Step 5: Remove Runtime Cognito User Pool")
    print("="*60)
    
    pool_id = get_ssm_parameter('/campaign/mcp-runtime-user-pool-id')
    
    if not pool_id:
        print("⚠️  Runtime User Pool ID not found in SSM. Skipping.")
        return
    
    print(f"User Pool ID: {pool_id}")
    
    cognito = boto3.client('cognito-idp', region_name='us-east-1')
    
    try:
        # Delete domain first if exists
        pool_info = cognito.describe_user_pool(UserPoolId=pool_id)
        domain = pool_info.get('UserPool', {}).get('Domain')
        if domain:
            print(f"Deleting domain: {domain}")
            cognito.delete_user_pool_domain(Domain=domain, UserPoolId=pool_id)
        
        print("Deleting User Pool...")
        cognito.delete_user_pool(UserPoolId=pool_id)
        
        print("✅ Runtime Cognito User Pool removed successfully!")
        
    except Exception as e:
        print(f"❌ Error removing Runtime Cognito: {e}")

def remove_gateway_cognito():
    """Step 6: Remove Gateway Cognito User Pool"""
    print("\n" + "="*60)
    print("Step 6: Remove Gateway Cognito User Pool")
    print("="*60)
    
    pool_id = get_ssm_parameter('/campaign/gateway-user-pool-id')
    
    if not pool_id:
        print("⚠️  Gateway User Pool ID not found in SSM. Skipping.")
        return
    
    print(f"User Pool ID: {pool_id}")
    
    cognito = boto3.client('cognito-idp', region_name='us-east-1')
    
    try:
        # Delete domain first if exists
        pool_info = cognito.describe_user_pool(UserPoolId=pool_id)
        domain = pool_info.get('UserPool', {}).get('Domain')
        if domain:
            print(f"Deleting domain: {domain}")
            cognito.delete_user_pool_domain(Domain=domain, UserPoolId=pool_id)
        
        print("Deleting User Pool...")
        cognito.delete_user_pool(UserPoolId=pool_id)
        
        print("✅ Gateway Cognito User Pool removed successfully!")
        
    except Exception as e:
        print(f"❌ Error removing Gateway Cognito: {e}")

def remove_ssm_parameters():
    """Step 7: Remove SSM Parameters"""
    print("\n" + "="*60)
    print("Step 7: Remove SSM Parameters")
    print("="*60)
    
    ssm = boto3.client('ssm', region_name='us-east-1')
    
    # Only delete AgentCore-related parameters
    agentcore_params = [
        '/campaign/gateway-id',
        '/campaign/gateway-url',
        '/campaign/gateway-client-id',
        '/campaign/gateway-client-secret',
        '/campaign/gateway-scope',
        '/campaign/gateway-user-pool-id',
        '/campaign/gateway-credential-provider-arn',
        '/campaign/gateway-target-id',
        '/campaign/mcp-runtime-id',
        '/campaign/mcp-runtime-arn',
        '/campaign/mcp-runtime-user-pool-id',
        '/campaign/mcp-runtime-client-id',
        '/campaign/mcp-runtime-client-secret',
        '/campaign/mcp-runtime-discovery-url',
        '/campaign/mcp-runtime-scope'
    ]
    
    deleted = []
    for param in agentcore_params:
        try:
            ssm.delete_parameter(Name=param)
            deleted.append(param)
            print(f"✓ Deleted: {param}")
        except:
            pass
    
    if deleted:
        print(f"\n✅ Deleted {len(deleted)} SSM parameters")
    else:
        print("⚠️  No SSM parameters found")
    
    print("\nKept infrastructure parameters:")
    print("  /campaign/vpc-id")
    print("  /campaign/private-subnet-ids")
    print("  /campaign/mcp-sg-id")
    print("  /campaign/rds-sg-id")
    print("  /campaign/db-endpoint")
    print("  /campaign/db-secret-arn")

def remove_local_config():
    """Step 8: Remove Local AgentCore Configuration"""
    print("\n" + "="*60)
    print("Step 8: Remove Local AgentCore Configuration")
    print("="*60)
    
    import os
    import shutil
    
    files_to_remove = [
        '.bedrock_agentcore.yaml',
        '.bedrock_agentcore'
    ]
    
    for item in files_to_remove:
        try:
            if os.path.isfile(item):
                os.remove(item)
                print(f"✓ Deleted file: {item}")
            elif os.path.isdir(item):
                shutil.rmtree(item)
                print(f"✓ Deleted folder: {item}")
        except Exception as e:
            print(f"⚠️  Could not delete {item}: {e}")
    
    print("✅ Local configuration cleaned up!")

def main():
    print("="*60)
    print("Campaign MCP Server Cleanup")
    print("="*60)
    print("\nThis will remove all Campaign MCP Server resources.")
    print("Resources to be removed:")
    print("  1. Gateway Target")
    print("  2. AgentCore Gateway")
    print("  3. AgentCore Runtime")
    print("  4. Identity Credential Provider")
    print("  5. Runtime Cognito Pool")
    print("  6. Gateway Cognito Pool")
    print("  7. SSM Parameters")
    print("  8. Local AgentCore Configuration")
    
    response = input("\nContinue? (yes/no): ").strip().lower()
    if response != 'yes':
        print("Cleanup cancelled.")
        sys.exit(0)
    
    # Step 1: Remove Gateway Target
    remove_gateway_target()

    time.sleep(30)
    
    # Step 2: Remove Gateway
    remove_gateway()
    
    # Step 3: Remove Runtime
    remove_runtime()
    
    # Step 4: Remove Identity Credential Provider
    remove_identity_credential_provider()
    
    # Step 5: Remove Runtime Cognito
    remove_runtime_cognito()
    
    # Step 6: Remove Gateway Cognito
    remove_gateway_cognito()
    
    # Step 7: Remove SSM Parameters
    remove_ssm_parameters()
    
    # Step 8: Remove Local Configuration
    remove_local_config()
    
    print("\n" + "="*60)
    print("✅ All Cleanup Complete!")
    print("="*60)
    print("\nAll AgentCore resources have been removed.")
    print("Infrastructure (VPC, RDS, etc.) is preserved.")

if __name__ == "__main__":
    main()
