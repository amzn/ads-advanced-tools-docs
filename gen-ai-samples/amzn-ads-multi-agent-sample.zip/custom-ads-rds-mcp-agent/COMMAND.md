cdk bootstrap
npm install
npm run build
cdk deploy --all 

## after deploying the stack of db, run below to establish the SSM port forwarding to access database
INSTANCE_ID=$(isengardcli run -- aws ssm get-parameter --name /campaign/db-access-instance-id --query Parameter.Value --output text)
DB_ENDPOINT=$(isengardcli run -- aws ssm get-parameter --name /campaign/db-endpoint --query Parameter.Value --output text)
SECRET_ARN=$(isengardcli run -- aws ssm get-parameter --name /campaign/db-secret-arn --query Parameter.Value --output text)
DB_PASSWORD=$(isengardcli run -- aws secretsmanager get-secret-value --secret-id $SECRET_ARN --query SecretString --output text | jq -r .password)

# if there is no sesison manager plug in: (put in prerequisite)
curl "https://s3.amazonaws.com/session-manager-downloads/plugin/latest/mac_arm64/sessionmanager-bundle.zip" -o "sessionmanager-bundle.zip"
unzip sessionmanager-bundle.zip
sudo ./sessionmanager-bundle/install -i /usr/local/sessionmanagerplugin -b /usr/local/bin/session-manager-plugin

# Start SSM port forwarding session (keep this running in one terminal)
isengardcli run -- aws ssm start-session \
  --target $INSTANCE_ID \
  --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters "{\"host\":[\"$DB_ENDPOINT\"],\"portNumber\":[\"5432\"],\"localPortNumber\":[\"5432\"]}"

# In another terminal, connect to localhost
echo $(isengardcli run -- aws secretsmanager get-secret-value --secret-id $SECRET_ARN --query SecretString --output text | jq -r .password)

# copy the above password for input
psql -h localhost -p 5432 -U dbadmin -d campaigndb -f create-campaign-table.sql
psql -h localhost -p 5432 -U dbadmin -d campaigndb -f insert-sample-data.sql
# to check if data is there
psql -h localhost -p 5432 -U dbadmin -d campaigndb -c "SELECT * FROM campaign;"

# to deploy mcp server to agentcore runtime with vpc attachment, use the following command
cd mcp-server
# Create virtual environment
python3 -m venv venv
# On Mac
source venv/bin/activate 
# On Windows: 
venv\Scripts\activate

pip install --upgrade pip
pip install -r requirements-local.txt

# create cognito user pool to protect mcp server
python setup_cognito.py

# deploy mcp server to agentcore runtime with VPC attachment
./deploy.sh

# create gateway cognito and create Identity Credential Provider for (gateway -> runtime verification)
python create_gateway.py

# add gateway target
python add_gateway_target.py

# test using gateway to search database
python test_gateway_search.py

# if testing with langraph agent










# check current table
PGPASSWORD='xse9cXIABG9QcZ.9TQ_cue53Y-dNfG' psql "host=campaignrdsstack-campaigndatabasefec899e6-jwsqana3jbax.c85yq622kyby.us-east-1.rds.amazonaws.com port=5432 dbname=campaigndb user=dbadmin sslmode=require" -c "SELECT * FROM campaign;"

# get secrete
eval $(isengardcli creds 711387107464 --role Admin)
aws secretsmanager get-secret-value --secret-id arn:aws:secretsmanager:us-east-1:711387107464:secret:CampaignRdsStackCampaignDat-97NQJCawnRzG-0klqIX --query SecretString --output text | jq

{
  "password": "xse9cXIABG9QcZ.9TQ_cue53Y-dNfG",
  "dbname": "campaigndb",
  "engine": "postgres",
  "port": 5432,
  "dbInstanceIdentifier": "campaignrdsstack-campaigndatabasefec899e6-jwsqana3jbax",
  "host": "campaignrdsstack-campaigndatabasefec899e6-jwsqana3jbax.c85yq622kyby.us-east-1.rds.amazonaws.com",
  "username": "dbadmin"
}

# insert rows 
PGPASSWORD='xse9cXIABG9QcZ.9TQ_cue53Y-dNfG' psql "host=campaignrdsstack-campaigndatabasefec899e6-jwsqana3jbax.c85yq622kyby.us-east-1.rds.amazonaws.com port=5432 dbname=campaigndb user=dbadmin sslmode=require" -f insert-sample-data.sql

# create tables
PGPASSWORD='xse9cXIABG9QcZ.9TQ_cue53Y-dNfG' psql "host=campaignrdsstack-campaigndatabasefec899e6-jwsqana3jbax.c85yq622kyby.us-east-1.rds.amazonaws.com port=5432 dbname=campaigndb user=dbadmin sslmode=require" -f create-campaign-table.sql

aws rds modify-db-instance \  --db-instance-identifier campaignrdsstack-campaigndatabasefec899e6-jwsqana3jbax \                                    
  --publicly-accessible \
  --apply-immediately



