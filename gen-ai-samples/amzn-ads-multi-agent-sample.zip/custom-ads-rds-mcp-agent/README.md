# amazon-ads-custom-mcp-server-agent


### Install Node.js and npm (if not already installed) and Install AWS CDK
```bash
npm install -g aws-cdk
```

### Install AWS CLI and configure credentials
```bash
aws configure
```

### Install AWS Session Manager plugin (for database access)
```bash
curl "https://s3.amazonaws.com/session-manager-downloads/plugin/latest/
mac_arm64/sessionmanager-bundle.zip" -o "sessionmanager-bundle.zip"
unzip sessionmanager-bundle.zip
sudo ./sessionmanager-bundle/install -i /usr/local/sessionmanagerplugin -b
/usr/local/bin/session-manager-plugin
```

### Install PostgreSQL client (for database operations)
```bash
brew install postgresql
```


## Step-by-Step Execution

1. Initialize and Deploy Infrastructure

    **Bootstrap CDK (only needed once per account/region)**

    ```bash
    cdk bootstrap
    ```
    **Install Node.js dependencies**

    ```bash
    npm install
    ```
    **Deploy the Application**:
    ```bash
    npm run build
    cdk deploy --all
    ```
   If you do not want to mannually approve all security-sensitive changes, run 
    ```bash
    npm run build
    cdk deploy --all --require-approval never
    ``` 

2. Setup Database

    **Run below to establish the SSM port forwarding to access database**
      ```bash
        INSTANCE_ID=$(aws ssm get-parameter --name /campaign/db-access-instance-id --query Parameter.Value --output text)
        DB_ENDPOINT=$(aws ssm get-parameter --name /campaign/db-endpoint --query Parameter.Value --output text)
        SECRET_ARN=$(aws ssm get-parameter --name /campaign/db-secret-arn --query Parameter.Value --output text)
        DB_PASSWORD=$(aws secretsmanager get-secret-value --secret-id $SECRET_ARN --query SecretString --output text | jq -r .password)
      ```

    **Start SSM port forwarding session (keep this running in one terminal)**
      ```bash
        aws ssm start-session \
        --target $INSTANCE_ID \
        --document-name AWS-StartPortForwardingSessionToRemoteHost \
        --parameters "{\"host\":[\"$DB_ENDPOINT\"],\"portNumber\":[\"5432\"],\"localPortNumber\":[\"5432\"]}"
      ```

    **In another terminal, run the command to get database password**
      ```bash
        SECRET_ARN=$(aws ssm get-parameter --name /campaign/db-secret-arn --query Parameter.Value --output text)
        echo $(aws secretsmanager get-secret-value --secret-id $SECRET_ARN --query   SecretString --output text | jq -r .password)
      ```

    **Copy the above password for input. Run following commands to create table and insert data**
      ```bash
        psql -h localhost -p 5432 -U dbadmin -d campaigndb -f create-campaign-table.sql
        psql -h localhost -p 5432 -U dbadmin -d campaigndb -f insert-sample-data.sql
      ```

    **to check if data is there**
      ```bash
        psql -h localhost -p 5432 -U dbadmin -d campaigndb -c "SELECT * FROM campaign;"
      ```

3. Deploy MCP server to AgentCore Runtime

      ```bash
        cd mcp-server
      ```

    **Create virtual environment**
      ```bash
        python3 -m venv venv

        # To activate virtual environment
        # On Mac
        source venv/bin/activate 
        # On Windows: 
        venv\Scripts\activate

        # install required dependencies
        pip install --upgrade pip
        pip install -r requirements-local.txt
      ```
    **create cognito user pool to protect mcp server**
    ```bash
      python setup_cognito.py
    ```

    **deploy mcp server to agentcore runtime with VPC attachment**
    ```bash
      ./deploy.sh
    ```

    **create gateway cognito and create Identity Credential Provider for (gateway -> runtime verification)**
    ```bash
      python create_gateway.py
    ```

    **add MCP server as a gateway target**
    ```bash
      python add_gateway_target.py
    ```

3. Deploy Langraph agent to AgentCore Runtime
    ```bash
      cd ..
      cd langraph
      ./deploy.sh
    ```
    **To test agent performance**
    ```bash
      python test_agent.py
    ```

    




