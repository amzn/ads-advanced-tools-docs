# Fix RDS Agent 0 Skills Issue

## Problem
The RDS Campaign Agent shows 0 skills because the MCP Gateway target is in FAILED status and cannot connect to the MCP server.

## Root Cause
Gateway status check revealed:
```
Status: FAILED
Reason: "Failed to connect and fetch tools from the provided MCP target server. Unable to connect to the MCP server."
```

## Solution Steps

### 1. Redeploy the MCP Server
```bash
cd custom-ads-rds-mcp-agent/mcp-server
./deploy.sh
```

This will:
- Rebuild and redeploy the MCP server runtime
- Ensure it's properly configured with VPC networking
- Update the runtime ARN in SSM Parameter Store

### 2. Verify MCP Server is Running
```bash
# Check MCP server status
agentcore status

# Test MCP server directly
agentcore invoke '{"prompt": "test"}' --session-id "test-$(uuidgen)"
```

### 3. Update Gateway Target (if needed)
If the MCP server runtime ARN changed, you need to update the gateway target:

```bash
cd custom-ads-rds-mcp-agent/mcp-server

# Delete old gateway target
python3 << 'EOF'
import boto3
ssm = boto3.client('ssm', region_name='us-east-1')
gateway_client = boto3.client('bedrock-agentcore-control', region_name='us-east-1')

gateway_id = ssm.get_parameter(Name='/campaign/gateway-id')['Parameter']['Value']
target_id = ssm.get_parameter(Name='/campaign/gateway-target-id')['Parameter']['Value']

gateway_client.delete_gateway_target(
    gatewayIdentifier=gateway_id,
    targetId=target_id
)
print("✓ Old gateway target deleted")
EOF

# Re-add gateway target with new MCP server
python add_gateway_target.py
```

### 4. Verify Gateway Target Status
```bash
python3 << 'EOF'
import boto3
ssm = boto3.client('ssm', region_name='us-east-1')
gateway_client = boto3.client('bedrock-agentcore-control', region_name='us-east-1')

gateway_id = ssm.get_parameter(Name='/campaign/gateway-id')['Parameter']['Value']
targets = gateway_client.list_gateway_targets(gatewayIdentifier=gateway_id)

for target in targets['items']:
    print(f"Target: {target['name']}")
    print(f"Status: {target['status']}")
    print()
EOF
```

The status should be **AVAILABLE** (not FAILED).

### 5. Test the RDS Agent
Once the gateway target is AVAILABLE, test the RDS agent:

```bash
cd custom-ads-rds-mcp-agent/langraph
agentcore invoke '{"prompt": "list campaigns"}' --session-id "test-$(uuidgen)"
```

### 6. Test via Orchestrator
```bash
cd orchestration-a2a-agent
agentcore invoke --session-id "session-$(uuidgen)" '{"prompt": "what campaign tools do you have?"}'
```

The orchestrator should now show the RDS Campaign Agent with tools (not 0 skills).

## Expected Result

After these steps:
- MCP server runtime is running and accessible
- Gateway target status is AVAILABLE
- Gateway returns tools from MCP server
- RDS agent shows N skills (where N > 0)
- Orchestrator can route queries to RDS agent

## Troubleshooting

If the gateway target still shows FAILED:

1. **Check MCP server logs:**
   ```bash
   aws logs tail /aws/bedrock-agentcore/runtimes/campaign_mcp_server-ii5guYAFWH-DEFAULT \
     --log-stream-name-prefix "2026/02/06/[runtime-logs]" --follow
   ```

2. **Verify VPC networking:**
   - MCP server must be in the same VPC as RDS
   - Security groups must allow communication
   - VPC endpoints must be configured

3. **Check Cognito authentication:**
   - Verify OAuth credentials are valid
   - Check that the gateway can authenticate with the MCP server

4. **Test MCP server endpoint directly:**
   Use the gateway's perspective to test connectivity
