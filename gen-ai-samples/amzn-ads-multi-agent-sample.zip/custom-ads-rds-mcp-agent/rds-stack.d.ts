import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import { Construct } from 'constructs';
export declare class CampaignRdsStack extends cdk.Stack {
    readonly database: rds.DatabaseInstance;
    readonly vpc: ec2.Vpc;
    readonly dbSecurityGroup: ec2.SecurityGroup;
    readonly mcpServerSecurityGroup: ec2.SecurityGroup;
    constructor(scope: Construct, id: string, props?: cdk.StackProps);
}
