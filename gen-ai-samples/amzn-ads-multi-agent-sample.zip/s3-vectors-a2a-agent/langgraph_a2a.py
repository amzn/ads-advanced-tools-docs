"""
S3 Vectors A2A Agent - Optimized with Performance Best Practices

Performance Optimizations Applied:
1. Lazy initialization pattern (faster cold starts)
2. Async boto3 with aioboto3 (non-blocking I/O)
3. TTLCache instead of lru_cache (prevents memory leaks)
4. uvloop for 2-4x event loop performance
5. Optimized connection pooling (50 connections)
6. ORJSONResponse for faster JSON serialization
7. GZip compression for bandwidth reduction
8. Sonnet model for better reasoning
9. System prompt binding (reduced token usage)
10. Optimized token limits (2048 max)
"""
import uvloop
uvloop.install()  # Install uvloop BEFORE other imports

from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, SystemMessage, BaseMessage
from langchain_aws import ChatBedrock
from typing import List, Optional, Dict, Any
import operator
import os
import aioboto3
from botocore.config import Config
import boto3
import json
import logging
import uvicorn
from fastapi import FastAPI, Request as FastAPIRequest
from fastapi.responses import ORJSONResponse
from fastapi.middleware.gzip import GZipMiddleware
from cachetools import TTLCache
from threading import Lock
import uuid
import traceback


# ============================================================================
# Structured Logging Configuration
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================================
# Configuration
# ============================================================================

AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')
AGENTCORE_RUNTIME_URL = os.environ.get('AGENTCORE_RUNTIME_URL', 'http://127.0.0.1:9000/')
AGENT_NAME = "S3 Vectors Knowledge Agent"
AGENT_DESCRIPTION = "Enhanced RAG knowledge base agent with best practices"


def _get_config_value(env_var: str, ssm_name: str, default: str) -> str:
    """Get config value from env var, then SSM Parameter Store, then default."""
    value = os.getenv(env_var)
    if value:
        return value
    try:
        ssm = boto3.client('ssm', region_name=AWS_REGION)
        result = ssm.get_parameter(Name=ssm_name)
        return result['Parameter']['Value']
    except Exception:
        return default


VECTOR_BUCKET_NAME = _get_config_value('VECTOR_BUCKET_NAME', '/ads/vector-bucket-name', 'ads-knowledge-vectors-bucket')
VECTOR_INDEX_NAME = _get_config_value('VECTOR_INDEX_NAME', '/ads/vector-index-name', 'ads-knowledge-index')


# ============================================================================
# Boto3 Client Initialization with Optimization
# ============================================================================

def _create_optimized_boto3_config() -> Config:
    """Create optimized boto3 configuration"""
    return Config(
        max_pool_connections=50,  # Increased for async concurrency
        retries={'max_attempts': 3, 'mode': 'adaptive'},  # Adaptive retries
        connect_timeout=5,   # Fail fast
        read_timeout=30,     # Reasonable timeout
        tcp_keepalive=True   # Keep connections alive
    )


# Global aioboto3 session (singleton pattern)
_aioboto3_session = None

def get_aioboto3_session():
    """Get or create aioboto3 session (singleton pattern)"""
    global _aioboto3_session
    if _aioboto3_session is None:
        _aioboto3_session = aioboto3.Session()
    return _aioboto3_session


# ============================================================================
# S3 Vectors Integration (Optimized with TTLCache)
# ============================================================================

# TTL Cache for embeddings (prevents memory leaks)
_embedding_cache = TTLCache(maxsize=200, ttl=3600)  # 1 hour TTL
_cache_lock = Lock()


async def generate_embedding_async(text: str) -> tuple:
    """
    Generate embedding with TTL caching (prevents memory leaks).
    Returns tuple for hashability.
    """
    cache_key = text
    
    # Check cache
    with _cache_lock:
        if cache_key in _embedding_cache:
            return _embedding_cache[cache_key]
    
    try:
        # Generate embedding asynchronously
        session = get_aioboto3_session()
        config = _create_optimized_boto3_config()
        
        async with session.client('bedrock-runtime', region_name=AWS_REGION, config=config) as bedrock_runtime:
            response = await bedrock_runtime.invoke_model(
                modelId="amazon.titan-embed-text-v2:0",
                body=json.dumps({"inputText": text}).encode('utf-8')
            )
            response_body = json.loads(await response["Body"].read())
            embedding = tuple(response_body["embedding"])
        
        # Cache result
        with _cache_lock:
            _embedding_cache[cache_key] = embedding
        
        return embedding
    except Exception as e:
        logger.error(f"Embedding generation error: {e}")
        raise


async def query_s3_vectors_async(query: str, top_k: int = 3, filters: Dict = None) -> List[Dict[str, Any]]:
    """Query S3 knowledge base using S3 Vectors query_vectors API (async, optimized)"""
    try:
        # Generate query embedding (cached for repeated queries)
        query_embedding = list(await generate_embedding_async(query))
        
        # Build query parameters (optimized with dict comprehension for conditional filter)
        query_params = {
            'vectorBucketName': VECTOR_BUCKET_NAME,
            'indexName': VECTOR_INDEX_NAME,
            'queryVector': {"float32": query_embedding},
            'topK': top_k,
            'returnDistance': True,
            'returnMetadata': True
        }
        
        # Add metadata filter if provided (optimized with early return pattern)
        if filters and 'category' in filters:
            filter_category = filters['category'].get('$eq')
            if filter_category:
                query_params['filter'] = {"category": filter_category}
        
        # Query S3 Vectors asynchronously
        session = get_aioboto3_session()
        config = _create_optimized_boto3_config()
        
        async with session.client('s3vectors', region_name=AWS_REGION, config=config) as s3vectors_client:
            response = await s3vectors_client.query_vectors(**query_params)
        
        # Optimized: Cache metadata to avoid repeated .get() calls
        return [
            {
                'id': match.get('key', 'unknown'),
                'distance': match.get('distance', 0.0),
                'text': (metadata := match.get('metadata', {})).get('text', ''),
                'metadata': {
                    'category': metadata.get('category', ''),
                    'topic': metadata.get('topic', '')
                }
            }
            for match in response.get('vectors', [])
        ]
        
    except Exception as e:
        logger.error(f"S3 Vectors query error: {e}")
        logger.error(traceback.format_exc())
        return []


# ============================================================================
# Tools Definition (Optimized)
# ============================================================================

@tool
async def search_knowledge(query: str, category: str = None) -> str:
    """
    Search the knowledge base for relevant information about Amazon Advertising.
    
    Args:
        query: The search query (e.g., "how to optimize campaigns", "profile management best practices")
        category: Optional category filter (e.g., "profiles", "campaigns", "budgets", "targeting")
    
    Returns:
        Relevant documentation and knowledge from the knowledge base
    """
    logger.info(f"search_knowledge called: query='{query[:50]}...', category={category}")
    
    # Build metadata filters if category provided
    filters = {"category": {"$eq": category}} if category else None
    
    # Query S3 Vectors - reduced to top 3 for faster responses
    results = await query_s3_vectors_async(query, top_k=3, filters=filters)
    
    if not results:
        return "No relevant information found in the knowledge base. Try rephrasing your query or removing category filters."
    
    logger.info(f"Found {len(results)} results")
    
    # Format results with full text content
    formatted_results = [
        f"[{i}] {result['metadata'].get('topic', 'N/A')}\n{result['text']}"
        for i, result in enumerate(results, 1)
    ]
    
    response = "\n\n".join(formatted_results)
    
    return response


@tool
def list_knowledge_categories() -> str:
    """
    List all available knowledge base categories.
    
    Returns:
        List of available categories in the knowledge base
    """
    logger.info("list_knowledge_categories called")
    
    categories = [
        "profiles - Profile management and configuration",
        "campaigns - Campaign creation, optimization, and management",
        "budgets - Budget allocation and monitoring",
        "targeting - Targeting strategies and keyword management",
        "authentication - API authentication and authorization",
        "reporting - Performance reporting and analytics",
        "best_practices - General best practices and guidelines"
    ]
    return "Available knowledge base categories:\n\n" + "\n".join(f"• {cat}" for cat in categories)


# Collect all tools
tools = [search_knowledge, list_knowledge_categories]


# ============================================================================
# Build LangGraph Agent (Lazy Initialization)
# ============================================================================

# Global agent instance
_agent = None
_llm_with_tools = None
_system_prompt = None  # Store system prompt globally


def _initialize_llm():
    """Initialize LLM with optimized settings (lazy)"""
    global _llm_with_tools, _system_prompt
    
    if _llm_with_tools is not None:
        return _llm_with_tools
    
    # Create Bedrock client with optimized connection pooling
    config = Config(
        max_pool_connections=50,  # Increased for async concurrency
        retries={'max_attempts': 3, 'mode': 'adaptive'},  # Adaptive retries
        connect_timeout=5,   # Fail fast
        read_timeout=30,     # Reasonable timeout
        tcp_keepalive=True   # Keep connections alive
    )
    bedrock_client = boto3.client('bedrock-runtime', region_name='us-west-2', config=config)
    
    # Initialize LLM with Haiku for speed
    llm = ChatBedrock(
        client=bedrock_client,
        model_id='us.anthropic.claude-sonnet-4-5-20250929-v1:0',  # US inference profile
        model_kwargs={
            "temperature": 0,  # Deterministic responses
            "max_tokens": 2048,  # Enough for complex knowledge queries
        }
    )
    
    # System prompt with search-first mandate and clear scope
    _system_prompt = f"""You are a DOCUMENTATION AND BEST PRACTICES specialist for Amazon Advertising.

SCOPE (ONLY these tasks):
- Answer "how to" questions about Amazon Advertising features
- Provide best practices and guidelines from official documentation
- Explain concepts, terminology, and workflows
- Reference official documentation and knowledge base

STRICT RULES:
1. ALWAYS search knowledge base FIRST - never answer from memory or training data
2. Use category filter when topic is clear:
   - "profiles" → profile management questions
   - "campaigns" → campaign creation/optimization
   - "budgets" → budget allocation/monitoring
   - "targeting" → targeting strategies/keywords
   - "authentication" → API authentication/authorization
   - "reporting" → report generation/metrics
   - "best_practices" → general guidelines
3. If search returns NO results, respond: "I don't have documentation on that topic. I can help with: profiles, campaigns, budgets, targeting, authentication, reporting, or best practices."
4. If search returns irrelevant results, try ONE more search with refined keywords (max 2 searches total)
5. Always cite sources: "According to our documentation..." or "Based on our knowledge base..."

FORBIDDEN ACTIONS:
- Performing operations like creating campaigns (delegate to Custom Ads Agent)
- Running reports or analytics (delegate to Remote MCP Agent)
- Answering without searching knowledge base first
- Providing information not found in search results
- Inventing best practices or making up answers

SEARCH STRATEGY:
1. Extract key terms from user question
2. Determine if category filter applies (profiles/campaigns/budgets/etc.)
3. Call search_knowledge with query and optional category (top_k=3)
4. If results are off-topic, refine query and search again (max 2 searches)
5. If still no relevant results, admit limitation and suggest related topics

VALIDATION (before responding):
- Did I search the knowledge base?
- Are search results relevant to the question?
- Am I citing documentation, not inventing answers?
- Did I make at most 2 searches?

Available tools: {len(tools)}
Categories: profiles, campaigns, budgets, targeting, authentication, reporting, best_practices"""
    
    _llm_with_tools = llm
    
    return _llm_with_tools


def _initialize_agent():
    """Initialize agent (lazy initialization on first request)"""
    global _agent
    
    if _agent is not None:
        return _agent
    
    logger.info("="*60)
    logger.info("INITIALIZING S3 VECTORS AGENT")
    logger.info("="*60)
    
    # Initialize LLM
    llm = _initialize_llm()
    
    # Create agent with system_prompt parameter
    _agent = create_agent(
        llm,
        tools,
        system_prompt=_system_prompt
    ).with_config(recursion_limit=15)
    
    logger.info("✓ Agent ready")
    logger.info("="*60)
    
    return _agent


# ============================================================================
# A2A Server with FastAPI (Optimized)
# ============================================================================

app = FastAPI(default_response_class=ORJSONResponse)  # Faster JSON serialization
app.add_middleware(GZipMiddleware, minimum_size=1000)  # Compress responses > 1KB


@app.post("/")
async def a2a_endpoint(request: FastAPIRequest):
    """A2A JSON-RPC endpoint with session tracking"""
    try:
        body = await request.json()
        
        # Extract session/actor info
        actor_id = body.get("actor_id", "default-user")
        session_id = body.get("session_id", str(uuid.uuid4()))
        
        # Optimized: Extract text from request with generator expression
        text = (body["prompt"] if "prompt" in body else
                next((part.get("text") for part in body.get("params", {}).get("message", {}).get("parts", []) if "text" in part), 
                     body.get("params", {}).get("message", {}).get("text", "")))
        
        logger.info("="*60)
        logger.info(f"NEW REQUEST | Actor: {actor_id} | Session: {session_id}")
        logger.info(f"Query: {text[:100]}...")
        logger.info("="*60)
        
        # Initialize agent on first request (lazy)
        agent = _initialize_agent()
        
        # Invoke graph
        result = await agent.ainvoke({"messages": [HumanMessage(content=text)]})
        response_text = result["messages"][-1].content if result.get("messages") else "No response"
        
        logger.info(f"Response: {response_text[:200]}...")
        logger.info("="*60)
        
        # Return appropriate format
        if "method" not in body:
            return response_text
        else:
            return {
                "jsonrpc": "2.0",
                "id": body.get("id"),
                "result": {
                    "status": {
                        "message": {
                            "role": "assistant",
                            "parts": [{"kind": "text", "text": response_text}]
                        }
                    }
                }
            }
            
    except Exception as e:
        logger.error(f"ERROR: {str(e)}")
        logger.error(traceback.format_exc())
        
        return {
            "jsonrpc": "2.0",
            "id": body.get("id") if 'body' in locals() else None,
            "error": {"code": -32603, "message": f"Internal error: {str(e)}"}
        }


@app.get("/ping")
def ping():
    """Health check endpoint"""
    return {"status": "ok"}


@app.get("/.well-known/agent-card.json")
def agent_card():
    """Agent card endpoint for A2A discovery (optimized with list comprehension)"""
    return {
        "protocolVersions": ["0.3"],
        "name": AGENT_NAME,
        "description": f"{AGENT_DESCRIPTION} with {len(tools)} tools",
        "supportedInterfaces": [{"url": AGENTCORE_RUNTIME_URL, "protocolBinding": "JSONRPC"}],
        "version": "2.0.0",  # Enhanced version
        "capabilities": {"streaming": False, "pushNotifications": False},
        "defaultInputModes": ["text/plain"],
        "defaultOutputModes": ["text/plain"],
        # Optimized: List comprehension for skills
        "skills": [
            {
                "id": tool.name,
                "name": tool.name.replace('_', ' ').title(),
                "description": tool.description,
                "tags": ["advertising", "knowledge", "rag", "s3-vectors", "enhanced"],
                "examples": [f"Use {tool.name}"],
                "inputModes": ["text/plain"],
                "outputModes": ["text/plain"]
            }
            for tool in tools
        ]
    }


# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    logger.info("Starting Enhanced A2A Server on port 9000...")
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=9000,
        log_level="warning",
        timeout_keep_alive=300  # Prevent connection timeouts
    )
