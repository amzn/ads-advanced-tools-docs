#!/usr/bin/env python3
"""
Verification script to confirm S3 Vectors integration is working correctly
"""
import boto3
import json
import os
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

# Configuration
VECTOR_BUCKET_NAME = os.getenv('VECTOR_BUCKET_NAME', 'ads-knowledge-vectors-bucket')
VECTOR_INDEX_NAME = os.getenv('VECTOR_INDEX_NAME', 'ads-knowledge-index')
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')

# Initialize clients
s3vectors_client = boto3.client('s3vectors', region_name=AWS_REGION)
bedrock_runtime = boto3.client('bedrock-runtime', region_name=AWS_REGION)

print("="*80)
print("S3 VECTORS VERIFICATION SCRIPT")
print("="*80)
print(f"Timestamp: {datetime.now().isoformat()}")
print(f"Bucket: {VECTOR_BUCKET_NAME}")
print(f"Index: {VECTOR_INDEX_NAME}")
print(f"Region: {AWS_REGION}")
print("="*80)
print()


def check_vector_index():
    """Verify vector index exists and get its configuration"""
    print("1. Checking Vector Index Configuration...")
    try:
        response = s3vectors_client.describe_index(
            vectorBucketName=VECTOR_BUCKET_NAME,
            indexName=VECTOR_INDEX_NAME
        )
        
        print(f"   ✓ Index exists: {VECTOR_INDEX_NAME}")
        print(f"   - Dimension: {response.get('dimension', 'N/A')}")
        print(f"   - Distance Metric: {response.get('distanceMetric', 'N/A')}")
        print(f"   - Status: {response.get('status', 'N/A')}")
        print(f"   - Created: {response.get('creationDate', 'N/A')}")
        return True
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False


def count_vectors():
    """Count total vectors in the index"""
    print("\n2. Counting Vectors in Index...")
    try:
        # List vectors with pagination
        total_count = 0
        next_token = None
        
        while True:
            params = {
                'vectorBucketName': VECTOR_BUCKET_NAME,
                'indexName': VECTOR_INDEX_NAME,
                'maxResults': 100
            }
            if next_token:
                params['nextToken'] = next_token
            
            response = s3vectors_client.list_vectors(**params)
            vectors = response.get('vectors', [])
            total_count += len(vectors)
            
            next_token = response.get('nextToken')
            if not next_token:
                break
        
        print(f"   ✓ Total vectors: {total_count}")
        return total_count
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return 0


def list_sample_vectors():
    """List first 5 vectors to verify content"""
    print("\n3. Listing Sample Vectors...")
    try:
        response = s3vectors_client.list_vectors(
            vectorBucketName=VECTOR_BUCKET_NAME,
            indexName=VECTOR_INDEX_NAME,
            maxResults=5
        )
        
        vectors = response.get('vectors', [])
        print(f"   ✓ Retrieved {len(vectors)} sample vectors:")
        
        for i, vector in enumerate(vectors, 1):
            key = vector.get('key', 'N/A')
            metadata = vector.get('metadata', {})
            category = metadata.get('category', 'N/A')
            topic = metadata.get('topic', 'N/A')
            print(f"   {i}. {key}")
            print(f"      Category: {category}, Topic: {topic}")
        
        return True
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False


def test_vector_query():
    """Test querying vectors to verify search functionality"""
    print("\n4. Testing Vector Query...")
    
    test_query = "How do I optimize my advertising campaigns?"
    print(f"   Query: '{test_query}'")
    
    try:
        # Generate query embedding
        response = bedrock_runtime.invoke_model(
            modelId="amazon.titan-embed-text-v2:0",
            body=json.dumps({"inputText": test_query})
        )
        
        response_body = json.loads(response["body"].read())
        query_embedding = response_body["embedding"]
        print(f"   ✓ Generated embedding (dimension: {len(query_embedding)})")
        
        # Query S3 Vectors
        response = s3vectors_client.query_vectors(
            vectorBucketName=VECTOR_BUCKET_NAME,
            indexName=VECTOR_INDEX_NAME,
            queryVector={"float32": query_embedding},
            topK=3,
            returnDistance=True,
            returnMetadata=True
        )
        
        vectors = response.get('vectors', [])
        print(f"   ✓ Query returned {len(vectors)} results:")
        
        for i, match in enumerate(vectors, 1):
            key = match.get('key', 'N/A')
            distance = match.get('distance', 0.0)
            similarity = 1.0 - distance
            metadata = match.get('metadata', {})
            category = metadata.get('category', 'N/A')
            topic = metadata.get('topic', 'N/A')
            text_preview = metadata.get('text', '')[:100]
            
            print(f"\n   Result {i}:")
            print(f"   - Key: {key}")
            print(f"   - Distance: {distance:.4f} (Similarity: {similarity:.4f})")
            print(f"   - Category: {category}")
            print(f"   - Topic: {topic}")
            print(f"   - Text Preview: {text_preview}...")
        
        return True
    except Exception as e:
        print(f"   ✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_metadata_filter():
    """Test querying with metadata filter"""
    print("\n5. Testing Metadata Filter Query...")
    
    test_query = "campaign strategies"
    filter_category = "campaigns"
    print(f"   Query: '{test_query}' with filter category='{filter_category}'")
    
    try:
        # Generate query embedding
        response = bedrock_runtime.invoke_model(
            modelId="amazon.titan-embed-text-v2:0",
            body=json.dumps({"inputText": test_query})
        )
        
        response_body = json.loads(response["body"].read())
        query_embedding = response_body["embedding"]
        
        # Query S3 Vectors with filter
        response = s3vectors_client.query_vectors(
            vectorBucketName=VECTOR_BUCKET_NAME,
            indexName=VECTOR_INDEX_NAME,
            queryVector={"float32": query_embedding},
            topK=3,
            filter={"category": filter_category},
            returnDistance=True,
            returnMetadata=True
        )
        
        vectors = response.get('vectors', [])
        print(f"   ✓ Filtered query returned {len(vectors)} results:")
        
        for i, match in enumerate(vectors, 1):
            key = match.get('key', 'N/A')
            distance = match.get('distance', 0.0)
            metadata = match.get('metadata', {})
            category = metadata.get('category', 'N/A')
            
            print(f"   {i}. {key} (distance: {distance:.4f}, category: {category})")
            
            # Verify filter worked
            if category != filter_category:
                print(f"      ⚠️  WARNING: Result has category '{category}' but filter was '{filter_category}'")
        
        return True
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False


def verify_data_source():
    """Verify that data is actually coming from S3 Vectors, not cached or mocked"""
    print("\n6. Verifying Data Source (S3 Vectors API)...")
    
    try:
        # Get a specific vector to verify it exists in S3 Vectors
        response = s3vectors_client.get_vectors(
            vectorBucketName=VECTOR_BUCKET_NAME,
            indexName=VECTOR_INDEX_NAME,
            keys=["profile-management-001"]
        )
        
        vectors = response.get('vectors', [])
        if vectors:
            vector = vectors[0]
            print(f"   ✓ Successfully retrieved vector from S3 Vectors API:")
            print(f"   - Key: {vector.get('key', 'N/A')}")
            print(f"   - Has embedding data: {bool(vector.get('data'))}")
            print(f"   - Has metadata: {bool(vector.get('metadata'))}")
            
            metadata = vector.get('metadata', {})
            print(f"   - Category: {metadata.get('category', 'N/A')}")
            print(f"   - Topic: {metadata.get('topic', 'N/A')}")
            
            # Verify embedding dimension
            data = vector.get('data', {})
            float32_data = data.get('float32', [])
            print(f"   - Embedding dimension: {len(float32_data)}")
            
            print("\n   ✓ CONFIRMED: Data is coming from S3 Vectors API")
            print("   - Using s3vectors boto3 client")
            print("   - Vectors stored with embeddings")
            print("   - Metadata properly attached")
            return True
        else:
            print("   ✗ No vectors found")
            return False
            
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False


def run_verification():
    """Run all verification checks"""
    results = {
        'index_check': False,
        'vector_count': 0,
        'sample_list': False,
        'query_test': False,
        'filter_test': False,
        'source_verify': False
    }
    
    results['index_check'] = check_vector_index()
    results['vector_count'] = count_vectors()
    results['sample_list'] = list_sample_vectors()
    results['query_test'] = test_vector_query()
    results['filter_test'] = test_metadata_filter()
    results['source_verify'] = verify_data_source()
    
    # Summary
    print("\n" + "="*80)
    print("VERIFICATION SUMMARY")
    print("="*80)
    
    all_passed = all([
        results['index_check'],
        results['vector_count'] > 0,
        results['sample_list'],
        results['query_test'],
        results['filter_test'],
        results['source_verify']
    ])
    
    print(f"Index Configuration: {'✓ PASS' if results['index_check'] else '✗ FAIL'}")
    print(f"Vector Count: {results['vector_count']} vectors")
    print(f"Sample Listing: {'✓ PASS' if results['sample_list'] else '✗ FAIL'}")
    print(f"Query Test: {'✓ PASS' if results['query_test'] else '✗ FAIL'}")
    print(f"Filter Test: {'✓ PASS' if results['filter_test'] else '✗ FAIL'}")
    print(f"Source Verification: {'✓ PASS' if results['source_verify'] else '✗ FAIL'}")
    
    print("\n" + "="*80)
    if all_passed:
        print("✓ ALL CHECKS PASSED - S3 Vectors integration is working correctly!")
        print("✓ Data is confirmed to be coming from S3 Vectors API")
    else:
        print("✗ SOME CHECKS FAILED - Review errors above")
    print("="*80)
    
    return all_passed


if __name__ == "__main__":
    success = run_verification()
    exit(0 if success else 1)
