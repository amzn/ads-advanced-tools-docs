# S3 Vectors A2A Agent

Amazon Advertising agent with RAG (Retrieval Augmented Generation) using S3 Vectors for knowledge base.

## Features

- **A2A Protocol**: Full A2A server implementation for agent-to-agent communication
- **S3 Vectors RAG**: Direct integration with S3 Vectors for cost-effective knowledge retrieval
- **LangGraph**: Pure LangGraph implementation with tool calling
- **Knowledge Base**: Search advertising documentation, best practices, and guides
- **Advertising Tools**: Mock tools for profiles and campaigns (replace with real APIs)

## Architecture

```
┌─────────────────────────────────────────┐
│   S3 Vectors A2A Agent                  │
│                                         │
│  ┌──────────────────────────────────┐  │
│  │  LangGraph Agent                 │  │
│  │  - Tool calling                  │  │
│  │  - RAG knowledge search          │  │
│  │  - Advertising operations        │  │
│  └──────────────────────────────────┘  │
│                                         │
│  ┌──────────────────────────────────┐  │
│  │  S3 Vectors Integration          │  │
│  │  - Titan Embed v2 (1024 dims)    │  │
│  │  - Direct boto3 queries          │  │
│  │  - Metadata filtering            │  │
│  └──────────────────────────────────┘  │
│                                         │
│  ┌──────────────────────────────────┐  │
│  │  A2A Server (FastAPI)            │  │
│  │  - JSON-RPC endpoint             │  │
│  │  - Agent card discovery          │  │
│  └──────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

## Prerequisites

### 1. Create S3 Vector Bucket and Index

You need to create an S3 bucket with vector indexing enabled:

```bash
# Create S3 bucket
aws s3api create-bucket \
  --bucket my-ads-vectors-bucket \
  --region us-east-1

# Enable S3 Vectors (via AWS Console or API)
# - Go to S3 Console > Your Bucket > Properties
# - Enable "Vector Search"
# - Create index with:
#   - Name: ads-knowledge-index
#   - Dimensions: 1024 (for Titan Embed v2)
#   - Metadata fields: document_type, category, created_date
```

### 2. Update Configuration

Edit `.env` file with your bucket and index names:

```bash
VECTOR_BUCKET_NAME=my-ads-vectors-bucket
VECTOR_INDEX_NAME=ads-knowledge-index
AWS_REGION=us-east-1
```

### 3. IAM Permissions

The AgentCore execution role needs these permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::my-ads-vectors-bucket",
        "arn:aws:s3:::my-ads-vectors-bucket/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:QueryVectors",
        "s3:PutVectors",
        "s3:DeleteVectors"
      ],
      "Resource": "arn:aws:s3:::my-ads-vectors-bucket/ads-knowledge-index"
    },
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel"
      ],
      "Resource": "arn:aws:bedrock:*::foundation-model/amazon.titan-embed-text-v2:0"
    }
  ]
}
```

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Upload Knowledge Base Documents

Use the helper script to upload documents to S3 Vectors:

```python
# upload_knowledge.py
import boto3
from langchain_aws import BedrockEmbeddings

s3vectors_client = boto3.client('s3', region_name='us-east-1')
embeddings = BedrockEmbeddings(
    model_id="amazon.titan-embed-text-v2:0",
    region_name="us-east-1"
)

documents = [
    {
        "id": "doc-001",
        "text": "Amazon Advertising profiles represent seller or vendor accounts...",
        "metadata": {"document_type": "api_docs", "category": "profiles"}
    },
    {
        "id": "doc-002",
        "text": "Best practices for campaign optimization include...",
        "metadata": {"document_type": "best_practices", "category": "campaigns"}
    }
]

for doc in documents:
    embedding = embeddings.embed_query(doc['text'])
    s3vectors_client.put_vectors(
        Bucket='my-ads-vectors-bucket',
        Index='ads-knowledge-index',
        Vectors=[{
            'Id': doc['id'],
            'Values': embedding,
            'Metadata': {'text': doc['text'], **doc['metadata']}
        }]
    )
```

### 3. Deploy to AgentCore

```bash
agentcore deploy
```

### 4. Test the Agent

```bash
# Test knowledge search
agentcore invoke '{
  "prompt": "What are best practices for managing advertising profiles?",
  "session_id": "test-123"
}'

# Test with advertising tools
agentcore invoke '{
  "prompt": "List US advertising profiles and tell me best practices",
  "session_id": "test-456"
}'
```

## Tools Available

### 1. search_advertising_knowledge
Search the RAG knowledge base for documentation and best practices.

**Example**: "What are best practices for campaign optimization?"

### 2. list_advertising_profiles
List advertising profiles by country code.

**Example**: "List US advertising profiles"

### 3. get_campaign_details
Get campaign performance details by campaign ID.

**Example**: "Get details for campaign 12345"

## How It Works

1. **User Query**: User asks a question
2. **Knowledge Search**: Agent searches S3 Vectors for relevant documentation
3. **Tool Execution**: Agent uses advertising tools to get real-time data
4. **Response**: Agent combines knowledge base insights with live data

## Integration with Orchestration Agent

This agent can be called by the orchestration agent via A2A protocol:

```python
# In orchestration agent
VECTOR_AGENT_ARN = "arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/langgraph_a2a_s3_vectors_agent-XXX"

# Orchestration agent will discover this agent's skills via agent card
# and route knowledge-related queries here
```

## Customization

### Add More Tools

Edit `langgraph_a2a.py` and add new tools:

```python
@tool
def my_new_tool(param: str) -> str:
    """Tool description"""
    # Implementation
    return result

# Add to tools list
tools = [search_advertising_knowledge, list_advertising_profiles, get_campaign_details, my_new_tool]
```

### Modify Knowledge Base Query

Adjust `query_s3_vectors()` function to change:
- Number of results (`top_k`)
- Metadata filters
- Relevance scoring

### Replace Mock Tools

Replace `list_advertising_profiles` and `get_campaign_details` with real API calls to Amazon Advertising API.

## Monitoring

View logs:
```bash
aws logs tail /aws/bedrock-agentcore/runtimes/langgraph_a2a_s3_vectors_agent-XXX-DEFAULT --follow
```

## Troubleshooting

### S3 Vectors Not Found
- Verify bucket and index names in `.env`
- Check IAM permissions
- Ensure S3 Vectors is enabled on the bucket

### No Knowledge Base Results
- Upload documents to S3 Vectors first
- Check embedding dimensions match (1024 for Titan v2)
- Verify metadata structure

### Agent Not Responding
- Check AgentCore logs
- Verify A2A protocol configuration
- Test with simple prompt first

## Cost Optimization

- S3 Vectors: ~$0.023/GB/month (90% cheaper than vector DBs)
- Titan Embed v2: ~$0.0001 per 1K tokens
- Cache frequent queries in application layer
- Use metadata filters to reduce query scope

## Next Steps

1. Upload your advertising documentation to S3 Vectors
2. Replace mock tools with real API integrations
3. Add more specialized tools for your use case
4. Integrate with orchestration agent
5. Monitor performance and optimize queries
