"""
Helper script to upload documents to S3 Vectors knowledge base
"""
import boto3
from langchain_aws import BedrockEmbeddings
import os
from dotenv import load_dotenv
import json

load_dotenv()

# Configuration
VECTOR_BUCKET_NAME = os.getenv('VECTOR_BUCKET_NAME', 'ads-knowledge-vectors-bucket')
VECTOR_INDEX_NAME = os.getenv('VECTOR_INDEX_NAME', 'ads-knowledge-index')
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')

# Initialize clients - Using S3 Vectors API
s3vectors_client = boto3.client('s3vectors', region_name=AWS_REGION)
bedrock_runtime = boto3.client('bedrock-runtime', region_name=AWS_REGION)

print("✓ Using S3 Vectors API with Bedrock embeddings")
print(f"  Region: {AWS_REGION}\n")

# Sample knowledge base documents - Comprehensive Amazon Advertising Documentation
SAMPLE_DOCUMENTS = [
    {
        "id": "profile-management-001",
        "text": """Amazon Advertising Profiles Overview:
        
A profile represents a seller or vendor account in Amazon Advertising. Each profile is associated with:
- A unique profileId (numeric identifier)
- A specific marketplace (e.g., US, UK, CA, DE, FR, IT, ES, JP)
- An account type (seller or vendor)
- A currency code for billing

Profile Management Best Practices:
1. Always verify profile status before making API calls
2. Cache profile information to reduce API calls (profiles rarely change)
3. Use batch operations when updating multiple profiles
4. Store profileId mappings for quick lookups
5. Monitor profile status changes via webhooks when available
6. Implement retry logic for profile-related API calls

Common Profile Operations:
- List all profiles: GET /v2/profiles
- Get profile details: GET /v2/profiles/{profileId}
- Update profile: PUT /v2/profiles/{profileId}

Profile Status Values:
- ENABLED: Profile is active and can run campaigns
- PAUSED: Profile is temporarily disabled
- ARCHIVED: Profile is permanently disabled""",
        "metadata": {
            "category": "profiles",
            "topic": "profile_management"
        }
    },
    {
        "id": "campaign-optimization-001",
        "text": """Campaign Optimization Best Practices:

Daily Optimization Tasks:
1. Monitor campaign performance metrics (impressions, clicks, conversions)
2. Adjust bids based on conversion data and ROI
3. Review search term reports for new keyword opportunities
4. Add negative keywords to filter irrelevant traffic
5. Check budget utilization and adjust as needed

Weekly Optimization Tasks:
1. Analyze campaign performance trends
2. Test different ad creatives and messaging
3. Review competitor strategies and adjust positioning
4. Optimize bid strategies based on performance data
5. Adjust targeting parameters (keywords, products, audiences)

Budget Management:
- Set realistic daily budgets based on historical performance
- Monitor budget utilization throughout the day
- Implement alerts when budget reaches 80% utilization
- Use budget rules to automatically adjust based on performance
- Review and adjust budgets weekly based on ROI

Bid Optimization:
- Start with recommended bids and adjust based on performance
- Increase bids for high-performing keywords
- Decrease bids for low-performing keywords
- Use dynamic bidding strategies when appropriate
- Monitor bid landscape and adjust for competitiveness

Performance Metrics to Track:
- ACOS (Advertising Cost of Sale)
- ROAS (Return on Ad Spend)
- CTR (Click-Through Rate)
- Conversion Rate
- CPC (Cost Per Click)""",
        "metadata": {
            "category": "campaigns",
            "topic": "optimization"
        }
    },
    {
        "id": "api-authentication-001",
        "text": """Amazon Advertising API Authentication:

OAuth 2.0 Authentication Flow:
1. Register your application in the Amazon Advertising Console
2. Obtain client_id and client_secret
3. Request authorization from the user
4. Exchange authorization code for access token
5. Use access token in API requests
6. Refresh token before expiration

Required OAuth Scopes:
- advertising::campaign_management - Full campaign management access
- advertising::campaign_management:read - Read-only campaign access

Token Management:
- Access tokens expire after 1 hour
- Refresh tokens are valid for 1 year
- Always handle token refresh gracefully in your application
- Store tokens securely (encrypted at rest)
- Never expose tokens in client-side code or logs

API Request Headers:
- Authorization: Bearer {access_token}
- Amazon-Advertising-API-ClientId: {client_id}
- Amazon-Advertising-API-Scope: {profileId}
- Content-Type: application/json

Error Handling:
- 401 Unauthorized: Token expired or invalid, refresh token
- 403 Forbidden: Insufficient permissions, check scopes
- 429 Too Many Requests: Rate limit exceeded, implement backoff
- 500 Internal Server Error: Retry with exponential backoff

Rate Limits:
- Standard tier: 100 requests per second
- Burst tier: 200 requests per second
- Implement rate limiting in your application to avoid throttling""",
        "metadata": {
            "category": "authentication",
            "topic": "oauth"
        }
    },
    {
        "id": "budget-management-001",
        "text": """Budget Management Guidelines:

Setting Budgets:
- Start with conservative daily budgets and scale up based on performance
- Allocate budgets based on historical ROI and conversion data
- Consider seasonality and promotional periods
- Set separate budgets for testing vs. proven campaigns

Budget Monitoring:
- Check budget utilization multiple times per day
- Set up alerts for 50%, 75%, and 90% budget consumption
- Monitor budget pacing to ensure even distribution throughout the day
- Track budget vs. actual spend variance

Budget Optimization:
- Increase budgets for high-performing campaigns (ROAS > target)
- Decrease budgets for underperforming campaigns (ROAS < target)
- Reallocate budgets from low-performing to high-performing campaigns
- Use budget rules for automatic adjustments

Budget Rules:
- Increase budget by X% when ROAS > Y
- Decrease budget by X% when ROAS < Y
- Pause campaign when daily budget is exhausted
- Resume campaign at start of new day

Budget Forecasting:
- Project monthly spend based on daily budget and pacing
- Account for weekday vs. weekend variations
- Factor in promotional periods and seasonality
- Plan for budget increases during peak seasons

Common Budget Issues:
- Budget exhaustion too early in the day: Increase daily budget or adjust bids
- Budget not fully utilized: Increase bids or expand targeting
- Inconsistent daily spend: Review bid strategy and competition
- Budget overspend: Check for bid automation issues or manual adjustments""",
        "metadata": {
            "category": "budgets",
            "topic": "management"
        }
    },
    {
        "id": "targeting-strategies-001",
        "text": """Effective Targeting Strategies:

Keyword Targeting:
1. Keyword Research:
   - Use keyword research tools to identify high-value keywords
   - Analyze competitor keywords and strategies
   - Look for long-tail keywords with lower competition
   - Consider search volume, competition, and relevance

2. Match Types:
   - Exact Match: Highest relevance, lowest reach
   - Phrase Match: Moderate relevance and reach
   - Broad Match: Lowest relevance, highest reach
   - Start with exact/phrase and expand to broad based on performance

3. Negative Keywords:
   - Build comprehensive negative keyword lists
   - Add irrelevant search terms from search term reports
   - Use negative keyword lists across campaigns
   - Review and update negative keywords weekly

Product Targeting:
- Target specific ASINs or product categories
- Use automatic targeting to discover new opportunities
- Analyze product targeting reports for insights
- Adjust bids based on product performance

Audience Targeting:
- Leverage Amazon's audience segments
- Create custom audiences based on behavior
- Use remarketing for cart abandoners and past purchasers
- Test different audience combinations

Placement Targeting:
- Top of search (premium placement)
- Product pages (contextual placement)
- Rest of search (standard placement)
- Adjust bids by placement based on performance

Geographic Targeting:
- Target specific regions or cities
- Adjust bids by location performance
- Consider local events and seasonality
- Test different geographic segments

Time-Based Targeting:
- Analyze performance by day of week
- Adjust bids for high-performing time periods
- Consider business hours vs. off-hours
- Account for time zone differences

Device Targeting:
- Monitor performance by device type (mobile, desktop, tablet)
- Adjust bids based on device performance
- Optimize creative for different devices
- Consider mobile-first strategies for mobile-heavy categories""",
        "metadata": {
            "category": "targeting",
            "topic": "strategies"
        }
    },
    {
        "id": "reporting-analytics-001",
        "text": """Performance Reporting and Analytics:

Key Performance Indicators (KPIs):
1. ACOS (Advertising Cost of Sale):
   - Formula: (Ad Spend / Ad Revenue) × 100
   - Target: Varies by category, typically 15-30%
   - Lower is better (more efficient advertising)

2. ROAS (Return on Ad Spend):
   - Formula: Ad Revenue / Ad Spend
   - Target: Typically 3-5x or higher
   - Higher is better (more revenue per dollar spent)

3. CTR (Click-Through Rate):
   - Formula: (Clicks / Impressions) × 100
   - Benchmark: 0.3-0.5% for search ads
   - Indicates ad relevance and appeal

4. Conversion Rate:
   - Formula: (Conversions / Clicks) × 100
   - Benchmark: 10-15% for well-optimized campaigns
   - Indicates landing page and product quality

5. CPC (Cost Per Click):
   - Formula: Ad Spend / Clicks
   - Varies by category and competition
   - Monitor trends over time

Report Types:
- Campaign Reports: Overall campaign performance
- Ad Group Reports: Performance by ad group
- Keyword Reports: Performance by keyword
- Search Term Reports: Actual search queries
- Product Reports: Performance by advertised product
- Placement Reports: Performance by ad placement

Reporting Best Practices:
1. Pull reports daily for active campaigns
2. Use date ranges for trend analysis
3. Segment data by campaign type, product, or category
4. Compare performance across time periods
5. Export data for deeper analysis in spreadsheets or BI tools

Analytics Insights:
- Identify top-performing keywords and products
- Discover new keyword opportunities from search terms
- Analyze conversion paths and attribution
- Monitor competitive landscape changes
- Track seasonal trends and patterns

Custom Reporting:
- Create custom reports for specific business needs
- Schedule automated report delivery
- Set up dashboards for real-time monitoring
- Integrate with third-party analytics tools
- Use APIs for programmatic report generation""",
        "metadata": {
            "category": "reporting",
            "topic": "analytics"
        }
    },
    {
        "id": "campaign-structure-001",
        "text": """Campaign Structure Best Practices:

Hierarchical Structure:
1. Account Level:
   - Multiple profiles (one per marketplace)
   - Shared settings and billing

2. Campaign Level:
   - Campaign type (Sponsored Products, Brands, Display)
   - Budget and schedule
   - Targeting type (automatic or manual)

3. Ad Group Level:
   - Product selection
   - Keyword or product targeting
   - Bids and bid adjustments

Campaign Organization Strategies:

1. By Product Category:
   - Separate campaigns for each product category
   - Easier budget allocation and performance tracking
   - Better control over category-specific strategies

2. By Match Type:
   - Separate campaigns for exact, phrase, and broad match
   - Different bid strategies per match type
   - Clearer performance attribution

3. By Performance:
   - High-performing campaigns (proven winners)
   - Testing campaigns (new products or keywords)
   - Allows different budget allocations

4. By Funnel Stage:
   - Awareness campaigns (broad targeting)
   - Consideration campaigns (mid-funnel)
   - Conversion campaigns (bottom-funnel)

Naming Conventions:
- Use consistent, descriptive names
- Include campaign type, product, and targeting
- Example: "SP_Electronics_Headphones_Exact"
- Makes reporting and management easier

Campaign Settings:
- Daily budget: Set based on goals and performance
- Start/end dates: Use for seasonal or promotional campaigns
- Targeting: Choose automatic or manual based on goals
- Bidding strategy: Dynamic bids or fixed bids

Ad Group Organization:
- Group similar products together
- Keep ad groups focused (5-20 keywords max)
- Use single keyword ad groups (SKAGs) for high-value terms
- Maintain consistent themes within ad groups""",
        "metadata": {
            "category": "campaigns",
            "topic": "structure"
        }
    },
    {
        "id": "api-rate-limits-001",
        "text": """API Rate Limits and Throttling:

Rate Limit Tiers:
1. Standard Tier:
   - 100 requests per second per profile
   - Suitable for most applications
   - No additional approval required

2. Burst Tier:
   - 200 requests per second per profile
   - Short-term burst capacity
   - Automatically available

3. Enterprise Tier:
   - Custom rate limits available
   - Requires approval from Amazon
   - For high-volume applications

Rate Limit Headers:
- X-RateLimit-Limit: Maximum requests allowed
- X-RateLimit-Remaining: Requests remaining in current window
- X-RateLimit-Reset: Time when limit resets (Unix timestamp)

Handling Rate Limits:
1. Implement exponential backoff:
   - First retry: Wait 1 second
   - Second retry: Wait 2 seconds
   - Third retry: Wait 4 seconds
   - Max retries: 5 attempts

2. Use rate limit headers:
   - Check remaining requests before making calls
   - Pause when approaching limit
   - Resume after reset time

3. Batch operations:
   - Use bulk APIs when available
   - Combine multiple operations into single requests
   - Reduces total API calls

4. Caching:
   - Cache frequently accessed data
   - Set appropriate TTL based on data freshness needs
   - Reduces redundant API calls

Error Codes:
- 429 Too Many Requests: Rate limit exceeded
- 503 Service Unavailable: Temporary service issue

Best Practices:
- Monitor rate limit usage in your application
- Implement request queuing for high-volume operations
- Use webhooks instead of polling when available
- Distribute API calls evenly over time
- Implement circuit breakers for fault tolerance""",
        "metadata": {
            "category": "authentication",
            "topic": "rate_limits"
        }
    },
    {
        "id": "keyword-research-001",
        "text": """Advanced Keyword Research Strategies:

Keyword Discovery Methods:
1. Search Term Reports:
   - Review actual customer search queries
   - Identify high-converting search terms
   - Add relevant terms as exact match keywords
   - Build negative keyword lists from irrelevant terms

2. Competitor Analysis:
   - Analyze competitor product listings
   - Review competitor ad placements
   - Identify gaps in competitor keyword coverage
   - Target competitor brand terms (where appropriate)

3. Amazon Auto-Suggest:
   - Use Amazon search bar suggestions
   - Identify long-tail keyword opportunities
   - Discover seasonal and trending keywords
   - Find question-based keywords

4. Category Research:
   - Browse relevant product categories
   - Identify category-specific terminology
   - Target category navigation keywords
   - Use category refinement terms

Keyword Qualification Criteria:
- Relevance: Directly related to your product
- Search Volume: Sufficient monthly searches
- Competition: Manageable competitive landscape
- Intent: Matches buyer intent (informational vs. transactional)
- Profitability: Potential for positive ROI

Keyword Organization:
1. Core Keywords (5-10):
   - Primary product descriptors
   - High volume, high relevance
   - Exact match campaigns
   - Higher bids

2. Secondary Keywords (20-30):
   - Related terms and variations
   - Moderate volume
   - Phrase match campaigns
   - Medium bids

3. Long-Tail Keywords (50+):
   - Specific, detailed queries
   - Lower volume, higher conversion
   - Broad match campaigns
   - Lower bids, test and optimize

Keyword Expansion Strategies:
- Add modifiers (color, size, material, brand)
- Include use case keywords (gift, professional, beginner)
- Target problem-solution keywords
- Use seasonal and event-based keywords
- Include comparison keywords (vs, alternative, best)

Keyword Maintenance:
- Review search term reports weekly
- Add new high-performing keywords
- Pause or remove underperforming keywords
- Update bids based on performance data
- Refresh keyword lists quarterly

Advanced Techniques:
1. Keyword Harvesting:
   - Start with broad match campaigns
   - Identify high-performing search terms
   - Move winners to exact match campaigns
   - Increase bids for proven keywords

2. Keyword Sculpting:
   - Use negative keywords to control traffic
   - Prevent keyword cannibalization
   - Direct traffic to most relevant ad groups
   - Improve quality score and relevance

3. Seasonal Keyword Planning:
   - Identify seasonal trends in your category
   - Prepare keyword lists in advance
   - Adjust bids for seasonal peaks
   - Pause seasonal keywords off-season

Tools and Resources:
- Amazon Brand Analytics (for brand registered sellers)
- Third-party keyword research tools
- Google Trends for trend analysis
- Competitor monitoring tools
- Search term report analysis tools""",
        "metadata": {
            "category": "targeting",
            "topic": "keyword_research"
        }
    },
    {
        "id": "ad-creative-best-practices-001",
        "text": """Ad Creative and Copywriting Best Practices:

Sponsored Products Creative Elements:
1. Product Images:
   - Use high-quality, professional images
   - Show product from multiple angles
   - Include lifestyle images showing product in use
   - Ensure images meet Amazon's technical requirements
   - Use white background for main image
   - Add infographics for key features

2. Product Titles:
   - Include primary keywords naturally
   - Highlight key features and benefits
   - Follow Amazon's title guidelines (200 characters max)
   - Use proper capitalization
   - Include brand name, product type, key features
   - Avoid promotional language

3. Bullet Points:
   - Start with most important features
   - Use clear, concise language
   - Include relevant keywords naturally
   - Highlight unique selling propositions
   - Address customer pain points
   - Use proper formatting and spacing

Sponsored Brands Creative:
1. Headline Best Practices:
   - Keep it concise (50 characters max)
   - Include brand name and value proposition
   - Use action-oriented language
   - Test different messaging approaches
   - Avoid excessive punctuation
   - Match headline to landing page

2. Logo Requirements:
   - Use high-resolution logo
   - Ensure logo is clear and recognizable
   - Follow Amazon's logo specifications
   - Use transparent background
   - Maintain brand consistency

3. Custom Images:
   - Showcase multiple products
   - Use lifestyle imagery
   - Maintain visual consistency
   - Include text overlays sparingly
   - Follow Amazon's image guidelines
   - Test different creative variations

Sponsored Display Creative:
1. Image Selection:
   - Use eye-catching visuals
   - Show product benefits clearly
   - Include lifestyle context
   - Test different image styles
   - Ensure mobile optimization

2. Headline Copy:
   - Clear value proposition
   - Compelling call-to-action
   - Benefit-focused messaging
   - Test different angles
   - Keep it concise

A/B Testing Strategy:
1. Test One Element at a Time:
   - Images vs. images
   - Headlines vs. headlines
   - Product selection vs. product selection
   - Run tests for minimum 2 weeks
   - Ensure statistical significance

2. Testing Priorities:
   - Start with highest-impact elements
   - Test main product image first
   - Then test headlines
   - Finally test supporting images
   - Document all test results

3. Performance Metrics:
   - Click-through rate (CTR)
   - Conversion rate
   - Cost per acquisition (CPA)
   - Return on ad spend (ROAS)
   - Detail page view rate

Creative Optimization Cycle:
1. Analyze Performance:
   - Review creative metrics weekly
   - Identify underperforming elements
   - Compare against benchmarks
   - Look for patterns in top performers

2. Generate Hypotheses:
   - Why is creative underperforming?
   - What could improve performance?
   - What are competitors doing?
   - What customer feedback suggests changes?

3. Implement Changes:
   - Create new creative variations
   - Launch A/B tests
   - Monitor performance closely
   - Document changes and results

4. Scale Winners:
   - Increase budget for winning creatives
   - Apply learnings to other campaigns
   - Retire underperforming creatives
   - Continue testing new variations

Common Creative Mistakes to Avoid:
- Using low-quality or blurry images
- Overcrowding images with text
- Ignoring mobile optimization
- Not testing creative variations
- Using generic stock photos
- Inconsistent brand messaging
- Violating Amazon's creative policies
- Not updating seasonal creative
- Copying competitor creative exactly
- Neglecting product detail page optimization

Mobile Optimization:
- Ensure images are clear on small screens
- Use larger text in custom images
- Test creative on mobile devices
- Simplify messaging for mobile
- Ensure fast loading times
- Optimize for vertical viewing""",
        "metadata": {
            "category": "best_practices",
            "topic": "creative"
        }
    },
    {
        "id": "seasonal-strategy-001",
        "text": """Seasonal Campaign Strategy and Planning:

Major Shopping Events:
1. Prime Day (July):
   - Start planning 2-3 months in advance
   - Increase budgets by 200-300%
   - Create event-specific campaigns
   - Optimize for deal seekers
   - Focus on competitive pricing
   - Prepare inventory for surge

2. Black Friday / Cyber Monday (November):
   - Highest traffic period of the year
   - Increase budgets by 300-500%
   - Start campaigns early (early November)
   - Extend through Cyber Week
   - Focus on gift-oriented messaging
   - Prepare for increased competition

3. Holiday Season (November-December):
   - Plan for sustained high volume
   - Adjust budgets weekly based on performance
   - Use gift-focused keywords
   - Highlight fast shipping options
   - Create holiday-themed creative
   - Monitor inventory closely

4. Back to School (July-August):
   - Target students and parents
   - Focus on relevant product categories
   - Use education-focused keywords
   - Highlight bulk purchase options
   - Emphasize value and durability

5. New Year (January):
   - Target resolution-related products
   - Focus on self-improvement categories
   - Use "new year, new you" messaging
   - Capitalize on gift card spending
   - Clear out holiday inventory

Pre-Event Preparation (4-6 weeks before):
1. Budget Planning:
   - Analyze previous year's performance
   - Allocate additional budget for peak periods
   - Set daily budget caps to control spend
   - Plan for budget increases during event
   - Reserve contingency budget

2. Inventory Management:
   - Ensure sufficient stock levels
   - Coordinate with suppliers
   - Plan for longer lead times
   - Monitor FBA inventory limits
   - Prepare for potential stockouts

3. Campaign Structure:
   - Create event-specific campaigns
   - Separate from evergreen campaigns
   - Use event-specific keywords
   - Set up custom ad schedules
   - Prepare multiple ad variations

4. Keyword Research:
   - Identify event-specific keywords
   - Add seasonal modifiers (gift, sale, deal)
   - Research trending search terms
   - Update negative keyword lists
   - Prepare for increased competition

During Event Execution:
1. Daily Monitoring:
   - Check performance multiple times per day
   - Adjust bids based on real-time performance
   - Monitor budget pacing
   - Watch for stockouts
   - Respond to competitive changes

2. Budget Management:
   - Increase budgets for top performers
   - Pause underperforming campaigns
   - Reallocate budget dynamically
   - Set up budget alerts
   - Track spend vs. target

3. Bid Optimization:
   - Increase bids for high-converting keywords
   - Adjust for increased competition
   - Use dynamic bidding strategies
   - Monitor placement performance
   - React to competitor bid changes

4. Performance Tracking:
   - Monitor key metrics hourly
   - Compare to previous year
   - Track market share
   - Analyze competitor activity
   - Document learnings

Post-Event Analysis (1-2 weeks after):
1. Performance Review:
   - Calculate total ROAS
   - Analyze campaign-level performance
   - Review keyword performance
   - Assess creative effectiveness
   - Compare to goals and benchmarks

2. Learnings Documentation:
   - What worked well?
   - What didn't work?
   - Unexpected results?
   - Competitive insights?
   - Process improvements?

3. Optimization Actions:
   - Update evergreen campaigns with learnings
   - Adjust keyword strategies
   - Refine targeting approaches
   - Update creative based on performance
   - Plan for next event

Year-Round Seasonal Planning:
- Create annual promotional calendar
- Identify category-specific events
- Plan budget allocation by quarter
- Prepare creative assets in advance
- Build seasonal keyword lists
- Monitor industry trends
- Track competitor seasonal strategies

Category-Specific Seasonal Opportunities:
1. Fashion/Apparel:
   - Spring/Summer collections (March-April)
   - Fall/Winter collections (September-October)
   - End-of-season clearance
   - Fashion week events

2. Electronics:
   - New product launches
   - Back to school
   - Holiday gift season
   - Tax refund season (April)

3. Home/Garden:
   - Spring cleaning (March-April)
   - Summer outdoor season (May-July)
   - Fall home improvement (September-October)
   - Holiday decorating (November-December)

4. Toys/Games:
   - Holiday season (October-December)
   - Birthday season (varies by category)
   - Summer vacation activities
   - Educational toys (back to school)

Budget Allocation by Season:
- Q1 (Jan-Mar): 20% of annual budget
- Q2 (Apr-Jun): 25% of annual budget
- Q3 (Jul-Sep): 25% of annual budget (includes Prime Day)
- Q4 (Oct-Dec): 30% of annual budget (includes holidays)

Adjust based on your category's seasonal patterns.""",
        "metadata": {
            "category": "best_practices",
            "topic": "seasonal_strategy"
        }
    },
    {
        "id": "automation-rules-001",
        "text": """Campaign Automation and Rules:

Automated Bidding Strategies:
1. Dynamic Bids - Down Only:
   - Reduces bids for less likely conversions
   - Good for maintaining ACOS targets
   - Recommended for new campaigns
   - Lower risk of overspending

2. Dynamic Bids - Up and Down:
   - Increases bids for likely conversions
   - Decreases bids for unlikely conversions
   - Can increase up to 100% for top of search
   - Best for established campaigns with data

3. Fixed Bids:
   - No automatic bid adjustments
   - Full manual control
   - Best for experienced advertisers
   - Requires active management

Budget Rules:
1. Performance-Based Budget Rules:
   - Increase budget when ROAS > target
   - Decrease budget when ROAS < target
   - Set minimum and maximum budget limits
   - Review and adjust thresholds monthly

2. Time-Based Budget Rules:
   - Increase budget during peak hours
   - Decrease budget during low-conversion periods
   - Adjust for day of week patterns
   - Account for time zone differences

3. Inventory-Based Rules:
   - Reduce budget when inventory is low
   - Pause campaigns when out of stock
   - Resume when inventory replenished
   - Set inventory threshold alerts

Bid Adjustment Rules:
1. Placement Adjustments:
   - Top of search: +50% to +200%
   - Product pages: +0% to +100%
   - Rest of search: baseline bid
   - Adjust based on placement performance

2. Performance-Based Bid Rules:
   - Increase bids for keywords with ACOS < target
   - Decrease bids for keywords with ACOS > target
   - Pause keywords with no conversions after 30 days
   - Set bid floors and ceilings

3. Competitive Bid Rules:
   - Monitor competitor bid changes
   - Adjust bids to maintain position
   - Set maximum bid limits
   - Focus on profitable positions

Campaign Scheduling Rules:
1. Dayparting:
   - Identify high-performing hours
   - Increase bids during peak times
   - Decrease bids during low-conversion hours
   - Test different schedules

2. Day of Week Optimization:
   - Analyze performance by day
   - Adjust budgets for high-performing days
   - Reduce spend on low-performing days
   - Account for weekly patterns

Keyword Management Rules:
1. Automatic Keyword Harvesting:
   - Review search term reports weekly
   - Add high-performing terms as exact match
   - Set conversion threshold (e.g., 3+ conversions)
   - Maintain minimum ROAS threshold

2. Negative Keyword Automation:
   - Add terms with 0 conversions after X clicks
   - Set click threshold (e.g., 20 clicks)
   - Review and approve before applying
   - Build negative keyword lists by theme

3. Keyword Bid Optimization:
   - Increase bids for keywords with ROAS > target
   - Decrease bids for keywords with ROAS < target
   - Pause keywords with no sales after 30 days
   - Set bid change limits (e.g., max 20% per adjustment)

Portfolio Management Rules:
1. Budget Reallocation:
   - Move budget from low ROAS campaigns to high ROAS
   - Set minimum budget per campaign
   - Maintain budget diversity
   - Review weekly

2. Campaign Lifecycle Rules:
   - Launch new campaigns with conservative budgets
   - Increase budgets as performance proves out
   - Pause campaigns with sustained poor performance
   - Archive campaigns after 90 days of inactivity

Alert and Notification Rules:
1. Performance Alerts:
   - ACOS exceeds target by X%
   - Daily spend exceeds budget by X%
   - Conversion rate drops below threshold
   - Impression share drops significantly

2. Inventory Alerts:
   - Stock level below X units
   - Out of stock detected
   - Inventory replenished
   - FBA inventory limits approaching

3. Competitive Alerts:
   - Lost top of search placement
   - Significant bid increases detected
   - New competitor campaigns launched
   - Market share changes

Automation Best Practices:
1. Start Conservative:
   - Begin with small adjustments
   - Test rules on single campaigns first
   - Monitor results closely
   - Scale gradually

2. Set Guardrails:
   - Maximum bid limits
   - Minimum and maximum budgets
   - ACOS thresholds
   - Conversion requirements

3. Regular Review:
   - Review automation performance weekly
   - Adjust rules based on results
   - Disable underperforming rules
   - Document rule changes

4. Human Oversight:
   - Don't fully automate critical decisions
   - Review automated changes daily
   - Override when necessary
   - Maintain manual control options

5. Testing and Iteration:
   - A/B test automation rules
   - Compare automated vs. manual performance
   - Refine rules based on data
   - Document learnings

Common Automation Pitfalls:
- Over-automating without sufficient data
- Setting rules too aggressively
- Not monitoring automated changes
- Ignoring seasonal patterns
- Not adjusting rules over time
- Automating without clear goals
- Not setting proper guardrails
- Forgetting to review and optimize rules

Tools for Automation:
- Amazon's native automation features
- Third-party bid management tools
- Custom scripts and APIs
- Spreadsheet-based rule engines
- Machine learning optimization tools""",
        "metadata": {
            "category": "best_practices",
            "topic": "automation"
        }
    },
    {
        "id": "troubleshooting-guide-001",
        "text": """Common Issues and Troubleshooting Guide:

Low Impressions:
Symptoms:
- Campaign shows very few impressions
- Ads not appearing in search results

Possible Causes and Solutions:
1. Low Bids:
   - Check suggested bid range
   - Increase bids by 20-30%
   - Monitor for impression increase
   - Adjust based on results

2. Low Budget:
   - Check if budget is exhausted early
   - Increase daily budget
   - Monitor budget pacing
   - Consider budget rules

3. Poor Keyword Relevance:
   - Review keyword-product match
   - Add more relevant keywords
   - Remove irrelevant keywords
   - Improve product listing quality

4. Targeting Too Narrow:
   - Expand keyword list
   - Add phrase and broad match
   - Consider automatic targeting
   - Review negative keywords

5. Product Not Eligible:
   - Check product eligibility
   - Ensure product is in stock
   - Verify product is active
   - Review account health

High ACOS / Low ROAS:
Symptoms:
- Advertising cost exceeds target
- Poor return on ad spend

Possible Causes and Solutions:
1. Bids Too High:
   - Reduce bids by 10-20%
   - Focus on lower-cost placements
   - Use dynamic bidding
   - Monitor ACOS improvement

2. Poor Keyword Selection:
   - Review search term reports
   - Add negative keywords
   - Focus on high-intent keywords
   - Remove broad match keywords

3. Low Conversion Rate:
   - Optimize product listing
   - Improve product images
   - Enhance product description
   - Check pricing competitiveness
   - Review customer reviews

4. Wrong Targeting:
   - Review audience targeting
   - Refine product targeting
   - Adjust keyword match types
   - Focus on bottom-funnel keywords

Low Click-Through Rate (CTR):
Symptoms:
- High impressions but few clicks
- CTR below category average

Possible Causes and Solutions:
1. Poor Product Images:
   - Use high-quality images
   - Show product in use
   - Add lifestyle images
   - Follow Amazon's image guidelines

2. Uncompetitive Pricing:
   - Review competitor pricing
   - Adjust pricing strategy
   - Highlight value proposition
   - Consider promotions

3. Weak Product Title:
   - Include relevant keywords
   - Highlight key features
   - Follow title best practices
   - Test different titles

4. Low Product Rating:
   - Improve product quality
   - Address customer concerns
   - Encourage positive reviews
   - Respond to negative reviews

Low Conversion Rate:
Symptoms:
- Good CTR but few sales
- High traffic, low conversions

Possible Causes and Solutions:
1. Product Listing Issues:
   - Improve product description
   - Add more bullet points
   - Include A+ Content
   - Add product videos

2. Pricing Issues:
   - Review competitor pricing
   - Adjust pricing strategy
   - Offer promotions
   - Bundle products

3. Poor Reviews:
   - Address quality issues
   - Respond to reviews
   - Improve customer service
   - Encourage satisfied customers to review

4. Stock Issues:
   - Ensure consistent stock
   - Avoid stockouts
   - Use FBA for faster shipping
   - Highlight Prime eligibility

Budget Exhausted Early:
Symptoms:
- Budget runs out before end of day
- Missing sales opportunities

Possible Causes and Solutions:
1. Budget Too Low:
   - Increase daily budget
   - Analyze hourly spend patterns
   - Adjust budget based on performance
   - Use budget rules

2. Bids Too High:
   - Review and reduce bids
   - Focus on efficient keywords
   - Use dynamic bidding
   - Adjust placement multipliers

3. Inefficient Spend:
   - Add negative keywords
   - Pause underperforming campaigns
   - Focus budget on top performers
   - Improve targeting

Campaign Not Delivering:
Symptoms:
- Campaign shows as "Eligible" but no activity
- Zero impressions despite adequate budget and bids

Possible Causes and Solutions:
1. Product Issues:
   - Check product is in stock
   - Verify product is active
   - Ensure product is eligible for advertising
   - Review product detail page

2. Targeting Issues:
   - Keywords too specific
   - Negative keywords blocking traffic
   - Targeting settings too restrictive
   - Bid too low for competition

3. Account Issues:
   - Check account health
   - Verify payment method
   - Review account restrictions
   - Contact Amazon support

API Errors:
Common Error Codes and Solutions:

1. 401 Unauthorized:
   - Token expired - refresh access token
   - Invalid credentials - verify client ID/secret
   - Check OAuth scopes

2. 403 Forbidden:
   - Insufficient permissions
   - Profile not accessible
   - Check account access

3. 429 Too Many Requests:
   - Rate limit exceeded
   - Implement exponential backoff
   - Reduce request frequency
   - Use batch operations

4. 500 Internal Server Error:
   - Temporary Amazon issue
   - Retry with exponential backoff
   - Check Amazon status page
   - Contact support if persistent

5. 422 Unprocessable Entity:
   - Invalid request parameters
   - Check API documentation
   - Validate input data
   - Review error message details

Performance Degradation:
Symptoms:
- Previously successful campaign declining
- Metrics worsening over time

Possible Causes and Solutions:
1. Increased Competition:
   - Analyze competitive landscape
   - Adjust bids to maintain position
   - Differentiate product offering
   - Improve product listing

2. Seasonal Changes:
   - Adjust for seasonal patterns
   - Update keywords for season
   - Modify creative for season
   - Adjust budgets accordingly

3. Product Lifecycle:
   - Product may be maturing
   - Consider product refresh
   - Adjust pricing strategy
   - Focus on differentiation

4. Market Saturation:
   - Explore new keywords
   - Target new audiences
   - Expand to new products
   - Test new ad formats

Diagnostic Checklist:
□ Check campaign status and eligibility
□ Verify product is in stock and active
□ Review bid levels vs. suggested bids
□ Check daily budget and pacing
□ Analyze keyword relevance and performance
□ Review negative keyword lists
□ Check targeting settings
□ Verify account health and payment method
□ Review product listing quality
□ Analyze competitive landscape
□ Check for seasonal factors
□ Review recent changes to campaigns
□ Verify API credentials and permissions
□ Check rate limit usage
□ Review error logs and messages""",
        "metadata": {
            "category": "best_practices",
            "topic": "troubleshooting"
        }
    }
]


def upload_document(doc_id: str, text: str, metadata: dict):
    """Upload a single document to S3 Vectors using put_vectors API"""
    print(f"Uploading document: {doc_id}")
    
    # Generate embedding using Bedrock
    response = bedrock_runtime.invoke_model(
        modelId="amazon.titan-embed-text-v2:0",
        body=json.dumps({"inputText": text})
    )
    
    # Extract embedding from response
    response_body = json.loads(response["body"].read())
    embedding = response_body["embedding"]
    
    # Store the original text in metadata
    full_metadata = {**metadata, "text": text}
    
    # Upload to S3 Vectors using put_vectors API
    s3vectors_client.put_vectors(
        vectorBucketName=VECTOR_BUCKET_NAME,
        indexName=VECTOR_INDEX_NAME,
        vectors=[
            {
                "key": doc_id,
                "data": {"float32": embedding},
                "metadata": full_metadata
            }
        ]
    )
    
    print(f"✓ Uploaded: {doc_id}")
    return {'status': 'success', 'doc_id': doc_id}


def batch_upload_documents(documents: list):
    """Batch upload multiple documents"""
    print(f"\nUploading {len(documents)} documents to S3 Vectors...")
    print(f"Bucket: {VECTOR_BUCKET_NAME}")
    print(f"Index: {VECTOR_INDEX_NAME}\n")
    
    success_count = 0
    for doc in documents:
        try:
            upload_document(doc['id'], doc['text'], doc['metadata'])
            success_count += 1
        except Exception as e:
            print(f"✗ Error uploading {doc['id']}: {e}")
    
    print(f"\n✓ Upload complete! {success_count}/{len(documents)} documents uploaded successfully.")


def delete_document(doc_id: str):
    """Delete a document from S3 Vectors using delete_vectors API"""
    s3vectors_client.delete_vectors(
        vectorBucketName=VECTOR_BUCKET_NAME,
        indexName=VECTOR_INDEX_NAME,
        keys=[doc_id]
    )
    print(f"✓ Deleted: {doc_id}")
    return {'status': 'success'}


def test_query(query: str, top_k: int = 3):
    """Test querying the knowledge base using S3 Vectors query_vectors API"""
    print(f"\nTesting query: '{query}'")
    print(f"Top {top_k} results:\n")
    
    # Generate query embedding using Bedrock
    response = bedrock_runtime.invoke_model(
        modelId="amazon.titan-embed-text-v2:0",
        body=json.dumps({"inputText": query})
    )
    
    # Extract embedding from response
    response_body = json.loads(response["body"].read())
    query_embedding = response_body["embedding"]
    
    # Query S3 Vectors using query_vectors API
    response = s3vectors_client.query_vectors(
        vectorBucketName=VECTOR_BUCKET_NAME,
        indexName=VECTOR_INDEX_NAME,
        queryVector={"float32": query_embedding},
        topK=top_k,
        returnDistance=True,
        returnMetadata=True
    )
    
    # Display results
    for i, match in enumerate(response.get('vectors', []), 1):
        print(f"[Result {i}] Distance: {match.get('distance', 'N/A'):.4f}")
        print(f"Key: {match.get('key', 'N/A')}")
        metadata = match.get('metadata', {})
        print(f"Category: {metadata.get('category', 'N/A')}")
        print(f"Topic: {metadata.get('topic', 'N/A')}")
        text = metadata.get('text', '')
        print(f"Text: {text[:200]}...")
        print("-" * 80)


def test_query_with_filter(query: str, category: str, top_k: int = 3):
    """Test querying with metadata filter"""
    print(f"\nTesting query with filter: '{query}' (category={category})")
    print(f"Top {top_k} results:\n")
    
    # Generate query embedding using Bedrock
    response = bedrock_runtime.invoke_model(
        modelId="amazon.titan-embed-text-v2:0",
        body=json.dumps({"inputText": query})
    )
    
    # Extract embedding from response
    response_body = json.loads(response["body"].read())
    query_embedding = response_body["embedding"]
    
    # Query S3 Vectors with metadata filter
    response = s3vectors_client.query_vectors(
        vectorBucketName=VECTOR_BUCKET_NAME,
        indexName=VECTOR_INDEX_NAME,
        queryVector={"float32": query_embedding},
        topK=top_k,
        filter={"category": category},
        returnDistance=True,
        returnMetadata=True
    )
    
    # Display results
    for i, match in enumerate(response.get('vectors', []), 1):
        print(f"[Result {i}] Distance: {match.get('distance', 'N/A'):.4f}")
        print(f"Key: {match.get('key', 'N/A')}")
        metadata = match.get('metadata', {})
        print(f"Category: {metadata.get('category', 'N/A')}")
        print(f"Topic: {metadata.get('topic', 'N/A')}")
        text = metadata.get('text', '')
        print(f"Text: {text[:200]}...")
        print("-" * 80)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python upload_knowledge.py upload              # Upload sample documents")
        print("  python upload_knowledge.py test                # Test query")
        print("  python upload_knowledge.py test-filter         # Test query with category filter")
        print("  python upload_knowledge.py delete <doc_id>     # Delete document")
        print(f"\nAvailable documents: {len(SAMPLE_DOCUMENTS)}")
        print("Categories: profiles, campaigns, budgets, targeting, authentication, reporting, best_practices")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "upload":
        batch_upload_documents(SAMPLE_DOCUMENTS)
    
    elif command == "test":
        test_query("How do I manage advertising profiles?")
        test_query("What are campaign optimization best practices?")
        test_query("How do I handle API rate limits?")
    
    elif command == "test-filter":
        test_query_with_filter("How do I optimize campaigns?", "campaigns")
        test_query_with_filter("Tell me about authentication", "authentication")
        test_query_with_filter("What are keyword research strategies?", "targeting")
    
    elif command == "delete" and len(sys.argv) > 2:
        doc_id = sys.argv[2]
        delete_document(doc_id)
    
    else:
        print("Invalid command")
        sys.exit(1)
