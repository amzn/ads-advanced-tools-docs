# Orchestration A2A Agent - A2A Client with Dynamic Tool Discovery

Orchestration agent that acts as an **A2A CLIENT** to communicate with A2A server sub-agents. Built with pure LangGraph and uses HTTP protocol. **Dynamically discovers and creates tools from A2A agent cards at startup.**

## Features

- **Pure LangGraph**: Consistent with other agents
- **HTTP Protocol**: Port 8080, BedrockAgentCoreApp
- **A2A Client**: Calls sub-agents using A2A JSON-RPC protocol
- **Dynamic Tool Discovery**: Fetches agent cards and creates tools from skills automatically
- **Direct HTTP A2A Calls**: Uses SigV4 authentication to call sub-agents
- **Unified Interface**: Presents seamless experience to users
- **Automatic Scaling**: Tools scale with agent capabilities - no hardcoding!

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│     Orchestration Agent (HTTP - A2A Client)                 │
│                                                             │
│  HTTP Server (BedrockAgentCoreApp on port 8080):           │
│  - Accepts simple prompts: {"prompt": "..."}               │
│  - NOT an A2A server (no JSON-RPC endpoint)                │
│                                                             │
│  Startup: Fetch Agent Cards                                │
│  1. GET /.well-known/agent-card.json from custom agent    │
│  2. GET /.well-known/agent-card.json from remote agent    │
│  3. Extract skills from both agent cards                   │
│  4. Create LangChain tool for each skill                   │
│                                                             │
│  LangGraph with N dynamically created tools:               │
│  - custom_ads_agent_skill_1                                │
│  - custom_ads_agent_skill_2                                │
│  - ...                                                     │
│  - remote_ads_agent_skill_1                                │
│  - remote_ads_agent_skill_2                                │
│  - ...                                                     │
│                                                             │
│  Each tool calls sub-agent via A2A JSON-RPC:               │
│  - HTTP POST with SigV4 auth                               │
│  - SendMessage method (A2A protocol)                       │
│  - Extract text from response                              │
└─────────────────────────────────────────────────────────────┘
                    │                    │
                    │ A2A JSON-RPC       │ A2A JSON-RPC
                    ▼                    ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│  Custom A2A Agent        │  │  Remote A2A Agent        │
│  (8 skills, SigV4)       │  │  (46 skills, OAuth)      │
│  Port 9000 (A2A Server)  │  │  Port 9000 (A2A Server)  │
│  Agent Card with skills  │  │  Agent Card with skills  │
└──────────────────────────┘  └──────────────────────────┘
```

## Key Difference: HTTP vs A2A

| Aspect | Orchestration Agent | Sub-Agents |
|--------|-------------------|------------|
| Protocol | **HTTP** | **A2A** |
| Port | 8080 | 9000 |
| Role | **A2A Client** | **A2A Server** |
| Input Format | Simple prompts | A2A JSON-RPC |
| Output Format | Plain text | A2A JSON-RPC |
| Agent Card | No | Yes |
| Tool Discovery | Fetches from sub-agents | Publishes skills |

## Prerequisites

Deploy the A2A sub-agents first:

1. **Custom A2A Agent** (`custom-ads-a2a-agent/`)
   ```bash
   cd custom-ads-a2a-agent
   agentcore deploy
   ```

2. **Remote A2A Agent** (`mcp-ads-a2a-agent/`)
   ```bash
   cd mcp-ads-a2a-agent
   agentcore deploy
   ```

Get their ARNs from the deployment output.

## Configuration

Create `.env` file with deployed A2A agent ARNs:

```bash
CUSTOM_A2A_AGENT_ARN=arn:aws:bedrock-agentcore:us-east-1:YOUR_ACCOUNT_ID:runtime/YOUR_CUSTOM_ADS_AGENT_ID
REMOTE_A2A_AGENT_ARN=arn:aws:bedrock-agentcore:us-east-1:YOUR_ACCOUNT_ID:runtime/YOUR_MCP_ADS_AGENT_ID
```

## How It Works

### 1. Agent Card Discovery (Startup)
At startup, the orchestration agent fetches agent cards from both A2A sub-agents:

```python
# Fetch agent cards via A2A protocol
custom_agent_card = fetch_agent_card(CUSTOM_A2A_AGENT_ARN)
# GET https://bedrock-agentcore.../invocations/.well-known/agent-card.json

remote_agent_card = fetch_agent_card(REMOTE_A2A_AGENT_ARN)
# GET https://bedrock-agentcore.../invocations/.well-known/agent-card.json

# Extract skills from agent cards
custom_skills = custom_agent_card['skills']  # e.g., 8 skills
remote_skills = remote_agent_card['skills']  # e.g., 46 skills
```

### 2. Dynamic Tool Creation
Each skill in the agent cards becomes a LangChain tool:

```python
for skill in agent_card['skills']:
    tool = StructuredTool(
        name=f"{agent_name}_{skill['id']}",
        description=f"{skill['description']}\n\nTags: {skill['tags']}\n\nExamples:\n{skill['examples']}",
        func=lambda query: call_a2a_agent_sync(
            agent_arn, 
            f"[Skill: {skill['id']}] {query}"
        )
    )
```

**Tool Naming Pattern:** `{agent_name}_{skill_id}`
- Example: `custom_ads_agent_list_profiles`
- Example: `remote_ads_agent_performance_reports`

**Tool Description:** Includes skill description, tags, and examples from agent card

### 3. User Query
User sends query to orchestration agent via HTTP protocol.

### 4. LLM Tool Selection
LLM analyzes query and selects appropriate tool based on:
- Skill descriptions from agent cards
- Tags (e.g., "profiles", "campaigns", "analytics")
- Examples from agent cards
- User intent

### 5. A2A Sub-Agent Call
Selected tool calls sub-agent using A2A JSON-RPC:

```python
def call_a2a_agent_sync(agent_arn: str, message: str) -> str:
    # Build A2A JSON-RPC request
    a2a_request = {
        "jsonrpc": "2.0",
        "method": "SendMessage",
        "params": {
            "message": {
                "messageId": "msg-123",
                "role": "user",
                "parts": [{"text": message}]
            }
        },
        "id": 1
    }
    
    # Sign with SigV4 and send
    response = requests.post(endpoint, data=body, headers=signed_headers)
    
    # Extract text from A2A response (Task or Message)
    return response_text
```

### 6. Response
Sub-agent executes skill and returns result via A2A protocol. Orchestration agent returns unified response to user.

## Local Testing

### Start Server
```bash
python orchestration_a2a.py
```

The server will start on port 8080 (HTTP protocol).

**Note:** Requires deployed A2A sub-agents (can't run fully local).

### Test with agentcore
```bash
# Simple prompt format (recommended)
agentcore invoke '{"prompt": "list all my profiles"}'
```

### Test with curl
```bash
# Simple prompt format
curl -X POST http://localhost:8080/ \
  -H "Content-Type: application/json" \
  -d '{"prompt": "list all my profiles"}'
```

## Deployment

### Deploy
```bash
agentcore deploy
```

### Test
```bash
agentcore invoke '{"prompt": "list all my profiles"}'
```

### View Logs
```bash
agentcore logs --follow
```

## Tool Selection Logic

The LLM intelligently routes queries based on dynamically discovered skills:

| Query Type | Example Tool Selected | Reason |
|-----------|----------------------|---------|
| "list profiles" | custom_ads_agent_list_profiles | Skill description matches |
| "campaign metrics" | custom_ads_agent_get_campaign_metrics | Tags include "campaigns", "metrics" |
| "performance report" | remote_ads_agent_performance_reports | Skill description for analytics |
| "forecast budget" | remote_ads_agent_forecasting | Tags include "forecasting" |

## Key Implementation Details

### Agent Card Fetching
```python
def fetch_agent_card(agent_arn: str) -> Dict[str, Any]:
    url = f"https://bedrock-agentcore.{region}.amazonaws.com/runtimes/{encoded_arn}/invocations/.well-known/agent-card.json"
    
    # Sign with SigV4
    response = requests.get(url, headers=signed_headers)
    
    return response.json()
```

### Dynamic Tool Creation
```python
def create_tools_from_agent_card(agent_arn, agent_card):
    tools = []
    for skill in agent_card['skills']:
        tool = StructuredTool(
            name=f"{agent_name}_{skill['id']}",
            description=build_description(skill),
            func=make_tool_func(agent_arn, skill['id'])
        )
        tools.append(tool)
    return tools
```

### HTTP Server (BedrockAgentCoreApp)
```python
from bedrock_agentcore.runtime import BedrockAgentCoreApp

app = BedrockAgentCoreApp()

@app.entrypoint
async def orchestration_agent(payload):
    user_input = payload.get("prompt")
    result = await agent.ainvoke({"messages": [HumanMessage(content=user_input)]})
    return result["messages"][-1].content

if __name__ == "__main__":
    app.run()
```

### A2A Client Communication
```python
def call_a2a_agent_sync(agent_arn, message):
    # Direct HTTP with SigV4 (no a2a-client library)
    # Sends A2A JSON-RPC SendMessage
    # Returns extracted text response
```

## Comparison with Other Agents

| Feature | custom-ads-a2a-agent | mcp-ads-a2a-agent | orchestration-a2a-agent |
|---------|---------------------|-------------------|------------------------|
| Framework | Pure LangGraph | Pure LangGraph | Pure LangGraph |
| Protocol | **A2A** (port 9000) | **A2A** (port 9000) | **HTTP** (port 8080) |
| Role | A2A Server | A2A Server | **A2A Client** |
| Tools | 8 (from MCP) | 46 (from MCP) | **N (from agent cards)** |
| MCP Server | Custom (SigV4) | Remote (OAuth) | N/A |
| Sub-Agents | None | None | 2 A2A agents |
| Purpose | Profile/Campaign | Advanced Analytics | Orchestration |
| Agent Card | Yes (publishes skills) | Yes (publishes skills) | No (consumes skills) |
| Tool Discovery | N/A | N/A | **Dynamic from agent cards** |

## Benefits

1. **No Hardcoding**: Tools are discovered automatically from agent cards
2. **Automatic Scaling**: Adding skills to sub-agents automatically adds tools
3. **Consistent Architecture**: Pure LangGraph like other agents
4. **HTTP Protocol**: Simple interface for orchestration
5. **A2A Client**: Properly calls A2A servers using JSON-RPC
6. **Direct HTTP**: No a2a-client library needed
7. **Unified Experience**: Users see seamless interface
8. **Clear Separation**: HTTP client orchestrates A2A servers
9. **Maintainable**: No need to update orchestration when sub-agents change

## Troubleshooting

### Issue: Orchestration agent can't reach sub-agents

**Check:**
1. Verify sub-agents are deployed
2. Check ARNs in orchestration `.env`
3. Verify IAM permissions
4. Check sub-agent logs for errors

**Solution:**
```bash
# Verify sub-agent ARNs
cd custom-ads-a2a-agent
agentcore status

cd mcp-ads-a2a-agent
agentcore status

# Update orchestration .env
cd orchestration-a2a-agent
cat .env
```

### Issue: Agent card fetch fails

**Check:**
1. Verify sub-agents have agent cards at `/.well-known/agent-card.json`
2. Check SigV4 authentication
3. Verify network connectivity

**Solution:**
```bash
# Test agent card endpoint manually
curl <agent-card-url>
```

### Issue: No tools created

**Check:**
1. Verify agent cards have `skills` array
2. Check logs for tool creation messages
3. Verify skill format in agent cards

**Solution:**
```bash
# Check orchestration logs
agentcore logs --follow | grep "Creating tools"
```

### Issue: Tools not executing

**Check:**
1. Verify tool names in logs
2. Check A2A call format
3. Verify sub-agent responses

**Solution:**
```bash
# Check logs for A2A calls
agentcore logs --follow | grep "A2A"
```

## Dependencies

```
langchain-aws
langgraph
bedrock-agentcore
python-dotenv
boto3
pydantic
requests
```

No a2a-client, no httpx, no FastAPI/uvicorn - just pure HTTP with BedrockAgentCoreApp!

## Next Steps

1. ✅ Deploy custom A2A agent
2. ✅ Deploy remote A2A agent
3. ✅ Update `.env` with ARNs
4. ✅ Deploy orchestration agent
5. 📋 Test end-to-end flows
6. 📋 Monitor performance
7. 📋 Optimize based on usage
8. 📋 Add more sub-agents (tools scale automatically!)

## Related Documentation

- [Custom A2A Agent](../custom-ads-a2a-agent/README.md)
- [Remote A2A Agent](../mcp-ads-a2a-agent/README.md)
- [A2A Index](../A2A_INDEX.md)
- [A2A Deployment Guide](../A2A_DEPLOYMENT_GUIDE.md)
- [A2A Protocol Specification](https://a2a-protocol.org/latest/specification/)
