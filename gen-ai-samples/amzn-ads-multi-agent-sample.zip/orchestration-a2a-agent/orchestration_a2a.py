"""
Lightweight Orchestration Agent - Fast Multi-Agent Router

Performance Optimizations Applied:
- uvloop for 2-4x event loop performance
- Optimized HTTP connection pooling (20/50 connections)
- Boto3 session reuse (singleton pattern)
- Credential caching with expiry handling
- Parallel agent card fetching
- ORJSONResponse for faster JSON serialization (if using FastAPI)
- Minimal overhead routing logic
"""
import uvloop
uvloop.install()  # Install uvloop BEFORE other imports

from langchain.agents import create_agent
from langgraph_checkpoint_aws import AgentCoreMemorySaver, AgentCoreMemoryStore
from langchain_core.tools import StructuredTool
from langchain_aws import ChatBedrock
from bedrock_agentcore.runtime import BedrockAgentCoreApp
import os
import urllib.parse
from pydantic import Field, create_model
import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.config import Config
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import json
import logging
import uuid
import time

app = BedrockAgentCoreApp()
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Suppress noisy boto3/botocore credential logs
logging.getLogger('botocore.credentials').setLevel(logging.WARNING)
logging.getLogger('botocore.httpsession').setLevel(logging.WARNING)

# ============================================================================
# AGENT CONFIGURATION
# ============================================================================

def get_agent_runtime_arn(runtime_name: str, region: str = "us-east-1") -> str:
    """Get AgentCore runtime ARN from SSM Parameter Store"""
    ssm = boto3.client('ssm', region_name=region)
    try:
        ssm_name = f"/ads/agent-arn/{runtime_name}"
        response = ssm.get_parameter(Name=ssm_name)
        arn = response['Parameter']['Value']
        logger.info(f"Found runtime ARN for '{runtime_name}': {arn}")
        return arn
    except Exception as e:
        logger.error(f"Error fetching runtime ARN for '{runtime_name}' from SSM: {e}")
        raise


def get_memory_arn(memory_name: str, region: str = "us-east-1") -> str:
    """Get AgentCore memory ARN from SSM Parameter Store"""
    ssm = boto3.client('ssm', region_name=region)
    try:
        ssm_name = f"/ads/memory-arn/{memory_name}"
        response = ssm.get_parameter(Name=ssm_name)
        arn = response['Parameter']['Value']
        logger.info(f"Found memory ARN for '{memory_name}': {arn}")
        return arn
    except Exception as e:
        logger.error(f"Error fetching memory ARN for '{memory_name}' from SSM: {e}")
        raise


# SSM parameter names mapping agent display names to their SSM paths
_SSM_ARN_MAPPING = {
    "Custom Ads Agent": "/ads/agent-arn/custom-ads-a2a-agent",
    "Remote MCP Ads Agent": "/ads/agent-arn/mcp-ads-a2a-agent",
    "S3 Vectors Knowledge Agent": "/ads/agent-arn/s3-vectors-a2a-agent",
    "RDS Campaign Agent": "/ads/agent-arn/custom-ads-rds-mcp-agent",
}

AGENT_DESCRIPTIONS = {
    "Custom Ads Agent": "Manages advertising profiles and campaigns (CRUD operations)",
    "Remote MCP Ads Agent": "Provides analytics, reports, and performance metrics",
    "S3 Vectors Knowledge Agent": "Answers 'how to' questions and provides documentation",
    "RDS Campaign Agent": "Database operations for campaign data (list tables, execute queries, describe schema)",
}

# Resolve all ARNs from SSM in a single batch call
logger.info("Resolving agent runtime ARNs from SSM...")
_ssm_client = boto3.client('ssm', region_name='us-east-1')
try:
    _ssm_response = _ssm_client.get_parameters(
        Names=list(_SSM_ARN_MAPPING.values()) + ['/ads/memory-arn/orchestration-a2a-agent']
    )
    _ssm_params = {p['Name']: p['Value'] for p in _ssm_response['Parameters']}
except Exception as e:
    logger.error(f"Failed to fetch ARNs from SSM: {e}")
    _ssm_params = {}

AGENTS_CONFIG = []
for agent_name, ssm_path in _SSM_ARN_MAPPING.items():
    arn = _ssm_params.get(ssm_path)
    if not arn:
        logger.warning(f"  {agent_name}: ARN not found at {ssm_path}")
        continue
    AGENTS_CONFIG.append({
        "name": agent_name,
        "arn": arn,
        "description": AGENT_DESCRIPTIONS[agent_name],
    })
    logger.info(f"  {agent_name}: {arn}")

# Memory Configuration
MEMORY_ARN = _ssm_params.get('/ads/memory-arn/orchestration-a2a-agent')
if not MEMORY_ARN:
    logger.warning("Memory ARN not found in SSM, trying env var...")
    MEMORY_ARN = os.getenv('MEMORY_ARN', '')
    if not MEMORY_ARN:
        raise Exception("Memory ARN not found. Deploy orchestration agent first or set MEMORY_ARN env var.")
MEMORY_ID = MEMORY_ARN.split('/')[-1]
AWS_REGION = "us-east-1"

# Module-level constants (performance optimization)
LOG_SEPARATOR = "=" * 60

# Initialize AgentCore Memory
checkpointer = AgentCoreMemorySaver(memory_id=MEMORY_ID, region_name=AWS_REGION)
store = AgentCoreMemoryStore(memory_id=MEMORY_ID, region_name=AWS_REGION)

logger.info(LOG_SEPARATOR)
logger.info("LIGHTWEIGHT ORCHESTRATION AGENT")
logger.info(LOG_SEPARATOR)
logger.info(f"Configured Agents: {len(AGENTS_CONFIG)}")
for agent in AGENTS_CONFIG:
    logger.info(f"  • {agent['name']}")
logger.info(f"Memory: {MEMORY_ID}")
logger.info(LOG_SEPARATOR)


# ============================================================================
# Helper Functions & Constants
# ============================================================================

# Boto3 session caching (saves 20-30ms per request)
_boto3_session = None
_frozen_credentials = None
_credentials_expiry = 0

# HTTP session with connection pooling (saves 50-100ms per request)
_http_session = None

def get_http_session():
    """Get or create HTTP session with optimized connection pooling"""
    global _http_session
    if _http_session is None:
        _http_session = requests.Session()
        
        # Optimized adapter configuration
        adapter = HTTPAdapter(
            pool_connections=20,  # One pool per agent + buffer
            pool_maxsize=50,      # Higher limit for concurrent requests
            pool_block=False,     # Fail fast instead of blocking
            max_retries=Retry(
                total=3,
                backoff_factor=0.3,  # More reasonable: 0.3s, 0.6s, 1.2s
                status_forcelist=[429, 500, 502, 503, 504],  # Include 429 (rate limit)
                allowed_methods=["GET", "POST"]
            )
        )
        
        _http_session.mount('https://', adapter)
        _http_session.mount('http://', adapter)
    return _http_session


def get_signed_request(method: str, url: str, body: bytes = None) -> dict:
    """Create SigV4 signed request headers with credential caching"""
    global _boto3_session, _frozen_credentials, _credentials_expiry
    
    import time
    current_time = time.time()
    
    # Initialize session once
    if _boto3_session is None:
        _boto3_session = boto3.Session()
    
    # Refresh credentials if expired (with 5 min buffer)
    if _frozen_credentials is None or current_time > (_credentials_expiry - 300):
        credentials = _boto3_session.get_credentials()
        _frozen_credentials = credentials.get_frozen_credentials()
        _credentials_expiry = current_time + 3600  # IAM role credentials expire after 1 hour
    
    headers = {'Accept': 'application/json'}
    if body:
        headers.update({'Content-Type': 'application/json', 'A2A-Version': '0.3'})
    
    aws_request = AWSRequest(method=method, url=url, data=body, headers=headers)
    SigV4Auth(_frozen_credentials, 'bedrock-agentcore', AWS_REGION).add_auth(aws_request)
    return dict(aws_request.headers)


def fetch_agent_card(agent_arn: str, agent_name: str) -> dict:
    """Fetch agent card from A2A agent"""
    try:
        encoded_arn = urllib.parse.quote(agent_arn, safe='')
        url = f"https://bedrock-agentcore.{AWS_REGION}.amazonaws.com/runtimes/{encoded_arn}/invocations/.well-known/agent-card.json"
        
        logger.info(f"Fetching agent card: {agent_name} URL: {url[:120]}...")
        headers = get_signed_request('GET', url)
        session = get_http_session()  # Use connection pooling
        response = session.get(url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            logger.warning(f"Failed to fetch agent card for {agent_name}: {response.status_code} - {response.text[:500]}")
            return None
        
        agent_card = response.json()
        logger.info(f"✓ Fetched: {agent_name} ({len(agent_card.get('skills', []))} skills)")
        return agent_card
    except Exception as e:
        logger.error(f"Error fetching agent card for {agent_name}: {e}")
        return None


def call_a2a_agent(agent_arn: str, agent_name: str, message: str) -> str:
    """Call A2A agent - direct, no retries or caching"""
    try:
        logger.info(f"→ Calling {agent_name}...")
        logger.info(f"→ Message being sent: '{message}'")
        logger.info(f"→ Message length: {len(message)} characters")
        
        encoded_arn = urllib.parse.quote(agent_arn, safe='')
        url = f"https://bedrock-agentcore.{AWS_REGION}.amazonaws.com/runtimes/{encoded_arn}/invocations"
        
        a2a_request = {
            "jsonrpc": "2.0",
            "method": "SendMessage",
            "params": {
                "message": {
                    "messageId": f"msg-{hash(message)}",
                    "role": "user",
                    "parts": [{"text": message}]
                }
            },
            "id": 1
        }
        
        headers = get_signed_request('POST', url, json.dumps(a2a_request).encode('utf-8'))
        session = get_http_session()  # Use connection pooling
        
        logger.info(f"→ Calling {agent_name}...")
        response = session.post(url, json=a2a_request, headers=headers, timeout=300)
        
        if response.status_code != 200:
            logger.error(f"A2A call failed: {response.status_code}")
            return f"Error: Agent call failed with status {response.status_code}"
        
        result = response.json()
        
        try:
            message_obj = result["result"]["status"]["message"]
            parts = message_obj.get("parts", [])
            text = next((p["text"] for p in parts if "text" in p), "No response")
            logger.info(f"✓ Response from {agent_name}: {text[:100]}...")
            return text
        except (KeyError, TypeError, StopIteration):
            logger.warning(f"Unexpected response format from {agent_name}")
            return "Error: Unexpected response format"
    except Exception as e:
        logger.error(f"Error calling {agent_name}: {e}")
        return f"Error: {str(e)}"


def create_a2a_tool(agent_config: dict, skill: dict) -> StructuredTool:
    """Create LangChain tool from agent skill"""
    agent_arn = agent_config['arn']
    agent_name = agent_config['name']
    
    skill_id = skill['id']
    skill_name = skill.get('name', 'Unknown')
    skill_description = skill.get('description', '')
    skill_tags = skill.get('tags', [])
    skill_examples = skill.get('examples', [])
    
    # Build comprehensive description (optimized - single join instead of concatenation)
    parts = [f"[{agent_name}] {skill_description}"]
    if skill_tags:
        parts.append(f"Tags: {', '.join(skill_tags)}")
    if skill_examples:
        parts.append(f"Examples: {', '.join(skill_examples[:2])}")
    description = '\n'.join(parts)
    
    def tool_func(query: str) -> str:
        # Log what we're sending to help debug
        logger.info(f"Tool called with query parameter: '{query}'")
        logger.info(f"Query length: {len(query)} characters")
        
        # Pass query directly to agent without modification
        response = call_a2a_agent(agent_arn, agent_name, query)
        return response
    
    # Create safe tool name (optimized - partition is faster than split for first element)
    first_word = agent_name.partition(' ')[0]
    prefix = first_word.lower()[:10]
    max_skill_len = 63 - len(prefix) - 1
    truncated_id = skill_id[:max_skill_len] if len(skill_id) > max_skill_len else skill_id
    tool_name = f"{prefix}_{truncated_id}".replace('-', '_').replace(' ', '_')
    
    return StructuredTool(
        name=tool_name,
        description=description,
        func=tool_func,
        args_schema=create_model(
            f"{skill_id}_args",
            query=(str, Field(description=f"The FULL ORIGINAL user query/request, passed exactly as the user wrote it. Example: if user says 'list 5 profiles', pass 'list 5 profiles' here."))
        ),
        return_direct=True  # Return tool output directly without LLM post-processing
    )


def create_memory_search_tool() -> StructuredTool:
    """Create a tool for searching past conversation memories"""
    
    def search_memories(query: str, actor_id: str = "default-user") -> str:
        """Search through past conversation memories for relevant context"""
        try:
            namespace = ("memories", actor_id)
            memories = store.search(namespace, query=query, limit=3)
            
            if not memories:
                return "No relevant past conversations found."
            
            # Optimized: Use walrus operator to cache data and avoid repeated access
            results = [
                f"{i}. {(data := mem.value['data'])[:200]}{'...' if len(data) > 200 else ''}"
                for i, mem in enumerate(memories[:3], 1)
                if mem.value and 'data' in mem.value and (data := mem.value['data'])
            ]
            
            return "\n".join(results) if results else "No relevant past conversations found."
        except Exception as e:
            logger.warning(f"Memory search failed: {e}")
            return f"Memory search unavailable: {str(e)}"
    
    return StructuredTool(
        name="search_conversation_memory",
        description="Search through past conversations to find relevant context.",
        func=search_memories,
        args_schema=create_model(
            "MemorySearchArgs",
            query=(str, Field(description="What to search for in past conversations")),
            actor_id=(str, Field(default="default-user", description="User ID for memory search"))
        ),
        return_direct=True  # Return tool output directly without LLM post-processing
    )


# ============================================================================
# Build Orchestration Agent (Lazy Initialization)
# ============================================================================

agent = None
_system_prompt = None
_agent_cards_cache = {}


def _fetch_all_agent_cards() -> dict:
    """Fetch and cache all agent cards in parallel"""
    global _agent_cards_cache
    
    if _agent_cards_cache:
        return _agent_cards_cache
    
    logger.info("Fetching agent cards in parallel...")
    
    import concurrent.futures
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(AGENTS_CONFIG)) as executor:
        future_to_agent = {
            executor.submit(fetch_agent_card, agent['arn'], agent['name']): agent
            for agent in AGENTS_CONFIG
        }
        
        for future in concurrent.futures.as_completed(future_to_agent):
            agent_config = future_to_agent[future]
            agent_name = agent_config['name']
            
            try:
                agent_card = future.result()
                if agent_card:
                    _agent_cards_cache[agent_name] = {
                        'config': agent_config,
                        'card': agent_card
                    }
            except Exception as e:
                logger.error(f"Failed to fetch agent card for {agent_name}: {e}")
    
    logger.info(f"✓ Fetched {len(_agent_cards_cache)} agent cards")
    
    return _agent_cards_cache


def _initialize_agent():
    """Initialize agent once (called on first request)"""
    global agent, _system_prompt
    
    if agent is not None:
        return agent
    
    logger.info(LOG_SEPARATOR)
    logger.info("INITIALIZING ORCHESTRATION AGENT")
    logger.info(LOG_SEPARATOR)
    
    # Fetch all agent cards in parallel
    agent_cards = _fetch_all_agent_cards()
    
    if not agent_cards:
        logger.error("No agent cards fetched!")
        raise Exception("Failed to fetch any agent cards")
    
    # Create tools from all agents (optimized with list comprehension)
    logger.info("Creating tools...")
    all_tools = [
        create_a2a_tool(agent_data['config'], skill)
        for agent_data in agent_cards.values()
        for skill in agent_data['card'].get('skills', [])
    ]
    
    # Add memory search tool
    all_tools.append(create_memory_search_tool())
    
    logger.info(f"✓ {len(all_tools)} tools created")
    
    # Initialize LLM with optimized boto3 config (Sonnet for reliable tool calling)
    logger.info("Initializing LLM (Sonnet for reliable tool calling)...")
    config = Config(
        max_pool_connections=50,  # Increased for async concurrency
        retries={'max_attempts': 3, 'mode': 'adaptive'},  # Adaptive retries
        connect_timeout=5,   # Fail fast
        read_timeout=30,     # Reasonable timeout
        tcp_keepalive=True   # Keep connections alive
    )
    
    llm = ChatBedrock(
        model_id='us.anthropic.claude-sonnet-4-5-20250929-v1:0',  # US inference profile for Sonnet 4.5
        region_name='us-west-2',
        model_kwargs={
            "temperature": 0,
            "max_tokens": 1024  # Routing doesn't need long responses
        },
        config=config
    )
    
    # Build agent descriptions dynamically from agent cards
    agent_descriptions = []
    for name, data in agent_cards.items():
        desc = data['card'].get('description', 'No description')
        skills = data['card'].get('skills', [])
        skill_names = [s.get('name', s.get('id', '')) for s in skills[:3]]
        skill_text = ', '.join(skill_names) if skill_names else 'No skills listed'
        agent_descriptions.append(f"• {name}: {desc}\n  Example skills: {skill_text}")

    agent_desc_text = '\n'.join(agent_descriptions)
    
    system_prompt = f"""You are a ROUTING SPECIALIST. Your ONLY job is selecting the right agent.

AVAILABLE AGENTS:
{agent_desc_text}

ROUTING LOGIC:
1. Analyze user query to identify PRIMARY intent (the main action requested)
2. Match PRIMARY intent to ONE agent:
   • Custom Ads Agent → profile/campaign CRUD (create, read, update, delete)
   • Remote MCP Agent → analytics, reports, billing data, performance metrics
   • S3 Vectors Agent → "how to" questions, best practices, documentation, explanations
3. Call the selected agent's tool ONCE with the FULL ORIGINAL user query (do not modify or paraphrase)
4. Return the agent's response VERBATIM - do not modify, summarize, or enhance

CRITICAL: When calling a tool, pass the EXACT user query as the 'query' parameter.
Example:
- User says: "list 5 profiles"
- You call: custom_list_profiles(query="list 5 profiles")  ← EXACT COPY
- NOT: custom_list_profiles(query="list profiles")  ← WRONG, missing "5"
- NOT: custom_list_profiles(query="show me the profiles")  ← WRONG, paraphrased

STRICT RULES (enforced by recursion_limit=15):
- Make EXACTLY ONE tool call per request
- Pass the FULL ORIGINAL user query to the tool (word-for-word)
- If query spans multiple agents, choose the PRIMARY intent:
  Example: "Create a campaign and show performance" → PRIMARY is "create" → Custom Ads Agent
  (User can ask for performance separately)
- If no agent fits, respond: "I can help with: (1) managing profiles/campaigns, (2) analytics/reporting, or (3) documentation/best practices. Please clarify your request."
- NEVER call multiple agents in sequence
- NEVER try to combine or refine agent responses
- NEVER answer questions yourself - always delegate to an agent

FORBIDDEN ACTIONS:
- Calling multiple tools (recursion_limit prevents this)
- Modifying or summarizing agent responses
- Paraphrasing or shortening the user query when calling tools
- Answering without delegating to an agent
- Retrying failed calls (let user retry with clarification)
- Processing or filtering agent responses

ROUTING EXAMPLES:
"Show me my profiles" → custom_list_profiles (Custom Ads Agent)
"Campaign performance last week" → remote_reporting_campaign_metrics (Remote MCP Agent)
"How do I optimize budgets?" → s3vectors_search_knowledge (S3 Vectors Agent)
"Create a campaign and show performance" → custom_create_campaign (Custom Ads Agent - PRIMARY intent)
"What's my spend and how to reduce it?" → remote_analytics_spend (Remote MCP Agent - PRIMARY intent is data)

VALIDATION (before calling tool):
- Is this query within ANY agent's scope?
- Which agent is the BEST fit for the PRIMARY intent?
- Am I passing the FULL user query to the agent (not just part of it)?
- Am I making only ONE tool call?"""
    
    # Store system prompt for use in invoke calls
    _system_prompt = system_prompt
    
    # Build agent with system_prompt parameter (handles deduplication internally)
    logger.info("Building agent...")
    
    agent = create_agent(
        model=llm,
        tools=all_tools,
        system_prompt=system_prompt,
        checkpointer=checkpointer,
        store=store
    ).with_config(
        recursion_limit=15
    )
    
    logger.info(f"✓ Agent ready ({len(all_tools)} tools, {len(agent_cards)} agents)")
    logger.info(LOG_SEPARATOR)
    
    return agent


@app.entrypoint
async def orchestration_agent(payload):
    """Main entrypoint - optimized for speed"""
    global agent
    
    user_input = payload.get("prompt")
    actor_id = payload.get("actor_id", "default-user")
    session_id = payload.get("session_id", str(uuid.uuid4()))
    
    logger.info(LOG_SEPARATOR)
    logger.info(f"REQUEST | Actor: {actor_id} | Session: {session_id}")
    logger.info(f"Query: {user_input}")
    logger.info(LOG_SEPARATOR)
    
    try:
        # Initialize agent on first request (lazy)
        if agent is None:
            agent = _initialize_agent()
        
        # Invoke agent with memory continuity
        response = agent.invoke(
            {"messages": [("human", user_input)]},
            config={
                "configurable": {
                    "thread_id": session_id,
                    "actor_id": actor_id,
                    "memory_id": MEMORY_ID
                }
            }
        )
        
        messages = response.get("messages", [])
        
        # DEBUG: Log all messages to understand the flow
        logger.info(f"Total messages in response: {len(messages)}")
        for i, msg in enumerate(messages):
            msg_type = getattr(msg, 'type', None)
            content_preview = str(getattr(msg, 'content', ''))[:100]
            logger.info(f"Message {i}: type={msg_type}, content={content_preview}...")
            
            # If it's an AI message, check for tool calls
            if msg_type == 'ai' and hasattr(msg, 'tool_calls'):
                tool_calls = getattr(msg, 'tool_calls', [])
                logger.info(f"  → Tool calls in message {i}: {tool_calls}")
                for tc in tool_calls:
                    logger.info(f"    → Tool: {tc.get('name')}, Args: {tc.get('args')}")
        
        # Extract response: prioritize tool response over AI response
        response_text = None
        tool_response = None
        ai_response = None
        
        # Single pass to find both - iterate in reverse to get most recent
        for msg in messages[::-1]:
            msg_type = getattr(msg, 'type', None)
            if msg_type == 'tool' and hasattr(msg, 'content') and tool_response is None:
                tool_response = msg.content
            elif msg_type == 'ai' and hasattr(msg, 'content') and ai_response is None:
                ai_response = msg.content
            
            # Early exit if we have both
            if tool_response and ai_response:
                break
        
        # ALWAYS prioritize tool response (actual agent output) over AI summary
        # This ensures we return sub-agent responses verbatim
        if tool_response:
            response_text = tool_response
            logger.info(f"✓ Returning tool response (bypassing AI summary): {str(response_text)[:100]}...")
        elif ai_response:
            response_text = ai_response
            logger.info(f"✓ AI response (no tool called): {str(response_text)[:100]}...")
        else:
            response_text = "No response generated"
            logger.warning("No valid response found in messages")
        
        logger.info(LOG_SEPARATOR)
        return {"response": response_text}
        
    except Exception as e:
        logger.error(f"ERROR: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {"response": f"Error: {str(e)}"}


if __name__ == "__main__":
    logger.info("Starting Lightweight Orchestration Agent...")
    app.run()
