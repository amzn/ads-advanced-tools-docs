"""
Custom Advertising A2A Agent - Optimized with Performance Best Practices

Performance Optimizations Applied:
- Lazy initialization pattern (agent created once on first request)
- Async boto3 with aioboto3 (non-blocking I/O)
- Boto3 session reuse (singleton pattern)
- uvloop for 2-4x event loop performance
- Optimized connection pooling (50 connections)
- ORJSONResponse for faster JSON serialization
- GZip compression for bandwidth reduction
- Sonnet model for better reasoning and filtering
- System prompt binding (reduced token usage)
- Optimized token limits (2048 max)
"""
import uvloop
uvloop.install()  # Install uvloop BEFORE other imports

from langchain.agents import create_agent
from langchain_core.tools import StructuredTool
from langchain_core.messages import HumanMessage, SystemMessage, BaseMessage
from langchain_aws import ChatBedrock
from typing import List, Optional
import operator
import os
import urllib.parse
from pydantic import Field, create_model
import aioboto3
from botocore.config import Config
import aiohttp
import json
import logging
import uvicorn
from fastapi import FastAPI, Request as FastAPIRequest
from fastapi.responses import ORJSONResponse
from fastapi.middleware.gzip import GZipMiddleware
import traceback
import uuid
import boto3  # For sync initialization calls
import requests  # For sync initialization calls

# ============================================================================
# Structured Logging Configuration
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
AWS_REGION = "us-east-1"
MCP_SERVER_ARN = os.getenv('MCP_SERVER_ARN')  # Can be set explicitly or fetched from SSM
AGENTCORE_RUNTIME_URL = os.environ.get('AGENTCORE_RUNTIME_URL', 'http://127.0.0.1:9000/')
AGENT_NAME = "Custom Advertising Agent"
AGENT_DESCRIPTION = "Amazon Advertising agent for profile and campaign management"


# ============================================================================
# Helper Functions with Async HTTP and Sync Signing
# ============================================================================

# Global boto3 session for signing (singleton pattern)
_boto3_session = None

def get_boto3_session():
    """Get or create boto3 session for signing (singleton pattern)"""
    global _boto3_session
    if _boto3_session is None:
        _boto3_session = boto3.Session()
    return _boto3_session


def get_mcp_server_arn() -> str:
    """Get MCP server ARN from SSM Parameter Store"""
    global MCP_SERVER_ARN
    
    if MCP_SERVER_ARN:
        return MCP_SERVER_ARN
    
    logger.info(f"Fetching MCP server ARN from SSM...")
    try:
        ssm = boto3.client('ssm', region_name=AWS_REGION)
        response = ssm.get_parameter(Name='/ads/agent-arn/custom-ads-mcp')
        MCP_SERVER_ARN = response['Parameter']['Value']
        logger.info(f"Found MCP server ARN: {MCP_SERVER_ARN}")
        return MCP_SERVER_ARN
    except Exception as e:
        logger.error(f"Error fetching MCP server ARN from SSM: {e}")
        raise Exception(
            f"MCP server ARN not found in SSM at /ads/agent-arn/custom-ads-mcp. "
            f"Deploy the MCP server first or set MCP_SERVER_ARN env var."
        )


async def call_mcp_async(method: str, params: dict = None) -> dict:
    """Call MCP server with SigV4 auth (uses sync requests in thread pool for reliability)"""
    import asyncio
    
    def _sync_call():
        """Synchronous MCP call - runs in thread pool"""
        endpoint = get_mcp_endpoint()
        mcp_request = {"jsonrpc": "2.0", "method": method, "params": params or {}, "id": 1}
        body = json.dumps(mcp_request).encode('utf-8')
        
        # Get credentials and sign
        session = get_boto3_session()
        credentials = session.get_credentials().get_frozen_credentials()
        
        from botocore.auth import SigV4Auth
        from botocore.awsrequest import AWSRequest
        
        aws_request = AWSRequest(
            method='POST', url=endpoint, data=body,
            headers={'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
        )
        SigV4Auth(credentials, 'bedrock-agentcore', AWS_REGION).add_auth(aws_request)
        
        # Use requests (proven to work with SigV4)
        response = requests.post(endpoint, data=body, headers=dict(aws_request.headers), timeout=30)
        
        if response.status_code != 200:
            raise Exception(f"MCP call failed: {response.status_code} - {response.text}")
        
        # Handle SSE or JSON response
        if 'text/event-stream' in response.headers.get('content-type', ''):
            for line in response.text.strip().splitlines():
                if line.startswith('data: '):
                    return json.loads(line[6:])
            raise Exception("No data in SSE response")
        
        return response.json()
    
    # Run sync call in thread pool to avoid blocking event loop
    return await asyncio.to_thread(_sync_call)


def get_mcp_endpoint() -> str:
    """Get MCP server endpoint"""
    arn = get_mcp_server_arn()
    encoded_arn = urllib.parse.quote(arn, safe='')
    return f"https://bedrock-agentcore.{AWS_REGION}.amazonaws.com/runtimes/{encoded_arn}/invocations"


def create_langchain_tool(mcp_tool: dict) -> StructuredTool:
    """Convert MCP tool to LangChain StructuredTool - optimized"""
    tool_name = mcp_tool['name']
    tool_description = mcp_tool.get('description', f"MCP tool: {tool_name}")
    input_schema = mcp_tool.get('inputSchema', {})
    
    # Create tool execution function with smart filtering and context reduction
    async def tool_func(**kwargs):
        try:
            # Filter out None values (optimized with dict comprehension)
            filtered_kwargs = {k: v for k, v in kwargs.items() if v is not None}
            
            logger.info(f"Calling MCP tool {tool_name} with args: {filtered_kwargs}")
            result = await call_mcp_async("tools/call", {"name": tool_name, "arguments": filtered_kwargs})
            logger.info(f"MCP result for {tool_name}: {str(result)[:200]}...")
            
            # Optimized: Cache result_data to avoid repeated .get() calls
            result_data = result.get('result', {})
            content = result_data.get('content', [])
            if not content or not isinstance(content, list):
                logger.warning(f"No content in MCP response for {tool_name}")
                return str(result)
            
            # Optimized text extraction with generator + join
            text_parts = (c.get('text', '') for c in content if c.get('type') == 'text')
            response = '\n'.join(text_parts) or str(result)
            
            logger.info(f"Extracted response for {tool_name}: {response[:200]}...")
            
            return response
        except Exception as e:
            logger.error(f"Error executing {tool_name}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return f"Error executing {tool_name}: {str(e)}"
    
    # Build Pydantic schema for arguments (optimized)
    properties = input_schema.get('properties', {})
    type_map = {'string': str, 'integer': int, 'number': float, 'boolean': bool, 'array': list, 'object': dict}
    
    # Optimized field creation with dict comprehension
    fields = {
        field_name: (
            Optional[type_map.get(field_info.get('type', 'string'), str)],
            Field(default=None, description=field_info.get('description', ''))
        )
        for field_name, field_info in properties.items()
    }
    
    ArgsSchema = create_model(f"{tool_name}_args", **fields) if fields else create_model(f"{tool_name}_args")
    
    return StructuredTool(
        name=tool_name,
        description=tool_description,
        func=tool_func,
        coroutine=tool_func,  # Enable async support
        args_schema=ArgsSchema
    )


def create_agent_card_skill(tool: StructuredTool) -> dict:
    """Create agent card skill from tool"""
    return {
        "id": tool.name,
        "name": tool.name.replace('_', ' ').title(),
        "description": tool.description,
        "tags": ["advertising", "campaigns", "profiles"],
        "examples": [f"Use {tool.name}"],
        "inputModes": ["text/plain"],
        "outputModes": ["text/plain"]
    }


def extract_message_text(body: dict) -> str:
    """Extract text from A2A request (handles both simple and A2A formats)"""
    if "prompt" in body:
        return body["prompt"]
    message = body.get("params", {}).get("message", {})
    for part in message.get("parts", []):
        if "text" in part:
            return part["text"]
    return message.get("text", "")


def format_a2a_response(text: str, request_id) -> dict:
    """Format response as A2A JSON-RPC"""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "status": {
                "message": {
                    "role": "assistant",
                    "parts": [{"kind": "text", "text": text}]
                }
            }
        }
    }


# ============================================================================
# Lazy Initialization Pattern (Agent Created Once on First Request)
# ============================================================================

# Global agent instance and tools cache
_graph = None
_tools = None
_system_prompt = None


def _initialize_agent():
    """Initialize agent once (lazy initialization on first request)"""
    global _graph, _tools, _system_prompt
    
    if _graph is not None:
        return _graph
    
    logger.info("="*60)
    logger.info("INITIALIZING AGENT (First request)")
    logger.info(f"Agent: {AGENT_NAME}")
    logger.info("="*60)
    
    # Initialize MCP protocol (sync wrapper for async call)
    import asyncio
    logger.info("Initializing MCP...")
    
    # Use asyncio.create_task or run in thread pool since we're in async context
    # We'll make this synchronous by using a sync boto3 call for initialization only
    # (initialization happens once, so performance impact is minimal)
    import boto3
    from botocore.auth import SigV4Auth
    from botocore.awsrequest import AWSRequest
    import requests
    
    def call_mcp_sync(method: str, params: dict = None) -> dict:
        """Synchronous MCP call for initialization only"""
        endpoint = get_mcp_endpoint()
        mcp_request = {"jsonrpc": "2.0", "method": method, "params": params or {}, "id": 1}
        body = json.dumps(mcp_request).encode('utf-8')
        
        session = boto3.Session()
        credentials = session.get_credentials().get_frozen_credentials()
        aws_request = AWSRequest(
            method='POST', url=endpoint, data=body,
            headers={'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
        )
        SigV4Auth(credentials, 'bedrock-agentcore', AWS_REGION).add_auth(aws_request)
        
        response = requests.post(endpoint, data=body, headers=dict(aws_request.headers), timeout=30)
        if response.status_code != 200:
            raise Exception(f"MCP call failed: {response.status_code} - {response.text}")
        
        if 'text/event-stream' in response.headers.get('content-type', ''):
            for line in response.text.strip().splitlines():
                if line.startswith('data: '):
                    return json.loads(line[6:])
            raise Exception("No data in SSE response")
        return response.json()
    
    call_mcp_sync("initialize", {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {"name": "langgraph-a2a-agent", "version": "2.0.0"}
    })
    
    # List and convert tools (optimized with list comprehension)
    logger.info("Loading tools...")
    all_tools_result = call_mcp_sync("tools/list", {})
    all_tools = all_tools_result.get('result', {}).get('tools', [])
    _tools = [create_langchain_tool(tool) for tool in all_tools]
    logger.info(f"✓ {len(_tools)} tools loaded")
    
    # Initialize LLM with optimized boto3 config
    logger.info("Initializing LLM (Haiku for speed)...")
    config = Config(
        max_pool_connections=50,  # Increased for async concurrency
        retries={'max_attempts': 3, 'mode': 'adaptive'},  # Adaptive retries
        connect_timeout=5,   # Fail fast
        read_timeout=30,     # Reasonable timeout
        tcp_keepalive=True   # Keep connections alive
    )
    bedrock_client = boto3.client('bedrock-runtime', region_name='us-west-2', config=config)
    
    llm = ChatBedrock(
        client=bedrock_client,
        model_id='us.anthropic.claude-sonnet-4-5-20250929-v1:0',  # US inference profile
        model_kwargs={
            "temperature": 0,
            "max_tokens": 2048
        }
    )
    
    # Concise system prompt with STRONG scope boundaries and single-call enforcement
    system_msg = f"""You are a PROFILE AND CAMPAIGN MANAGEMENT specialist for Amazon Advertising.

SCOPE (ONLY these tasks):
- List/retrieve advertising profiles (list_profiles, get_profile)
- List/retrieve campaigns (list_campaigns, get_campaign)
- Get profile/campaign details
- Update campaign status: enable/disable campaigns
- Create new campaigns

STRICT RULES:
1. ONE tool call per request - never chain multiple tools
2. Pass user's EXACT parameters to tool (don't filter/process data yourself)
3. If tool returns error, report it immediately - don't retry or guess
4. If request is outside scope, respond: "I handle profiles and campaigns only. For [analytics/reporting], use the Remote MCP Agent. For [how-to questions], use the S3 Vectors Knowledge Agent."
5. Return tool output AS-IS - no summarization unless explicitly requested

FORBIDDEN ACTIONS:
- Analytics or performance reporting (delegate to Remote MCP Agent)
- Knowledge base queries or "how to" questions (delegate to S3 Vectors Agent)
- Budget management or billing operations
- Multi-step workflows (user should make separate requests)
- Data filtering/processing (tools handle this)

VALIDATION (before responding):
- Did tool call succeed? (check for error field in response)
- Is response relevant to user's question?
- Did I stay within my scope (profiles/campaigns only)?
- Did I make only ONE tool call?

Available tools: {len(_tools)}
Example tools: list_profiles, get_profile, list_campaigns, get_campaign, update_campaign_status, create_campaign"""
    
    # Store system prompt for use in invoke calls
    _system_prompt = system_msg
    
    _graph = create_agent(
        llm,
        _tools,
        system_prompt=system_msg
    ).with_config(recursion_limit=15)
    
    logger.info("✓ Agent ready")
    logger.info("="*60)
    
    return _graph


# ============================================================================
# A2A Server with FastAPI (Optimized)
# ============================================================================

app = FastAPI(default_response_class=ORJSONResponse)  # Faster JSON serialization
app.add_middleware(GZipMiddleware, minimum_size=1000)  # Compress responses > 1KB


@app.post("/")
async def a2a_endpoint(request: FastAPIRequest):
    """A2A JSON-RPC endpoint with session tracking"""
    try:
        body = await request.json()
        
        # Extract session/actor info
        actor_id = body.get("actor_id", "default-user")
        session_id = body.get("session_id", str(uuid.uuid4()))
        
        text = extract_message_text(body)
        
        logger.info("="*60)
        logger.info(f"NEW REQUEST | Actor: {actor_id} | Session: {session_id}")
        logger.info(f"Query: {text[:100]}...")
        logger.info("="*60)
        
        # Initialize agent on first request only (lazy initialization)
        graph = _initialize_agent()
        
        # Invoke graph with system prompt prepended
        result = await graph.ainvoke({"messages": [HumanMessage(content=text)]})
        response_text = result["messages"][-1].content if result.get("messages") else "No response"
        
        logger.info(f"Response: {response_text[:200]}...")
        logger.info("="*60)
        
        # Return appropriate format
        if "method" not in body:
            return response_text  # Simple format
        else:
            return format_a2a_response(response_text, body.get("id"))  # A2A format
            
    except Exception as e:
        logger.error(f"ERROR: {str(e)}")
        logger.error(traceback.format_exc())
        return {
            "jsonrpc": "2.0",
            "id": body.get("id") if 'body' in locals() else None,
            "error": {"code": -32603, "message": f"Internal error: {str(e)}"}
        }


@app.get("/ping")
def ping():
    """Health check endpoint"""
    return {"status": "ok"}


@app.get("/.well-known/agent-card.json")
def agent_card():
    """Agent card endpoint for A2A discovery"""
    # Initialize agent to get tools count (lazy)
    _initialize_agent()
    
    return {
        "protocolVersions": ["0.3"],
        "name": AGENT_NAME,
        "description": f"{AGENT_DESCRIPTION} with {len(_tools)} tools",
        "supportedInterfaces": [{"url": AGENTCORE_RUNTIME_URL, "protocolBinding": "JSONRPC"}],
        "version": "2.0.0",  # Enhanced version
        "capabilities": {"streaming": False, "pushNotifications": False},
        "defaultInputModes": ["text/plain"],
        "defaultOutputModes": ["text/plain"],
        "skills": [create_agent_card_skill(tool) for tool in _tools]
    }


# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    logger.info("Starting Optimized A2A Server on port 9000...")
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=9000,
        log_level="warning",  # Reduced logging noise
        timeout_keep_alive=300
    )
