"""
MCP Server for Amazon Advertising AI Tools (AgentCore Compatible)

This server exposes Amazon Advertising AI tools through the MCP protocol.
Configured for AgentCore Runtime with stateless streamable-HTTP transport.
"""
import os
import requests
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server with AgentCore requirements:
# - host="0.0.0.0" - Listen on all interfaces
# - stateless_http=True - Required for AgentCore (provides session isolation)
# AgentCore expects MCP servers at 0.0.0.0:8000/mcp
mcp = FastMCP(host="0.0.0.0", stateless_http=True)

print("Initializing Amazon Advertising AI MCP Server for AgentCore...")
print("Server will be available at 0.0.0.0:8000/mcp")

refresh_token = None
client_id = None
client_secret = None

# Load credentials from SSM Parameter Store first (deployed on AgentCore)
try:
    import boto3
    ssm = boto3.client('ssm', region_name='us-east-1')
    params = ssm.get_parameters(
        Names=['/ads/refresh-token', '/ads/client-id', '/ads/client-secret'],
        WithDecryption=True
    )
    param_dict = {p['Name']: p['Value'] for p in params['Parameters']}
    refresh_token = param_dict.get('/ads/refresh-token')
    client_id = param_dict.get('/ads/client-id')
    client_secret = param_dict.get('/ads/client-secret')
    print("✓ Credentials loaded from SSM Parameter Store")
except Exception as e:
    print(f"SSM fetch failed ({e}), trying env vars...")
    refresh_token = os.getenv('REFRESH_TOKEN')
    client_id = os.getenv('CLIENT_ID')
    client_secret = os.getenv('CLIENT_SECRET')

if not all([refresh_token, client_id, client_secret]):
    raise Exception(
        "Missing OAuth credentials. Store in SSM at /ads/refresh-token, /ads/client-id, /ads/client-secret"
    )

def get_access_token() -> str:
    """Get OAuth access token using refresh token flow"""
    auth_data = {
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
        'client_id': client_id,
        'client_secret': client_secret
    }
    response = requests.post('https://api.amazon.com/auth/o2/token', data=auth_data)
    if response.status_code == 200:
        return response.json()['access_token']
    raise Exception(f"Auth failed: {response.status_code}")


print("Initializing MCP client...")
access_token = get_access_token()
print(f"Using client_id for MCP headers: {client_id}")

@mcp.tool()
def list_profiles(
    api_program: str = None,
    access_level: str = None,
    profile_type_filter: str = None,
    valid_payment_method_filter: str = None
) -> str:
    """
    Get a list of advertising profiles associated with the account
    
    Profiles represent an advertiser and their account's marketplace.
    Each profile is used in subsequent API calls via Amazon-Advertising-API-Scope header.
    
    Args:
        api_program: Optional. Filter by API program (billing, campaign, paymentMethod, store, report, account, posts)
        access_level: Optional. Filter by access level (edit, view)
        profile_type_filter: Optional. Filter by profile type - comma-delimited (seller, vendor, agency)
        valid_payment_method_filter: Optional. Filter by valid payment method (true, false)
        
    Returns:
        List of profiles as JSON string with profileId, countryCode, currencyCode, timezone, accountInfo, etc.
    """
    try:
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Amazon-Advertising-API-ClientId": client_id,
            "Content-Type": "application/json"
        }
        
        # Build query parameters
        params = {}
        if api_program:
            params['apiProgram'] = api_program
        if access_level:
            params['accessLevel'] = access_level
        if profile_type_filter:
            params['profileTypeFilter'] = profile_type_filter
        if valid_payment_method_filter:
            params['validPaymentMethodFilter'] = valid_payment_method_filter
        
        response = requests.get(
            "https://advertising-api.amazon.com/v2/profiles",
            headers=headers,
            params=params
        )
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.tool()
def get_profile(profile_id: str) -> str:
    """
    Get detailed information for a specific advertising profile
    
    Args:
        profile_id: The profile ID (from list_profiles)
        
    Returns:
        Profile details as JSON string including profileId, countryCode, currencyCode, 
        dailyBudget, timezone, accountInfo (marketplace, type, name, etc.)
    """
    try:
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Amazon-Advertising-API-ClientId": client_id,
            "Content-Type": "application/json"
        }
        response = requests.get(
            f"https://advertising-api.amazon.com/v2/profiles/{profile_id}",
            headers=headers
        )
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.tool()
def update_profile_budget(profile_id: str, daily_budget: float) -> str:
    """
    Update the daily budget for a profile
    
    Note: This operation is only for Sellers using Sponsored Products.
    Not supported for vendor type accounts.
    
    Args:
        profile_id: The profile ID
        daily_budget: New daily budget amount
        
    Returns:
        Updated profile details as JSON string
    """
    try:
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Amazon-Advertising-API-ClientId": client_id,
            "Content-Type": "application/json"
        }
        payload = {
            "profileId": int(profile_id),
            "dailyBudget": daily_budget
        }
        response = requests.put(
            f"https://advertising-api.amazon.com/v2/profiles",
            headers=headers,
            json=payload
        )
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"


if __name__ == "__main__":
    # Run the MCP server with streamable-http transport (required for AgentCore)
    print("Starting Amazon Advertising AI MCP Server...")
    print("Transport: streamable-http (AgentCore compatible)")
    print("Available tools:")
    print("  - list_profiles (get all advertising profiles)")
    print("  - get_profile (get specific profile details)")
    print("  - update_profile_budget (update profile daily budget)")
    print("  - list_campaigns")
    print("  - get_campaign_metrics")
    print("  - create_campaign")
    print("  - update_campaign_budget")
    print("  - pause_campaign")
    mcp.run(transport="streamable-http")
