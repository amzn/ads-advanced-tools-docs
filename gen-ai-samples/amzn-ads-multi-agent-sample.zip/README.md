# Amazon Advertising Multi-Agent System

A multi-agent architecture built on AWS Bedrock AgentCore for Amazon Advertising operations. The system uses an orchestration agent that routes requests to specialized sub-agents via the A2A (Agent-to-Agent) protocol.

## Architecture

```
                            ┌──────────────────────────┐
                            │    Orchestration Agent    │
                            │   (orchestration-a2a)     │
                            └──┬───────┬───────┬─────┬──┘
                               │       │       │     │
              ┌────────────────┘       │       │     └──────────────┐
              ▼                        ▼       ▼                     ▼
   ┌──────────────────┐ ┌────────────────┐ ┌─────────────────┐ ┌──────────────────┐
   │ Custom Ads Agent │ │ Amazon Ads MCP │ │ S3 Vectors Agent│ │ RDS Campaign Agent│
   │ (profiles/camps) │ │ Agent          │ │ (knowledge/RAG) │ │ (database queries)│
   └────────┬─────────┘ └───────┬────────┘ └────────┬────────┘ └────────┬─────────┘
            │                    │                    │                   │
            ▼                    ▼                    ▼                   ▼
   ┌──────────────────┐ ┌──────────────────┐ ┌───────────────┐ ┌─────────────────────┐
   │ Custom Ads MCP   │ │ Amazon Ads API   │ │  S3 Vectors   │ │  AgentCore Gateway  │
   │ Server (AgentCore)│ │ (Remote MCP)     │ │  Bucket+Index │ │  (Cognito + JWT)    │
   └──────────────────┘ └──────────────────┘ └───────────────┘ └────────┬────────────┘
                                                                        │
                                                               ┌────────▼────────────┐
                                                               │ Campaign MCP Server │
                                                               │ (VPC-attached)      │
                                                               └────────┬────────────┘
                                                                        │
                                                               ┌────────▼────────────┐
                                                               │   Amazon RDS (VPC)  │
                                                               │   (PostgreSQL)      │
                                                               └─────────────────────┘
```

## Agents Overview

| Agent | Directory | Protocol | Description |
|-------|-----------|----------|-------------|
| Custom Ads Agent | `custom-ads-a2a-agent/` | A2A | Profile & campaign management via internal MCP server |
| Amazon Ads MCP Agent | `mcp-ads-a2a-agent/` | A2A | Amazon Ads MCP for analytics & reporting |
| S3 Vectors Agent | `s3-vectors-a2a-agent/` | A2A | RAG knowledge base using S3 Vectors |
| Orchestration Agent | `orchestration-a2a-agent/` | HTTP | Routes queries to the right sub-agent |
| RDS Campaign Agent | `custom-ads-rds-mcp-agent/langraph/` | A2A | Direct RDS database queries via MCP Gateway |
| Campaign MCP Server | `custom-ads-rds-mcp-agent/mcp-server/` | MCP | MCP server for RDS (VPC-attached) |
| Custom Ads MCP Server | `custom-ads-mcp/` | MCP | MCP server wrapping Ads API tools |

## Prerequisites

- Python 3.12+
- AWS CLI configured (`aws sts get-caller-identity` should work)
- AWS account with admin access

## Initial Setup

### 1. Create and activate a virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
```

### 2. Install the Bedrock AgentCore Starter Toolkit

```bash
pip install bedrock-agentcore-starter-toolkit
agentcore --version
```

This gives you the `agentcore` CLI used for configuring, deploying, and invoking agents.

---

## Deploying Individual Agents

Each agent is deployed independently using `agentcore configure` + `agentcore deploy`. Always run commands from inside the agent's directory.


### Agent 1: Custom Ads A2A Agent

Manages advertising profiles and campaigns via the internal MCP server.

```bash
cd custom-ads-a2a-agent

# Install dependencies
pip install -r requirements.txt

# Configure (first-time only)
agentcore configure \
    --entrypoint langgraph_a2a.py \
    --requirements-file requirements.txt \
    --name custom_ads_a2a_agent \
    --region us-east-1 \
    --protocol A2A \
    --deployment-type container \
    --non-interactive

# Deploy
agentcore deploy

# Verify
agentcore status --verbose
```

Environment variables (`.env`):
```
MCP_SERVER_ARN=arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:runtime/<your-mcp-server-id>
```

---

### Agent 2: MCP Ads A2A Agent

Analytics and reporting agent connecting to Amazon Advertising's remote MCP server.

```bash
cd mcp-ads-a2a-agent

# Install dependencies
pip install -r requirements.txt

# Configure (first-time only)
agentcore configure \
    --entrypoint langgraph_a2a.py \
    --requirements-file requirements.txt \
    --name langgraph_a2a_mcp_ads_agent \
    --region us-east-1 \
    --protocol A2A \
    --deployment-type container \
    --non-interactive

# Deploy
agentcore deploy

# Verify
agentcore status --verbose
```

Environment variables (`.env`):
```
REFRESH_TOKEN="<your-amazon-ads-refresh-token>"
CLIENT_ID="<your-amazon-ads-client-id>"
CLIENT_SECRET="<your-amazon-ads-client-secret>"
TOOL_FILTER="account_management-, billing-"
```

---

### Agent 3: S3 Vectors Knowledge Agent

RAG-based knowledge agent using S3 Vectors for document retrieval.

```bash
cd s3-vectors-a2a-agent

# Install dependencies
pip install -r requirements.txt

# Configure (first-time only)
agentcore configure \
    --entrypoint langgraph_a2a.py \
    --requirements-file requirements.txt \
    --name s3_vector_langgraph_a2a \
    --region us-east-1 \
    --protocol A2A \
    --deployment-type container \
    --non-interactive

# Deploy
agentcore deploy

# Verify
agentcore status --verbose
```

Environment variables (`.env`):
```
VECTOR_BUCKET_NAME=ads-knowledge-vectors-bucket
VECTOR_INDEX_NAME=ads-knowledge-index
AWS_REGION=us-east-1
```

For S3 Vectors bucket and index setup, see `deployment_tool/S3_VECTOR_SETUP.md`.

---

### Agent 4: Orchestration Agent

Routes incoming queries to the appropriate sub-agent. Deploy this after all sub-agents are deployed since it needs their ARNs.

```bash
cd orchestration-a2a-agent

# Install dependencies
pip install -r requirements.txt

# Configure (first-time only)
agentcore configure \
    --entrypoint orchestration_a2a.py \
    --requirements-file requirements.txt \
    --name orchestration_a2a \
    --region us-east-1 \
    --protocol HTTP \
    --deployment-type container \
    --non-interactive

# Deploy
agentcore deploy

# Verify
agentcore status --verbose
```

Environment variables (`.env`) — update ARNs from sub-agent deployments:
```
CUSTOM_A2A_AGENT_ARN=arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:runtime/<custom-ads-agent-id>
REMOTE_A2A_AGENT_ARN=arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:runtime/<mcp-ads-agent-id>
S3_VECTORS_AGENT_ARN=arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:runtime/<s3-vectors-agent-id>
MEMORY_ARN=arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:memory/<memory-id>
```

Note: The orchestration agent uses `protocol HTTP` (not A2A) because it uses the `BedrockAgentCoreApp` SDK runtime.

---

### Agent 5: RDS Campaign Agent

Queries a PostgreSQL campaign database via an MCP Gateway. This agent has its own infrastructure (RDS, VPC, Cognito) that must be deployed first.

#### 5a. Deploy Infrastructure (CDK)

```bash
cd custom-ads-rds-mcp-agent

npm install
npm run build
cdk deploy --all --require-approval never
```

This creates the RDS instance, VPC, security groups, and SSM parameters.

#### 5b. Set Up the Database

```bash
# Get connection details
INSTANCE_ID=$(aws ssm get-parameter --name /campaign/db-access-instance-id --query Parameter.Value --output text)
DB_ENDPOINT=$(aws ssm get-parameter --name /campaign/db-endpoint --query Parameter.Value --output text)
SECRET_ARN=$(aws ssm get-parameter --name /campaign/db-secret-arn --query Parameter.Value --output text)
DB_PASSWORD=$(aws secretsmanager get-secret-value --secret-id $SECRET_ARN --query SecretString --output text | jq -r .password)

# Start port forwarding (keep running in a separate terminal)
aws ssm start-session \
    --target $INSTANCE_ID \
    --document-name AWS-StartPortForwardingSessionToRemoteHost \
    --parameters "{\"host\":[\"$DB_ENDPOINT\"],\"portNumber\":[\"5432\"],\"localPortNumber\":[\"5432\"]}"

# In another terminal, create tables and insert data
psql -h localhost -p 5432 -U dbadmin -d campaigndb -f create-campaign-table.sql
psql -h localhost -p 5432 -U dbadmin -d campaigndb -f insert-sample-data.sql
```

#### 5c. Deploy the MCP Server (VPC-attached)

```bash
cd mcp-server

python3 -m venv venv
source venv/bin/activate
pip install -r requirements-local.txt

# Set up Cognito auth
python setup_cognito.py

# Deploy MCP server with VPC
./deploy.sh

# Create gateway and add target
python create_gateway.py
python add_gateway_target.py
```

#### 5d. Deploy the LangGraph Agent

```bash
cd ../langraph

pip install -r requirements.txt

# Configure
agentcore configure \
    --entrypoint agent.py \
    --requirements-file requirements.txt \
    --name campaign_agent_v2 \
    --region us-east-1 \
    --protocol A2A \
    --deployment-type container \
    --disable-memory \
    --non-interactive

# Deploy
agentcore deploy
```

Or use the deploy script which also sets up IAM permissions:
```bash
./deploy.sh
```

---

### Agent 6: Custom Ads MCP Server

The internal MCP server that wraps Amazon Advertising API tools. Used by the Custom Ads A2A Agent.

```bash
cd custom-ads-mcp

pip install -r requirements.txt

# Configure
agentcore configure \
    --entrypoint mcp_server.py \
    --requirements-file requirements.txt \
    --name ads_mcp_server \
    --region us-east-1 \
    --protocol MCP \
    --deployment-type container \
    --non-interactive

# Deploy
agentcore deploy

# Verify
agentcore status --verbose
```

---

## Testing

Test any deployed agent:

```bash
# Test with agentcore invoke
agentcore invoke '{"prompt": "list all campaigns"}'

# Test a specific agent by navigating to its directory first
cd custom-ads-a2a-agent
agentcore invoke '{"prompt": "list my advertising profiles"}'
```

Check logs:
```bash
# Get the log stream from agentcore invoke output, then:
aws logs tail /aws/bedrock-agentcore/runtimes/<AGENT_ID>-DEFAULT \
    --log-stream-name-prefix "$(date +%Y/%m/%d)/[runtime-logs]" \
    --since 1h
```

---

## Automated Deployment Tool

For fully automated deployment of all agents with IAM policies, cross-agent permissions, and state management, see the `deployment_tool/` directory:

```bash
cd deployment_tool
pip install -r requirements.txt

# Validate configuration
python -m cli.cli validate --config deployment.yaml

# Deploy everything
python -m cli.cli deploy --config deployment.yaml

# Check status
python -m cli.cli status --config deployment.yaml
```

See `deployment_tool/DEPLOYMENT_GUIDE.md` for full documentation.

---

## Frontend

The Next.js chat frontend connects to the orchestration agent. See `deployment_tool/FRONTEND_DEPLOYMENT.md` for setup instructions.

```bash
cd ads-chat-nextjs
npm install
npm run dev
```

Update `ads-chat-nextjs/.env.local` with the orchestration agent ARN.

---

## Redeploying After Code Changes

After modifying an agent's code, redeploy from its directory:

```bash
cd <agent-directory>
agentcore deploy
```

The `agentcore deploy` command rebuilds the container and pushes the update. No need to re-run `agentcore configure` unless you're changing deployment settings.
