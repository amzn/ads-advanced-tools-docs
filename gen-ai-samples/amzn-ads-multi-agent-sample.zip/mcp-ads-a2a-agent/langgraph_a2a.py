"""
Remote Advertising A2A Agent - Optimized with Performance Best Practices

Performance Optimizations Applied:
- Lazy initialization pattern (agent created once on first request)
- OAuth token caching with automatic expiry handling
- Async HTTP with aiohttp (non-blocking I/O)
- uvloop for 2-4x event loop performance
- Optimized connection pooling (50 connections)
- ORJSONResponse for faster JSON serialization
- GZip compression for bandwidth reduction
- Sonnet model for better reasoning and filtering
- System prompt binding (reduced token usage)
- Optimized token limits (2048 max)
"""
import uvloop
uvloop.install()  # Install uvloop BEFORE other imports

from langchain.agents import create_agent
from langchain_core.tools import StructuredTool
from langchain_core.messages import HumanMessage, SystemMessage, BaseMessage
from langchain_aws import ChatBedrock
from typing import List, Optional
import operator
import os
import aiohttp
from pydantic import Field, create_model
from dotenv import load_dotenv
from botocore.config import Config
import boto3
import aiohttp
import json
import logging
import uvicorn
from fastapi import FastAPI, Request as FastAPIRequest
from fastapi.responses import ORJSONResponse
from fastapi.middleware.gzip import GZipMiddleware
import traceback
import uuid
import time
import requests  # For sync initialization calls

load_dotenv()

# ============================================================================
# Structured Logging Configuration
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
MCP_SERVER_URL = "https://advertising-ai.amazon.com/mcp"
AGENTCORE_RUNTIME_URL = os.environ.get('AGENTCORE_RUNTIME_URL', 'http://127.0.0.1:9000/')
AGENT_NAME = "Remote Advertising Agent"
AGENT_DESCRIPTION = "Amazon Advertising AI agent for campaigns, advanced analytics and reporting"
TOOL_FILTER = os.getenv('TOOL_FILTER', '')

# ============================================================================
# Credential Management (Secrets Manager → SSM → env vars)
# ============================================================================

_credentials_cache = {}


def _load_credentials() -> dict:
    """Load OAuth credentials from Secrets Manager, then SSM, then env vars."""
    global _credentials_cache
    if _credentials_cache:
        return _credentials_cache

    # Try Secrets Manager first
    try:
        import boto3
        sm = boto3.client('secretsmanager', region_name='us-east-1')
        secret = sm.get_secret_value(SecretId='ads/oauth-credentials')
        import json as _json
        creds = _json.loads(secret['SecretString'])
        _credentials_cache = {
            'refresh_token': creds.get('refresh_token', ''),
            'client_id': creds.get('client_id', ''),
            'client_secret': creds.get('client_secret', ''),
        }
        logger.info("✓ Credentials loaded from Secrets Manager (ads/oauth-credentials)")
        return _credentials_cache
    except Exception as e:
        logger.info(f"Secrets Manager lookup failed ({e}), trying SSM...")

    # Try SSM Parameter Store
    try:
        import boto3
        ssm = boto3.client('ssm', region_name='us-east-1')
        params = ssm.get_parameters(
            Names=['/ads/refresh-token', '/ads/client-id', '/ads/client-secret'],
            WithDecryption=True
        )
        param_dict = {p['Name']: p['Value'] for p in params['Parameters']}
        if param_dict:
            _credentials_cache = {
                'refresh_token': param_dict.get('/ads/refresh-token', ''),
                'client_id': param_dict.get('/ads/client-id', ''),
                'client_secret': param_dict.get('/ads/client-secret', ''),
            }
            logger.info("✓ Credentials loaded from SSM Parameter Store")
            return _credentials_cache
    except Exception as e:
        logger.info(f"SSM lookup failed ({e}), trying env vars...")

    # Fall back to env vars (no hardcoded defaults)
    _credentials_cache = {
        'refresh_token': os.getenv('REFRESH_TOKEN', ''),
        'client_id': os.getenv('CLIENT_ID', ''),
        'client_secret': os.getenv('CLIENT_SECRET', ''),
    }

    if all(_credentials_cache.values()):
        logger.info("✓ Credentials loaded from environment variables")
    else:
        logger.warning("⚠ Some credentials are missing. Set them in Secrets Manager, SSM, or env vars.")

    return _credentials_cache


# ============================================================================
# Helper Functions with OAuth Token Caching
# ============================================================================

# Global OAuth token cache
_access_token = None
_token_expiry = 0


def get_access_token() -> str:
    """Get OAuth access token with automatic expiry handling and caching"""
    global _access_token, _token_expiry
    
    current_time = time.time()
    
    # Return cached token if still valid (with 5 min buffer for safety)
    if _access_token and current_time < (_token_expiry - 300):
        logger.debug("Using cached OAuth token")
        return _access_token
    
    # Fetch new token
    logger.info("Fetching new OAuth token...")
    creds = _load_credentials()
    refresh_token = creds['refresh_token']
    client_id = creds['client_id']
    client_secret = creds['client_secret']
    
    if not all([refresh_token, client_id, client_secret]):
        raise Exception(
            "Missing OAuth credentials. Store them in Secrets Manager (ads/oauth-credentials), "
            "SSM (/ads/refresh-token, /ads/client-id, /ads/client-secret), or env vars."
        )
    
    auth_data = {
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
        'client_id': client_id,
        'client_secret': client_secret
    }
    
    try:
        response = requests.post('https://api.amazon.com/auth/o2/token', data=auth_data, timeout=10)
        if response.status_code == 200:
            token_data = response.json()
            _access_token = token_data['access_token']
            # Set expiry time (default 1 hour if not provided)
            expires_in = token_data.get('expires_in', 3600)
            _token_expiry = current_time + expires_in
            logger.info(f"✓ OAuth token refreshed (expires in {expires_in}s)")
            return _access_token
        else:
            raise Exception(f"Failed to get access token: {response.status_code} - {response.text}")
    except Exception as e:
        logger.error(f"OAuth token fetch failed: {e}")
        raise


async def call_mcp_async(method: str, params: dict = None) -> dict:
    """Call MCP server with OAuth using async HTTP (handles JSON and SSE responses, with token retry)"""
    max_retries = 2
    
    for attempt in range(max_retries):
        try:
            access_token = get_access_token()
            creds = _load_credentials()
            client_id = creds['client_id']
            
            mcp_request = {"jsonrpc": "2.0", "method": method, "params": params or {}, "id": 1}
            headers = {
                "Authorization": access_token,
                "Amazon-Ads-ClientId": client_id,
                "Accept": "application/json, text/event-stream",
                "Content-Type": "application/json"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    MCP_SERVER_URL, 
                    json=mcp_request, 
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    # If 401 Unauthorized and we have retries left, invalidate token and retry
                    if response.status == 401 and attempt < max_retries - 1:
                        logger.warning("OAuth token expired or invalid, fetching new token...")
                        global _access_token, _token_expiry
                        _access_token = None
                        _token_expiry = 0
                        continue
                    
                    if response.status != 200:
                        text = await response.text()
                        raise Exception(f"MCP call failed: {response.status} - {text}")
                    
                    content_type = response.headers.get('content-type', '')
                    
                    # Handle SSE or JSON response
                    if 'text/event-stream' in content_type:
                        text = await response.text()
                        for line in text.strip().splitlines():
                            if line.startswith('data: '):
                                return json.loads(line[6:])
                        raise Exception("No data in SSE response")
                    
                    return await response.json()
            
        except Exception as e:
            if attempt < max_retries - 1:
                logger.warning(f"MCP call attempt {attempt + 1} failed, retrying: {e}")
                continue
            raise
    
    raise Exception("MCP call failed after all retries")


def create_langchain_tool(mcp_tool: dict) -> StructuredTool:
    """Convert MCP tool to LangChain StructuredTool (optimized with comprehensions)"""
    tool_name = mcp_tool['name']
    tool_description = mcp_tool.get('description', f"MCP tool: {tool_name}")
    input_schema = mcp_tool.get('inputSchema', {})
    
    # Create tool execution function with context reduction
    async def tool_func(**kwargs):
        try:
            result = await call_mcp_async("tools/call", {"name": tool_name, "arguments": kwargs})
            content = result.get('result', {}).get('content', [])
            if content and isinstance(content, list):
                # Optimized: Generator expression for text extraction
                text_parts = (c.get('text', '') for c in content if c.get('type') == 'text')
                response = '\n'.join(text_parts) or str(result)
                
                # Context length reduction: Truncate large responses (optimization)
                MAX_RESPONSE_LENGTH = 2000  # ~500 tokens
                if len(response) > MAX_RESPONSE_LENGTH:
                    logger.info(f"Truncating response from {len(response)} to {MAX_RESPONSE_LENGTH} chars")
                    response = response[:MAX_RESPONSE_LENGTH] + "\n\n[... Response truncated for speed. Parse and filter the data shown above.]"
                
                return response
            return str(result)
        except Exception as e:
            logger.error(f"Error executing {tool_name}: {e}")
            return f"Error executing {tool_name}: {str(e)}"
    
    # Build Pydantic schema for arguments (optimized with dict comprehension)
    properties = input_schema.get('properties', {})
    required = input_schema.get('required', [])
    type_map = {'string': str, 'integer': int, 'number': float, 'boolean': bool, 'array': list, 'object': dict}
    
    # Optimized: Dict comprehension for field creation
    fields = {
        field_name: (
            (Optional[type_map.get(field_info.get('type', 'string'), str)], 
             Field(default=None, description=field_info.get('description', '')))
            if field_name not in required else
            (type_map.get(field_info.get('type', 'string'), str), 
             Field(description=field_info.get('description', '')))
        )
        for field_name, field_info in properties.items()
    }
    
    ArgsSchema = create_model(f"{tool_name}_args", **fields) if fields else create_model(f"{tool_name}_args")
    
    return StructuredTool(
        name=tool_name,
        description=tool_description,
        func=tool_func,
        coroutine=tool_func,  # Enable async support
        args_schema=ArgsSchema
    )


def create_agent_card_skill(tool: StructuredTool) -> dict:
    """Create agent card skill from tool"""
    return {
        "id": tool.name,
        "name": tool.name.replace('_', ' ').title(),
        "description": tool.description,
        "tags": ["advertising", "analytics", "reporting"],
        "examples": [f"Use {tool.name}"],
        "inputModes": ["text/plain"],
        "outputModes": ["text/plain"]
    }


def extract_message_text(body: dict) -> str:
    """Extract text from A2A request (optimized with generator expression)"""
    if "prompt" in body:
        return body["prompt"]
    message = body.get("params", {}).get("message", {})
    # Optimized: Generator expression with next() for early exit
    return next((part.get("text") for part in message.get("parts", []) if "text" in part), 
                message.get("text", ""))


def format_a2a_response(text: str, request_id) -> dict:
    """Format response as A2A JSON-RPC"""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "status": {
                "message": {
                    "role": "assistant",
                    "parts": [{"kind": "text", "text": text}]
                }
            }
        }
    }


# ============================================================================
# Lazy Initialization Pattern (Agent Created Once on First Request)
# ============================================================================

# Global agent instance and tools cache
_graph = None
_tools = None
_system_prompt = None


def _initialize_agent():
    """Initialize agent once (lazy initialization on first request)"""
    global _graph, _tools, _system_prompt
    
    if _graph is not None:
        return _graph
    
    logger.info("="*60)
    logger.info("INITIALIZING AGENT")
    logger.info(f"Agent: {AGENT_NAME}")
    logger.info("="*60)
    
    # Initialize MCP protocol (sync wrapper for async call)
    import asyncio
    logger.info("Initializing MCP protocol...")
    
    # Use synchronous requests for initialization only (happens once)
    def call_mcp_sync(method: str, params: dict = None) -> dict:
        """Synchronous MCP call for initialization only"""
        max_retries = 2
        
        for attempt in range(max_retries):
            try:
                access_token = get_access_token()
                creds = _load_credentials()
                client_id = creds['client_id']
                
                mcp_request = {"jsonrpc": "2.0", "method": method, "params": params or {}, "id": 1}
                headers = {
                    "Authorization": access_token,
                    "Amazon-Ads-ClientId": client_id,
                    "Accept": "application/json, text/event-stream",
                    "Content-Type": "application/json"
                }
                
                import requests
                response = requests.post(MCP_SERVER_URL, json=mcp_request, headers=headers, timeout=30)
                
                if response.status_code == 401 and attempt < max_retries - 1:
                    logger.warning("OAuth token expired or invalid, fetching new token...")
                    global _access_token, _token_expiry
                    _access_token = None
                    _token_expiry = 0
                    continue
                
                if response.status_code != 200:
                    raise Exception(f"MCP call failed: {response.status_code} - {response.text}")
                
                if 'text/event-stream' in response.headers.get('content-type', ''):
                    for line in response.text.strip().splitlines():
                        if line.startswith('data: '):
                            return json.loads(line[6:])
                    raise Exception("No data in SSE response")
                
                return response.json()
                
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"MCP call attempt {attempt + 1} failed, retrying: {e}")
                    continue
                raise
        
        raise Exception("MCP call failed after all retries")
    
    call_mcp_sync("initialize", {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {"name": "langgraph-a2a-agent", "version": "2.0.0"}
    })
    
    # List and filter tools (optimized with list comprehensions)
    logger.info("Loading tools from MCP server...")
    all_tools_result = call_mcp_sync("tools/list", {})
    all_tools = all_tools_result.get('result', {}).get('tools', [])
    
    if TOOL_FILTER:
        # Optimized: List comprehension for filtering
        allowed_groups = [g.strip() for g in TOOL_FILTER.replace('"', '').split(',') if g.strip()]
        mcp_tools = [t for t in all_tools if any(t.get('name', '').startswith(g) for g in allowed_groups)]
        logger.info(f"✓ Filtered to {len(mcp_tools)} tools from {len(all_tools)} total")
    else:
        mcp_tools = all_tools
        logger.info(f"✓ Loaded {len(mcp_tools)} tools (no filter)")
    
    # Convert to LangChain tools (list comprehension already optimal)
    _tools = [create_langchain_tool(tool) for tool in mcp_tools]
    
    # Initialize LLM with optimized boto3 config
    logger.info("Initializing LLM (Haiku for speed)...")
    config = Config(
        max_pool_connections=50,  # Increased for async concurrency
        retries={'max_attempts': 3, 'mode': 'adaptive'},  # Adaptive retries
        connect_timeout=5,   # Fail fast
        read_timeout=30,     # Reasonable timeout
        tcp_keepalive=True   # Keep connections alive
    )
    bedrock_client = boto3.client('bedrock-runtime', region_name='us-west-2', config=config)
    
    llm = ChatBedrock(
        client=bedrock_client,
        model_id='anthropic.claude-3-5-haiku-20241022-v1:0',
        model_kwargs={
            "temperature": 0,  # More deterministic
            "max_tokens": 2048  # Enough for filtering and formatting
        }
    )
    
    # System prompt with clear scope and tool selection guidance
    system_msg = f"""You are an ANALYTICS AND REPORTING specialist for Amazon Advertising.

SCOPE (ONLY these tasks):
- Performance reports: clicks, impressions, spend, conversions, ROAS
- Billing reports: invoices, payments, account balance
- Historical data analysis: trends over time
- Metric aggregations: totals, averages, comparisons
- Data exports for external analysis

STRICT RULES:
1. ONE tool call per request - never chain multiple tools
2. Choose the MOST SPECIFIC tool for the query:
   - billing-* tools → invoices, payments, account balance
   - reporting-* tools → performance metrics, campaign stats
   - analytics-* tools → trends, aggregations, comparisons
3. Pass ALL user filters to tool: date ranges, countries, statuses, metrics
4. If tool returns error, report it immediately - don't retry
5. If request is outside scope, respond: "I handle analytics and reporting only. For [profile/campaign management], use the Custom Ads Agent. For [how-to questions], use the S3 Vectors Knowledge Agent."

FORBIDDEN ACTIONS:
- Creating/updating campaigns or profiles (delegate to Custom Ads Agent)
- Knowledge base queries or best practices (delegate to S3 Vectors Agent)
- Budget modifications or campaign operations
- Multi-step workflows (user should make separate requests)

TOOL SELECTION GUIDE:
- "show me invoices" → billing-list-invoices
- "campaign performance last week" → reporting-campaign-metrics
- "spending trends this month" → analytics-spend-over-time
- "top performing campaigns" → reporting-campaign-rankings

VALIDATION (before responding):
- Did I choose the right tool category (billing/reporting/analytics)?
- Did tool call succeed?
- Is data relevant to user's time period and filters?
- Did I make only ONE tool call?

Available tools: {len(_tools)} (filtered to: {TOOL_FILTER})
Tool categories: billing, reporting, analytics"""
    
    # Store system prompt for use in invoke calls
    _system_prompt = system_msg
    
    # Create agent with system_prompt parameter
    _graph = create_agent(
        llm,
        _tools,
        system_prompt=system_msg
    ).with_config(recursion_limit=15)
    
    logger.info("✓ Agent ready")
    logger.info("="*60)
    
    return _graph


# ============================================================================
# A2A Server with FastAPI (Optimized)
# ============================================================================

app = FastAPI(default_response_class=ORJSONResponse)  # Faster JSON serialization
app.add_middleware(GZipMiddleware, minimum_size=1000)  # Compress responses > 1KB


@app.post("/")
async def a2a_endpoint(request: FastAPIRequest):
    """A2A JSON-RPC endpoint with session tracking"""
    try:
        body = await request.json()
        
        # Extract session/actor info
        actor_id = body.get("actor_id", "default-user")
        session_id = body.get("session_id", str(uuid.uuid4()))
        
        text = extract_message_text(body)
        
        logger.info("="*60)
        logger.info(f"NEW REQUEST | Actor: {actor_id} | Session: {session_id}")
        logger.info(f"Query: {text[:100]}...")
        logger.info("="*60)
        
        # Initialize agent on first request only (lazy initialization)
        graph = _initialize_agent()
        
        # Invoke graph with system prompt prepended
        result = await graph.ainvoke({"messages": [HumanMessage(content=text)]})
        response_text = result["messages"][-1].content if result.get("messages") else "No response"
        
        logger.info(f"Response: {response_text[:200]}...")
        logger.info("="*60)
        
        # Return appropriate format
        if "method" not in body:
            return response_text  # Simple format
        else:
            return format_a2a_response(response_text, body.get("id"))  # A2A format
            
    except Exception as e:
        logger.error(f"ERROR: {str(e)}")
        logger.error(traceback.format_exc())
        return {
            "jsonrpc": "2.0",
            "id": body.get("id") if 'body' in locals() else None,
            "error": {"code": -32603, "message": f"Internal error: {str(e)}"}
        }


@app.get("/.well-known/agent-card.json")
def agent_card():
    """Agent card endpoint for A2A discovery"""
    # Initialize agent to get tools count (lazy)
    _initialize_agent()
    
    return {
        "protocolVersions": ["0.3"],
        "name": AGENT_NAME,
        "description": f"{AGENT_DESCRIPTION} with {len(_tools)} tools",
        "supportedInterfaces": [{"url": AGENTCORE_RUNTIME_URL, "protocolBinding": "JSONRPC"}],
        "version": "2.0.0",  # Enhanced version
        "capabilities": {"streaming": False, "pushNotifications": False},
        "defaultInputModes": ["text/plain"],
        "defaultOutputModes": ["text/plain"],
        "skills": [create_agent_card_skill(tool) for tool in _tools]
    }


# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    logger.info("Starting Optimized A2A Server on port 9000...")
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=9000,
        log_level="warning",  # Reduced logging noise
        timeout_keep_alive=300
    )
