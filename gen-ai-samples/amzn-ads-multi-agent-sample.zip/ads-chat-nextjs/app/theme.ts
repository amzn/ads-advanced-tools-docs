export const themes = {
  dark: {
    // Main backgrounds - Amazon Ads dark theme
    bgPrimary: '#0F1419',
    bgSecondary: '#16191F',
    bgSidebar: '#0A0E13',
    bgInput: '#1A1F29',
    
    // Borders
    borderPrimary: '#2D3139',
    borderSecondary: '#3D4149',
    
    // Text
    textPrimary: '#FFFFFF',
    textSecondary: '#D5D7DA',
    textMuted: '#8B8D98',
    
    // Buttons - Softer amber/orange
    btnPrimary: '#E88B2C',
    btnPrimaryHover: '#D67D24',
    btnSecondary: '#1A1F29',
    
    // Avatars
    avatarUser: '#E88B2C',
    avatarAssistant: '#00A8E1',
    
    // Code
    codeBg: '#0A0E13',
    
    // Error
    errorBg: '#3D1F1F',
    
    // Scrollbar
    scrollbarTrack: '#16191F',
    scrollbarThumb: '#3D4149',
    scrollbarThumbHover: '#4D5159'
  },
  light: {
    // Main backgrounds - Amazon Ads light theme
    bgPrimary: '#FFFFFF',
    bgSecondary: '#F5F5F5',
    bgSidebar: '#FAFAFA',
    bgInput: '#FFFFFF',
    
    // Borders
    borderPrimary: '#E5E5E5',
    borderSecondary: '#D1D1D1',
    
    // Text
    textPrimary: '#0F1419',
    textSecondary: '#545B64',
    textMuted: '#8B8D98',
    
    // Buttons - Softer amber/orange (same as dark mode)
    btnPrimary: '#E88B2C',
    btnPrimaryHover: '#D67D24',
    btnSecondary: '#F5F5F5',
    
    // Avatars
    avatarUser: '#E88B2C',
    avatarAssistant: '#00A8E1',
    
    // Code
    codeBg: '#F5F5F5',
    
    // Error
    errorBg: '#FEE',
    
    // Scrollbar
    scrollbarTrack: '#F5F5F5',
    scrollbarThumb: '#D1D1D1',
    scrollbarThumbHover: '#B1B1B1'
  }
};

export type ThemeColors = typeof themes.dark;
