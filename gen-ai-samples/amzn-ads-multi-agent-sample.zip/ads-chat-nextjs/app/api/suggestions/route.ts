import { NextResponse } from 'next/server';

// Curated suggestions organized by category
const SUGGESTIONS = [
  // Profile Management
  'Show me a list of first 5 US advertising profiles',
  'What profiles do I have access to?',
  
  // Campaign Management
  'How do I create a new Sponsored Products campaign?',
  'Show me my active campaigns',
  'What are my top performing campaigns?',
  'Help me optimize my campaign budget allocation',
  'How can I improve my campaign ROI?',
  'What is the difference between ACOS and ROAS?',
  
  // Knowledge Base / Best Practices
  'What are the different types of Amazon Ads campaigns?',
  'Explain the difference between automatic and manual targeting',
  'What metrics should I track for campaign performance?',
  'How does Amazon\'s advertising auction work?',
  'Best practices for keyword research in Amazon Ads',
  'Tell me about budget allocation strategies',
  'How do I use negative keywords effectively?',
  'What are the best practices for product targeting?',
  
  // Performance Analysis
  'Analyze my advertising spend efficiency',
  'What are my top performing keywords this month?',
  'Show me my campaign performance metrics'
];

export async function GET() {
  try {
    // Shuffle suggestions for variety
    const shuffled = [...SUGGESTIONS].sort(() => Math.random() - 0.5);
    
    return NextResponse.json({
      suggestions: shuffled,
      source: 'curated'
    });
    
  } catch (error) {
    console.error('Error in suggestions endpoint:', error);
    
    return NextResponse.json({
      suggestions: SUGGESTIONS,
      source: 'curated',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}
