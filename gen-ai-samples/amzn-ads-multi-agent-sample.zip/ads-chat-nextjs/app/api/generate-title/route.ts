import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message } = body;
    
    if (!message) {
      return NextResponse.json(
        { error: 'Missing message' },
        { status: 400 }
      );
    }
    
    // Use the full message as title (will be truncated by CSS in UI)
    let title = message.trim();
    
    // Limit to reasonable length (200 characters)
    if (title.length > 200) {
      title = title.slice(0, 197) + '...';
    }
    
    console.log(`[API] Generated title: "${title.slice(0, 50)}..." from message`);
    
    return NextResponse.json({ title });
    
  } catch (error) {
    console.error('Error in generate-title endpoint:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
