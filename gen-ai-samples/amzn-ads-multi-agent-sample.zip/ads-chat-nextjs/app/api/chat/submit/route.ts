import { NextRequest, NextResponse } from 'next/server';
import { SignatureV4 } from '@smithy/signature-v4';
import { Sha256 } from '@aws-crypto/sha256-js';
import { HttpRequest } from '@smithy/protocol-http';
import { defaultProvider } from '@aws-sdk/credential-provider-node';
import { jobStore, encodeJobToken } from '@/lib/jobStore';

const ORCHESTRATION_AGENT_ARN = process.env.ORCHESTRATION_AGENT_ARN || '';
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';

async function callOrchestrationAgent(message: string, sessionId: string, userId: string): Promise<string> {
  try {
    const encodedArn = encodeURIComponent(ORCHESTRATION_AGENT_ARN);
    const url = `https://bedrock-agentcore.${AWS_REGION}.amazonaws.com/runtimes/${encodedArn}/invocations`;
    
    const requestBody = JSON.stringify({
      prompt: message,
      session_id: sessionId,
      user_id: userId
    });
    
    const credentials = await defaultProvider()();
    
    const request = new HttpRequest({
      method: 'POST',
      protocol: 'https:',
      hostname: `bedrock-agentcore.${AWS_REGION}.amazonaws.com`,
      path: `/runtimes/${encodedArn}/invocations`,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'host': `bedrock-agentcore.${AWS_REGION}.amazonaws.com`
      },
      body: requestBody
    });
    
    const signer = new SignatureV4({
      credentials,
      region: AWS_REGION,
      service: 'bedrock-agentcore',
      sha256: Sha256
    });
    
    const signedRequest = await signer.sign(request);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: signedRequest.headers as HeadersInit,
      body: requestBody
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Error: ${response.status} - ${errorText}`);
      return `Error calling agent: ${response.status}`;
    }
    
    let result = await response.text();
    
    // Try to parse as JSON first (in case backend returns {"response": "..."})
    try {
      const jsonResult = JSON.parse(result);
      if (jsonResult.response) {
        result = jsonResult.response;
      }
    } catch {
      // Not JSON, continue with text processing
    }
    
    // Remove escaped newlines
    if (result.includes('\\n')) {
      result = result.replace(/\\n/g, '\n');
    }
    
    // Remove surrounding quotes if present
    result = result.trim();
    if ((result.startsWith('"') && result.endsWith('"')) || 
        (result.startsWith("'") && result.endsWith("'"))) {
      result = result.slice(1, -1);
    }
    
    return result;
    
  } catch (error) {
    console.error('Error calling orchestration agent:', error);
    return `Error: ${error instanceof Error ? error.message : 'Unknown error'}`;
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, session_id, user_id } = body;
    
    if (!message || !session_id) {
      return NextResponse.json(
        { error: 'Missing message or session_id' },
        { status: 400 }
      );
    }
    
    // Generate job ID
    const jobId = `job-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Create initial job data
    const initialJob = {
      status: 'processing' as const,
      sessionId: session_id,
      message
    };
    
    // Store in memory (for same Lambda instance)
    jobStore.set(jobId, initialJob);
    
    // Verify job was created
    const verifyJob = jobStore.get(jobId);
    if (!verifyJob) {
      console.error(`[API] CRITICAL: Job ${jobId} was not stored properly!`);
      return NextResponse.json(
        { error: 'Failed to create job' },
        { status: 500 }
      );
    }
    
    console.log(`[API] Job ${jobId} created and verified for session ${session_id}`);
    console.log(`[API] JobStore size: ${jobStore.size()}, Job status: ${verifyJob.status}`);
    
    // Create a token that contains the job data (for cross-Lambda instance support)
    const jobToken = encodeJobToken({
      ...initialJob,
      createdAt: Date.now()
    });
    
    // Start async processing (don't await)
    (async () => {
      try {
        console.log(`[API] Job ${jobId} - Calling agent...`);
        const response = await callOrchestrationAgent(message, session_id, user_id || 'default-user');
        console.log(`[API] Job ${jobId} - Agent response received (${response.length} chars)`);
        
        const completedJob = {
          status: 'complete' as const,
          response,
          sessionId: session_id,
          message
        };
        
        jobStore.set(jobId, completedJob);
        
        console.log(`[API] Job ${jobId} - Marked as complete`);
        
      } catch (error) {
        console.error(`[API] Job ${jobId} - Error:`, error);
        jobStore.set(jobId, { 
          status: 'error',
          error: error instanceof Error ? error.message : 'Unknown error',
          sessionId: session_id,
          message
        });
      }
    })();
    
    // Return immediately with job ID and token
    return NextResponse.json({ 
      jobId,
      jobToken, // Client will pass this back for cross-instance support
      created: true,
      timestamp: Date.now()
    });
    
  } catch (error) {
    console.error('Error in submit endpoint:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
