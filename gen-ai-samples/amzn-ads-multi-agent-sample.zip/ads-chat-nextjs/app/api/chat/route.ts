import { NextRequest, NextResponse } from 'next/server';
import { SignatureV4 } from '@smithy/signature-v4';
import { Sha256 } from '@aws-crypto/sha256-js';
import { HttpRequest } from '@smithy/protocol-http';
import { defaultProvider } from '@aws-sdk/credential-provider-node';

const ORCHESTRATION_AGENT_ARN = process.env.ORCHESTRATION_AGENT_ARN || '';
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';

async function callOrchestrationAgent(message: string, sessionId: string, userId: string): Promise<string> {
  try {
    // Encode ARN for URL
    const encodedArn = encodeURIComponent(ORCHESTRATION_AGENT_ARN);
    const url = `https://bedrock-agentcore.${AWS_REGION}.amazonaws.com/runtimes/${encodedArn}/invocations`;
    
    // Build request body
    const requestBody = JSON.stringify({
      prompt: message,
      session_id: sessionId,
      user_id: userId
    });
    
    // Get AWS credentials
    const credentials = await defaultProvider()();
    
    // Create HTTP request
    const request = new HttpRequest({
      method: 'POST',
      protocol: 'https:',
      hostname: `bedrock-agentcore.${AWS_REGION}.amazonaws.com`,
      path: `/runtimes/${encodedArn}/invocations`,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'host': `bedrock-agentcore.${AWS_REGION}.amazonaws.com`
      },
      body: requestBody
    });
    
    // Sign the request with SigV4
    const signer = new SignatureV4({
      credentials,
      region: AWS_REGION,
      service: 'bedrock-agentcore',
      sha256: Sha256
    });
    
    const signedRequest = await signer.sign(request);
    
    // Make the HTTP request
    const response = await fetch(url, {
      method: 'POST',
      headers: signedRequest.headers as HeadersInit,
      body: requestBody
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Error: ${response.status} - ${errorText}`);
      return `Error calling agent: ${response.status}`;
    }
    
    let result = await response.text();
    
    // Try to parse as JSON first (in case backend returns {"response": "..."})
    try {
      const jsonResult = JSON.parse(result);
      if (jsonResult.response) {
        result = jsonResult.response;
      }
    } catch {
      // Not JSON, use as-is
    }
    
    // Handle escaped newlines if present
    if (result.includes('\\n')) {
      result = result.replace(/\\n/g, '\n');
    }
    
    console.log(`Response received: ${result.substring(0, 100)}...`);
    return result;
    
  } catch (error) {
    console.error('Error calling orchestration agent:', error);
    return `Error: ${error instanceof Error ? error.message : 'Unknown error'}`;
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, session_id, user_id } = body;
    
    console.log(`[API] New request - Session: ${session_id}, Message: ${message.substring(0, 50)}...`);
    
    if (!message || !session_id) {
      return NextResponse.json(
        { error: 'Missing message or session_id' },
        { status: 400 }
      );
    }
    
    // Create a streaming response using Server-Sent Events
    // This keeps the connection alive and avoids the 30s timeout
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Send a heartbeat immediately to establish the connection
          controller.enqueue(encoder.encode(': heartbeat\n\n'));
          
          // Set up interval to send keepalive messages every 5 seconds
          const keepaliveInterval = setInterval(() => {
            try {
              controller.enqueue(encoder.encode(': keepalive\n\n'));
            } catch (e) {
              clearInterval(keepaliveInterval);
            }
          }, 5000);
          
          console.log(`[API] Calling agent...`);
          
          try {
            // Call the agent (this may take > 30s)
            const response = await callOrchestrationAgent(message, session_id, user_id || 'default-user');
            console.log(`[API] Agent response received: ${response.substring(0, 100)}...`);
            
            // Clear the keepalive interval
            clearInterval(keepaliveInterval);
            
            // Send the complete response as a single chunk
            controller.enqueue(
              encoder.encode(`data: ${JSON.stringify({ chunk: response })}\n\n`)
            );
            
            // Send completion signal
            controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          } catch (agentError) {
            clearInterval(keepaliveInterval);
            throw agentError;
          }
          
          controller.close();
        } catch (error) {
          console.error('[API] Streaming error:', error);
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify({ error: 'Failed to get response' })}\n\n`)
          );
          controller.close();
        }
      },
    });
    
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache, no-store, no-transform, must-revalidate',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no', // Disable nginx buffering
        'Pragma': 'no-cache',
        'Expires': '0',
      },
    });
    
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
