import { NextRequest, NextResponse } from 'next/server';
import { jobStore, decodeJobToken } from '@/lib/jobStore';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ jobId: string }> }
) {
  try {
    // Await params in Next.js 15+
    const { jobId } = await params;
    
    // Get job token from query params (for cross-Lambda instance support)
    const jobToken = request.nextUrl.searchParams.get('token');
    
    console.log(`[API] Status check for job ${jobId}, JobStore size: ${jobStore.size()}, has token: ${!!jobToken}`);
    
    if (!jobId) {
      return NextResponse.json(
        { error: 'Missing jobId' },
        { status: 400 }
      );
    }
    
    // Try to get job from memory first (same Lambda instance)
    let job = jobStore.get(jobId);
    
    // If not found in memory but we have a token, decode it (different Lambda instance)
    if (!job && jobToken) {
      console.log(`[API] Job ${jobId} not in memory, attempting to decode token`);
      const decodedJob = decodeJobToken(jobToken);
      
      if (decodedJob) {
        console.log(`[API] Job ${jobId} decoded from token, status: ${decodedJob.status}`);
        job = decodedJob;
        
        // Store it in memory for future requests to this instance
        jobStore.set(jobId, decodedJob);
      }
    }
    
    if (!job) {
      console.error(`[API] Job ${jobId} NOT FOUND. JobStore size: ${jobStore.size()}, token provided: ${!!jobToken}`);
      console.error(`[API] This indicates the job was lost across Lambda instances and no token was provided.`);
      return NextResponse.json(
        { error: 'Job not found' },
        { status: 404 }
      );
    }
    
    console.log(`[API] Job ${jobId} found - status: ${job.status}, response length: ${job.response?.length || 0}`);
    
    // Return job status with updated token (in case status changed)
    return NextResponse.json({
      status: job.status,
      response: job.response,
      error: job.error
    });
    
  } catch (error) {
    console.error('Error in status endpoint:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
