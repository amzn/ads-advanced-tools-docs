'use client';

import { useState, useEffect } from 'react';
import ChatWindow from './components/ChatWindow';
import Sidebar from './components/Sidebar';
import SettingsModal from './components/SettingsModal';
import { ThemeProvider } from './context/ThemeContext';

export interface Message {
  id: number;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isError?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
}

export default function Home() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | undefined>();
  const [userId, setUserId] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const storedConversations = localStorage.getItem('conversations');
    const storedCurrentId = localStorage.getItem('currentConversationId');
    
    if (storedConversations) {
      const parsed = JSON.parse(storedConversations);
      setConversations(parsed);
      
      // Try to restore the last active conversation
      if (storedCurrentId && parsed.find((c: Conversation) => c.id === storedCurrentId)) {
        setCurrentConversationId(storedCurrentId);
      } else if (parsed.length > 0) {
        // If stored ID doesn't exist, use first conversation
        setCurrentConversationId(parsed[0].id);
      }
    }

    let storedUserId = localStorage.getItem('userId');
    if (!storedUserId) {
      storedUserId = `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('userId', storedUserId);
    }
    setUserId(storedUserId);
  }, []);

  useEffect(() => {
    if (conversations.length > 0) {
      localStorage.setItem('conversations', JSON.stringify(conversations));
    }
  }, [conversations]);

  // Save current conversation ID to localStorage
  useEffect(() => {
    if (currentConversationId) {
      localStorage.setItem('currentConversationId', currentConversationId);
    } else {
      localStorage.removeItem('currentConversationId');
    }
  }, [currentConversationId]);

  const handleNewConversation = () => {
    const newConv: Conversation = {
      id: `conv-${Date.now()}`,
      title: 'New conversation',
      messages: [],
      createdAt: new Date().toISOString()
    };
    setConversations([newConv, ...conversations]);
    setCurrentConversationId(newConv.id);
  };

  const handleSelectConversation = (id: string) => {
    setCurrentConversationId(id);
  };

  const handleUpdateConversation = (id: string, updates: Partial<Conversation>) => {
    setConversations(prevConversations => 
      prevConversations.map(conv => {
        if (conv.id === id) {
          // Merge updates carefully, preserving existing data
          return {
            ...conv,
            ...updates,
            // Ensure messages are preserved if not explicitly updated
            messages: updates.messages !== undefined ? updates.messages : conv.messages
          };
        }
        return conv;
      })
    );
  };

  const handleDeleteConversation = (id: string) => {
    const updated = conversations.filter(conv => conv.id !== id);
    setConversations(updated);
    
    if (currentConversationId === id) {
      const newCurrentId = updated.length > 0 ? updated[0].id : undefined;
      setCurrentConversationId(newCurrentId);
      
      // Update or remove from localStorage
      if (newCurrentId) {
        localStorage.setItem('currentConversationId', newCurrentId);
      } else {
        localStorage.removeItem('currentConversationId');
      }
    }
    
    // Also update conversations in localStorage immediately
    if (updated.length > 0) {
      localStorage.setItem('conversations', JSON.stringify(updated));
    } else {
      localStorage.removeItem('conversations');
    }
  };

  const handleReorderConversations = (reorderedConversations: Conversation[]) => {
    setConversations(reorderedConversations);
  };

  const currentConversation = conversations.find(conv => conv.id === currentConversationId);

  return (
    <ThemeProvider>
      <div style={{ display: 'flex', height: '100vh', width: '100vw', overflow: 'hidden', position: 'relative' }}>
        <Sidebar
          conversations={conversations}
          currentConversationId={currentConversationId}
          onSelectConversation={(id) => {
            handleSelectConversation(id);
            setSidebarOpen(false); // Close sidebar on mobile after selection
          }}
          onNewConversation={() => {
            handleNewConversation();
            setSidebarOpen(false); // Close sidebar on mobile after creating new chat
          }}
          onDeleteConversation={handleDeleteConversation}
          onReorderConversations={handleReorderConversations}
          onOpenSettings={() => setSettingsOpen(true)}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        
        <ChatWindow
          conversation={currentConversation}
          userId={userId}
          onUpdateConversation={handleUpdateConversation}
          onNewConversation={handleNewConversation}
          onOpenSidebar={() => setSidebarOpen(true)}
        />

        <SettingsModal
          isOpen={settingsOpen}
          onClose={() => setSettingsOpen(false)}
        />
      </div>
    </ThemeProvider>
  );
}
