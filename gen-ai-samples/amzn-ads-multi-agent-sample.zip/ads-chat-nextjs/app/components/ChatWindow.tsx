'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import MessageComponent from './Message';
import { Conversation, Message } from '../page';
import { useTheme } from '../context/ThemeContext';
import { themes } from '../theme';

interface ChatWindowProps {
  conversation: Conversation | undefined;
  userId: string | null;
  onUpdateConversation: (id: string, updates: Partial<Conversation>) => void;
  onNewConversation: () => void;
  onOpenSidebar: () => void;
}

export default function ChatWindow({
  conversation,
  userId,
  onUpdateConversation,
  onNewConversation,
  onOpenSidebar
}: ChatWindowProps) {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuggestionsLoading, setIsSuggestionsLoading] = useState(true);
  const [allSuggestions, setAllSuggestions] = useState<string[]>([
    'What are the different types of Amazon Ads campaigns?',
    'How do I optimize my Sponsored Products campaign?',
    'Explain the difference between automatic and manual targeting',
    'What metrics should I track for campaign performance?'
  ]);
  const [displayedSuggestions, setDisplayedSuggestions] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRotating, setIsRotating] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const activeConversationRef = useRef<string | undefined>(conversation?.id);
  const { effectiveTheme } = useTheme();
  const colors = themes[effectiveTheme];

  // Update active conversation ref when conversation changes
  useEffect(() => {
    activeConversationRef.current = conversation?.id;
  }, [conversation?.id]);

  // Fetch suggestions from agent cards on mount
  useEffect(() => {
    const fetchSuggestions = async () => {
      try {
        setIsSuggestionsLoading(true);
        const response = await fetch('/api/suggestions');
        if (response.ok) {
          const data = await response.json();
          if (data.suggestions && data.suggestions.length > 0) {
            setAllSuggestions(data.suggestions);
            // Show first 6 suggestions
            setDisplayedSuggestions(data.suggestions.slice(0, 6));
          }
        }
      } catch (error) {
        console.error('Error fetching suggestions:', error);
        // Keep default suggestions on error
        setDisplayedSuggestions(allSuggestions.slice(0, 6));
      } finally {
        setIsSuggestionsLoading(false);
      }
    };

    fetchSuggestions();
  }, []);

  const rotateSuggestions = useCallback(() => {
    if (allSuggestions.length <= 6) return;
    
    // Start fade out
    setIsRotating(true);
    
    // Wait for fade out, then update suggestions
    setTimeout(() => {
      const nextIndex = (currentIndex + 6) % allSuggestions.length;
      const endIndex = Math.min(nextIndex + 6, allSuggestions.length);
      let newSuggestions = allSuggestions.slice(nextIndex, endIndex);
      
      // If we don't have enough suggestions at the end, wrap around
      if (newSuggestions.length < 6) {
        const remaining = 6 - newSuggestions.length;
        newSuggestions = [...newSuggestions, ...allSuggestions.slice(0, remaining)];
      }
      
      setDisplayedSuggestions(newSuggestions);
      setCurrentIndex(nextIndex);
      
      // Fade back in
      setTimeout(() => {
        setIsRotating(false);
      }, 50);
    }, 300); // Match the CSS transition duration
  }, [allSuggestions, currentIndex]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [input]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date().toISOString()
    };

    if (!conversation) {
      onNewConversation();
      return;
    }

    const isFirstMessage = conversation.messages.length === 0;
    const messageContent = input.trim();
    const conversationId = conversation.id; // Capture conversation ID
    
    const updatedMessages = [...conversation.messages, userMessage];
    onUpdateConversation(conversation.id, {
      messages: updatedMessages
    });

    setInput('');
    setIsLoading(true);

    try {
      const assistantMessageId = Date.now() + 1;

      // Submit job (async, returns immediately)
      const submitResponse = await fetch('/api/chat/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageContent,
          session_id: conversationId,
          user_id: userId
        })
      });

      if (!submitResponse.ok) {
        throw new Error(`HTTP error! status: ${submitResponse.status}`);
      }

      const { jobId, jobToken } = await submitResponse.json();

      // Poll for result with fast intervals (no initial wait)
      const pollForResult = async (): Promise<string> => {
        const maxAttempts = 300;
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
          await new Promise(resolve => setTimeout(resolve, attempt < 5 ? 500 : 1000));

          const statusUrl = `/api/chat/status/${jobId}${jobToken ? `?token=${encodeURIComponent(jobToken)}` : ''}`;
          const statusResponse = await fetch(statusUrl);

          if (statusResponse.status === 404) continue;
          if (!statusResponse.ok) throw new Error(`Status check failed: ${statusResponse.status}`);

          const jobStatus = await statusResponse.json();
          if (jobStatus.status === 'complete') return jobStatus.response || 'No response received';
          if (jobStatus.status === 'error') throw new Error(jobStatus.error || 'Job failed');
        }
        throw new Error('Request timed out');
      };

      const responseContent = await pollForResult();

      const finalAssistantMessage: Message = {
        id: assistantMessageId,
        role: 'assistant',
        content: responseContent,
        timestamp: new Date().toISOString()
      };

      const finalMessages = [...updatedMessages, finalAssistantMessage];
      onUpdateConversation(conversationId, {
        messages: finalMessages
      });

      // Generate title for first message
      if (isFirstMessage) {
        fetch('/api/generate-title', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: messageContent })
        })
          .then(async (titleResponse) => {
            if (titleResponse.ok) {
              const { title } = await titleResponse.json();
              onUpdateConversation(conversationId, { title });
            }
          })
          .catch(console.error);
      }

    } catch (error: any) {
      console.error('Error sending message:', error);
      
      // Always update the correct conversation with error
      const errorMessage: Message = {
        id: Date.now() + 1,
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: new Date().toISOString(),
        isError: true
      };
      onUpdateConversation(conversationId, {
        messages: [...updatedMessages, errorMessage]
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  if (!conversation) {
    return (
      <div style={{ ...styles.chatWindow, backgroundColor: colors.bgPrimary }}>
        <div style={styles.emptyState}>
          <h1 style={{ ...styles.emptyStateH1, color: colors.textPrimary }}>Ads Assistant Demo</h1>
          <p style={{ ...styles.emptyStateP, color: colors.textSecondary }}>Start a new conversation to get help with your advertising campaigns</p>
          <button 
            style={{ ...styles.startBtn, backgroundColor: colors.btnPrimary }}
            onClick={onNewConversation}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = colors.btnPrimaryHover;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = colors.btnPrimary;
            }}
          >
            Start New Conversation
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ ...styles.chatWindow, backgroundColor: colors.bgPrimary }}>
      {/* Mobile hamburger menu */}
      <button
        onClick={onOpenSidebar}
        style={{
          ...styles.hamburgerBtn,
          backgroundColor: colors.bgSecondary,
          color: colors.textPrimary,
          borderColor: colors.borderSecondary
        }}
        className="hamburger-menu"
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = colors.btnSecondary;
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = colors.bgSecondary;
        }}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <line x1="3" y1="12" x2="21" y2="12"></line>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>
      </button>
      
      <div style={{ ...styles.messagesContainer, paddingBottom: conversation?.messages.length === 0 ? '24px' : '180px' }} className="messages-container">
        {conversation.messages.length === 0 ? (
          <div style={styles.welcomeMessage}>
            <h2 style={{ ...styles.welcomeH2, color: colors.textPrimary }} className="welcome-h2">👋 Welcome to Ads Assistant Demo</h2>
            <p style={{ ...styles.welcomeP, color: colors.textSecondary }} className="welcome-p">I can help you with:</p>
            
            {isSuggestionsLoading ? (
              <div style={{ ...styles.loadingMessage, color: colors.textMuted }}>
                <div style={styles.loadingSpinner}></div>
                <span>Loading suggestions...</span>
              </div>
            ) : (
              <>
                <div 
                  style={{
                    ...styles.suggestions,
                    opacity: isRotating ? 0 : 1,
                    transition: 'opacity 0.3s ease-in-out'
                  }} 
                  className="suggestions-grid"
                >
                  {displayedSuggestions.map((text, i) => (
                    <button 
                      key={`${currentIndex}-${i}`}
                      style={{ ...styles.suggestionBtn, backgroundColor: colors.bgInput, borderColor: colors.borderSecondary, color: colors.textPrimary }}
                      className="suggestion-btn"
                      onClick={() => setInput(text)}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = colors.bgSecondary;
                        e.currentTarget.style.borderColor = colors.borderPrimary;
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = colors.bgInput;
                        e.currentTarget.style.borderColor = colors.borderSecondary;
                      }}
                    >
                      {text}
                    </button>
                  ))}
                </div>
                {/* Centered refresh button below suggestions */}
                {allSuggestions.length > 6 && (
                  <div style={{ display: 'flex', justifyContent: 'center', marginTop: '16px' }}>
                    <button
                      onClick={rotateSuggestions}
                      disabled={isRotating}
                      style={{ 
                        ...styles.suggestionBtn, 
                        backgroundColor: colors.bgInput, 
                        borderColor: colors.borderSecondary, 
                        color: colors.textPrimary,
                        opacity: isRotating ? 0.5 : 1,
                        cursor: isRotating ? 'not-allowed' : 'pointer'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = colors.bgSecondary;
                        e.currentTarget.style.borderColor = colors.borderPrimary;
                        const svg = e.currentTarget.querySelector('svg');
                        if (svg) (svg as SVGElement).style.transform = 'rotate(180deg)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = colors.bgInput;
                        e.currentTarget.style.borderColor = colors.borderSecondary;
                        const svg = e.currentTarget.querySelector('svg');
                        if (svg) (svg as SVGElement).style.transform = 'rotate(0deg)';
                      }}
                      title="Show more suggestions"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transition: 'transform 0.3s ease', marginRight: '8px' }}>
                        <polyline points="23 4 23 10 17 10"></polyline>
                        <polyline points="1 20 1 14 7 14"></polyline>
                        <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                      </svg>
                      More suggestions
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        ) : (
          <>
            {conversation.messages.map(message => (
              <MessageComponent key={message.id} message={message} />
            ))}
            {isLoading && (
              <div style={{ display: 'flex', gap: '16px', padding: '24px', maxWidth: '800px', margin: '0 auto', width: '100%', backgroundColor: colors.bgSecondary }}>
                <div style={{ width: '32px', height: '32px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, backgroundColor: colors.avatarAssistant, color: 'white' }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
                  </svg>
                </div>
                <div style={{ flex: 1, color: colors.textPrimary, lineHeight: 1.6 }}>
                  <div style={styles.typingIndicator}>
                    <span style={styles.typingDot}></span>
                    <span style={{ ...styles.typingDot, animationDelay: '0.2s' }}></span>
                    <span style={{ ...styles.typingDot, animationDelay: '0.4s' }}></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      <div style={{ ...styles.inputContainer, backgroundColor: colors.bgPrimary, borderColor: colors.borderPrimary }} className="input-container fixed-input">
        <form onSubmit={handleSubmit} style={{ ...styles.inputForm, backgroundColor: colors.bgInput, borderColor: colors.borderSecondary }} className="input-form">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Message Ads Assistant Demo..."
            rows={1}
            disabled={isLoading}
            style={{ ...styles.textarea, color: colors.textPrimary }}
            className="textarea"
          />
          <button 
            type="submit" 
            disabled={!input.trim() || isLoading}
            style={{
              ...styles.submitBtn,
              color: colors.textMuted,
              ...((!input.trim() || isLoading) ? styles.submitBtnDisabled : {})
            }}
            className="submit-btn"
            onMouseEnter={(e) => {
              if (input.trim() && !isLoading) {
                e.currentTarget.style.color = colors.textPrimary;
              }
            }}
            onMouseLeave={(e) => {
              if (input.trim() && !isLoading) {
                e.currentTarget.style.color = colors.textMuted;
              }
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          </button>
        </form>
        <div style={{ ...styles.disclaimer, color: colors.textMuted }} className="disclaimer">
          Ads Assistant Demo can make mistakes. Please verify important information.
        </div>
      </div>

      <style jsx>{`
        @keyframes typing {
          0%, 60%, 100% {
            opacity: 0.3;
            transform: translateY(0);
          }
          30% {
            opacity: 1;
            transform: translateY(-10px);
          }
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
      
      <style jsx global>{`
        /* Fixed input on mobile */
        @media (max-width: 768px) {
          .fixed-input {
            position: fixed !important;
            bottom: 0 !important;
            left: 0 !important;
            right: 0 !important;
            z-index: 100 !important;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1) !important;
          }
          
          .hamburger-menu {
            display: block !important;
            position: fixed !important;
            top: 16px !important;
            left: 16px !important;
            z-index: 101 !important;
          }
          
          /* Add bottom padding to prevent content hiding under fixed input */
          .messages-container {
            padding-bottom: 180px !important;
          }
        }
        
        /* Mobile optimizations */
        @media (max-width: 640px) {
          /* Reduce padding on mobile but add extra bottom padding for fixed input */
          .messages-container {
            padding: 12px !important;
            padding-bottom: 180px !important;
          }
          
          /* Smaller welcome text */
          .welcome-h2 {
            font-size: 22px !important;
          }
          
          .welcome-p {
            font-size: 14px !important;
            margin-bottom: 20px !important;
          }
          
          /* Smaller suggestion cards */
          .suggestions-grid {
            grid-template-columns: 1fr !important;
            gap: 8px !important;
            margin-top: 16px !important;
          }
          
          .suggestion-btn {
            padding: 12px !important;
            font-size: 13px !important;
          }
          
          /* Compact input area */
          .input-container {
            padding: 12px !important;
          }
          
          .input-form {
            border-radius: 8px !important;
          }
          
          .textarea {
            font-size: 16px !important;
            padding: 12px !important;
          }
          
          .submit-btn {
            padding: 8px 12px !important;
          }
          
          .disclaimer {
            font-size: 11px !important;
            margin-top: 6px !important;
          }
          
          /* Compact empty state */
          .empty-state {
            padding: 20px !important;
          }
          
          .empty-state-h1 {
            font-size: 24px !important;
          }
          
          .empty-state-p {
            font-size: 14px !important;
          }
        }
      `}</style>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  chatWindow: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    position: 'relative'
  },
  hamburgerBtn: {
    position: 'fixed',
    top: '16px',
    left: '16px',
    zIndex: 100,
    padding: '8px',
    border: '1px solid',
    borderRadius: '6px',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    display: 'none'
  },
  emptyState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    textAlign: 'center',
    padding: '40px 20px'
  },
  emptyStateH1: {
    fontSize: '32px',
    marginBottom: '16px'
  },
  emptyStateP: {
    fontSize: '16px',
    marginBottom: '24px'
  },
  startBtn: {
    padding: '12px 24px',
    border: 'none',
    borderRadius: '6px',
    color: 'white',
    fontSize: '16px',
    cursor: 'pointer',
    transition: 'background-color 0.2s'
  },
  messagesContainer: {
    flex: 1,
    overflowY: 'auto',
    padding: '24px'
  },
  welcomeMessage: {
    maxWidth: '800px',
    margin: '0 auto',
    textAlign: 'center',
    padding: '40px 20px'
  },
  welcomeH2: {
    fontSize: '28px',
    marginBottom: '16px'
  },
  welcomeP: {
    fontSize: '16px',
    marginBottom: '32px'
  },
  loadingMessage: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '12px',
    padding: '40px',
    fontSize: '16px'
  },
  loadingSpinner: {
    width: '20px',
    height: '20px',
    border: '3px solid rgba(139, 141, 152, 0.3)',
    borderTop: '3px solid #E88B2C',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite'
  },
  suggestions: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '12px',
    marginTop: '24px'
  },
  suggestionBtn: {
    padding: '16px',
    border: '1px solid',
    borderRadius: '8px',
    fontSize: '14px',
    cursor: 'pointer',
    transition: 'all 0.2s',
    textAlign: 'left'
  },
  inputContainer: {
    padding: '24px',
    borderTop: '1px solid'
  },
  inputForm: {
    maxWidth: '800px',
    margin: '0 auto',
    position: 'relative',
    display: 'flex',
    alignItems: 'flex-end',
    borderRadius: '12px',
    border: '1px solid'
  },
  disclaimer: {
    maxWidth: '800px',
    margin: '8px auto 0',
    fontSize: '12px',
    textAlign: 'center',
    padding: '0 16px'
  },
  textarea: {
    flex: 1,
    background: 'transparent',
    border: 'none',
    fontSize: '16px',
    padding: '16px',
    resize: 'none',
    maxHeight: '200px',
    outline: 'none',
    fontFamily: 'inherit'
  },
  submitBtn: {
    backgroundColor: 'transparent',
    border: 'none',
    cursor: 'pointer',
    padding: '12px 16px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'color 0.2s'
  },
  submitBtnDisabled: {
    opacity: 0.4,
    cursor: 'not-allowed'
  },
  typingIndicator: {
    display: 'flex',
    gap: '4px',
    padding: '8px 0'
  },
  typingDot: {
    width: '8px',
    height: '8px',
    borderRadius: '50%',
    backgroundColor: '#8B8D98',
    animation: 'typing 1.4s infinite'
  }
};
