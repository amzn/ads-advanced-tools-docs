'use client';

import { useTheme } from '../context/ThemeContext';
import { themes } from '../theme';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { theme, setTheme, effectiveTheme } = useTheme();
  const colors = themes[effectiveTheme];

  if (!isOpen) return null;

  return (
    <div style={styles.overlay} onClick={onClose}>
      <div style={{ ...styles.modal, backgroundColor: colors.bgPrimary, borderColor: colors.borderPrimary }} onClick={(e) => e.stopPropagation()}>
        <div style={{ ...styles.header, borderColor: colors.borderPrimary }}>
          <h2 style={{ ...styles.title, color: colors.textPrimary }}>Settings</h2>
          <button style={{ ...styles.closeBtn, color: colors.textPrimary }} onClick={onClose}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        <div style={styles.content}>
          <div style={styles.section}>
            <label style={{ ...styles.label, color: colors.textPrimary }}>Theme</label>
            <div style={styles.themeOptions}>
              <button
                style={{
                  ...styles.themeBtn,
                  backgroundColor: theme === 'light' ? colors.btnPrimary : colors.bgInput,
                  borderColor: theme === 'light' ? colors.btnPrimary : colors.borderSecondary,
                  color: theme === 'light' ? '#ffffff' : colors.textPrimary
                }}
                onClick={() => setTheme('light')}
                onMouseEnter={(e) => {
                  if (theme !== 'light') {
                    e.currentTarget.style.backgroundColor = colors.btnSecondary;
                  }
                }}
                onMouseLeave={(e) => {
                  if (theme !== 'light') {
                    e.currentTarget.style.backgroundColor = colors.bgInput;
                  }
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="5"></circle>
                  <line x1="12" y1="1" x2="12" y2="3"></line>
                  <line x1="12" y1="21" x2="12" y2="23"></line>
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                  <line x1="1" y1="12" x2="3" y2="12"></line>
                  <line x1="21" y1="12" x2="23" y2="12"></line>
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                </svg>
                Light
              </button>

              <button
                style={{
                  ...styles.themeBtn,
                  backgroundColor: theme === 'dark' ? colors.btnPrimary : colors.bgInput,
                  borderColor: theme === 'dark' ? colors.btnPrimary : colors.borderSecondary,
                  color: theme === 'dark' ? '#ffffff' : colors.textPrimary
                }}
                onClick={() => setTheme('dark')}
                onMouseEnter={(e) => {
                  if (theme !== 'dark') {
                    e.currentTarget.style.backgroundColor = colors.btnSecondary;
                  }
                }}
                onMouseLeave={(e) => {
                  if (theme !== 'dark') {
                    e.currentTarget.style.backgroundColor = colors.bgInput;
                  }
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                </svg>
                Dark
              </button>

              <button
                style={{
                  ...styles.themeBtn,
                  backgroundColor: theme === 'system' ? colors.btnPrimary : colors.bgInput,
                  borderColor: theme === 'system' ? colors.btnPrimary : colors.borderSecondary,
                  color: theme === 'system' ? '#ffffff' : colors.textPrimary
                }}
                onClick={() => setTheme('system')}
                onMouseEnter={(e) => {
                  if (theme !== 'system') {
                    e.currentTarget.style.backgroundColor = colors.btnSecondary;
                  }
                }}
                onMouseLeave={(e) => {
                  if (theme !== 'system') {
                    e.currentTarget.style.backgroundColor = colors.bgInput;
                  }
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                  <line x1="8" y1="21" x2="16" y2="21"></line>
                  <line x1="12" y1="17" x2="12" y2="21"></line>
                </svg>
                System
              </button>
            </div>
            {theme === 'system' && (
              <p style={{ ...styles.hint, color: colors.textMuted }}>
                Currently using: {effectiveTheme === 'dark' ? 'Dark' : 'Light'}
              </p>
            )}
          </div>
        </div>

        <div style={{ ...styles.footer, borderColor: colors.borderPrimary }}>
          <button
            style={{ ...styles.doneBtn, backgroundColor: colors.btnPrimary }}
            onClick={onClose}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = colors.btnPrimaryHover;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = colors.btnPrimary;
            }}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  overlay: {
    position: 'fixed',
    inset: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    padding: '16px'
  },
  modal: {
    width: '100%',
    maxWidth: '480px',
    borderRadius: '12px',
    border: '1px solid',
    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '20px 24px',
    borderBottom: '1px solid'
  },
  title: {
    fontSize: '20px',
    fontWeight: 600,
    margin: 0
  },
  closeBtn: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '6px',
    transition: 'opacity 0.2s'
  },
  content: {
    padding: '24px'
  },
  section: {
    marginBottom: '24px'
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: 600,
    marginBottom: '12px'
  },
  themeOptions: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: '8px'
  },
  themeBtn: {
    padding: '12px',
    border: '1px solid',
    borderRadius: '8px',
    fontSize: '14px',
    cursor: 'pointer',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '8px',
    transition: 'all 0.2s',
    fontWeight: 500
  },
  hint: {
    fontSize: '12px',
    marginTop: '8px',
    fontStyle: 'italic'
  },
  footer: {
    padding: '16px 24px',
    borderTop: '1px solid',
    display: 'flex',
    justifyContent: 'flex-end'
  },
  doneBtn: {
    padding: '10px 24px',
    border: 'none',
    borderRadius: '6px',
    color: 'white',
    fontSize: '14px',
    fontWeight: 600,
    cursor: 'pointer',
    transition: 'background-color 0.2s'
  }
};
