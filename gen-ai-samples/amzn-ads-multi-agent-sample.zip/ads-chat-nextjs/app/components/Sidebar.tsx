'use client';

import { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Conversation } from '../page';
import { useTheme } from '../context/ThemeContext';
import { themes } from '../theme';

interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | undefined;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  onReorderConversations: (conversations: Conversation[]) => void;
  onOpenSettings: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({
  conversations,
  currentConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  onReorderConversations,
  onOpenSettings,
  isOpen,
  onClose
}: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('sidebarCollapsed');
      return saved === 'true';
    }
    return false;
  });
  const [hoveredConversation, setHoveredConversation] = useState<string | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState<{ top: number; left: number } | null>(null);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const { effectiveTheme } = useTheme();
  const colors = themes[effectiveTheme];

  const toggleSidebar = () => {
    setIsCollapsed(prev => {
      const newValue = !prev;
      localStorage.setItem('sidebarCollapsed', String(newValue));
      return newValue;
    });
  };

  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    setDragOverIndex(index);
  };

  const handleDragEnd = () => {
    if (draggedIndex !== null && dragOverIndex !== null && draggedIndex !== dragOverIndex) {
      const reordered = [...conversations];
      const [removed] = reordered.splice(draggedIndex, 1);
      reordered.splice(dragOverIndex, 0, removed);
      onReorderConversations(reordered);
    }
    setDraggedIndex(null);
    setDragOverIndex(null);
  };

  const handleConversationHover = (conversationId: string, event: React.MouseEvent<HTMLButtonElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    setHoveredConversation(conversationId);
    setTooltipPosition({
      top: rect.top + rect.height / 2,
      left: rect.right + 10
    });
  };

  const handleConversationLeave = () => {
    setHoveredConversation(null);
    setTooltipPosition(null);
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 998,
            display: 'none'
          }}
          onClick={onClose}
          className="mobile-overlay"
        />
      )}
      
      <div style={{ 
        ...styles.sidebar, 
        backgroundColor: colors.bgSidebar, 
        borderColor: colors.borderPrimary,
        width: isCollapsed ? '80px' : '260px',
        transform: isOpen ? 'translateX(0)' : 'translateX(-100%)',
        transition: 'transform 0.3s ease, width 0.2s ease'
      }}
      className="sidebar-container"
      >
      <div style={{ ...styles.sidebarHeader, borderColor: colors.borderPrimary }}>
        <div style={isCollapsed ? styles.headerButtonsCollapsed : styles.headerButtons}>
          {!isCollapsed && (
            <button 
              style={{ ...styles.newChatBtn, borderColor: colors.borderSecondary, color: colors.textPrimary }}
              onClick={onNewConversation}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = colors.btnSecondary;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ flexShrink: 0 }}>
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              <span style={{ lineHeight: 1 }}>New chat</span>
            </button>
          )}
          
          <button 
            style={{ 
              ...styles.toggleHeaderBtn, 
              color: colors.textPrimary,
              width: isCollapsed ? '100%' : '44px'
            }}
            onClick={toggleSidebar}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = colors.btnSecondary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
            title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            <svg 
              width={isCollapsed ? "24" : "20"}
              height={isCollapsed ? "24" : "20"}
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2"
              style={{ transform: isCollapsed ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}
            >
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="9" y1="3" x2="9" y2="21"></line>
              <polyline points="14 8 18 12 14 16"></polyline>
            </svg>
          </button>
        </div>
        
        {isCollapsed && (
          <button 
            style={{ 
              ...styles.collapsedNewChatBtn, 
              color: colors.textPrimary,
              marginTop: '12px'
            }}
            onClick={onNewConversation}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = colors.btnSecondary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
            title="New chat"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
        )}
      </div>
      
      {!isCollapsed && (
        <div style={styles.conversationsList}>
          {conversations.map((conversation, index) => {
            const isActive = conversation.id === currentConversationId;
            const isDragging = draggedIndex === index;
            const isDragOver = dragOverIndex === index;
            
            return (
              <div
                key={conversation.id}
                draggable
                onDragStart={() => handleDragStart(index)}
                onDragOver={(e) => handleDragOver(e, index)}
                onDragEnd={handleDragEnd}
                style={{
                  ...styles.conversationItem,
                  backgroundColor: isActive ? colors.btnSecondary : 'transparent',
                  color: isActive ? colors.btnPrimary : colors.textPrimary,
                  opacity: isDragging ? 0.5 : 1,
                  borderTop: isDragOver && draggedIndex !== index ? `2px solid ${colors.btnPrimary}` : 'none',
                  cursor: 'grab'
                }}
                onClick={() => onSelectConversation(conversation.id)}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.backgroundColor = colors.btnSecondary;
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }
                }}
              >
                <svg 
                  width="16" 
                  height="16" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke={isActive ? colors.btnPrimary : 'currentColor'}
                  strokeWidth="2"
                >
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                <span style={styles.conversationTitle}>{conversation.title}</span>
                <button
                  className="delete-btn"
                  style={{ ...styles.deleteBtn, color: colors.textMuted, opacity: 1 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteConversation(conversation.id);
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#ff6b6b';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = colors.textMuted;
                  }}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                  </svg>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {isCollapsed && (
        <div style={styles.collapsedConversationsList}>
          {conversations.map(conversation => (
            <button
              key={conversation.id}
              style={{
                ...styles.collapsedConversationItem,
                backgroundColor: conversation.id === currentConversationId ? colors.btnSecondary : 'transparent',
                color: conversation.id === currentConversationId ? colors.btnPrimary : colors.textMuted
              }}
              onClick={() => onSelectConversation(conversation.id)}
              onMouseEnter={(e) => handleConversationHover(conversation.id, e)}
              onMouseLeave={handleConversationLeave}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
            </button>
          ))}
        </div>
      )}

      {/* Tooltip Portal */}
      {isCollapsed && hoveredConversation && tooltipPosition && typeof window !== 'undefined' && createPortal(
        <div style={{
          ...styles.tooltip,
          backgroundColor: colors.bgPrimary,
          color: colors.textPrimary,
          borderColor: colors.borderPrimary,
          position: 'fixed',
          top: `${tooltipPosition.top}px`,
          left: `${tooltipPosition.left}px`,
          transform: 'translateY(-50%)'
        }}>
          {conversations.find(c => c.id === hoveredConversation)?.title}
        </div>,
        document.body
      )}

      <div style={{ ...styles.sidebarFooter, borderColor: colors.borderPrimary }}>
        {!isCollapsed && (
          <>
            <button
              style={{ ...styles.settingsBtn, color: colors.textPrimary }}
              onClick={onOpenSettings}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = colors.btnSecondary;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M12 1v6m0 6v6m5.2-13.2l-4.2 4.2m0 6l4.2 4.2M23 12h-6m-6 0H1m18.2 5.2l-4.2-4.2m-6 0l-4.2 4.2"></path>
              </svg>
              Settings
            </button>
            
            <div style={{ ...styles.userInfo, color: colors.textPrimary }}>
              <div style={{ ...styles.userAvatar, backgroundColor: colors.bgPrimary }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </div>
              <span>Demo User</span>
            </div>
          </>
        )}

        {isCollapsed && (
          <>
            <button
              style={{ ...styles.collapsedIconBtn, color: colors.textPrimary }}
              onClick={onOpenSettings}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = colors.btnSecondary;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
              title="Settings"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M12 1v6m0 6v6m5.2-13.2l-4.2 4.2m0 6l4.2 4.2M23 12h-6m-6 0H1m18.2 5.2l-4.2-4.2m-6 0l-4.2 4.2"></path>
              </svg>
            </button>
            
            <div style={{ ...styles.collapsedUserAvatar, color: colors.textPrimary }} title="Demo User">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
            </div>
          </>
        )}
      </div>
    </div>
    
    {/* Mobile-specific styles */}
    <style jsx global>{`
      @media (max-width: 768px) {
        .sidebar-container {
          position: fixed !important;
          top: 0;
          left: 0;
          bottom: 0;
          z-index: 999;
          transform: translateX(-100%);
        }
        
        .mobile-overlay {
          display: block !important;
        }
      }
      
      @media (min-width: 769px) {
        .sidebar-container {
          position: relative !important;
          transform: translateX(0) !important;
        }
      }
    `}</style>
    </>
  );
}

const styles: Record<string, React.CSSProperties> = {
  sidebar: {
    display: 'flex',
    flexDirection: 'column',
    borderRight: '1px solid',
    transition: 'width 0.3s ease',
    position: 'relative'
  },
  sidebarHeader: {
    padding: '12px',
    borderBottom: '1px solid'
  },
  headerButtons: {
    display: 'flex',
    gap: '8px',
    alignItems: 'center'
  },
  headerButtonsCollapsed: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '100%'
  },
  toggleHeaderBtn: {
    padding: '12px',
    backgroundColor: 'transparent',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.2s',
    flexShrink: 0,
    height: '44px'
  },
  newChatBtn: {
    flex: 1,
    padding: '12px 16px',
    backgroundColor: 'transparent',
    border: '1px solid',
    borderRadius: '6px',
    fontSize: '14px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    transition: 'all 0.2s',
    fontWeight: 500
  },
  collapsedNewChatBtn: {
    width: '100%',
    padding: '12px',
    backgroundColor: 'transparent',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.2s'
  },
  conversationsList: {
    flex: 1,
    overflowY: 'auto',
    padding: '8px'
  },
  collapsedConversationsList: {
    flex: 1,
    overflowY: 'auto',
    padding: '8px 0',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '4px'
  },
  collapsedConversationItem: {
    width: '100%',
    padding: '12px',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    transition: 'all 0.2s',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0
  },
  tooltip: {
    padding: '8px 12px',
    borderRadius: '6px',
    fontSize: '14px',
    zIndex: 1000,
    border: '1px solid',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    pointerEvents: 'none',
    maxWidth: '300px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    display: '-webkit-box',
    WebkitLineClamp: 3,
    WebkitBoxOrient: 'vertical',
    lineHeight: '1.4'
  },
  conversationItem: {
    width: '100%',
    padding: '12px',
    marginBottom: '4px',
    borderRadius: '6px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    transition: 'all 0.2s',
    position: 'relative',
    border: 'none',
    textAlign: 'left',
    fontSize: '14px'
  },
  conversationTitle: {
    flex: 1,
    fontSize: '14px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    display: '-webkit-box',
    WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical',
    lineHeight: '1.4'
  },
  deleteBtn: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '4px',
    display: 'flex',
    alignItems: 'center',
    transition: 'color 0.2s'
  },
  sidebarFooter: {
    padding: '12px',
    borderTop: '1px solid',
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  settingsBtn: {
    width: '100%',
    padding: '12px',
    background: 'none',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    transition: 'background-color 0.2s'
  },
  collapsedIconBtn: {
    width: '100%',
    padding: '12px',
    background: 'none',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'background-color 0.2s'
  },
  userInfo: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px',
    borderRadius: '6px',
    fontSize: '14px'
  },
  userAvatar: {
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  collapsedUserAvatar: {
    width: '100%',
    padding: '12px',
    borderRadius: '6px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer'
  }
};
