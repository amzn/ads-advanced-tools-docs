'use client';

import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message } from '../page';
import { useTheme } from '../context/ThemeContext';
import { themes } from '../theme';

interface MessageProps {
  message: Message;
}

export default function MessageComponent({ message }: MessageProps) {
  const isUser = message.role === 'user';
  const { effectiveTheme } = useTheme();
  const colors = themes[effectiveTheme];

  return (
    <div style={{
      ...styles.message,
      ...(isUser ? {} : { backgroundColor: colors.bgSecondary }),
      ...(message.isError ? { backgroundColor: colors.errorBg } : {})
    }}>
      <div style={{
        ...styles.messageAvatar,
        backgroundColor: isUser ? colors.avatarUser : colors.avatarAssistant,
        color: 'white'
      }}>
        {isUser ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
        ) : (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
          </svg>
        )}
      </div>
      <div style={{ ...styles.messageContent, color: colors.textPrimary }}>
        {isUser ? (
          <p style={{ margin: 0 }}>{message.content}</p>
        ) : (
          <div className="markdown-content">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {message.content}
            </ReactMarkdown>
          </div>
        )}
        <div style={{ ...styles.messageTimestamp, color: colors.textMuted }}>
          {new Date(message.timestamp).toLocaleTimeString()}
        </div>
      </div>
      <style jsx global>{`
        .markdown-content p {
          margin: 0 0 12px 0;
        }
        .markdown-content p:last-child {
          margin-bottom: 0;
        }
        .markdown-content h1,
        .markdown-content h2,
        .markdown-content h3 {
          margin: 16px 0 8px 0;
          color: #ececf1;
        }
        .markdown-content h1 {
          font-size: 24px;
        }
        .markdown-content h2 {
          font-size: 20px;
        }
        .markdown-content h3 {
          font-size: 18px;
        }
        .markdown-content ul,
        .markdown-content ol {
          margin: 12px 0;
          padding-left: 24px;
        }
        .markdown-content li {
          margin: 4px 0;
        }
        .markdown-content code {
          background-color: #2d2d2d;
          padding: 2px 6px;
          border-radius: 4px;
          font-family: 'Courier New', monospace;
          font-size: 14px;
        }
        .markdown-content pre {
          background-color: #2d2d2d;
          padding: 16px;
          border-radius: 8px;
          overflow-x: auto;
          margin: 12px 0;
        }
        .markdown-content pre code {
          background: none;
          padding: 0;
        }
        .markdown-content blockquote {
          border-left: 4px solid #565869;
          padding-left: 16px;
          margin: 12px 0;
          color: #c5c5d2;
        }
        .markdown-content table {
          border-collapse: collapse;
          width: 100%;
          margin: 12px 0;
        }
        .markdown-content th,
        .markdown-content td {
          border: 1px solid #565869;
          padding: 8px 12px;
          text-align: left;
        }
        .markdown-content th {
          background-color: #2d2d2d;
          font-weight: 600;
        }
        .markdown-content a {
          color: #10a37f;
          text-decoration: none;
        }
        .markdown-content a:hover {
          text-decoration: underline;
        }
      `}</style>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  message: {
    display: 'flex',
    gap: '16px',
    padding: '24px',
    maxWidth: '800px',
    margin: '0 auto',
    width: '100%'
  },
  messageAvatar: {
    width: '32px',
    height: '32px',
    borderRadius: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0
  },
  messageContent: {
    flex: 1,
    lineHeight: 1.6
  },
  messageTimestamp: {
    fontSize: '12px',
    marginTop: '8px'
  }
};
