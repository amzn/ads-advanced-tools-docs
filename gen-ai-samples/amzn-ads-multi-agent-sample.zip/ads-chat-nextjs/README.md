# Amazon Ads Chat Assistant

A web interface for Amazon Advertising, built with Next.js. Connects to the orchestration agent on AWS Bedrock AgentCore via SigV4-signed API calls.

## Features

- Chat UI with dark/light theme support
- Conversation history persisted in localStorage
- Server-side SigV4 authentication (credentials never exposed to browser)
- Async job-based request handling with SSE keepalives (avoids 30s timeout)
- Markdown rendering with code blocks and tables
- Curated suggestion prompts
- Deployable to AWS Amplify Hosting

## Prerequisites

- Node.js 20+
- npm 10+
- AWS credentials configured locally (`aws sts get-caller-identity` should work)
- A deployed orchestration agent on Bedrock AgentCore (see root `README.md`)

## Setup

### 1. Install dependencies

```bash
cd ads-chat-nextjs
npm install
```

### 2. Configure environment variables

Create a `.env` file (or `.env.local`) in the `ads-chat-nextjs/` directory:

```bash
# Orchestration A2A Agent ARN (from orchestration agent deployment)
ORCHESTRATION_AGENT_ARN=arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:runtime/<ORCHESTRATION_AGENT_ID>

# AWS Region
AWS_REGION=us-east-1
```

To get the orchestration agent ARN:
```bash
cd ../orchestration-a2a-agent
agentcore status
# Look for "agent_arn" in the output
```

### 3. Run locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Project Structure

```
ads-chat-nextjs/
├── app/
│   ├── api/
│   │   ├── chat/
│   │   │   ├── route.ts              # SSE streaming chat endpoint
│   │   │   ├── submit/route.ts       # Async job submission endpoint
│   │   │   └── status/[jobId]/route.ts  # Job status polling endpoint
│   │   ├── generate-title/route.ts   # Conversation title generation
│   │   └── suggestions/route.ts      # Curated prompt suggestions
│   ├── components/
│   │   ├── ChatWindow.tsx            # Main chat interface
│   │   ├── Message.tsx               # Message rendering (markdown)
│   │   ├── SettingsModal.tsx         # Theme settings
│   │   └── Sidebar.tsx               # Conversation list
│   ├── context/ThemeContext.tsx       # Dark/light/system theme
│   ├── theme.ts                      # Theme color definitions
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx                      # Main page with state management
├── lib/
│   └── jobStore.ts                   # In-memory job store for async requests
├── public/                           # Static assets
├── amplify.yml                       # AWS Amplify build config
├── next.config.ts
├── package.json
└── tsconfig.json
```

## How It Works

1. User sends a message in the chat UI
2. Frontend calls `/api/chat` (Next.js server-side API route)
3. API route signs the request with SigV4 using server-side AWS credentials
4. Signed request is sent to the orchestration agent on Bedrock AgentCore
5. Response is streamed back to the browser via Server-Sent Events (SSE)
6. SSE keepalives prevent connection timeout during long agent processing

There's also an alternative async flow via `/api/chat/submit` + `/api/chat/status/[jobId]` for polling-based responses.

## Deploy to AWS Amplify

Amplify Hosting runs Next.js server components, but environment variables set in the Amplify console are not automatically available to the SSR runtime. The included `amplify.yml` handles this by writing them into `.env.production` during the build phase. See [AWS docs](https://docs.aws.amazon.com/amplify/latest/userguide/ssr-environment-variables.html) for details.

### 1. Connect your repo

1. Go to [AWS Amplify Console](https://console.aws.amazon.com/amplify/)
2. Click "New app" → "Host web app"
3. Connect your Git repository and select the `ads-chat-nextjs` directory as the app root

### 2. Set environment variables

In the Amplify console, go to App settings → Environment variables and add:

| Variable | Value |
|----------|-------|
| `ORCHESTRATION_AGENT_ARN` | `arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:runtime/<ORCHESTRATION_AGENT_ID>` |
| `AWS_REGION` | `us-east-1` |

These get piped into `.env.production` at build time via the `amplify.yml` build command:
```yaml
- env | grep -e ORCHESTRATION_AGENT_ARN -e AWS_REGION >> .env.production
```
This makes them available to Next.js server-side API routes at runtime.

### 3. Configure compute and IAM

- Enable SSR in App settings → Compute settings
- Attach a service role with permission to invoke the orchestration agent (see IAM section below)

### 4. Deploy

Amplify auto-detects Next.js and uses the included `amplify.yml`. Push to your branch and it builds automatically.

### amplify.yml reference

```yaml
version: 1
frontend:
  phases:
    preBuild:
      commands:
        - npm ci
    build:
      commands:
        - env | grep -e ORCHESTRATION_AGENT_ARN -e AWS_REGION >> .env.production
        - npm run build
  artifacts:
    baseDirectory: .next
    files:
      - '**/*'
  cache:
    paths:
      - node_modules/**/*
      - .next/cache/**/*
```

### IAM Permissions for Amplify

The Amplify service role needs permission to invoke the orchestration agent:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "bedrock-agentcore:InvokeRuntime",
      "Resource": "arn:aws:bedrock-agentcore:us-east-1:<ACCOUNT_ID>:runtime/*"
    }
  ]
}
```

## Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `ORCHESTRATION_AGENT_ARN` | ARN of the deployed orchestration agent | Yes | — |
| `AWS_REGION` | AWS region where agents are deployed | No | `us-east-1` |

## Troubleshooting

- If you get 500 errors, check that `ORCHESTRATION_AGENT_ARN` is correct and your AWS credentials have `bedrock-agentcore:InvokeRuntime` permission
- For Amplify deployments, check CloudWatch logs in the Amplify console
- Ensure Node.js 20+ is being used (check `engines` in `package.json`)
