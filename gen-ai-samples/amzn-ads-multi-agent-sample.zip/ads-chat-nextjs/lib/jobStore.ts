// Shared job store for async processing
// Uses both in-memory storage AND client-side token passing to handle multiple Lambda instances

export interface Job {
  status: 'processing' | 'complete' | 'error';
  response?: string;
  error?: string;
  createdAt: number;
  sessionId?: string;
  message?: string;
}

// Encode job data into a token that can be passed by the client
export function encodeJobToken(job: Job): string {
  return Buffer.from(JSON.stringify(job)).toString('base64');
}

// Decode job data from a token
export function decodeJobToken(token: string): Job | null {
  try {
    return JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
  } catch {
    return null;
  }
}

class JobStore {
  private jobs: Map<string, Job>;

  constructor() {
    this.jobs = new Map();
    console.log('[JobStore] Instance created');
    
    // Clean up old jobs every minute
    setInterval(() => {
      const now = Date.now();
      const fiveMinutesAgo = now - 5 * 60 * 1000;
      
      for (const [jobId, job] of this.jobs.entries()) {
        if (job.createdAt < fiveMinutesAgo) {
          this.jobs.delete(jobId);
          console.log(`[JobStore] Cleaned up old job: ${jobId}`);
        }
      }
    }, 60 * 1000);
  }

  set(jobId: string, job: Omit<Job, 'createdAt'>) {
    this.jobs.set(jobId, {
      ...job,
      createdAt: Date.now()
    });
    console.log(`[JobStore] Set job ${jobId}, total jobs: ${this.jobs.size}`);
  }

  get(jobId: string): Job | undefined {
    const job = this.jobs.get(jobId);
    console.log(`[JobStore] Get job ${jobId}: ${job ? 'found' : 'not found'}`);
    return job;
  }

  delete(jobId: string) {
    this.jobs.delete(jobId);
    console.log(`[JobStore] Deleted job ${jobId}`);
  }
  
  size(): number {
    return this.jobs.size;
  }
}

// Use globalThis to ensure singleton across Next.js hot reloads
const globalForJobStore = globalThis as unknown as {
  jobStore: JobStore | undefined;
};

export const jobStore = globalForJobStore.jobStore ?? new JobStore();

if (process.env.NODE_ENV !== 'production') {
  globalForJobStore.jobStore = jobStore;
}
