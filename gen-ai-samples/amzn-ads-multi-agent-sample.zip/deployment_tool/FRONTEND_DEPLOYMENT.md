# Next.js Frontend Deployment Guide

This guide provides instructions for deploying the `ads-chat-nextjs` frontend application after the AgentCore agents have been deployed.

## Prerequisites

Before deploying the frontend, ensure:

1. ✅ All AgentCore agents have been successfully deployed using the deployment tool
2. ✅ The `ads-chat-nextjs/.env.local` file has been updated with the orchestration agent ARN
3. ✅ Node.js (>= 20.0.0) and npm (>= 10.0.0) are installed
4. ✅ You have AWS credentials configured for deployment (if deploying to AWS)

## Verify Configuration

Before deployment, verify that the `.env.local` file contains the correct configuration:

```bash
cd ads-chat-nextjs
cat .env.local
```

You should see:
```
ORCHESTRATION_AGENT_ARN=arn:aws:bedrock-agentcore:us-east-1:ACCOUNT_ID:runtime/orchestration_a2a-XXXXX
AWS_REGION=us-east-1
```

## Deployment Options

### Option 1: AWS Amplify Deployment (Recommended)

AWS Amplify provides a fully managed hosting solution with CI/CD integration.

#### Step 1: Install Amplify CLI (if not already installed)

```bash
npm install -g @aws-amplify/cli
```

#### Step 2: Initialize Amplify in the Frontend Directory

```bash
cd ads-chat-nextjs
amplify init
```

Follow the prompts:
- **Enter a name for the project**: ads-chat-nextjs
- **Enter a name for the environment**: prod (or dev, staging, etc.)
- **Choose your default editor**: (select your preferred editor)
- **Choose the type of app**: javascript
- **What javascript framework**: react
- **Source Directory Path**: (press Enter for default)
- **Distribution Directory Path**: .next
- **Build Command**: npm run build
- **Start Command**: npm run start
- **Do you want to use an AWS profile?**: Yes (select your profile)

#### Step 3: Add Hosting

```bash
amplify add hosting
```

Select:
- **Select the plugin module to execute**: Hosting with Amplify Console
- **Choose a type**: Manual deployment

#### Step 4: Configure Environment Variables in Amplify Console

1. Go to the [AWS Amplify Console](https://console.aws.amazon.com/amplify/)
2. Select your app
3. Go to **App settings** > **Environment variables**
4. Add the following variables:
   - `ORCHESTRATION_AGENT_ARN`: (value from .env.local)
   - `AWS_REGION`: (value from .env.local)

#### Step 5: Deploy

```bash
amplify publish
```

This will:
- Build the Next.js application
- Deploy to AWS Amplify
- Provide a URL for accessing the application

#### Step 6: Access Your Application

After deployment completes, Amplify will provide a URL like:
```
https://main.d1234567890abc.amplifyapp.com
```

### Option 2: Manual Deployment with npm

For manual deployment to any hosting platform (Vercel, Netlify, custom server, etc.):

#### Step 1: Install Dependencies

```bash
cd ads-chat-nextjs
npm install
```

#### Step 2: Build the Application

```bash
npm run build
```

This creates an optimized production build in the `.next` directory.

#### Step 3: Test the Production Build Locally

```bash
npm run start
```

The application will be available at `http://localhost:3000`.

#### Step 4: Deploy to Your Hosting Platform

**For Vercel:**
```bash
npm install -g vercel
vercel --prod
```

**For Netlify:**
```bash
npm install -g netlify-cli
netlify deploy --prod
```

**For Custom Server:**
- Copy the entire project directory to your server
- Ensure Node.js >= 20.0.0 is installed
- Run `npm install` and `npm run build`
- Start the application with `npm run start`
- Use a process manager like PM2 to keep it running:
  ```bash
  npm install -g pm2
  pm2 start npm --name "ads-chat-nextjs" -- start
  pm2 save
  pm2 startup
  ```

### Option 3: Local Development

For local development and testing:

#### Step 1: Install Dependencies

```bash
cd ads-chat-nextjs
npm install
```

#### Step 2: Start Development Server

```bash
npm run dev
```

The application will be available at `http://localhost:3000` with hot-reloading enabled.

#### Step 3: Make Changes

Edit files in the `app/` directory. Changes will be reflected immediately in the browser.

## Environment Variables

The frontend requires the following environment variables:

| Variable | Description | Example |
|----------|-------------|---------|
| `ORCHESTRATION_AGENT_ARN` | ARN of the deployed orchestration agent | `arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/orchestration_a2a-abc123` |
| `AWS_REGION` | AWS region where agents are deployed | `us-east-1` |

These are automatically configured by the deployment tool in `.env.local`.

## Troubleshooting

### Build Errors

**Error: "Module not found"**
```bash
# Solution: Clean install dependencies
rm -rf node_modules package-lock.json
npm install
```

**Error: "Environment variable not found"**
```bash
# Solution: Verify .env.local exists and contains required variables
cat .env.local
```

### Runtime Errors

**Error: "Failed to connect to orchestration agent"**
- Verify the `ORCHESTRATION_AGENT_ARN` is correct
- Ensure the orchestration agent is deployed and running
- Check AWS credentials have permission to invoke the agent

**Error: "CORS error"**
- Ensure the orchestration agent is configured to accept requests from the frontend domain
- Check the agent's CORS configuration in the AgentCore settings

### Deployment Errors

**Amplify deployment fails:**
- Verify AWS credentials are configured correctly
- Check that the Amplify CLI is up to date: `npm update -g @aws-amplify/cli`
- Review build logs in the Amplify Console

**Vercel/Netlify deployment fails:**
- Ensure environment variables are set in the platform's dashboard
- Check build logs for specific errors
- Verify Node.js version matches requirements (>= 20.0.0)

## Post-Deployment Verification

After deployment, verify the application is working correctly:

1. **Access the application URL**
2. **Test the chat interface**:
   - Send a test message
   - Verify the orchestration agent responds
   - Check that sub-agents are being invoked correctly
3. **Monitor logs**:
   - Check browser console for errors
   - Review agent logs in AWS CloudWatch (if applicable)

## Updating the Frontend

To update the frontend after making changes:

### For Amplify:
```bash
cd ads-chat-nextjs
amplify publish
```

### For Vercel:
```bash
vercel --prod
```

### For Netlify:
```bash
netlify deploy --prod
```

### For Custom Server:
```bash
npm run build
pm2 restart ads-chat-nextjs
```

## Security Considerations

1. **Environment Variables**: Never commit `.env.local` to version control
2. **API Keys**: Store sensitive credentials in AWS Secrets Manager or similar
3. **CORS**: Configure appropriate CORS policies on the orchestration agent
4. **Authentication**: Consider adding authentication to the frontend (Cognito, Auth0, etc.)
5. **HTTPS**: Always use HTTPS in production deployments

## Additional Resources

- [Next.js Deployment Documentation](https://nextjs.org/docs/deployment)
- [AWS Amplify Documentation](https://docs.amplify.aws/)
- [Vercel Deployment Guide](https://vercel.com/docs)
- [Netlify Deployment Guide](https://docs.netlify.com/)
- [AWS Bedrock AgentCore Documentation](https://docs.aws.amazon.com/bedrock/)

## Support

For issues related to:
- **Frontend deployment**: Check Next.js and hosting platform documentation
- **Agent connectivity**: Review AgentCore deployment logs
- **AWS configuration**: Consult AWS documentation and support

---

**Note**: This frontend deployment is separate from the automated agent deployment. The deployment tool only configures the environment variables needed for the frontend to connect to the orchestration agent. You must manually deploy the frontend using one of the methods described above.
