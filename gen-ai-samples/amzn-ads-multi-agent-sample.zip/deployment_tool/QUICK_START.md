# Quick Start Guide

This guide will help you get started with deploying your AgentCore agents.

## Prerequisites

1. AWS CLI configured with appropriate credentials
2. Python 3.8+ with pip installed
3. Virtual environment activated (recommended)

## Step 1: Configure Your Deployment

The `deployment.yaml` file has been created with default values. You need to update it with your AWS account details:

### Required Changes

1. **AWS Account ID** (Line 5):
   ```yaml
   aws_account_id: "123456789012"  # REPLACE with your AWS account ID
   ```
   
   To find your AWS account ID:
   ```bash
   aws sts get-caller-identity --query Account --output text
   ```

2. **AWS Region** (Line 6):
   ```yaml
   aws_region: "us-east-1"  # Update if using a different region
   ```
   
   Common regions: `us-east-1`, `us-west-2`, `eu-west-1`, `ap-southeast-1`

### Optional Changes

3. **S3 Bucket Name** (Line 38) - Only if deploying the s3-vectors agent:
   ```yaml
   S3_BUCKET_NAME: "my-vector-knowledge-base"  # REPLACE with your S3 bucket name
   ```
   
   See `S3_VECTOR_SETUP.md` for instructions on setting up the S3 vector knowledge base.

### Agent Naming

Agent names in the configuration can contain hyphens (e.g., `custom-ads-a2a-agent`). The deployment tool automatically converts hyphens to underscores to comply with AgentCore naming requirements (e.g., `custom_ads_a2a_agent`). You'll see a note during deployment when this conversion happens.

## Step 2: Validate Your Configuration

Before deploying, validate your configuration:

```bash
python deploy_agents.py validate --config deployment.yaml
```

This will check:
- Configuration file syntax
- Agent directories exist
- Required files are present
- AWS credentials are valid

## Step 3: Deploy Your Agents

### Deploy All Agents

```bash
python deploy_agents.py deploy --config deployment.yaml
```

### Deploy Specific Agents

```bash
python deploy_agents.py deploy --config deployment.yaml --agents custom-ads-a2a-agent --agents mcp-ads-a2a-agent
```

### Dry Run (Preview Changes)

```bash
python deploy_agents.py deploy --config deployment.yaml --dry-run
```

## Step 4: Check Deployment Status

```bash
python deploy_agents.py status --config deployment.yaml
```

This shows:
- Deployed agents and their ARNs
- IAM roles and policies
- Memory configurations
- Frontend configuration status

## Step 5: Update Frontend (Optional)

If you're using the Next.js frontend, the deployment tool automatically updates the `.env.local` file with the orchestration agent ARN. After deployment:

```bash
cd ../ads-chat-nextjs
npm install
npm run dev
```

## Troubleshooting

### Configuration Errors

If validation fails, check:
- YAML syntax is correct (proper indentation)
- All required fields are present
- Agent directories exist relative to `deployment_tool/`

### AWS Credential Errors

If you see AWS authentication errors:
```bash
aws configure
# or
export AWS_PROFILE=your-profile-name
```

### Agent Deployment Failures

Check the deployment logs:
```bash
python deploy_agents.py status --config deployment.yaml
```

View detailed logs in `deployment_state.json`

## Cleanup

To remove all deployed resources:

```bash
python deploy_agents.py cleanup --config deployment.yaml
```

Options:
- `--delete-ecr`: Also delete ECR repositories
- `--delete-iam`: Also delete IAM roles
- `--delete-codebuild`: Also delete CodeBuild projects

## Next Steps

1. Review the full documentation in `README.md`
2. Check `DEPLOYMENT_GUIDE.md` for detailed deployment workflows
3. See `S3_VECTOR_SETUP.md` if using the s3-vectors agent
4. See `FRONTEND_DEPLOYMENT.md` for frontend integration details

## Common Commands Reference

```bash
# Validate configuration
python deploy_agents.py validate --config deployment.yaml

# Deploy all agents
python deploy_agents.py deploy --config deployment.yaml

# Deploy specific agents
python deploy_agents.py deploy --config deployment.yaml --agents agent1 --agents agent2

# Check status
python deploy_agents.py status --config deployment.yaml

# Cleanup everything
python deploy_agents.py cleanup --config deployment.yaml

# Get help
python deploy_agents.py --help
python deploy_agents.py deploy --help
```
