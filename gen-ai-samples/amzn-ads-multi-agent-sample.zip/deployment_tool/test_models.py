#!/usr/bin/env python3
"""Quick test script to verify data models work correctly."""

from deployment_tool.models import (
    AgentConfig, 
    DeploymentConfig, 
    IAMPolicyConfig,
    AgentDeploymentState,
    DeploymentState,
    AgentDeploymentResult,
    DeploymentResult
)
from datetime import datetime

# Test AgentConfig
agent = AgentConfig(
    name="test-agent",
    directory="/path/to/agent",
    entrypoint="agent.py"
)
print(f"✓ AgentConfig: {agent.name}")

# Test IAMPolicyConfig
iam_policy = IAMPolicyConfig(
    base_policy={"Version": "2012-10-17"},
    cross_agent_policy_template={"Version": "2012-10-17"}
)
print(f"✓ IAMPolicyConfig created")

# Test DeploymentConfig
config = DeploymentConfig(
    aws_account_id="123456789012",
    aws_region="us-east-1",
    agents=[agent],
    iam_policies=iam_policy,
    deployment_order=["test-agent"]
)
print(f"✓ DeploymentConfig: {config.aws_region}")

# Test AgentDeploymentState
state = AgentDeploymentState(
    agent_name="test-agent",
    agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/test",
    execution_role_arn="arn:aws:iam::123456789012:role/test",
    ecr_repository_uri="123456789012.dkr.ecr.us-east-1.amazonaws.com/test",
    codebuild_project_name="test-builder",
    memory_arn=None,
    deployed_at=datetime.now()
)
print(f"✓ AgentDeploymentState: {state.agent_name}")

# Test DeploymentState
deployment_state = DeploymentState(
    agents={"test-agent": state},
    last_deployment=datetime.now(),
    deployment_version="0.1.0"
)
print(f"✓ DeploymentState: {len(deployment_state.agents)} agent(s)")

# Test AgentDeploymentResult
result = AgentDeploymentResult(
    success=True,
    agent_name="test-agent",
    agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/test"
)
print(f"✓ AgentDeploymentResult: success={result.success}")

# Test DeploymentResult
deployment_result = DeploymentResult(
    success=True,
    deployed_agents=[result],
    failed_agents=[],
    total_duration=120.5
)
print(f"✓ DeploymentResult: {len(deployment_result.deployed_agents)} deployed")

print("\n✅ All data models work correctly!")
