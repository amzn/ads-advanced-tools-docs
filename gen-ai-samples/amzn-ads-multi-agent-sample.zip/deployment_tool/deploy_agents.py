#!/usr/bin/env python3
"""
Main entry point for AgentCore Automated Deployment System.

This script provides the command-line interface for deploying, validating,
monitoring, and cleaning up AWS Bedrock AgentCore agents.

Usage:
    ./deploy_agents.py deploy --config deployment.yaml
    ./deploy_agents.py validate --config deployment.yaml
    ./deploy_agents.py status
    ./deploy_agents.py cleanup --delete-ecr --delete-codebuild

Validates Requirements: 1.1, 10.5
"""

import sys
import os

# Add the parent directory to Python path so 'deployment_tool' can be imported
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import and run the CLI
from deployment_tool.cli.cli import main

if __name__ == '__main__':
    main()
