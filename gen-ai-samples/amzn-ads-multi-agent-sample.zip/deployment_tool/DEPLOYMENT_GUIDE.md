# AgentCore Automated Deployment Guide

This guide provides comprehensive step-by-step instructions for deploying AWS Bedrock AgentCore agents using the automated deployment tool.

## Table of Contents

- [Pre-Deployment Checklist](#pre-deployment-checklist)
- [Step-by-Step Deployment](#step-by-step-deployment)
- [Post-Deployment Verification](#post-deployment-verification)
- [Common Error Scenarios](#common-error-scenarios)
- [Advanced Deployment Scenarios](#advanced-deployment-scenarios)

## Pre-Deployment Checklist

Before starting the deployment, ensure all prerequisites are met:

### 1. AWS Account Setup

- [ ] AWS account created and accessible
- [ ] AWS Bedrock service enabled in your target region
- [ ] Sufficient service quotas for:
  - IAM roles (minimum 5)
  - ECR repositories (minimum 5)
  - CodeBuild projects (minimum 5)
  - Bedrock agents (minimum 5)

### 2. AWS Credentials Configuration

Verify AWS credentials are properly configured:

```bash
# Check if AWS CLI is installed
aws --version

# Verify credentials are configured
aws sts get-caller-identity
```

Expected output should show your AWS account ID and user/role ARN.

**If credentials are not configured**, set them up using one of these methods:

**Method 1: AWS CLI Configuration (Recommended)**
```bash
aws configure
# Enter:
# - AWS Access Key ID
# - AWS Secret Access Key
# - Default region (e.g., us-east-1)
# - Default output format (json)
```

**Method 2: Environment Variables**
```bash
export AWS_ACCESS_KEY_ID=your_access_key_here
export AWS_SECRET_ACCESS_KEY=your_secret_key_here
export AWS_REGION=us-east-1
```

**Method 3: AWS Credentials File**
```bash
# Edit ~/.aws/credentials
[default]
aws_access_key_id = your_access_key_here
aws_secret_access_key = your_secret_key_here

# Edit ~/.aws/config
[default]
region = us-east-1
output = json
```

### 3. Agent Directories Verification

Verify all agent directories exist and contain required files:

```bash
# Check agent directories exist
ls -la ../custom-ads-a2a-agent
ls -la ../mcp-ads-a2a-agent
ls -la ../s3-vectors-a2a-agent
ls -la ../orchestration-a2a-agent
ls -la ../ads-chat-nextjs
```

For each agent directory, verify:
- [ ] Agent entrypoint file exists (e.g., `langgraph_a2a.py`)
- [ ] `requirements.txt` file exists
- [ ] `.bedrock_agentcore.yaml` file exists or will be created
- [ ] `.env` file exists (if needed for agent configuration)

### 4. Python Environment Setup

- [ ] Python 3.8 or higher installed
- [ ] Virtual environment created and activated
- [ ] All dependencies installed

Verify Python setup:

```bash
# Check Python version
python3 --version

# Navigate to deployment tool directory
cd deployment_tool

# Create virtual environment if not exists
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate  # On macOS/Linux
# or
venv\Scripts\activate  # On Windows

# Install dependencies
pip install -r requirements.txt

# Verify installation
python -m cli.cli --help
```

### 5. AWS Bedrock AgentCore SDK

- [ ] AgentCore SDK installed

```bash
# Install AgentCore SDK
pip install bedrock-agentcore-starter-toolkit

# Verify installation
agentcore --version
```

### 6. IAM Permissions Verification

Verify your AWS user/role has required permissions:

```bash
# Test IAM permissions
aws iam get-user

# Test ECR permissions
aws ecr describe-repositories --max-items 1

# Test S3 permissions
aws s3 ls

# Test Bedrock permissions (if available in your region)
aws bedrock list-foundation-models --max-results 1
```

If any command fails with "Access Denied", contact your AWS administrator to grant the necessary permissions.

### 7. Configuration File Preparation

- [ ] `deployment.yaml` file created from template
- [ ] AWS account ID updated in configuration
- [ ] AWS region updated in configuration
- [ ] Agent directories verified in configuration
- [ ] IAM policy files exist

```bash
# Copy template to create configuration
cp deployment.yaml.template deployment.yaml

# Edit configuration with your details
# Update aws_account_id, aws_region, and verify agent paths
```

## Step-by-Step Deployment

### Step 1: Validate Configuration

Before deploying, validate your configuration to catch any errors early:

```bash
python -m cli.cli validate --config deployment.yaml
```

**Expected Output:**
```
✓ Configuration file loaded successfully
✓ AWS account ID format valid
✓ AWS region valid
✓ All agent directories exist
✓ All entrypoint files exist
✓ All IAM policy files exist
✓ AWS credentials valid
✓ Configuration validation passed
```

**If validation fails**, review the error messages and fix the issues before proceeding.

### Step 2: Review Deployment Plan

Review what will be deployed:

```bash
# Check current deployment state (if any)
python -m cli.cli status --config deployment.yaml
```

The deployment will create:
- IAM execution roles for each agent
- ECR repositories for container images
- CodeBuild projects for building containers
- Bedrock agents with proper configurations
- Cross-agent communication policies
- S3 bucket for vector knowledge base (if s3-vectors agent included)

### Step 3: Deploy Sub-Agents

Deploy all agents in the correct order:

```bash
python -m cli.cli deploy --config deployment.yaml
```

**Deployment Process:**

The tool will execute the following steps automatically:

1. **Install Dependencies** for each agent
   - Reads `requirements.txt`
   - Installs packages in agent's environment

2. **Configure Agents** using AgentCore
   - Executes `agentcore configure` with appropriate flags
   - Creates IAM execution roles
   - Creates ECR repositories
   - Creates CodeBuild projects
   - Generates `.bedrock_agentcore.yaml` files

3. **Deploy Sub-Agents** in order:
   - custom-ads-a2a-agent
   - mcp-ads-a2a-agent
   - s3-vectors-a2a-agent (if included)

4. **Apply Cross-Agent Policies**
   - Attaches communication policies to all execution roles
   - Grants InvokeRuntime permissions
   - Grants memory access permissions

5. **Deploy Orchestration Agent**
   - Injects sub-agent ARNs into environment
   - Deploys orchestration agent

6. **Configure Frontend** (if included)
   - Updates `.env.local` with orchestration agent ARN

**Expected Output:**

```
Starting deployment...

[1/5] Deploying custom-ads-a2a-agent...
  ✓ Installing dependencies
  ✓ Configuring agent
  ✓ Deploying agent
  ✓ Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/ABC123

[2/5] Deploying mcp-ads-a2a-agent...
  ✓ Installing dependencies
  ✓ Configuring agent
  ✓ Deploying agent
  ✓ Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/DEF456

[3/5] Deploying s3-vectors-a2a-agent...
  ✓ Installing dependencies
  ✓ Configuring S3 bucket
  ✓ Configuring agent
  ✓ Deploying agent
  ✓ Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/GHI789

[4/5] Applying cross-agent communication policies...
  ✓ Policies applied to all execution roles

[5/5] Deploying orchestration-a2a-agent...
  ✓ Installing dependencies
  ✓ Updating environment with sub-agent ARNs
  ✓ Configuring agent
  ✓ Deploying agent
  ✓ Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/JKL012

Deployment completed successfully!

Summary:
  Total agents deployed: 4
  Total duration: 15m 32s
  
Deployed Agents:
  - custom-ads-a2a-agent: arn:aws:bedrock:us-east-1:123456789012:agent/ABC123
  - mcp-ads-a2a-agent: arn:aws:bedrock:us-east-1:123456789012:agent/DEF456
  - s3-vectors-a2a-agent: arn:aws:bedrock:us-east-1:123456789012:agent/GHI789
  - orchestration-a2a-agent: arn:aws:bedrock:us-east-1:123456789012:agent/JKL012

Next Steps:
  1. Verify deployment: python -m cli.cli status --config deployment.yaml
  2. Test agents in AWS Bedrock console
  3. Deploy frontend application (see FRONTEND_DEPLOYMENT.md)
```

**Deployment Time:** Expect 10-20 minutes for complete deployment depending on:
- Number of agents
- Agent complexity
- Container build times
- Network speed

### Step 4: Verify Deployment State

After deployment completes, verify the state:

```bash
python -m cli.cli status --config deployment.yaml
```

**Expected Output:**

```
Deployment Status:

Agent: custom-ads-a2a-agent
  Status: Deployed
  Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/ABC123
  Execution Role: arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-abc123
  Memory ARN: arn:aws:bedrock:us-east-1:123456789012:memory/custom-ads-mem
  Deployed: 2024-02-06 10:30:45 UTC

Agent: mcp-ads-a2a-agent
  Status: Deployed
  Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/DEF456
  Execution Role: arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-def456
  Memory ARN: arn:aws:bedrock:us-east-1:123456789012:memory/mcp-ads-mem
  Deployed: 2024-02-06 10:35:20 UTC

[... additional agents ...]

Total Deployed Agents: 4
Last Deployment: 2024-02-06 10:45:15 UTC
```

## Post-Deployment Verification

### 1. Verify AWS Resources

Check that all resources were created correctly:

**IAM Roles:**
```bash
# List IAM roles created by deployment
aws iam list-roles --query 'Roles[?contains(RoleName, `AmazonBedrockAgentCoreSDKRuntime`)].RoleName'
```

**ECR Repositories:**
```bash
# List ECR repositories
aws ecr describe-repositories --query 'repositories[?contains(repositoryName, `bedrock-agentcore`)].repositoryName'
```

**CodeBuild Projects:**
```bash
# List CodeBuild projects
aws codebuild list-projects --query 'projects[?contains(@, `bedrock-agentcore`)]'
```

**Bedrock Agents:**
```bash
# List Bedrock agents (if CLI supports it)
aws bedrock list-agents
```

**S3 Buckets (if s3-vectors agent deployed):**
```bash
# List S3 buckets
aws s3 ls | grep vector
```

### 2. Test Agent Invocation

Test each agent individually:

**Test Sub-Agent:**
```bash
# Using AWS CLI (if available)
aws bedrock-agent-runtime invoke-agent \
  --agent-id ABC123 \
  --agent-alias-id TSTALIASID \
  --session-id test-session-1 \
  --input-text "Test query"
```

**Test Orchestration Agent:**
```bash
aws bedrock-agent-runtime invoke-agent \
  --agent-id JKL012 \
  --agent-alias-id TSTALIASID \
  --session-id test-session-2 \
  --input-text "Get campaign data"
```

### 3. Verify Cross-Agent Communication

Test that the orchestration agent can invoke sub-agents:

1. Invoke the orchestration agent with a query that requires sub-agent calls
2. Check CloudWatch logs for sub-agent invocations
3. Verify responses include data from sub-agents

**Check CloudWatch Logs:**
```bash
# Get log groups for agents
aws logs describe-log-groups --query 'logGroups[?contains(logGroupName, `bedrock-agent`)].logGroupName'

# Tail logs for orchestration agent
aws logs tail /aws/bedrock/agent/orchestration-a2a-agent --follow
```

### 4. Verify Frontend Configuration

If frontend was configured, verify the environment file:

```bash
# Check frontend .env.local file
cat ../ads-chat-nextjs/.env.local
```

Should contain:
```
ORCHESTRATION_AGENT_ARN=arn:aws:bedrock:us-east-1:123456789012:agent/JKL012
AWS_REGION=us-east-1
```

### 5. Test End-to-End Flow

1. Deploy the Next.js frontend (see FRONTEND_DEPLOYMENT.md)
2. Open the frontend in a browser
3. Submit a test query
4. Verify the orchestration agent responds
5. Check that sub-agents are invoked correctly

## Common Error Scenarios

### Scenario 1: Configuration Validation Fails

**Error:**
```
✗ Agent directory not found: ../custom-ads-a2a-agent
```

**Cause:** Agent directory path is incorrect or directory doesn't exist.

**Solution:**
1. Verify the directory exists:
   ```bash
   ls -la ../custom-ads-a2a-agent
   ```
2. Update the path in `deployment.yaml` if incorrect
3. Use absolute paths if relative paths cause issues

---

### Scenario 2: AWS Credentials Invalid

**Error:**
```
✗ AWS credentials validation failed: Unable to locate credentials
```

**Cause:** AWS credentials not configured or expired.

**Solution:**
1. Configure credentials:
   ```bash
   aws configure
   ```
2. Verify credentials work:
   ```bash
   aws sts get-caller-identity
   ```
3. If using temporary credentials, refresh them

---

### Scenario 3: Insufficient IAM Permissions

**Error:**
```
✗ Access Denied when creating IAM role
Error: User: arn:aws:iam::123456789012:user/myuser is not authorized to perform: iam:CreateRole
```

**Cause:** AWS user/role lacks required IAM permissions.

**Solution:**
1. Contact AWS administrator to grant permissions
2. Required permissions listed in README.md
3. Alternatively, use a different AWS profile with sufficient permissions:
   ```bash
   export AWS_PROFILE=admin-profile
   ```

---

### Scenario 4: AgentCore Configure Fails

**Error:**
```
✗ Failed to configure agent: agentcore command not found
```

**Cause:** AWS Bedrock AgentCore SDK not installed.

**Solution:**
```bash
pip install bedrock-agentcore-starter-toolkit
agentcore --version
```

---

### Scenario 5: Agent Deployment Fails

**Error:**
```
✗ Failed to deploy agent: Container build failed
```

**Cause:** Container build errors, missing dependencies, or CodeBuild issues.

**Solution:**
1. Check CodeBuild logs in AWS Console
2. Verify `requirements.txt` is correct
3. Check for dependency conflicts
4. Try building locally:
   ```bash
   cd ../agent-directory
   docker build -t test-build .
   ```

---

### Scenario 6: Sub-Agent ARN Not Found

**Error:**
```
✗ Sub-agent ARN not found in state: custom-ads-a2a-agent
```

**Cause:** Sub-agent deployment failed or state file corrupted.

**Solution:**
1. Check deployment state:
   ```bash
   python -m cli.cli status --config deployment.yaml
   ```
2. Redeploy failed sub-agent:
   ```bash
   python -m cli.cli deploy --config deployment.yaml --agents custom-ads-a2a-agent
   ```
3. If state file corrupted, delete and redeploy:
   ```bash
   rm .deployment_state.json
   python -m cli.cli deploy --config deployment.yaml
   ```

---

### Scenario 7: Cross-Agent Policy Application Fails

**Error:**
```
✗ Failed to apply cross-agent policy: Role not found
```

**Cause:** IAM role doesn't exist or was deleted.

**Solution:**
1. Verify roles exist:
   ```bash
   aws iam list-roles --query 'Roles[?contains(RoleName, `AmazonBedrockAgentCoreSDKRuntime`)].RoleName'
   ```
2. Redeploy affected agents to recreate roles
3. Rerun deployment to apply policies

---

### Scenario 8: S3 Bucket Creation Fails

**Error:**
```
✗ Failed to create S3 bucket: BucketAlreadyExists
```

**Cause:** Bucket name already taken globally.

**Solution:**
1. Choose a unique bucket name
2. Update configuration with new name
3. Redeploy s3-vectors agent

---

### Scenario 9: Memory Resource Creation Fails

**Error:**
```
✗ Failed to create memory resource: Service quota exceeded
```

**Cause:** Bedrock memory quota reached.

**Solution:**
1. Request quota increase from AWS Support
2. Delete unused memory resources
3. Disable memory for some agents if not needed

---

### Scenario 10: Frontend Configuration Fails

**Error:**
```
✗ Failed to update frontend .env.local: File not found
```

**Cause:** Frontend directory path incorrect or .env.local doesn't exist.

**Solution:**
1. Verify frontend directory exists:
   ```bash
   ls -la ../ads-chat-nextjs
   ```
2. Create .env.local if missing:
   ```bash
   touch ../ads-chat-nextjs/.env.local
   ```
3. Update path in deployment.yaml if incorrect

## Advanced Deployment Scenarios

### Partial Deployment

Deploy specific agents only:

```bash
# Deploy only custom-ads and mcp-ads agents
python -m cli.cli deploy --config deployment.yaml --agents custom-ads-a2a-agent,mcp-ads-a2a-agent
```

**Use Cases:**
- Testing individual agents
- Updating specific agents without redeploying all
- Troubleshooting deployment issues

### Incremental Deployment

Deploy agents one at a time:

```bash
# Deploy first agent
python -m cli.cli deploy --config deployment.yaml --agents custom-ads-a2a-agent

# Verify it works
python -m cli.cli status --config deployment.yaml

# Deploy next agent
python -m cli.cli deploy --config deployment.yaml --agents mcp-ads-a2a-agent

# Continue for remaining agents...
```

### Redeployment After Configuration Changes

If you modify agent code or configuration:

```bash
# Redeploy specific agent
python -m cli.cli deploy --config deployment.yaml --agents custom-ads-a2a-agent
```

The tool will:
- Update existing resources
- Rebuild containers
- Redeploy agent with new configuration

### Multi-Region Deployment

To deploy to multiple regions:

1. Create separate configuration files:
   ```bash
   cp deployment.yaml deployment-us-east-1.yaml
   cp deployment.yaml deployment-eu-west-1.yaml
   ```

2. Update region in each file

3. Deploy to each region:
   ```bash
   python -m cli.cli deploy --config deployment-us-east-1.yaml
   python -m cli.cli deploy --config deployment-eu-west-1.yaml
   ```

### Cleanup and Redeployment

To completely clean up and redeploy:

```bash
# Clean up everything
python -m cli.cli cleanup --config deployment.yaml --delete-ecr --delete-codebuild --delete-iam

# Verify cleanup
python -m cli.cli status --config deployment.yaml

# Redeploy from scratch
python -m cli.cli deploy --config deployment.yaml
```

### Deployment with Custom IAM Roles

If you want to use pre-existing IAM roles:

1. Create roles manually in AWS Console or via CloudFormation
2. Update agent configuration to reference existing roles
3. Deploy agents (tool will use existing roles instead of creating new ones)

### Deployment Rollback

If deployment fails partway through:

1. Check what was deployed:
   ```bash
   python -m cli.cli status --config deployment.yaml
   ```

2. Clean up failed deployment:
   ```bash
   python -m cli.cli cleanup --config deployment.yaml
   ```

3. Fix configuration issues

4. Redeploy:
   ```bash
   python -m cli.cli deploy --config deployment.yaml
   ```

## Best Practices

1. **Always validate before deploying**
   ```bash
   python -m cli.cli validate --config deployment.yaml
   ```

2. **Deploy to a test environment first**
   - Use a separate AWS account or region for testing
   - Verify everything works before deploying to production

3. **Monitor deployment progress**
   - Watch the console output for errors
   - Check CloudWatch logs if issues occur

4. **Keep deployment state file safe**
   - Back up `.deployment_state.json` after successful deployments
   - Don't delete it unless you're cleaning up completely

5. **Use version control for configuration**
   - Commit `deployment.yaml` to git
   - Track changes to configuration over time

6. **Document custom configurations**
   - Note any deviations from standard deployment
   - Document environment-specific settings

7. **Test agents after deployment**
   - Verify each agent responds correctly
   - Test cross-agent communication
   - Check error handling

8. **Plan for cleanup**
   - Know how to clean up resources when done
   - Be aware of costs for running resources

## Next Steps

After successful deployment:

1. **Deploy the Frontend**: Follow [FRONTEND_DEPLOYMENT.md](FRONTEND_DEPLOYMENT.md) to deploy the Next.js application

2. **Configure S3 Vector Knowledge Base**: If using s3-vectors agent, follow [S3_VECTOR_SETUP.md](S3_VECTOR_SETUP.md)

3. **Set Up Monitoring**: Configure CloudWatch alarms for agent errors and performance

4. **Test End-to-End**: Verify the complete system works as expected

5. **Document Your Deployment**: Record agent ARNs, configuration details, and any customizations

## Support

For issues or questions:
- Review the [README.md](README.md) for general information
- Check the [Troubleshooting](#common-error-scenarios) section above
- Review AWS Bedrock AgentCore documentation
- Check AWS service health dashboard for outages
