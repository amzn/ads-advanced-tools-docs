"""
Configuration Manager for AgentCore Automated Deployment System.

This module handles loading, validating, and providing access to deployment
configuration from YAML files.
"""

import os
import yaml
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import asdict

# Import from parent package - use relative import
import sys
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import (
    AgentConfig,
    DeploymentConfig,
    IAMPolicyConfig,
    FrontendConfig
)


class ValidationError(Exception):
    """Exception raised for configuration validation errors."""
    
    def __init__(self, field: str, message: str):
        self.field = field
        self.message = message
        super().__init__(f"{field}: {message}")


class ConfigurationManager:
    """Manages deployment configuration loading and validation.
    
    This class is responsible for:
    - Loading YAML configuration files
    - Validating configuration structure and required fields
    - Verifying agent directories and entrypoint files exist
    - Determining deployment order based on dependencies
    
    Validates Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 14.1, 14.2, 14.3
    """
    
    def __init__(self, config_path: str):
        """Initialize ConfigurationManager with path to configuration file.
        
        Args:
            config_path: Path to deployment.yaml configuration file
        """
        self.config_path = Path(config_path)
        self.config: Optional[DeploymentConfig] = None
        self._raw_config: Optional[Dict[str, Any]] = None
    
    def load_config(self) -> DeploymentConfig:
        """Load and parse configuration file.
        
        Reads the YAML configuration file and converts it into a DeploymentConfig
        object with all nested data structures.
        
        Returns:
            DeploymentConfig object with parsed configuration
            
        Raises:
            FileNotFoundError: If configuration file doesn't exist
            yaml.YAMLError: If YAML parsing fails
            ValidationError: If configuration structure is invalid
        """
        if not self.config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        
        try:
            with open(self.config_path, 'r') as f:
                self._raw_config = yaml.safe_load(f)
        except yaml.YAMLError as e:
            raise ValidationError("yaml_parsing", f"Failed to parse YAML: {e}")
        
        if not isinstance(self._raw_config, dict):
            raise ValidationError("config_root", "Configuration must be a YAML dictionary")
        
        # Parse configuration into data models
        try:
            # Parse agents
            agents_data = self._raw_config.get('agents', [])
            agents = [self._parse_agent_config(agent_data) for agent_data in agents_data]
            
            # Parse IAM policies
            iam_policies_data = self._raw_config.get('iam_policies', {})
            iam_policies = IAMPolicyConfig(
                base_policy=iam_policies_data.get('base_policy', {}),
                cross_agent_policy_template=iam_policies_data.get('cross_agent_policy_template', {})
            )
            
            # Parse frontend config (optional)
            frontend_config = None
            if 'frontend_config' in self._raw_config:
                frontend_data = self._raw_config['frontend_config']
                frontend_config = FrontendConfig(
                    directory=frontend_data.get('directory', ''),
                    env_file=frontend_data.get('env_file', ''),
                    orchestration_arn_var=frontend_data.get('orchestration_arn_var', '')
                )
            
            # Parse SSM parameters (optional)
            ssm_parameters = self._raw_config.get('ssm_parameters', None)
            
            # Create deployment config
            self.config = DeploymentConfig(
                aws_account_id=self._raw_config.get('aws_account_id', ''),
                aws_region=self._raw_config.get('aws_region', ''),
                agents=agents,
                iam_policies=iam_policies,
                deployment_order=self._raw_config.get('deployment_order', []),
                frontend_config=frontend_config,
                ssm_parameters=ssm_parameters
            )
            
            return self.config
            
        except (KeyError, TypeError, ValueError) as e:
            raise ValidationError("config_parsing", f"Failed to parse configuration: {e}")
    
    def _parse_agent_config(self, agent_data: Dict[str, Any]) -> AgentConfig:
        """Parse agent configuration from dictionary.
        
        Args:
            agent_data: Dictionary containing agent configuration
            
        Returns:
            AgentConfig object
        """
        return AgentConfig(
            name=agent_data.get('name', ''),
            directory=agent_data.get('directory', ''),
            entrypoint=agent_data.get('entrypoint', ''),
            language=agent_data.get('language', 'python'),
            platform=agent_data.get('platform', 'linux/arm64'),
            memory_mode=agent_data.get('memory_mode', 'STM_ONLY'),
            server_protocol=agent_data.get('server_protocol', 'HTTP'),
            dependencies=agent_data.get('dependencies', []),
            environment_variables=agent_data.get('environment_variables', {})
        )
    
    def validate_config(self) -> List[ValidationError]:
        """Validate configuration structure and required fields.
        
        Checks that all required fields are present and have valid values:
        - aws_account_id: Must be non-empty string
        - aws_region: Must be non-empty string
        - agents: Must be non-empty list
        - Each agent must have name, directory, and entrypoint
        
        Returns:
            List of ValidationError objects (empty if valid)
            
        Validates Requirements: 1.2, 1.3, 1.4, 1.5
        """
        errors = []
        
        if not self.config:
            errors.append(ValidationError("config", "Configuration not loaded. Call load_config() first."))
            return errors
        
        # Validate AWS account ID
        if not self.config.aws_account_id:
            errors.append(ValidationError("aws_account_id", "AWS account ID is required"))
        elif not self.config.aws_account_id.isdigit():
            errors.append(ValidationError("aws_account_id", "AWS account ID must be numeric"))
        elif len(self.config.aws_account_id) != 12:
            errors.append(ValidationError("aws_account_id", "AWS account ID must be 12 digits"))
        
        # Validate AWS region
        if not self.config.aws_region:
            errors.append(ValidationError("aws_region", "AWS region is required"))
        elif not self._is_valid_aws_region(self.config.aws_region):
            errors.append(ValidationError("aws_region", f"Invalid AWS region format: {self.config.aws_region}"))
        
        # Validate agents list
        if not self.config.agents:
            errors.append(ValidationError("agents", "At least one agent must be defined"))
        else:
            # Validate each agent
            for i, agent in enumerate(self.config.agents):
                agent_errors = self._validate_agent_config(agent, i)
                errors.extend(agent_errors)
        
        # Validate deployment order if specified
        if self.config.deployment_order:
            agent_names = {agent.name for agent in self.config.agents}
            for order_name in self.config.deployment_order:
                if order_name not in agent_names:
                    errors.append(ValidationError(
                        "deployment_order",
                        f"Agent '{order_name}' in deployment_order not found in agents list"
                    ))
        
        return errors
    
    def _validate_agent_config(self, agent: AgentConfig, index: int) -> List[ValidationError]:
        """Validate a single agent configuration.
        
        Args:
            agent: AgentConfig to validate
            index: Index of agent in list (for error messages)
            
        Returns:
            List of ValidationError objects
        """
        errors = []
        prefix = f"agents[{index}]"
        
        if not agent.name:
            errors.append(ValidationError(f"{prefix}.name", "Agent name is required"))
        
        if not agent.directory:
            errors.append(ValidationError(f"{prefix}.directory", "Agent directory is required"))
        
        if not agent.entrypoint:
            errors.append(ValidationError(f"{prefix}.entrypoint", "Agent entrypoint is required"))
        
        # Validate server protocol
        valid_protocols = ['HTTP', 'A2A', 'MCP']
        if agent.server_protocol not in valid_protocols:
            errors.append(ValidationError(
                f"{prefix}.server_protocol",
                f"Invalid protocol '{agent.server_protocol}'. Must be one of: {', '.join(valid_protocols)}"
            ))
        
        # Validate memory mode
        valid_memory_modes = ['STM_ONLY', 'DISABLED']
        if agent.memory_mode not in valid_memory_modes:
            errors.append(ValidationError(
                f"{prefix}.memory_mode",
                f"Invalid memory mode '{agent.memory_mode}'. Must be one of: {', '.join(valid_memory_modes)}"
            ))
        
        return errors
    
    def _is_valid_aws_region(self, region: str) -> bool:
        """Check if AWS region format is valid.
        
        Args:
            region: AWS region string
            
        Returns:
            True if region format is valid
        """
        # Basic validation: region should match pattern like us-east-1, eu-west-2, etc.
        if not region:
            return False
        
        parts = region.split('-')
        if len(parts) < 3:
            return False
        
        # First part should be a valid region prefix
        valid_prefixes = ['us', 'eu', 'ap', 'sa', 'ca', 'me', 'af']
        if parts[0] not in valid_prefixes:
            return False
        
        # Last part should be a number
        if not parts[-1].isdigit():
            return False
        
        return True
    
    def validate_agent_directories(self) -> List[ValidationError]:
        """Verify all agent directories and entrypoint files exist.
        
        Checks the filesystem to ensure:
        - Each agent's directory exists
        - Each agent's entrypoint file exists within the directory
        - requirements.txt exists in each agent directory (warning if missing)
        
        Returns:
            List of ValidationError objects (empty if all valid)
            
        Validates Requirements: 14.1, 14.2, 14.3
        """
        errors = []
        
        if not self.config:
            errors.append(ValidationError("config", "Configuration not loaded. Call load_config() first."))
            return errors
        
        # Get base directory (parent of config file)
        base_dir = self.config_path.parent
        
        for agent in self.config.agents:
            # Check agent directory
            agent_dir = base_dir / agent.directory
            if not agent_dir.exists():
                errors.append(ValidationError(
                    f"agent.{agent.name}.directory",
                    f"Agent directory does not exist: {agent_dir}"
                ))
                continue  # Skip further checks if directory doesn't exist
            
            if not agent_dir.is_dir():
                errors.append(ValidationError(
                    f"agent.{agent.name}.directory",
                    f"Agent directory path is not a directory: {agent_dir}"
                ))
                continue
            
            # Check entrypoint file
            entrypoint_path = agent_dir / agent.entrypoint
            if not entrypoint_path.exists():
                errors.append(ValidationError(
                    f"agent.{agent.name}.entrypoint",
                    f"Agent entrypoint file does not exist: {entrypoint_path}"
                ))
            elif not entrypoint_path.is_file():
                errors.append(ValidationError(
                    f"agent.{agent.name}.entrypoint",
                    f"Agent entrypoint path is not a file: {entrypoint_path}"
                ))
            
            # Check requirements.txt (warning, not error)
            requirements_path = agent_dir / "requirements.txt"
            if not requirements_path.exists():
                # This is a warning, but we'll include it as an error for now
                # In production, you might want a separate warning mechanism
                errors.append(ValidationError(
                    f"agent.{agent.name}.requirements",
                    f"Warning: requirements.txt not found in {agent_dir}"
                ))
        
        return errors
    
    def get_agents_in_deployment_order(self) -> List[AgentConfig]:
        """Return agents sorted by deployment dependencies.
        
        Ensures that:
        1. If deployment_order is specified in config, use that order
        2. Otherwise, sort agents so sub-agents come before orchestration agents
        3. Sub-agents are identified by having no dependencies or being depended upon
        4. Orchestration agents are identified by having dependencies on other agents
        
        Returns:
            List of AgentConfig objects in deployment order
            
        Validates Requirements: 6.1, 6.2
        """
        if not self.config:
            raise ValueError("Configuration not loaded. Call load_config() first.")
        
        # If explicit deployment order is specified, use it
        if self.config.deployment_order:
            return self._order_by_explicit_list(self.config.deployment_order)
        
        # Otherwise, perform topological sort based on dependencies
        return self._topological_sort_agents()
    
    def _order_by_explicit_list(self, order: List[str]) -> List[AgentConfig]:
        """Order agents according to explicit deployment_order list.
        
        Args:
            order: List of agent names in desired order
            
        Returns:
            List of AgentConfig objects in specified order
        """
        agent_map = {agent.name: agent for agent in self.config.agents}
        ordered_agents = []
        
        for name in order:
            if name in agent_map:
                ordered_agents.append(agent_map[name])
        
        # Add any agents not in the order list at the end
        ordered_names = set(order)
        for agent in self.config.agents:
            if agent.name not in ordered_names:
                ordered_agents.append(agent)
        
        return ordered_agents
    
    def _topological_sort_agents(self) -> List[AgentConfig]:
        """Perform topological sort of agents based on dependencies.
        
        Uses Kahn's algorithm to sort agents so that dependencies are deployed first.
        
        Returns:
            List of AgentConfig objects in dependency order
            
        Raises:
            ValidationError: If circular dependencies are detected
        """
        # Build dependency graph
        agent_map = {agent.name: agent for agent in self.config.agents}
        in_degree = {agent.name: 0 for agent in self.config.agents}
        adjacency = {agent.name: [] for agent in self.config.agents}
        
        # Calculate in-degrees and build adjacency list
        for agent in self.config.agents:
            for dep in agent.dependencies:
                if dep in agent_map:
                    adjacency[dep].append(agent.name)
                    in_degree[agent.name] += 1
        
        # Kahn's algorithm
        queue = [name for name, degree in in_degree.items() if degree == 0]
        sorted_names = []
        
        while queue:
            # Sort queue to ensure deterministic ordering
            queue.sort()
            current = queue.pop(0)
            sorted_names.append(current)
            
            # Reduce in-degree for dependent agents
            for dependent in adjacency[current]:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)
        
        # Check for circular dependencies
        if len(sorted_names) != len(self.config.agents):
            remaining = [name for name in in_degree if name not in sorted_names]
            raise ValidationError(
                "dependencies",
                f"Circular dependencies detected among agents: {', '.join(remaining)}"
            )
        
        # Return agents in sorted order
        return [agent_map[name] for name in sorted_names]
