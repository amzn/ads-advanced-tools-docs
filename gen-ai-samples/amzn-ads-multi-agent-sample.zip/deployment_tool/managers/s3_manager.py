"""
S3 Manager for AgentCore Automated Deployment System.

This module manages S3 resources for agent deployments, specifically for
the s3-vectors-a2a-agent which requires an S3 bucket configured for vector
knowledge base operations.

Operations include:
- Checking if S3 buckets exist
- Creating S3 buckets for vector knowledge base
- Configuring bucket policies to allow agent access
- Verifying S3 vector index configuration

Requirements: 16.1, 16.2, 16.3, 16.4, 16.5, 16.6
"""

import time
import json
from typing import Optional
import boto3
from botocore.exceptions import ClientError, BotoCoreError


class S3Manager:
    """Manages S3 resources for agent deployments.
    
    This class handles S3 operations required for the s3-vectors-a2a-agent,
    including bucket creation, policy configuration, and vector index verification.
    """
    
    def __init__(self, boto3_session: boto3.Session):
        """Initialize S3 Manager with boto3 session.
        
        Args:
            boto3_session: Configured boto3 session for AWS API calls
        """
        self.session = boto3_session
        self.s3_client = boto3_session.client('s3')
        
        # Exponential backoff configuration
        self.max_retries = 5
        self.base_delay = 1.0  # seconds
        self.max_delay = 32.0  # seconds
    
    def bucket_exists(self, bucket_name: str) -> bool:
        """Check if an S3 bucket exists.
        
        Args:
            bucket_name: Name of the S3 bucket to check
            
        Returns:
            True if the bucket exists and is accessible, False otherwise
            
        Raises:
            Exception: If AWS API call fails (other than NoSuchBucket or 404)
            
        Requirements: 16.1
        """
        try:
            self.s3_client.head_bucket(Bucket=bucket_name)
            return True
        except ClientError as e:
            error_code = e.response['Error']['Code']
            # Bucket doesn't exist or we don't have access
            if error_code in ['404', 'NoSuchBucket']:
                return False
            # Re-raise other errors (e.g., permission issues)
            raise Exception(
                f"Failed to check if bucket '{bucket_name}' exists: "
                f"{error_code} - {e.response['Error']['Message']}"
            )
        except BotoCoreError as e:
            raise Exception(f"AWS API error checking bucket '{bucket_name}': {str(e)}")
    
    def create_vector_bucket(
        self,
        bucket_name: str,
        region: str
    ) -> str:
        """Create S3 bucket for vector knowledge base.
        
        Creates an S3 bucket with appropriate configuration for storing
        vector embeddings and knowledge base documents. Uses exponential
        backoff for retries on transient errors.
        
        Args:
            bucket_name: Name for the S3 bucket
            region: AWS region where the bucket should be created
            
        Returns:
            The bucket name (for confirmation)
            
        Raises:
            Exception: If bucket creation fails after retries
            
        Requirements: 16.3
        """
        for attempt in range(self.max_retries):
            try:
                # For us-east-1, don't specify LocationConstraint
                if region == 'us-east-1':
                    self.s3_client.create_bucket(Bucket=bucket_name)
                else:
                    self.s3_client.create_bucket(
                        Bucket=bucket_name,
                        CreateBucketConfiguration={
                            'LocationConstraint': region
                        }
                    )
                
                # Enable versioning for better data protection
                self.s3_client.put_bucket_versioning(
                    Bucket=bucket_name,
                    VersioningConfiguration={
                        'Status': 'Enabled'
                    }
                )
                
                return bucket_name  # Success
                
            except ClientError as e:
                error_code = e.response['Error']['Code']
                
                # If bucket already exists and we own it, that's okay
                if error_code == 'BucketAlreadyOwnedByYou':
                    return bucket_name
                
                # Retry on throttling or transient errors
                if error_code in ['Throttling', 'RequestLimitExceeded', 'ServiceUnavailable']:
                    if attempt < self.max_retries - 1:
                        delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                        time.sleep(delay)
                        continue
                
                # Non-retryable error
                raise Exception(
                    f"Failed to create bucket '{bucket_name}': "
                    f"{error_code} - {e.response['Error']['Message']}"
                )
                
            except BotoCoreError as e:
                # Retry on network/connection errors
                if attempt < self.max_retries - 1:
                    delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                    time.sleep(delay)
                    continue
                    
                raise Exception(
                    f"AWS API error creating bucket '{bucket_name}': {str(e)}"
                )
        
        # Max retries exceeded
        raise Exception(
            f"Failed to create bucket '{bucket_name}' after {self.max_retries} attempts"
        )
    
    def configure_bucket_policy(
        self,
        bucket_name: str,
        execution_role_arn: str
    ) -> None:
        """Configure bucket policy to allow agent access.
        
        Creates and applies a bucket policy that grants the agent's execution
        role the necessary permissions for vector knowledge base operations:
        - s3:GetObject - Read objects from the bucket
        - s3:PutObject - Write objects to the bucket
        - s3:ListBucket - List bucket contents
        - s3:QueryVectors - Query vector embeddings (if supported)
        
        Args:
            bucket_name: Name of the S3 bucket
            execution_role_arn: ARN of the agent's IAM execution role
            
        Raises:
            Exception: If policy configuration fails after retries
            
        Requirements: 16.4, 16.6
        """
        # Create bucket policy document
        policy_document = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Sid": "AllowAgentAccess",
                    "Effect": "Allow",
                    "Principal": {
                        "AWS": execution_role_arn
                    },
                    "Action": [
                        "s3:GetObject",
                        "s3:PutObject",
                        "s3:ListBucket"
                    ],
                    "Resource": [
                        f"arn:aws:s3:::{bucket_name}",
                        f"arn:aws:s3:::{bucket_name}/*"
                    ]
                }
            ]
        }
        
        # Note: s3:QueryVectors is included in the IAM role policy, not bucket policy
        # as it's a newer action that may not be supported in all regions yet
        
        for attempt in range(self.max_retries):
            try:
                self.s3_client.put_bucket_policy(
                    Bucket=bucket_name,
                    Policy=json.dumps(policy_document)
                )
                return  # Success
                
            except ClientError as e:
                error_code = e.response['Error']['Code']
                
                # Retry on throttling or transient errors
                if error_code in ['Throttling', 'RequestLimitExceeded', 'ServiceUnavailable']:
                    if attempt < self.max_retries - 1:
                        delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                        time.sleep(delay)
                        continue
                
                # Non-retryable error
                raise Exception(
                    f"Failed to configure bucket policy for '{bucket_name}': "
                    f"{error_code} - {e.response['Error']['Message']}"
                )
                
            except BotoCoreError as e:
                # Retry on network/connection errors
                if attempt < self.max_retries - 1:
                    delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                    time.sleep(delay)
                    continue
                    
                raise Exception(
                    f"AWS API error configuring bucket policy for '{bucket_name}': {str(e)}"
                )
        
        # Max retries exceeded
        raise Exception(
            f"Failed to configure bucket policy for '{bucket_name}' "
            f"after {self.max_retries} attempts"
        )
    
    def verify_vector_index(
        self,
        bucket_name: str
    ) -> bool:
        """Check if S3 vector index is configured.
        
        Verifies that the S3 bucket has vector search capabilities configured.
        This is a best-effort check as vector index configuration may not be
        directly queryable via standard S3 APIs.
        
        Note: As of the current AWS S3 API, there isn't a direct way to check
        for vector index configuration. This method checks for bucket existence
        and basic accessibility as a proxy. The actual vector index setup may
        need to be done through the AWS Console or specific vector search APIs.
        
        Args:
            bucket_name: Name of the S3 bucket to check
            
        Returns:
            True if the bucket exists and is accessible (proxy for vector index),
            False otherwise
            
        Requirements: 16.2, 16.5
        """
        try:
            # Check if bucket exists and is accessible
            self.s3_client.head_bucket(Bucket=bucket_name)
            
            # Try to get bucket tagging to see if vector index tag is present
            # This is a convention - users should tag buckets with vector index info
            try:
                response = self.s3_client.get_bucket_tagging(Bucket=bucket_name)
                tags = response.get('TagSet', [])
                
                # Check for vector index tag
                for tag in tags:
                    if tag.get('Key') == 'VectorIndexEnabled' and tag.get('Value') == 'true':
                        return True
                        
            except ClientError as e:
                # No tags configured - that's okay, just means we can't verify
                if e.response['Error']['Code'] == 'NoSuchTagSet':
                    pass
                else:
                    # Other tagging errors - log but don't fail
                    pass
            
            # Bucket exists and is accessible - assume vector index can be configured
            # The actual vector index setup is typically done separately
            return True
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code in ['404', 'NoSuchBucket']:
                return False
            # For other errors, re-raise
            raise Exception(
                f"Failed to verify vector index for bucket '{bucket_name}': "
                f"{error_code} - {e.response['Error']['Message']}"
            )
        except BotoCoreError as e:
            raise Exception(
                f"AWS API error verifying vector index for bucket '{bucket_name}': {str(e)}"
            )

    def ensure_vector_bucket_and_index(
        self,
        bucket_name: str,
        index_name: str,
        region: str
    ) -> dict:
        """Create S3 vector bucket and index if they don't exist.
        
        Uses the s3vectors API (not regular S3) for vector-specific operations.
        
        Args:
            bucket_name: Name for the S3 vector bucket
            index_name: Name for the vector index
            region: AWS region
            
        Returns:
            Dict with bucket_name, index_name, and created flags
        """
        result = {
            'bucket_name': bucket_name,
            'index_name': index_name,
            'bucket_created': False,
            'index_created': False
        }
        
        try:
            s3vectors = self.session.client('s3vectors', region_name=region)
            
            # Check/create vector bucket
            try:
                s3vectors.get_vector_bucket(vectorBucketName=bucket_name)
                print(f"    ✓ Vector bucket already exists: {bucket_name}")
            except ClientError as e:
                if e.response['Error']['Code'] in ['NotFoundException', 'NoSuchBucket']:
                    print(f"    Creating vector bucket: {bucket_name}")
                    s3vectors.create_vector_bucket(vectorBucketName=bucket_name)
                    result['bucket_created'] = True
                    print(f"    ✓ Vector bucket created")
                else:
                    raise
            
            # Check/create vector index
            try:
                s3vectors.get_index(
                    vectorBucketName=bucket_name,
                    indexName=index_name
                )
                print(f"    ✓ Vector index already exists: {index_name}")
            except ClientError as e:
                if e.response['Error']['Code'] in ['NotFoundException', 'NoSuchKey']:
                    print(f"    Creating vector index: {index_name} (1024 dims, cosine)")
                    s3vectors.create_index(
                        vectorBucketName=bucket_name,
                        indexName=index_name,
                        dataType='float32',
                        dimension=1024,
                        distanceMetric='cosine'
                    )
                    result['index_created'] = True
                    print(f"    ✓ Vector index created")
                else:
                    raise
                    
        except Exception as e:
            print(f"    Warning: Could not verify/create vector bucket/index: {e}")
            print(f"    You may need to create it manually (see S3_VECTOR_SETUP.md)")
        
        return result
