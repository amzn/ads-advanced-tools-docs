"""
AgentCore Integration for Automated Deployment System.

This module provides integration with AWS Bedrock AgentCore SDK for agent
configuration and deployment operations.
"""

import os
import subprocess
import re
from pathlib import Path
from typing import Dict, Optional, Tuple
import sys

# Import from parent package
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import AgentDeploymentResult


class AgentCoreIntegration:
    """Interface with AgentCore SDK for agent configuration and deployment.
    
    This class handles:
    - Executing agentcore configure with automation flags
    - Executing agentcore deploy commands
    - Parsing deployment output to extract ARNs
    - Installing agent dependencies
    
    Validates Requirements: 5.1-5.10, 12.1, 12.2
    """
    
    def __init__(self, agent_directory: str):
        """Initialize AgentCoreIntegration with agent directory path.
        
        Args:
            agent_directory: Path to the agent directory
        """
        self.agent_directory = Path(agent_directory)
        if not self.agent_directory.exists():
            raise ValueError(f"Agent directory does not exist: {agent_directory}")
    
    def run_configure(
        self,
        entrypoint: str,
        agent_name: str,
        protocol: str = "HTTP",
        enable_memory: bool = True,
        deployment_type: str = "container",
        region: str = None,
        non_interactive: bool = True,
        execution_role_arn: str = None
    ) -> subprocess.CompletedProcess:
        """Execute agentcore configure with flags for automation.
        
        Builds and executes the agentcore configure command with appropriate
        flags for non-interactive configuration. AgentCore automatically creates
        IAM execution roles, ECR repositories, and CodeBuild projects.
        
        Args:
            entrypoint: Path to agent Python file (e.g., 'langgraph_a2a.py')
            agent_name: Name for the agent
            protocol: Server protocol (HTTP, A2A, or MCP)
            enable_memory: Enable memory (STM_ONLY mode), default True
            deployment_type: Deployment type (container or direct_code_deploy)
            region: AWS region
            non_interactive: Skip prompts (default True)
            execution_role_arn: Optional pre-existing IAM role ARN
            
        Returns:
            subprocess.CompletedProcess with command output
            
        Raises:
            subprocess.CalledProcessError: If agentcore configure fails
            
        Command example (auto-create role):
            agentcore configure --entrypoint agent.py --name my-agent \
                --protocol A2A --ecr auto --deployment-type container \
                --region us-east-1 --non-interactive
                
        Command example (use existing role):
            agentcore configure --entrypoint agent.py --name my-agent \
                --execution-role arn:aws:iam::123:role/MyRole \
                --protocol A2A --ecr auto --deployment-type container \
                --region us-east-1 --non-interactive
                
        Validates Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 5.10
        """
        # Build command arguments
        cmd = [
            "agentcore", "configure",
            "--entrypoint", entrypoint,
            "--name", agent_name,
            "--protocol", protocol,
            "--ecr", "auto",
            "--deployment-type", deployment_type
        ]
        
        # Add region if specified
        if region:
            cmd.extend(["--region", region])
        
        # Add non-interactive flag
        if non_interactive:
            cmd.append("--non-interactive")
        
        # Add memory flag
        if not enable_memory:
            cmd.append("--disable-memory")
        
        # Add execution role if provided
        if execution_role_arn:
            cmd.extend(["--execution-role", execution_role_arn])
        
        # Execute command
        try:
            result = subprocess.run(
                cmd,
                cwd=self.agent_directory,
                capture_output=True,
                text=True,
                check=True
            )
            return result
        except subprocess.CalledProcessError as e:
            # Re-raise with more context
            error_msg = f"agentcore configure failed for {agent_name}\n"
            error_msg += f"Command: {' '.join(cmd)}\n"
            error_msg += f"Exit code: {e.returncode}\n"
            error_msg += f"Stdout: {e.stdout}\n"
            error_msg += f"Stderr: {e.stderr}"
            raise subprocess.CalledProcessError(
                e.returncode,
                e.cmd,
                output=error_msg,
                stderr=e.stderr
            )
    
    def run_deploy(self) -> subprocess.CompletedProcess:
        """Execute agentcore deploy command.
        
        Runs the agentcore deploy command to deploy the configured agent.
        This builds the container image, pushes to ECR, and deploys to AWS.
        
        Returns:
            subprocess.CompletedProcess with command output
            
        Raises:
            subprocess.CalledProcessError: If agentcore deploy fails
        """
        cmd = ["agentcore", "deploy", "--auto-update-on-conflict"]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=self.agent_directory,
                capture_output=True,
                text=True,
                check=True
            )
            return result
        except subprocess.CalledProcessError as e:
            # Re-raise with more context
            error_msg = f"agentcore deploy failed\n"
            error_msg += f"Command: {' '.join(cmd)}\n"
            error_msg += f"Exit code: {e.returncode}\n"
            error_msg += f"Stdout: {e.stdout}\n"
            error_msg += f"Stderr: {e.stderr}"
            raise subprocess.CalledProcessError(
                e.returncode,
                e.cmd,
                output=error_msg,
                stderr=e.stderr
            )
    
    def parse_deploy_output(self, output: str) -> Dict[str, str]:
        """Extract ARNs from deployment output.
        
        Parses the output from agentcore deploy to extract:
        - Agent ARN
        - Execution role ARN
        - Memory ARN (if applicable)
        - ECR repository URI
        - CodeBuild project name
        
        Args:
            output: Output string from agentcore deploy command
            
        Returns:
            Dictionary with extracted ARNs and resource identifiers:
            {
                'agent_arn': 'arn:aws:bedrock:...',
                'execution_role_arn': 'arn:aws:iam:...',
                'memory_arn': 'arn:aws:bedrock:...' (optional),
                'ecr_repository_uri': '123456789.dkr.ecr.us-east-1.amazonaws.com/...',
                'codebuild_project_name': 'bedrock-agentcore-...'
            }
            
        Note: This method uses regex patterns to extract ARNs from various
        output formats. It's designed to be flexible and handle different
        agentcore output formats.
        """
        result = {}
        
        # Pattern for agent ARN - supports both formats:
        # - arn:aws:bedrock:region:account:agent/ID (older format)
        # - arn:aws:bedrock-agentcore:region:account:runtime/NAME-ID (current format)
        agent_arn_pattern = r'arn:aws:bedrock(?:-agentcore)?:[a-z0-9-]+:\d+:(?:agent|runtime)/[A-Za-z0-9_-]+'
        agent_match = re.search(agent_arn_pattern, output)
        if agent_match:
            result['agent_arn'] = agent_match.group(0)
        
        # Pattern for execution role ARN
        role_arn_pattern = r'arn:aws:iam::\d+:role/[A-Za-z0-9-_]+'
        role_match = re.search(role_arn_pattern, output)
        if role_match:
            result['execution_role_arn'] = role_match.group(0)
        
        # Pattern for memory ARN - supports both formats:
        # - arn:aws:bedrock:region:account:memory/ID (older format)
        # - arn:aws:bedrock-agentcore:region:account:memory/NAME-ID (current format)
        memory_arn_pattern = r'arn:aws:bedrock(?:-agentcore)?:[a-z0-9-]+:\d+:memory/[A-Za-z0-9_-]+'
        memory_match = re.search(memory_arn_pattern, output)
        if memory_match:
            result['memory_arn'] = memory_match.group(0)
        
        # Pattern for ECR repository URI
        ecr_pattern = r'\d+\.dkr\.ecr\.[a-z0-9-]+\.amazonaws\.com/[a-z0-9-]+'
        ecr_match = re.search(ecr_pattern, output)
        if ecr_match:
            result['ecr_repository_uri'] = ecr_match.group(0)
        
        # Pattern for CodeBuild project name
        codebuild_pattern = r'bedrock-agentcore-[a-z0-9-]+-builder'
        codebuild_match = re.search(codebuild_pattern, output)
        if codebuild_match:
            result['codebuild_project_name'] = codebuild_match.group(0)
        
        return result
    
    def install_dependencies(self) -> bool:
        """Install requirements.txt dependencies.
        
        Runs pip install -r requirements.txt in the agent directory to install
        all required Python packages.
        
        Returns:
            True if installation succeeded, False otherwise
            
        Note: This method assumes a virtual environment is activated or
        pip is configured to install in the correct location.
        
        Validates Requirements: 12.1, 12.2
        """
        requirements_path = self.agent_directory / "requirements.txt"
        
        # Check if requirements.txt exists
        if not requirements_path.exists():
            # Return True but log warning (requirements.txt is optional)
            print(f"Warning: requirements.txt not found in {self.agent_directory}")
            return True
        
        # Run pip install
        cmd = ["pip", "install", "-r", "requirements.txt"]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=self.agent_directory,
                capture_output=True,
                text=True,
                check=True
            )
            print(f"Dependencies installed successfully for {self.agent_directory.name}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"Failed to install dependencies for {self.agent_directory.name}")
            print(f"Exit code: {e.returncode}")
            print(f"Stdout: {e.stdout}")
            print(f"Stderr: {e.stderr}")
            return False
