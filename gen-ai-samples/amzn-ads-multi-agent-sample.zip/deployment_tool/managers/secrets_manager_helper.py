"""
Secrets Manager Helper for AgentCore Automated Deployment System.

Creates and manages AWS Secrets Manager secrets for agent credentials.
Supports interactive prompting for secret values on first run,
and skips if secrets already exist.
"""

import json
import getpass
import logging
from typing import List, Dict, Optional
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class SecretsManagerHelper:
    """Manages Secrets Manager secrets for agent deployments."""

    def __init__(self, region: str = "us-east-1", boto3_session: boto3.Session = None):
        self.region = region
        session = boto3_session or boto3.Session()
        self.client = session.client("secretsmanager", region_name=region)

    def secret_exists(self, secret_name: str) -> bool:
        """Check if a secret already exists."""
        try:
            self.client.describe_secret(SecretId=secret_name)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                return False
            raise

    def get_secret(self, secret_name: str) -> Optional[dict]:
        """Get a secret's current value as a dict."""
        try:
            response = self.client.get_secret_value(SecretId=secret_name)
            return json.loads(response["SecretString"])
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                return None
            raise

    def create_or_update_secret(
        self,
        secret_name: str,
        secret_value: dict,
        description: str = "",
    ) -> str:
        """Create a new secret or update an existing one. Returns the ARN."""
        secret_string = json.dumps(secret_value)

        if self.secret_exists(secret_name):
            response = self.client.update_secret(
                SecretId=secret_name,
                SecretString=secret_string,
                Description=description,
            )
            logger.info(f"Updated secret: {secret_name}")
            return response["ARN"]
        else:
            response = self.client.create_secret(
                Name=secret_name,
                SecretString=secret_string,
                Description=description,
            )
            logger.info(f"Created secret: {secret_name}")
            return response["ARN"]

    def ensure_secrets(self, secrets_config: List[dict], interactive: bool = True) -> Dict[str, str]:
        """
        Ensure all secrets from config exist in Secrets Manager.

        For each secret in the config:
        1. If it already exists in Secrets Manager, skip it
        2. If it doesn't exist and interactive=True, prompt for values
        3. Create the secret

        Args:
            secrets_config: List of secret definitions from deployment.yaml
                Each has: name, description, keys (list of {key, description})
            interactive: Whether to prompt for missing values

        Returns:
            Dict mapping secret names to their ARNs
        """
        arns = {}

        for secret_def in secrets_config:
            secret_name = secret_def["name"]
            description = secret_def.get("description", "")
            keys = secret_def.get("keys", [])

            # Check if secret already exists
            existing = self.get_secret(secret_name)
            if existing:
                # Verify all keys are present
                missing_keys = [k["key"] for k in keys if k["key"] not in existing]
                if not missing_keys:
                    logger.info(f"✓ Secret '{secret_name}' already exists with all keys")
                    # Get ARN
                    resp = self.client.describe_secret(SecretId=secret_name)
                    arns[secret_name] = resp["ARN"]
                    continue
                else:
                    logger.info(
                        f"Secret '{secret_name}' exists but missing keys: {missing_keys}"
                    )
                    secret_value = existing
            else:
                logger.info(f"Secret '{secret_name}' not found, creating...")
                secret_value = {}

            # Prompt for missing values
            if interactive:
                print(f"\n  Secret: {secret_name}")
                print(f"  {description}")
                for key_def in keys:
                    key = key_def["key"]
                    if key in secret_value and secret_value[key]:
                        print(f"    {key}: [already set]")
                        continue
                    key_desc = key_def.get("description", key)
                    value = getpass.getpass(f"    Enter {key_desc}: ")
                    secret_value[key] = value
            else:
                # Non-interactive: set empty strings for missing keys
                for key_def in keys:
                    key = key_def["key"]
                    if key not in secret_value:
                        secret_value[key] = ""

            # Create or update
            arn = self.create_or_update_secret(secret_name, secret_value, description)
            arns[secret_name] = arn

        return arns

    def delete_secret(self, secret_name: str, force: bool = False) -> None:
        """Delete a secret."""
        try:
            kwargs = {"SecretId": secret_name}
            if force:
                kwargs["ForceDeleteWithoutRecovery"] = True
            else:
                kwargs["RecoveryWindowInDays"] = 7

            self.client.delete_secret(**kwargs)
            logger.info(f"Deleted secret: {secret_name}")
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                logger.info(f"Secret '{secret_name}' not found, skipping delete")
            else:
                raise
