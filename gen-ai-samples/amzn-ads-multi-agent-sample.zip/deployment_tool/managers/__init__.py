"""
AWS Resource Managers

This package contains managers for AWS resources including IAM, S3, 
and coordination of AWS operations.
"""
