"""
State Manager for the AgentCore Automated Deployment System.

This module manages deployment state persistence, tracking deployed agents,
their ARNs, execution roles, and other deployment metadata. The state is
stored in a JSON file to enable idempotent deployments and rollback operations.

Validates Requirements: 7.2, 9.1, 9.2
"""

import json
import os
import sys
from datetime import datetime
from typing import Optional, Dict
from pathlib import Path

# Add parent directory to path for imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import (
    DeploymentState,
    AgentDeploymentState
)


class StateManager:
    """Manages deployment state persistence for idempotent operations.
    
    The StateManager tracks all deployed agents and their associated resources
    (ARNs, execution roles, ECR repositories, etc.) in a JSON file. This enables:
    - Idempotent deployments (skip already-deployed agents)
    - Rollback operations (delete resources in reverse order)
    - State recovery after failures
    - Cross-agent ARN propagation
    
    Attributes:
        state_file_path: Path to the JSON state file
    """
    
    def __init__(self, state_file_path: str = ".deployment_state.json"):
        """Initialize StateManager with state file path.
        
        Args:
            state_file_path: Path to the JSON state file (default: .deployment_state.json)
        """
        self.state_file_path = Path(state_file_path)
    
    def load_state(self) -> DeploymentState:
        """Load deployment state from JSON file.
        
        Returns:
            DeploymentState object with all deployed agents, or empty state if file doesn't exist
            
        Raises:
            json.JSONDecodeError: If state file is corrupted
            ValueError: If state file has invalid structure
        """
        if not self.state_file_path.exists():
            # Return empty state if file doesn't exist
            return DeploymentState(
                agents={},
                last_deployment=datetime.now(),
                deployment_version="1.0.0"
            )
        
        try:
            with open(self.state_file_path, 'r') as f:
                data = json.load(f)
            
            # Validate required fields
            if not isinstance(data, dict):
                raise ValueError("State file must contain a JSON object")
            
            if 'agents' not in data:
                raise ValueError("State file missing 'agents' field")
            
            # Parse agents dictionary
            agents = {}
            for agent_name, agent_data in data.get('agents', {}).items():
                agents[agent_name] = AgentDeploymentState(
                    agent_name=agent_data['agent_name'],
                    agent_arn=agent_data['agent_arn'],
                    execution_role_arn=agent_data['execution_role_arn'],
                    ecr_repository_uri=agent_data['ecr_repository_uri'],
                    codebuild_project_name=agent_data['codebuild_project_name'],
                    memory_arn=agent_data.get('memory_arn'),
                    deployed_at=datetime.fromisoformat(agent_data['deployed_at'])
                )
            
            # Parse timestamps
            last_deployment = datetime.fromisoformat(data['last_deployment'])
            
            return DeploymentState(
                agents=agents,
                last_deployment=last_deployment,
                deployment_version=data.get('deployment_version', '1.0.0')
            )
            
        except json.JSONDecodeError as e:
            raise json.JSONDecodeError(
                f"State file is corrupted: {e.msg}",
                e.doc,
                e.pos
            )
        except KeyError as e:
            raise ValueError(f"State file missing required field: {e}")
    
    def save_state(self, state: DeploymentState) -> None:
        """Save deployment state to JSON file.
        
        Args:
            state: DeploymentState object to persist
            
        Raises:
            IOError: If unable to write to state file
        """
        # Convert state to dictionary
        data = {
            'agents': {},
            'last_deployment': state.last_deployment.isoformat(),
            'deployment_version': state.deployment_version
        }
        
        # Convert each agent state to dictionary
        for agent_name, agent_state in state.agents.items():
            data['agents'][agent_name] = {
                'agent_name': agent_state.agent_name,
                'agent_arn': agent_state.agent_arn,
                'execution_role_arn': agent_state.execution_role_arn,
                'ecr_repository_uri': agent_state.ecr_repository_uri,
                'codebuild_project_name': agent_state.codebuild_project_name,
                'memory_arn': agent_state.memory_arn,
                'deployed_at': agent_state.deployed_at.isoformat()
            }
        
        # Write to file with pretty formatting
        try:
            with open(self.state_file_path, 'w') as f:
                json.dump(data, f, indent=2)
        except IOError as e:
            raise IOError(f"Failed to write state file: {e}")
    
    def record_agent_deployment(
        self,
        agent_name: str,
        agent_arn: str,
        execution_role_arn: str,
        ecr_repository_uri: str = "",
        codebuild_project_name: str = "",
        memory_arn: Optional[str] = None
    ) -> None:
        """Record successful agent deployment in state.
        
        This method loads the current state, adds or updates the agent's
        deployment information, and saves the updated state back to disk.
        
        Args:
            agent_name: Name of the deployed agent
            agent_arn: ARN of the deployed agent
            execution_role_arn: ARN of the agent's IAM execution role
            ecr_repository_uri: URI of the agent's ECR repository (default: "")
            codebuild_project_name: Name of the agent's CodeBuild project (default: "")
            memory_arn: Optional ARN of the agent's memory resource
            
        Raises:
            IOError: If unable to save state file
        """
        # Load current state
        state = self.load_state()
        
        # Create agent deployment state
        agent_state = AgentDeploymentState(
            agent_name=agent_name,
            agent_arn=agent_arn,
            execution_role_arn=execution_role_arn,
            ecr_repository_uri=ecr_repository_uri,
            codebuild_project_name=codebuild_project_name,
            memory_arn=memory_arn,
            deployed_at=datetime.now()
        )
        
        # Update state
        state.agents[agent_name] = agent_state
        state.last_deployment = datetime.now()
        
        # Save updated state
        self.save_state(state)
    
    def get_agent_arn(self, agent_name: str) -> Optional[str]:
        """Retrieve ARN for previously deployed agent.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            Agent ARN if found, None otherwise
        """
        state = self.load_state()
        agent_state = state.agents.get(agent_name)
        return agent_state.agent_arn if agent_state else None
    
    def get_agent_state(self, agent_name: str) -> Optional[AgentDeploymentState]:
        """Retrieve full deployment state for an agent.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            AgentDeploymentState if found, None otherwise
        """
        state = self.load_state()
        return state.agents.get(agent_name)
    
    def clear_state(self) -> None:
        """Clear deployment state (for cleanup operations).
        
        This removes the state file from disk. Used during cleanup
        operations to reset the deployment state.
        
        Raises:
            IOError: If unable to delete state file
        """
        if self.state_file_path.exists():
            try:
                os.remove(self.state_file_path)
            except IOError as e:
                raise IOError(f"Failed to delete state file: {e}")
    
    def get_all_agent_arns(self) -> Dict[str, str]:
        """Get all deployed agent ARNs as a dictionary.
        
        Returns:
            Dictionary mapping agent names to their ARNs
        """
        state = self.load_state()
        return {
            agent_name: agent_state.agent_arn
            for agent_name, agent_state in state.agents.items()
        }
    
    def has_agent(self, agent_name: str) -> bool:
        """Check if an agent has been deployed.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            True if agent is in deployment state, False otherwise
        """
        state = self.load_state()
        return agent_name in state.agents
