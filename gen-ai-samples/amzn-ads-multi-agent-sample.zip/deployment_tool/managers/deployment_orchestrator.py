"""
Agent Deployment Orchestrator for AgentCore Automated Deployment System.

This module orchestrates the deployment of multiple agents in the correct order,
managing dependencies, ARN propagation, and cross-agent communication setup.

Validates Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 7.1, 7.2, 7.3, 7.4, 7.5, 7.6
"""

import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Import from parent package
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import (
    DeploymentConfig,
    AgentConfig,
    AgentDeploymentResult,
    DeploymentResult
)
from managers.agentcore_integration import AgentCoreIntegration
from managers.iam_manager import IAMManager
from managers.s3_manager import S3Manager
from managers.state_manager import StateManager
from managers.ssm_manager import SSMManager
from managers.secrets_manager_helper import SecretsManagerHelper


class AgentDeploymentOrchestrator:
    """Orchestrates deployment of multiple agents with dependency management.
    
    This class coordinates the deployment of all agents in the correct order,
    ensuring that:
    - Sub-agents are deployed before the orchestration agent
    - Agent ARNs are captured and propagated
    - Cross-agent communication policies are applied
    - Failures are isolated and reported
    
    Attributes:
        config: Deployment configuration
        iam_manager: IAM manager for role and policy operations
        s3_manager: S3 manager for bucket operations
        state_manager: State manager for deployment tracking
    """
    
    def __init__(
        self,
        config: DeploymentConfig,
        iam_manager: IAMManager,
        s3_manager: S3Manager,
        state_manager: StateManager,
        ssm_manager: SSMManager = None
    ):
        """Initialize AgentDeploymentOrchestrator.
        
        Args:
            config: Deployment configuration
            iam_manager: IAM manager instance
            s3_manager: S3 manager instance
            state_manager: State manager instance
            ssm_manager: SSM manager instance (optional, created if not provided)
        """
        self.config = config
        self.iam_manager = iam_manager
        self.s3_manager = s3_manager
        self.state_manager = state_manager
        self.ssm_manager = ssm_manager or SSMManager(region=config.aws_region)
    
    def deploy_all_agents(self) -> DeploymentResult:
        """Deploy all agents in dependency order.
        
        This method orchestrates the complete deployment process:
        1. Deploy sub-agents in order
        2. Apply cross-agent communication policy to all execution roles
        3. Deploy orchestration agent with sub-agent ARNs
        
        Returns:
            DeploymentResult with success status and deployment details
            
        Validates Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 7.1, 7.2, 7.3
        """
        start_time = time.time()
        deployed_agents = []
        failed_agents = []
        
        # Get agents in deployment order
        agents_to_deploy = self._get_agents_in_order()
        
        print(f"\n=== Starting deployment of {len(agents_to_deploy)} agents ===\n")
        
        # Create Secrets Manager secrets (before deploying agents so they can read them)
        secrets_config = getattr(self.config, 'secrets_manager', None)
        if secrets_config:
            print("=== Creating Secrets Manager secrets ===\n")
            try:
                sm_helper = SecretsManagerHelper(region=self.config.aws_region)
                sm_helper.ensure_secrets(secrets_config, interactive=True)
                print("✓ Secrets Manager secrets ready\n")
            except Exception as e:
                print(f"⚠ Secrets Manager setup failed: {e}")
                print("  Agents will fall back to SSM or env vars for credentials.\n")

        # Create SSM parameters (before deploying agents so they can read them)
        ssm_params = getattr(self.config, 'ssm_parameters', None)
        if ssm_params:
            print("=== Creating SSM parameters ===\n")
            ssm_results = self.ssm_manager.create_parameters(ssm_params)
            created = sum(1 for v in ssm_results.values() if v)
            skipped = sum(1 for v in ssm_results.values() if not v)
            print(f"✓ SSM parameters: {created} created, {skipped} skipped (empty values)\n")
        
        # Deploy each agent
        for agent_config in agents_to_deploy:
            print(f"Deploying agent: {agent_config.name}")
            
            result = self.deploy_agent(agent_config)
            
            if result.success:
                deployed_agents.append(result)
                print(f"✓ Successfully deployed {agent_config.name}")
                print(f"  Agent ARN: {result.agent_arn}")
                print(f"  Execution Role ARN: {result.execution_role_arn}\n")
            else:
                failed_agents.append(result)
                print(f"✗ Failed to deploy {agent_config.name}")
                print(f"  Error: {result.error_message}\n")
                
                # Halt deployment on failure (Requirement 6.4, 6.5)
                print("Halting deployment due to agent failure.")
                break
        
        # If all sub-agents succeeded, apply cross-agent policies
        if not failed_agents and deployed_agents:
            print("\n=== Applying cross-agent communication policies ===\n")
            
            try:
                self._apply_cross_agent_policies(deployed_agents)
                print("✓ Cross-agent policies applied successfully\n")
            except Exception as e:
                print(f"✗ Failed to apply cross-agent policies: {str(e)}\n")
                # This is a critical failure
                failed_agents.append(AgentDeploymentResult(
                    success=False,
                    agent_name="cross-agent-policy",
                    error_message=f"Failed to apply cross-agent policies: {str(e)}"
                ))
            
            # Apply SSM access policy to all execution roles
            print("=== Applying SSM access policies ===\n")
            try:
                ssm_policy = self.ssm_manager.create_ssm_access_policy()
                for result in deployed_agents:
                    if result.execution_role_arn:
                        role_name = result.execution_role_arn.split('/')[-1]
                        self.iam_manager.attach_base_policy(role_name, ssm_policy)
                print("✓ SSM access policies applied to all execution roles\n")
            except Exception as e:
                print(f"✗ Failed to apply SSM access policies: {str(e)}\n")
        
        # Calculate total duration
        total_duration = time.time() - start_time
        
        # Determine overall success
        success = len(failed_agents) == 0
        
        print(f"\n=== Deployment {'completed' if success else 'failed'} in {total_duration:.2f} seconds ===\n")
        
        return DeploymentResult(
            success=success,
            deployed_agents=deployed_agents,
            failed_agents=failed_agents,
            total_duration=total_duration
        )
    
    def deploy_agent(self, agent_config: AgentConfig) -> AgentDeploymentResult:
        """Deploy a single agent.
        
        This method handles the complete deployment process for one agent:
        1. Execute agentcore configure
        2. Execute agentcore deploy (creates execution role, ECR, builds and deploys)
        3. Attach base policy to execution role
        4. Attach additional S3 policy if needed (for s3-vectors agent)
        5. Record deployment in state
        
        Args:
            agent_config: Configuration for the agent to deploy
            
        Returns:
            AgentDeploymentResult with deployment status and details
            
        Validates Requirements: 6.3, 7.1, 7.2, 7.4, 7.5, 7.6
        """
        agent_name = agent_config.name
        
        try:
            # Initialize AgentCore integration
            agent_dir = Path(agent_config.directory)
            if not agent_dir.exists():
                return AgentDeploymentResult(
                    success=False,
                    agent_name=agent_name,
                    error_message=f"Agent directory does not exist: {agent_config.directory}"
                )
            
            agentcore = AgentCoreIntegration(str(agent_dir))
            
            # Sanitize agent name for AgentCore (replace hyphens with underscores)
            # AgentCore requires: start with letter, only letters/numbers/underscores, 1-48 chars
            sanitized_name = agent_name.replace('-', '_')
            
            # Step 1: Execute agentcore configure (AgentCore handles dependencies)
            print(f"  Configuring {agent_name}...")
            if sanitized_name != agent_name:
                print(f"  Note: Using sanitized name '{sanitized_name}' for AgentCore")
            
            enable_memory = agent_config.memory_mode != "DISABLED"
            
            try:
                configure_result = agentcore.run_configure(
                    entrypoint=agent_config.entrypoint,
                    agent_name=sanitized_name,
                    protocol=agent_config.server_protocol,
                    enable_memory=enable_memory,
                    deployment_type="container",
                    region=self.config.aws_region,
                    non_interactive=True
                )
                
                # Note: When using --ecr auto, the execution role is created during deploy, not configure
                print(f"  Configuration complete")
                
            except Exception as e:
                return AgentDeploymentResult(
                    success=False,
                    agent_name=agent_name,
                    error_message=f"agentcore configure failed: {str(e)}"
                )
            
            # Step 2: Execute agentcore deploy
            print(f"  Deploying {agent_name}...")
            try:
                deploy_result = agentcore.run_deploy()
                
                # Parse deployment output
                parsed_output = agentcore.parse_deploy_output(
                    deploy_result.stdout + deploy_result.stderr
                )
                
                agent_arn = parsed_output.get('agent_arn')
                memory_arn = parsed_output.get('memory_arn')
                execution_role_arn = parsed_output.get('execution_role_arn')
                ecr_repository_uri = parsed_output.get('ecr_repository_uri', '')
                codebuild_project_name = parsed_output.get('codebuild_project_name', '')
                
                if not agent_arn:
                    return AgentDeploymentResult(
                        success=False,
                        agent_name=agent_name,
                        error_message="Failed to extract agent ARN from deploy output"
                    )
                
                if not execution_role_arn:
                    return AgentDeploymentResult(
                        success=False,
                        agent_name=agent_name,
                        error_message="Failed to extract execution role ARN from deploy output"
                    )
                
                print(f"  Agent ARN: {agent_arn}")
                print(f"  Execution Role ARN: {execution_role_arn}")
                
            except Exception as e:
                return AgentDeploymentResult(
                    success=False,
                    agent_name=agent_name,
                    error_message=f"agentcore deploy failed: {str(e)}"
                )
            
            # Step 3: Attach base policy to execution role
            print(f"  Attaching base policy to {agent_name}...")
            try:
                role_name = execution_role_arn.split('/')[-1]
                base_policy = self.config.iam_policies.base_policy
                if base_policy:
                    self.iam_manager.attach_base_policy(role_name, base_policy)
            except Exception as e:
                return AgentDeploymentResult(
                    success=False,
                    agent_name=agent_name,
                    error_message=f"Failed to attach base policy: {str(e)}"
                )
            
            # Step 4: Create S3 vector bucket/index and attach policy (for s3-vectors agent)
            if "s3-vectors" in agent_name.lower():
                # Get bucket and index names from SSM or config
                bucket_name = None
                index_name = None
                try:
                    bucket_name = self.ssm_manager.get_parameter('/ads/vector-bucket-name')
                    index_name = self.ssm_manager.get_parameter('/ads/vector-index-name')
                except Exception:
                    pass
                bucket_name = bucket_name or agent_config.environment_variables.get('S3_BUCKET_NAME', 'ads-knowledge-vectors-bucket')
                index_name = index_name or 'ads-knowledge-index'
                
                print(f"  Ensuring S3 vector bucket and index exist...")
                try:
                    self.s3_manager.ensure_vector_bucket_and_index(
                        bucket_name=bucket_name,
                        index_name=index_name,
                        region=self.config.aws_region
                    )
                except Exception as e:
                    print(f"  Warning: S3 bucket/index setup issue: {e}")
                
                print(f"  Attaching S3 policy to {agent_name}...")
                try:
                    self._attach_s3_policy(execution_role_arn, agent_config)
                except Exception as e:
                    return AgentDeploymentResult(
                        success=False,
                        agent_name=agent_name,
                        error_message=f"Failed to attach S3 policy: {str(e)}"
                    )
            
            # Step 5: Record deployment in state
            print(f"  Recording deployment state for {agent_name}...")
            self.state_manager.record_agent_deployment(
                agent_name=agent_name,
                agent_arn=agent_arn,
                execution_role_arn=execution_role_arn,
                ecr_repository_uri=ecr_repository_uri,
                codebuild_project_name=codebuild_project_name,
                memory_arn=memory_arn
            )
            
            # Step 6: Save agent ARN to SSM for runtime discovery
            ssm_name = f"/ads/agent-arn/{agent_name}"
            print(f"  Saving ARN to SSM: {ssm_name}")
            try:
                self.ssm_manager.client.put_parameter(
                    Name=ssm_name,
                    Value=agent_arn,
                    Type='String',
                    Description=f"Agent runtime ARN for {agent_name}",
                    Overwrite=True
                )
                
                # Get memory ARN from deploy output or from .bedrock_agentcore.yaml
                effective_memory_arn = memory_arn
                if not effective_memory_arn:
                    try:
                        import yaml
                        yaml_path = agent_dir / '.bedrock_agentcore.yaml'
                        if yaml_path.exists():
                            with open(yaml_path) as f:
                                yaml_config = yaml.safe_load(f)
                            for agent_data in yaml_config.get('agents', {}).values():
                                mem = agent_data.get('memory', {}).get('memory_arn')
                                if mem:
                                    effective_memory_arn = mem
                                    break
                    except Exception:
                        pass
                
                if effective_memory_arn:
                    memory_ssm = f"/ads/memory-arn/{agent_name}"
                    print(f"  Saving memory ARN to SSM: {memory_ssm}")
                    self.ssm_manager.client.put_parameter(
                        Name=memory_ssm,
                        Value=effective_memory_arn,
                        Type='String',
                        Description=f"Memory ARN for {agent_name}",
                        Overwrite=True
                    )
            except Exception as e:
                print(f"  Warning: Failed to save ARN to SSM: {e}")
            
            return AgentDeploymentResult(
                success=True,
                agent_name=agent_name,
                agent_arn=agent_arn,
                execution_role_arn=execution_role_arn,
                memory_arn=memory_arn
            )
            
        except Exception as e:
            return AgentDeploymentResult(
                success=False,
                agent_name=agent_name,
                error_message=f"Unexpected error during deployment: {str(e)}"
            )
    
    def update_orchestration_env(
        self,
        orchestration_agent_name: str,
        sub_agent_arns: Dict[str, str]
    ) -> None:
        """Update orchestration agent .env file with sub-agent ARNs.
        
        Writes sub-agent ARNs to the orchestration agent's .env file using
        the naming pattern: {AGENT_NAME}_ARN
        
        Args:
            orchestration_agent_name: Name of the orchestration agent
            sub_agent_arns: Dictionary mapping agent names to their ARNs
            
        Raises:
            Exception: If .env file update fails
            
        Validates Requirements: 7.3, 7.4, 7.5
        """
        # Find orchestration agent config
        orchestration_config = None
        for agent in self.config.agents:
            if agent.name == orchestration_agent_name:
                orchestration_config = agent
                break
        
        if not orchestration_config:
            raise Exception(f"Orchestration agent '{orchestration_agent_name}' not found in config")
        
        # Path to .env file
        env_file_path = Path(orchestration_config.directory) / ".env"
        
        # Read existing .env file if it exists
        existing_env = {}
        if env_file_path.exists():
            with open(env_file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        existing_env[key.strip()] = value.strip()
        
        # Add sub-agent ARNs
        for agent_name, agent_arn in sub_agent_arns.items():
            # Convert agent name to environment variable format
            # e.g., "custom-ads-a2a-agent" -> "CUSTOM_ADS_A2A_AGENT_ARN"
            env_var_name = agent_name.upper().replace('-', '_') + '_ARN'
            existing_env[env_var_name] = agent_arn
        
        # Write updated .env file
        with open(env_file_path, 'w') as f:
            for key, value in existing_env.items():
                f.write(f"{key}={value}\n")
        
        print(f"Updated {env_file_path} with {len(sub_agent_arns)} sub-agent ARNs")
    
    def update_frontend_config(
        self,
        orchestration_agent_arn: str,
        frontend_directory: str = "ads-chat-nextjs"
    ) -> None:
        """Update Next.js frontend .env.local with orchestration agent ARN.
        
        This method updates the frontend configuration file with the deployed
        orchestration agent ARN and AWS region, preserving any existing
        environment variables.
        
        Args:
            orchestration_agent_arn: ARN of the deployed orchestration agent
            frontend_directory: Path to the Next.js frontend directory
            
        Raises:
            Exception: If frontend configuration update fails
            
        Validates Requirements: 13.1, 13.2, 13.3, 13.4, 13.7
        """
        frontend_path = Path(frontend_directory)
        
        # Verify frontend directory exists
        if not frontend_path.exists():
            raise Exception(f"Frontend directory does not exist: {frontend_directory}")
        
        # Verify package.json exists (Next.js dependency check)
        package_json_path = frontend_path / "package.json"
        if not package_json_path.exists():
            raise Exception(f"package.json not found in {frontend_directory}")
        
        # Verify Next.js is installed
        try:
            import json
            with open(package_json_path, 'r') as f:
                package_data = json.load(f)
                dependencies = package_data.get('dependencies', {})
                if 'next' not in dependencies:
                    raise Exception(f"Next.js not found in dependencies in {frontend_directory}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse package.json: {str(e)}")
        
        # Path to .env.local file
        env_local_path = frontend_path / ".env.local"
        
        # Read existing .env.local file if it exists
        existing_env = {}
        comments = []
        
        if env_local_path.exists():
            with open(env_local_path, 'r') as f:
                for line in f:
                    line_stripped = line.strip()
                    if line_stripped.startswith('#'):
                        # Preserve comments
                        comments.append(line)
                    elif line_stripped and '=' in line_stripped:
                        key, value = line_stripped.split('=', 1)
                        existing_env[key.strip()] = value.strip()
        
        # Update with orchestration agent ARN and AWS region
        existing_env['ORCHESTRATION_AGENT_ARN'] = orchestration_agent_arn
        existing_env['AWS_REGION'] = self.config.aws_region
        
        # Write updated .env.local file
        with open(env_local_path, 'w') as f:
            # Write comments first
            for comment in comments:
                f.write(comment)
            
            # Write environment variables
            for key, value in existing_env.items():
                f.write(f"{key}={value}\n")
        
        print(f"\n✓ Updated {env_local_path} with orchestration agent configuration")
        print(f"  ORCHESTRATION_AGENT_ARN={orchestration_agent_arn}")
        print(f"  AWS_REGION={self.config.aws_region}")
        print(f"\nFrontend is now configured to communicate with the orchestration agent.")
        print(f"See FRONTEND_DEPLOYMENT.md for deployment instructions.")
    
    def _get_agents_in_order(self) -> List[AgentConfig]:
        """Get agents in deployment order based on dependencies.
        
        Returns:
            List of AgentConfig objects in deployment order
            
        Validates Requirements: 6.1, 6.2
        """
        # Use the deployment_order from config if specified
        if self.config.deployment_order:
            ordered_agents = []
            agent_map = {agent.name: agent for agent in self.config.agents}
            
            for agent_name in self.config.deployment_order:
                if agent_name in agent_map:
                    ordered_agents.append(agent_map[agent_name])
            
            return ordered_agents
        
        # Otherwise, use dependency-based ordering
        # Simple approach: agents with no dependencies first, then others
        no_deps = []
        with_deps = []
        
        for agent in self.config.agents:
            if not agent.dependencies:
                no_deps.append(agent)
            else:
                with_deps.append(agent)
        
        return no_deps + with_deps
    
    def _extract_execution_role_arn(self, output: str) -> Optional[str]:
        """Extract execution role ARN from agentcore configure output.
        
        Args:
            output: Output from agentcore configure command
            
        Returns:
            Execution role ARN if found, None otherwise
        """
        import re
        
        # Pattern for IAM role ARN
        role_arn_pattern = r'arn:aws:iam::\d+:role/[A-Za-z0-9-_]+'
        match = re.search(role_arn_pattern, output)
        
        if match:
            return match.group(0)
        
        return None
    
    def _attach_s3_policy(
        self,
        execution_role_arn: str,
        agent_config: AgentConfig
    ) -> None:
        """Attach S3 policy to s3-vectors agent execution role.
        
        Uses the actual bucket name from SSM parameters or deployment config.
        
        Args:
            execution_role_arn: ARN of the execution role
            agent_config: Agent configuration
            
        Raises:
            Exception: If policy attachment fails
        """
        # Extract role name from ARN
        role_name = execution_role_arn.split('/')[-1]
        
        # Get the actual bucket name from SSM or config
        bucket_name = None
        try:
            bucket_name = self.ssm_manager.get_parameter('/ads/vector-bucket-name')
        except Exception:
            pass
        
        if not bucket_name:
            # Fallback to environment_variables in agent config
            bucket_name = agent_config.environment_variables.get('S3_BUCKET_NAME', 'ads-knowledge-vectors-bucket')
        
        # Load and populate the S3 policy template
        import json
        policy_template_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 's3-vector-policy.json')
        
        try:
            with open(policy_template_path, 'r') as f:
                policy_str = f.read().replace('${S3_BUCKET_NAME}', bucket_name)
                s3_policy = json.loads(policy_str)
        except FileNotFoundError:
            # Fallback: build policy inline with actual bucket name
            s3_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "s3:GetObject",
                            "s3:PutObject",
                            "s3:DeleteObject",
                            "s3:ListBucket",
                            "s3:GetBucketLocation"
                        ],
                        "Resource": [
                            f"arn:aws:s3:::{bucket_name}",
                            f"arn:aws:s3:::{bucket_name}/*"
                        ]
                    },
                    {
                        "Effect": "Allow",
                        "Action": [
                            "s3vectors:QueryVectors",
                            "s3vectors:GetVectorIndex",
                            "s3vectors:PutVectors"
                        ],
                        "Resource": [
                            f"arn:aws:s3:::{bucket_name}",
                            f"arn:aws:s3:::{bucket_name}/*"
                        ]
                    },
                    {
                        "Effect": "Allow",
                        "Action": [
                            "bedrock:InvokeModel"
                        ],
                        "Resource": "*"
                    }
                ]
            }
        
        print(f"  S3 bucket: {bucket_name}")
        
        # Attach policy
        self.iam_manager.attach_base_policy(role_name, s3_policy)
    
    def _apply_cross_agent_policies(
        self,
        deployed_agents: List[AgentDeploymentResult]
    ) -> None:
        """Apply cross-agent communication policies to all execution roles.
        
        Args:
            deployed_agents: List of successfully deployed agents
            
        Raises:
            Exception: If policy application fails
            
        Validates Requirements: 2.5, 2.6, 2.7, 2.8, 2.10
        """
        # Collect all agent ARNs and memory ARNs
        agent_arns = []
        memory_arns = []
        role_names = []
        
        for result in deployed_agents:
            if result.agent_arn:
                agent_arns.append(result.agent_arn)
            
            if result.memory_arn:
                memory_arns.append(result.memory_arn)
            
            if result.execution_role_arn:
                # Extract role name from ARN
                role_name = result.execution_role_arn.split('/')[-1]
                role_names.append(role_name)
        
        # Create cross-agent policy
        if agent_arns or memory_arns:
            policy_document = self.iam_manager.create_cross_agent_policy(
                agent_arns=agent_arns,
                memory_arns=memory_arns
            )
            
            # Apply policy to all execution roles
            if role_names:
                self.iam_manager.apply_cross_agent_policy(
                    role_names=role_names,
                    policy_document=policy_document
                )
