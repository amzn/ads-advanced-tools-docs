"""
AWS Resource Manager for AgentCore Automated Deployment System.

This module coordinates AWS resource management operations across IAM and S3
managers. It provides a unified interface for AWS operations including:
- Validating AWS credentials before operations
- Checking service quotas
- Coordinating IAM and S3 resource management
- Error handling for credential and permission errors

Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 14.4, 14.5
"""

import boto3
from botocore.exceptions import ClientError, BotoCoreError, NoCredentialsError
from typing import Optional, Dict, Any

from .iam_manager import IAMManager
from .s3_manager import S3Manager


class AWSResourceManager:
    """Coordinates AWS resource management operations.
    
    This class serves as the main coordinator for AWS operations, managing
    IAM and S3 resources through specialized managers. It handles credential
    validation, service quota checks, and provides unified error handling.
    """
    
    def __init__(
        self,
        region: str,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        aws_session_token: Optional[str] = None,
        profile_name: Optional[str] = None
    ):
        """Initialize AWS Resource Manager with credentials and region.
        
        Creates a boto3 session and initializes IAM and S3 managers.
        Credentials are loaded from standard locations if not provided:
        - Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
        - AWS credentials file (~/.aws/credentials)
        - IAM role (for EC2 instances)
        
        Args:
            region: AWS region for operations
            aws_access_key_id: Optional AWS access key ID
            aws_secret_access_key: Optional AWS secret access key
            aws_session_token: Optional AWS session token
            profile_name: Optional AWS profile name from credentials file
            
        Raises:
            Exception: If session creation fails
            
        Requirements: 11.1, 11.2, 11.3
        """
        try:
            # Create boto3 session with provided credentials or defaults
            session_kwargs = {'region_name': region}
            
            if profile_name:
                session_kwargs['profile_name'] = profile_name
            elif aws_access_key_id and aws_secret_access_key:
                session_kwargs['aws_access_key_id'] = aws_access_key_id
                session_kwargs['aws_secret_access_key'] = aws_secret_access_key
                if aws_session_token:
                    session_kwargs['aws_session_token'] = aws_session_token
            
            self.session = boto3.Session(**session_kwargs)
            self.region = region
            
            # Initialize specialized managers
            self.iam_manager = IAMManager(self.session)
            self.s3_manager = S3Manager(self.session)
            
            # Create STS client for credential validation
            self.sts_client = self.session.client('sts')
            
        except NoCredentialsError as e:
            raise Exception(
                "AWS credentials not found. Please configure credentials using "
                "environment variables, ~/.aws/credentials file, or IAM role."
            )
        except ClientError as e:
            raise Exception(
                f"Failed to create AWS session: "
                f"{e.response['Error']['Code']} - {e.response['Error']['Message']}"
            )
        except BotoCoreError as e:
            raise Exception(f"AWS API error creating session: {str(e)}")
        except Exception as e:
            raise Exception(f"Failed to initialize AWS Resource Manager: {str(e)}")
    
    def validate_credentials(self) -> Dict[str, str]:
        """Validate AWS credentials before operations.
        
        Calls AWS STS GetCallerIdentity to verify that credentials are valid
        and have basic AWS API access. This should be called before any
        resource creation operations to fail fast on credential issues.
        
        Returns:
            Dictionary containing:
                - account_id: AWS account ID
                - user_id: User or role ID
                - arn: ARN of the caller identity
                
        Raises:
            Exception: If credentials are invalid or API call fails
            
        Requirements: 11.6, 14.4
        """
        try:
            response = self.sts_client.get_caller_identity()
            
            return {
                'account_id': response['Account'],
                'user_id': response['UserId'],
                'arn': response['Arn']
            }
            
        except NoCredentialsError:
            raise Exception(
                "AWS credentials not found. Please configure credentials using "
                "environment variables, ~/.aws/credentials file, or IAM role."
            )
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            
            if error_code == 'InvalidClientTokenId':
                raise Exception(
                    "AWS credentials are invalid. The access key ID does not exist."
                )
            elif error_code == 'SignatureDoesNotMatch':
                raise Exception(
                    "AWS credentials are invalid. The secret access key is incorrect."
                )
            elif error_code == 'AccessDenied':
                raise Exception(
                    "AWS credentials do not have permission to call STS GetCallerIdentity. "
                    "Please verify IAM permissions."
                )
            else:
                raise Exception(
                    f"Failed to validate AWS credentials: {error_code} - {error_message}"
                )
                
        except BotoCoreError as e:
            raise Exception(f"AWS API error validating credentials: {str(e)}")
    
    def check_service_quotas(self) -> Dict[str, Any]:
        """Verify account has necessary service quotas.
        
        Checks AWS service quotas to ensure the account has sufficient limits
        for agent deployment operations. This includes checking quotas for:
        - IAM roles
        - ECR repositories
        - CodeBuild projects
        - Bedrock AgentCore agents
        
        Note: This is a best-effort check. Some quotas may not be directly
        queryable via API, and actual limits may vary by account type.
        
        Returns:
            Dictionary containing quota information:
                - iam_roles: Current count and limit
                - ecr_repositories: Current count and limit
                - warnings: List of any quota warnings
                
        Raises:
            Exception: If quota check fails or quotas are insufficient
            
        Requirements: 11.4, 11.5, 14.5
        """
        warnings = []
        quota_info = {}
        
        try:
            # Check IAM role quota
            iam_client = self.session.client('iam')
            
            try:
                # Get account summary for IAM resources
                summary = iam_client.get_account_summary()
                
                roles_quota = summary['SummaryMap'].get('RolesQuota', 1000)
                roles_count = summary['SummaryMap'].get('Roles', 0)
                
                quota_info['iam_roles'] = {
                    'current': roles_count,
                    'limit': roles_quota,
                    'available': roles_quota - roles_count
                }
                
                # Warn if approaching limit (>90%)
                if roles_count > roles_quota * 0.9:
                    warnings.append(
                        f"IAM roles quota nearly exhausted: {roles_count}/{roles_quota}"
                    )
                    
            except ClientError as e:
                # If we can't check IAM quotas, log warning but continue
                warnings.append(f"Could not check IAM quotas: {e.response['Error']['Code']}")
            
            # Check ECR repository quota
            ecr_client = self.session.client('ecr')
            
            try:
                # List repositories to get current count
                # Note: ECR has a default limit of 10,000 repositories per region
                paginator = ecr_client.get_paginator('describe_repositories')
                repo_count = 0
                
                for page in paginator.paginate(PaginationConfig={'MaxItems': 100}):
                    repo_count += len(page.get('repositories', []))
                
                # Default ECR limit is 10,000 repositories
                ecr_limit = 10000
                
                quota_info['ecr_repositories'] = {
                    'current': repo_count,
                    'limit': ecr_limit,
                    'available': ecr_limit - repo_count
                }
                
                # Warn if approaching limit (>90%)
                if repo_count > ecr_limit * 0.9:
                    warnings.append(
                        f"ECR repositories quota nearly exhausted: {repo_count}/{ecr_limit}"
                    )
                    
            except ClientError as e:
                # If we can't check ECR quotas, log warning but continue
                warnings.append(f"Could not check ECR quotas: {e.response['Error']['Code']}")
            
            quota_info['warnings'] = warnings
            
            return quota_info
            
        except ClientError as e:
            raise Exception(
                f"Failed to check service quotas: "
                f"{e.response['Error']['Code']} - {e.response['Error']['Message']}"
            )
        except BotoCoreError as e:
            raise Exception(f"AWS API error checking service quotas: {str(e)}")
