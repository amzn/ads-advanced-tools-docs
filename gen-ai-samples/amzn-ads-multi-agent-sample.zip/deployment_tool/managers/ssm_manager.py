"""
SSM Parameter Store Manager

Creates and manages SSM parameters used by agents at runtime.
Agents read these instead of .env files (which are excluded from Docker images).
"""
import boto3
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class SSMManager:
    """Manages SSM Parameter Store parameters for agent configuration."""

    def __init__(self, region: str = "us-east-1"):
        self.region = region
        self.client = boto3.client('ssm', region_name=region)

    def create_parameters(self, parameters: List[Dict[str, Any]]) -> Dict[str, bool]:
        """Create or update SSM parameters from config.
        Prompts the user for any empty values.

        Args:
            parameters: List of parameter dicts with name, value, type, description

        Returns:
            Dict mapping parameter name to success status
        """
        results = {}

        for param in parameters:
            name = param['name']
            value = param.get('value', '')
            param_type = param.get('type', 'String')
            description = param.get('description', '')

            # If value is empty, check if it already exists in SSM
            if not value:
                existing = self.get_parameter(name)
                if existing:
                    logger.info(f"✓ SSM parameter '{name}' already exists, skipping")
                    results[name] = True
                    continue

                # Prompt user for the value (visible input for all types)
                value = input(f"Enter value for {name} ({description}): ")

                if not value:
                    logger.warning(f"Skipping SSM parameter '{name}' — no value provided")
                    results[name] = False
                    continue

            try:
                self.client.put_parameter(
                    Name=name,
                    Value=value,
                    Type=param_type,
                    Description=description,
                    Overwrite=True
                )
                logger.info(f"✓ SSM parameter '{name}' created ({param_type})")
                results[name] = True
            except Exception as e:
                logger.error(f"✗ Failed to create SSM parameter '{name}': {e}")
                results[name] = False

        return results

    def get_parameter(self, name: str, decrypt: bool = True) -> Optional[str]:
        """Get a single SSM parameter value.

        Args:
            name: Parameter name
            decrypt: Whether to decrypt SecureString parameters

        Returns:
            Parameter value or None if not found
        """
        try:
            response = self.client.get_parameter(Name=name, WithDecryption=decrypt)
            return response['Parameter']['Value']
        except self.client.exceptions.ParameterNotFound:
            return None
        except Exception as e:
            logger.error(f"Error reading SSM parameter '{name}': {e}")
            return None

    def parameter_exists(self, name: str) -> bool:
        """Check if an SSM parameter exists."""
        return self.get_parameter(name) is not None

    def delete_parameters(self, names: List[str]) -> Dict[str, bool]:
        """Delete SSM parameters.

        Args:
            names: List of parameter names to delete

        Returns:
            Dict mapping parameter name to success status
        """
        results = {}
        for name in names:
            try:
                self.client.delete_parameter(Name=name)
                logger.info(f"✓ Deleted SSM parameter '{name}'")
                results[name] = True
            except self.client.exceptions.ParameterNotFound:
                logger.warning(f"SSM parameter '{name}' not found (already deleted)")
                results[name] = True
            except Exception as e:
                logger.error(f"✗ Failed to delete SSM parameter '{name}': {e}")
                results[name] = False
        return results

    def create_ssm_access_policy(self, parameter_prefixes: List[str] = None) -> Dict:
        """Generate an IAM policy document granting SSM read access.

        Args:
            parameter_prefixes: List of parameter path prefixes (e.g., ['/ads/', '/campaign/'])

        Returns:
            IAM policy document dict
        """
        if parameter_prefixes is None:
            parameter_prefixes = ['/ads/', '/campaign/']

        resources = [
            f"arn:aws:ssm:{self.region}:*:parameter{prefix}*"
            for prefix in parameter_prefixes
        ]

        return {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "ssm:GetParameter",
                        "ssm:GetParameters"
                    ],
                    "Resource": resources
                }
            ]
        }
