"""
IAM Manager for AgentCore Automated Deployment System.

This module manages IAM roles and policies for agent deployments, including:
- Checking if IAM roles exist
- Attaching base policies to execution roles
- Creating cross-agent communication policies
- Applying cross-agent policies to all execution roles

Requirements: 2.1, 2.5, 2.6, 2.7, 2.8, 2.9
"""

import time
import json
from typing import List, Dict, Optional
import boto3
from botocore.exceptions import ClientError, BotoCoreError


class IAMManager:
    """Manages IAM roles and policies for agent deployments.
    
    This class handles IAM operations required for agent deployment, including
    checking role existence, attaching policies, and managing cross-agent
    communication permissions.
    
    Note: AgentCore's configure command automatically creates IAM execution roles.
    This manager adds additional policies (cross-agent communication, S3 access)
    as needed after role creation.
    """
    
    def __init__(self, boto3_session: boto3.Session):
        """Initialize IAM Manager with boto3 session.
        
        Args:
            boto3_session: Configured boto3 session for AWS API calls
        """
        self.session = boto3_session
        self.iam_client = boto3_session.client('iam')
        
        # Exponential backoff configuration
        self.max_retries = 5
        self.base_delay = 1.0  # seconds
        self.max_delay = 32.0  # seconds
    
    def role_exists(self, role_name: str) -> bool:
        """Check if an IAM role exists.
        
        Args:
            role_name: Name of the IAM role to check
            
        Returns:
            True if the role exists, False otherwise
            
        Raises:
            Exception: If AWS API call fails (other than NoSuchEntity)
        """
        try:
            self.iam_client.get_role(RoleName=role_name)
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchEntity':
                return False
            # Re-raise other errors
            raise Exception(f"Failed to check if role '{role_name}' exists: {str(e)}")
        except BotoCoreError as e:
            raise Exception(f"AWS API error checking role '{role_name}': {str(e)}")
    
    def attach_base_policy(
        self,
        role_name: str,
        policy_document: dict
    ) -> None:
        """Attach additional base permissions policy to execution role.
        
        This method creates an inline policy with the provided policy document
        and attaches it to the specified role. Uses exponential backoff for
        retries on transient errors.
        
        Args:
            role_name: Name of the IAM role to attach policy to
            policy_document: IAM policy document as a dictionary
            
        Raises:
            Exception: If policy attachment fails after retries
        """
        policy_name = f"{role_name}-base-policy"
        
        for attempt in range(self.max_retries):
            try:
                self.iam_client.put_role_policy(
                    RoleName=role_name,
                    PolicyName=policy_name,
                    PolicyDocument=json.dumps(policy_document)
                )
                return  # Success
                
            except ClientError as e:
                error_code = e.response['Error']['Code']
                
                # Retry on throttling or transient errors
                if error_code in ['Throttling', 'RequestLimitExceeded', 'ServiceUnavailable']:
                    if attempt < self.max_retries - 1:
                        delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                        time.sleep(delay)
                        continue
                
                # Non-retryable error
                raise Exception(
                    f"Failed to attach base policy to role '{role_name}': "
                    f"{error_code} - {e.response['Error']['Message']}"
                )
                
            except BotoCoreError as e:
                # Retry on network/connection errors
                if attempt < self.max_retries - 1:
                    delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                    time.sleep(delay)
                    continue
                    
                raise Exception(
                    f"AWS API error attaching base policy to role '{role_name}': {str(e)}"
                )
        
        # Max retries exceeded
        raise Exception(
            f"Failed to attach base policy to role '{role_name}' after {self.max_retries} attempts"
        )
    
    def create_cross_agent_policy(
        self,
        agent_arns: List[str],
        memory_arns: List[str]
    ) -> dict:
        """Generate cross-agent communication policy document.
        
        Creates an IAM policy document that allows:
        - InvokeRuntime permission on all agent ARNs
        - GetMemory and PutMemory permissions on all memory ARNs
        
        Args:
            agent_arns: List of agent ARNs to grant InvokeRuntime permission
            memory_arns: List of memory ARNs to grant memory access permissions
            
        Returns:
            IAM policy document as a dictionary
            
        Requirements: 2.7, 2.8, 2.9
        """
        statements = []
        
        # Add InvokeRuntime permission for all agents
        if agent_arns:
            statements.append({
                "Effect": "Allow",
                "Action": [
                    "bedrock-agentcore:InvokeRuntime",
                    "bedrock-agentcore:InvokeAgentRuntime",
                    "bedrock-agentcore:Invoke",
                    "bedrock-agentcore:ListAgentRuntimes",
                    "bedrock-agentcore:GetAgentRuntime",
                    "bedrock-agentcore:GetAgentCard"
                ],
                "Resource": agent_arns + ["*"]
            })
        
        # Add memory access permissions
        if memory_arns:
            statements.append({
                "Effect": "Allow",
                "Action": [
                    "bedrock-agentcore:GetMemory",
                    "bedrock-agentcore:PutMemory"
                ],
                "Resource": memory_arns
            })
        
        policy_document = {
            "Version": "2012-10-17",
            "Statement": statements
        }
        
        return policy_document
    
    def apply_cross_agent_policy(
        self,
        role_names: List[str],
        policy_document: dict
    ) -> None:
        """Apply cross-agent communication policy to all execution roles.
        
        Attaches the cross-agent policy to each role in the provided list.
        Uses exponential backoff for retries on transient errors.
        
        Args:
            role_names: List of IAM role names to attach policy to
            policy_document: IAM policy document as a dictionary
            
        Raises:
            Exception: If policy attachment fails for any role after retries
            
        Requirements: 2.10
        """
        policy_name = "cross-agent-communication-policy"
        
        for role_name in role_names:
            for attempt in range(self.max_retries):
                try:
                    self.iam_client.put_role_policy(
                        RoleName=role_name,
                        PolicyName=policy_name,
                        PolicyDocument=json.dumps(policy_document)
                    )
                    break  # Success, move to next role
                    
                except ClientError as e:
                    error_code = e.response['Error']['Code']
                    
                    # Retry on throttling or transient errors
                    if error_code in ['Throttling', 'RequestLimitExceeded', 'ServiceUnavailable']:
                        if attempt < self.max_retries - 1:
                            delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                            time.sleep(delay)
                            continue
                    
                    # Non-retryable error
                    raise Exception(
                        f"Failed to apply cross-agent policy to role '{role_name}': "
                        f"{error_code} - {e.response['Error']['Message']}"
                    )
                    
                except BotoCoreError as e:
                    # Retry on network/connection errors
                    if attempt < self.max_retries - 1:
                        delay = min(self.base_delay * (2 ** attempt), self.max_delay)
                        time.sleep(delay)
                        continue
                        
                    raise Exception(
                        f"AWS API error applying cross-agent policy to role '{role_name}': {str(e)}"
                    )
            else:
                # Max retries exceeded for this role
                raise Exception(
                    f"Failed to apply cross-agent policy to role '{role_name}' "
                    f"after {self.max_retries} attempts"
                )
