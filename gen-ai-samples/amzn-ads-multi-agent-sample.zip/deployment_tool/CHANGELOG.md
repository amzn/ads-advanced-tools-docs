# Changelog

All notable changes to the AgentCore Automated Deployment Tool will be documented in this file.

## [Unreleased]

### Added
- **Custom Ads MCP Server** - Added custom-ads-mcp agent to deployment configuration. This MCP (Model Context Protocol) server provides custom advertising operations and is deployed alongside the other agents. The MCP server uses the `mcp_server.py` entrypoint and is configured with the MCP protocol.

### Fixed
- **Base policy attachment** - Fixed deployment orchestrator to attach base IAM policies (CloudWatch Logs, Bedrock InvokeModel, ECR access, etc.) to each agent's execution role after deployment. Previously, only S3 policies for s3-vectors agent and cross-agent communication policies were being attached. Now all agents receive the base policy defined in `deployment.yaml` immediately after their execution role is created by AgentCore.
- **Idempotent deployments** - Added `--auto-update-on-conflict` flag to `agentcore deploy` command to support redeploying existing agents. This allows the deployment tool to update agents that have already been deployed, making deployments idempotent and supporting iterative development workflows.
- **Agent ARN extraction** - Updated regex patterns to support the current AgentCore ARN format (`arn:aws:bedrock-agentcore:region:account:runtime/name-id`) in addition to the older format. This fixes the "Failed to extract agent ARN from deploy output" error.
- **Execution role ARN extraction** - Fixed the deployment flow to extract the execution role ARN from the `agentcore deploy` output instead of `agentcore configure`. When using `--ecr auto`, AgentCore creates the execution role during the deploy step, not the configure step. The deployment orchestrator now correctly extracts the role ARN after deployment completes.
- **Agent name sanitization** - The deployment orchestrator now automatically converts hyphens in agent names to underscores to comply with AgentCore naming requirements. AgentCore requires agent names to start with a letter and contain only letters, numbers, and underscores (1-48 characters). Agent names with hyphens (like `custom-ads-a2a-agent`) are now automatically converted to underscores (`custom_ads_a2a_agent`) during deployment while preserving the original name in configuration and state management.

### Changed
- **Removed redundant dependency installation step** - The deployment orchestrator no longer explicitly installs Python dependencies before deploying agents. AgentCore handles dependency installation automatically during the build process, making the separate installation step unnecessary and redundant. This change:
  - Speeds up deployment by eliminating duplicate work
  - Simplifies the deployment flow
  - Reduces potential points of failure
  - Maintains the same functionality since AgentCore handles dependencies internally

### Technical Details
- Modified `AgentDeploymentOrchestrator.deploy_agent()` method in `managers/deployment_orchestrator.py`
- Added Step 3: Attach base policy from `deployment.yaml` configuration to execution role
- Renumbered Step 4: Attach S3 policy (for s3-vectors agent only)
- Renumbered Step 5: Record deployment state
- Updated method documentation to reflect the streamlined 5-step process
- Base policy includes: CloudWatch Logs, Bedrock InvokeModel, ECR access, Secrets Manager access
- Removed call to `agentcore.install_dependencies()` 
- Updated test mocks in `tests/test_deployment_orchestrator.py` to remove dependency installation mock
- The `install_dependencies()` method remains available in `AgentCoreIntegration` for manual use if needed

## [1.0.0] - 2024-02-06

### Added
- Initial release of AgentCore Automated Deployment Tool
- Support for deploying multiple AWS Bedrock AgentCore agents
- Automated IAM role and policy management
- Cross-agent communication policy setup
- S3 vector knowledge base integration
- Frontend configuration updates
- Comprehensive test suite with 97.9% pass rate
- Property-based testing with 100 iterations minimum
- 91% code coverage
- CLI interface with deploy, validate, status, and cleanup commands
- State management for tracking deployments
- Deployment orchestration with dependency ordering
- Support for optional agents
- Dry-run mode for previewing changes
- Detailed deployment guides and documentation
