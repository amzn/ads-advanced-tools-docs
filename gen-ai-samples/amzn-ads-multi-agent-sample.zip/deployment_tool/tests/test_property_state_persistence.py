"""
Property-based tests for State Persistence Consistency.

This module implements Property 8: State Persistence Consistency
For any successful agent deployment, the deployment state file must contain
the agent's ARN, execution role ARN, and deployment timestamp.

**Validates: Requirements 7.2, 9.1**

Testing Strategy:
- Generate random agent deployment scenarios with various configurations
- Verify that all successful deployments are correctly persisted to state
- Verify that state can be loaded and contains all required fields
- Test with minimum 100 iterations using hypothesis
"""

import json
import os
from datetime import datetime
from tempfile import TemporaryDirectory
from hypothesis import given, strategies as st, settings
import pytest

from deployment_tool.managers.state_manager import StateManager
from deployment_tool.models.data_models import AgentDeploymentState


# Strategy for generating valid AWS ARNs
def arn_strategy(service: str, resource_type: str) -> st.SearchStrategy:
    """Generate valid AWS ARN strings."""
    return st.builds(
        lambda region, account, resource_id: (
            f"arn:aws:{service}:{region}:{account}:{resource_type}/{resource_id}"
        ),
        region=st.sampled_from(['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1']),
        account=st.integers(min_value=100000000000, max_value=999999999999).map(str),
        resource_id=st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='-'),
            min_size=10,
            max_size=50
        ).filter(lambda x: x and not x.startswith('-') and not x.endswith('-'))
    )


# Strategy for generating agent names
agent_name_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='-'),
    min_size=3,
    max_size=50
).filter(lambda x: x and not x.startswith('-') and not x.endswith('-'))


# Strategy for generating ECR repository URIs
ecr_uri_strategy = st.builds(
    lambda account, region, repo: f"{account}.dkr.ecr.{region}.amazonaws.com/{repo}",
    account=st.integers(min_value=100000000000, max_value=999999999999).map(str),
    region=st.sampled_from(['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1']),
    repo=st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='-/'),
        min_size=3,
        max_size=50
    ).filter(lambda x: x and not x.startswith('-') and not x.endswith('-'))
)


# Strategy for generating CodeBuild project names
codebuild_name_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='-_'),
    min_size=3,
    max_size=50
).filter(lambda x: x and not x.startswith('-') and not x.startswith('_'))


class TestPropertyStatePersistence:
    """Property-based tests for state persistence consistency."""
    
    @given(
        agent_name=agent_name_strategy,
        agent_arn=arn_strategy('bedrock', 'agent'),
        execution_role_arn=arn_strategy('iam', 'role'),
        ecr_uri=ecr_uri_strategy,
        codebuild_name=codebuild_name_strategy,
        has_memory=st.booleans()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_8_single_agent_persistence(
        self,
        agent_name,
        agent_arn,
        execution_role_arn,
        ecr_uri,
        codebuild_name,
        has_memory
    ):
        """
        Property 8: State Persistence Consistency
        
        For any successful agent deployment, the deployment state file must contain
        the agent's ARN, execution role ARN, and deployment timestamp.
        
        **Validates: Requirements 7.2, 9.1**
        
        This test verifies that:
        1. After recording a deployment, the state file exists
        2. The state file contains valid JSON
        3. The state contains the agent's ARN
        4. The state contains the execution role ARN
        5. The state contains a valid deployment timestamp
        6. All required fields are present and non-empty
        """
        # Create state manager with temporary file in a unique location
        # Use a unique filename for each test run to avoid conflicts
        import tempfile
        state_file = tempfile.mktemp(suffix=f"_{agent_name}.json", prefix="state_")
        state_manager = StateManager(state_file)
        
        try:
            # Generate optional memory ARN
            memory_arn = None
            if has_memory:
                # Generate memory ARN in same region/account as agent ARN
                parts = agent_arn.split(':')
                region = parts[3]
                account = parts[4]
                memory_id = f"mem-{agent_name}"
                memory_arn = f"arn:aws:bedrock:{region}:{account}:memory/{memory_id}"
            
            # Record the deployment (simulating successful deployment)
            before_deployment = datetime.now()
            state_manager.record_agent_deployment(
                agent_name=agent_name,
                agent_arn=agent_arn,
                execution_role_arn=execution_role_arn,
                ecr_repository_uri=ecr_uri,
                codebuild_project_name=codebuild_name,
                memory_arn=memory_arn
            )
            after_deployment = datetime.now()
            
            # Property verification: State file must exist
            assert os.path.exists(state_file), (
                f"State file must exist after successful deployment of {agent_name}"
            )
            
            # Property verification: State file must contain valid JSON
            with open(state_file, 'r') as f:
                state_data = json.load(f)
            
            assert isinstance(state_data, dict), "State file must contain a JSON object"
            assert 'agents' in state_data, "State must contain 'agents' field"
            assert agent_name in state_data['agents'], (
                f"State must contain entry for deployed agent {agent_name}"
            )
            
            # Property verification: Agent entry must contain ARN
            agent_data = state_data['agents'][agent_name]
            assert 'agent_arn' in agent_data, "Agent state must contain 'agent_arn' field"
            assert agent_data['agent_arn'] == agent_arn, (
                f"Stored agent ARN must match deployed ARN: {agent_arn}"
            )
            assert agent_data['agent_arn'], "Agent ARN must not be empty"
            
            # Property verification: Agent entry must contain execution role ARN
            assert 'execution_role_arn' in agent_data, (
                "Agent state must contain 'execution_role_arn' field"
            )
            assert agent_data['execution_role_arn'] == execution_role_arn, (
                f"Stored execution role ARN must match deployed role: {execution_role_arn}"
            )
            assert agent_data['execution_role_arn'], "Execution role ARN must not be empty"
            
            # Property verification: Agent entry must contain deployment timestamp
            assert 'deployed_at' in agent_data, (
                "Agent state must contain 'deployed_at' timestamp"
            )
            deployed_at = datetime.fromisoformat(agent_data['deployed_at'])
            assert before_deployment <= deployed_at <= after_deployment, (
                "Deployment timestamp must be within the deployment time window"
            )
            
            # Property verification: Memory ARN handling
            if has_memory:
                assert agent_data['memory_arn'] == memory_arn, (
                    "Stored memory ARN must match deployed memory ARN"
                )
            else:
                assert agent_data['memory_arn'] is None, (
                    "Memory ARN must be None when not provided"
                )
            
            # Property verification: State can be loaded back correctly
            loaded_state = state_manager.load_state()
            assert agent_name in loaded_state.agents, (
                "Loaded state must contain the deployed agent"
            )
            
            loaded_agent = loaded_state.agents[agent_name]
            assert loaded_agent.agent_arn == agent_arn, (
                "Loaded agent ARN must match original"
            )
            assert loaded_agent.execution_role_arn == execution_role_arn, (
                "Loaded execution role ARN must match original"
            )
            assert loaded_agent.memory_arn == memory_arn, (
                "Loaded memory ARN must match original"
            )
        finally:
            # Clean up temporary file
            if os.path.exists(state_file):
                os.remove(state_file)
    
    @given(
        agents=st.lists(
            st.tuples(
                agent_name_strategy,
                arn_strategy('bedrock', 'agent'),
                arn_strategy('iam', 'role'),
                ecr_uri_strategy,
                codebuild_name_strategy,
                st.booleans()
            ),
            min_size=1,
            max_size=10,
            unique_by=lambda x: x[0]  # Unique agent names
        )
    )
    @settings(max_examples=100, deadline=None)
    def test_property_8_multiple_agents_persistence(self, agents):
        """
        Property 8: State Persistence Consistency (Multiple Agents)
        
        For any set of successful agent deployments, the deployment state file
        must contain all agents' ARNs, execution role ARNs, and deployment timestamps.
        
        **Validates: Requirements 7.2, 9.1**
        
        This test verifies that:
        1. Multiple agent deployments are all persisted correctly
        2. Each agent's state is independent and complete
        3. State file remains valid JSON after multiple writes
        4. All agents can be retrieved from state
        """
        import tempfile
        state_file = tempfile.mktemp(suffix="_multi_agent.json", prefix="state_")
        state_manager = StateManager(state_file)
        
        try:
            deployed_agents = []
            
            # Deploy all agents
            for agent_name, agent_arn, role_arn, ecr_uri, codebuild_name, has_memory in agents:
                memory_arn = None
                if has_memory:
                    parts = agent_arn.split(':')
                    region = parts[3]
                    account = parts[4]
                    memory_arn = f"arn:aws:bedrock:{region}:{account}:memory/mem-{agent_name}"
                
                state_manager.record_agent_deployment(
                    agent_name=agent_name,
                    agent_arn=agent_arn,
                    execution_role_arn=role_arn,
                    ecr_repository_uri=ecr_uri,
                    codebuild_project_name=codebuild_name,
                    memory_arn=memory_arn
                )
                
                deployed_agents.append((agent_name, agent_arn, role_arn, memory_arn))
            
            # Property verification: State file exists and is valid JSON
            assert os.path.exists(state_file), (
                "State file must exist after multiple deployments"
            )
            
            with open(state_file, 'r') as f:
                state_data = json.load(f)
            
            # Property verification: All agents are in state
            assert len(state_data['agents']) == len(agents), (
                f"State must contain all {len(agents)} deployed agents"
            )
            
            # Property verification: Each agent has complete state
            for agent_name, agent_arn, role_arn, memory_arn in deployed_agents:
                assert agent_name in state_data['agents'], (
                    f"State must contain agent {agent_name}"
                )
                
                agent_data = state_data['agents'][agent_name]
                
                # Verify required fields
                assert agent_data['agent_arn'] == agent_arn, (
                    f"Agent {agent_name} ARN must match"
                )
                assert agent_data['execution_role_arn'] == role_arn, (
                    f"Agent {agent_name} execution role ARN must match"
                )
                assert 'deployed_at' in agent_data, (
                    f"Agent {agent_name} must have deployment timestamp"
                )
                assert agent_data['memory_arn'] == memory_arn, (
                    f"Agent {agent_name} memory ARN must match"
                )
            
            # Property verification: State can be loaded and all agents retrieved
            loaded_state = state_manager.load_state()
            assert len(loaded_state.agents) == len(agents), (
                "Loaded state must contain all deployed agents"
            )
            
            for agent_name, agent_arn, role_arn, memory_arn in deployed_agents:
                loaded_agent = loaded_state.agents[agent_name]
                assert loaded_agent.agent_arn == agent_arn
                assert loaded_agent.execution_role_arn == role_arn
                assert loaded_agent.memory_arn == memory_arn
        finally:
            # Clean up temporary file
            if os.path.exists(state_file):
                os.remove(state_file)
    
    @given(
        agent_name=agent_name_strategy,
        initial_arn=arn_strategy('bedrock', 'agent'),
        updated_arn=arn_strategy('bedrock', 'agent'),
        initial_role=arn_strategy('iam', 'role'),
        updated_role=arn_strategy('iam', 'role'),
        ecr_uri=ecr_uri_strategy,
        codebuild_name=codebuild_name_strategy
    )
    @settings(max_examples=100, deadline=None)
    def test_property_8_state_update_persistence(
        self,
        agent_name,
        initial_arn,
        updated_arn,
        initial_role,
        updated_role,
        ecr_uri,
        codebuild_name
    ):
        """
        Property 8: State Persistence Consistency (Updates)
        
        For any agent redeployment, the deployment state must be updated with
        the new ARN, execution role ARN, and deployment timestamp, replacing
        the previous values.
        
        **Validates: Requirements 7.2, 9.1**
        
        This test verifies that:
        1. Initial deployment is persisted correctly
        2. Redeployment updates the state
        3. Only the latest deployment information is retained
        4. Timestamp is updated on redeployment
        """
        import tempfile
        state_file = tempfile.mktemp(suffix=f"_update_{agent_name}.json", prefix="state_")
        state_manager = StateManager(state_file)
        
        try:
            # Initial deployment
            state_manager.record_agent_deployment(
                agent_name=agent_name,
                agent_arn=initial_arn,
                execution_role_arn=initial_role,
                ecr_repository_uri=ecr_uri,
                codebuild_project_name=codebuild_name
            )
            
            # Load initial state
            initial_state = state_manager.load_state()
            initial_timestamp = initial_state.agents[agent_name].deployed_at
            
            # Wait a moment to ensure timestamp difference
            import time
            time.sleep(0.01)
            
            # Redeployment with updated values
            state_manager.record_agent_deployment(
                agent_name=agent_name,
                agent_arn=updated_arn,
                execution_role_arn=updated_role,
                ecr_repository_uri=ecr_uri,
                codebuild_project_name=codebuild_name
            )
            
            # Property verification: State contains updated values
            updated_state = state_manager.load_state()
            
            # Only one entry should exist for the agent
            assert len([a for a in updated_state.agents if a == agent_name]) == 1, (
                "State must contain exactly one entry per agent"
            )
            
            updated_agent = updated_state.agents[agent_name]
            
            # Verify updated values
            assert updated_agent.agent_arn == updated_arn, (
                "State must contain updated agent ARN"
            )
            assert updated_agent.execution_role_arn == updated_role, (
                "State must contain updated execution role ARN"
            )
            
            # Verify timestamp was updated
            assert updated_agent.deployed_at > initial_timestamp, (
                "Deployment timestamp must be updated on redeployment"
            )
            
            # Verify state file contains updated values
            with open(state_file, 'r') as f:
                state_data = json.load(f)
            
            agent_data = state_data['agents'][agent_name]
            assert agent_data['agent_arn'] == updated_arn
            assert agent_data['execution_role_arn'] == updated_role
        finally:
            # Clean up temporary file
            if os.path.exists(state_file):
                os.remove(state_file)
    
    @given(
        agent_name=agent_name_strategy,
        agent_arn=arn_strategy('bedrock', 'agent'),
        execution_role_arn=arn_strategy('iam', 'role'),
        ecr_uri=ecr_uri_strategy,
        codebuild_name=codebuild_name_strategy
    )
    @settings(max_examples=100, deadline=None)
    def test_property_8_state_persistence_across_instances(
        self,
        agent_name,
        agent_arn,
        execution_role_arn,
        ecr_uri,
        codebuild_name
    ):
        """
        Property 8: State Persistence Consistency (Cross-Instance)
        
        For any successful agent deployment, the state must persist across
        different StateManager instances, ensuring durability.
        
        **Validates: Requirements 7.2, 9.1**
        
        This test verifies that:
        1. State persisted by one instance can be read by another
        2. All required fields are preserved across instances
        3. State file format is consistent and portable
        """
        import tempfile
        state_file = tempfile.mktemp(suffix=f"_cross_{agent_name}.json", prefix="state_")
        
        try:
            
            # First instance: record deployment
            manager1 = StateManager(state_file)
            manager1.record_agent_deployment(
                agent_name=agent_name,
                agent_arn=agent_arn,
                execution_role_arn=execution_role_arn,
                ecr_repository_uri=ecr_uri,
                codebuild_project_name=codebuild_name
            )
            
            # Second instance: load and verify state
            manager2 = StateManager(state_file)
            loaded_state = manager2.load_state()
            
            # Property verification: State is accessible from new instance
            assert agent_name in loaded_state.agents, (
                "State must be accessible from different StateManager instance"
            )
            
            loaded_agent = loaded_state.agents[agent_name]
            assert loaded_agent.agent_arn == agent_arn, (
                "Agent ARN must persist across instances"
            )
            assert loaded_agent.execution_role_arn == execution_role_arn, (
                "Execution role ARN must persist across instances"
            )
            assert loaded_agent.ecr_repository_uri == ecr_uri, (
                "ECR URI must persist across instances"
            )
            assert loaded_agent.codebuild_project_name == codebuild_name, (
                "CodeBuild project name must persist across instances"
            )
            
            # Third instance: verify using get_agent_arn method
            manager3 = StateManager(state_file)
            retrieved_arn = manager3.get_agent_arn(agent_name)
            
            assert retrieved_arn == agent_arn, (
                "Agent ARN retrieval must work across instances"
            )
        finally:
            # Clean up temporary file
            if os.path.exists(state_file):
                os.remove(state_file)
