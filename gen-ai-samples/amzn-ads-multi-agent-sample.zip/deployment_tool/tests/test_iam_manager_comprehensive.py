"""
Comprehensive tests for IAMManager class.

Tests all methods including error handling and exponential backoff.
"""

import pytest
from unittest.mock import Mock, patch, call
import boto3
from botocore.exceptions import ClientError, BotoCoreError
import json
import time

from managers.iam_manager import IAMManager


@pytest.fixture
def mock_session():
    """Create a mock boto3 session."""
    session = Mock(spec=boto3.Session)
    return session


@pytest.fixture
def mock_iam_client():
    """Create a mock IAM client."""
    return Mock()


@pytest.fixture
def iam_manager(mock_session, mock_iam_client):
    """Create an IAMManager instance with mocked dependencies."""
    mock_session.client.return_value = mock_iam_client
    return IAMManager(mock_session)


class TestRoleExists:
    """Tests for role_exists method."""
    
    def test_role_exists_returns_true(self, iam_manager, mock_iam_client):
        """Test that role_exists returns True when role exists."""
        mock_iam_client.get_role.return_value = {'Role': {'RoleName': 'test-role'}}
        
        result = iam_manager.role_exists('test-role')
        
        assert result is True
        mock_iam_client.get_role.assert_called_once_with(RoleName='test-role')
    
    def test_role_exists_returns_false(self, iam_manager, mock_iam_client):
        """Test that role_exists returns False when role does not exist."""
        error_response = {'Error': {'Code': 'NoSuchEntity', 'Message': 'Role not found'}}
        mock_iam_client.get_role.side_effect = ClientError(error_response, 'GetRole')
        
        result = iam_manager.role_exists('nonexistent-role')
        
        assert result is False
    
    def test_role_exists_raises_on_other_errors(self, iam_manager, mock_iam_client):
        """Test that role_exists raises exception on non-NoSuchEntity errors."""
        error_response = {'Error': {'Code': 'AccessDenied', 'Message': 'Access denied'}}
        mock_iam_client.get_role.side_effect = ClientError(error_response, 'GetRole')
        
        with pytest.raises(Exception) as exc_info:
            iam_manager.role_exists('test-role')
        
        assert "Failed to check if role 'test-role' exists" in str(exc_info.value)


class TestAttachBasePolicy:
    """Tests for attach_base_policy method."""
    
    def test_attach_base_policy_success(self, iam_manager, mock_iam_client):
        """Test successful policy attachment."""
        policy_document = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": "s3:GetObject",
                    "Resource": "*"
                }
            ]
        }
        
        iam_manager.attach_base_policy('test-role', policy_document)
        
        mock_iam_client.put_role_policy.assert_called_once_with(
            RoleName='test-role',
            PolicyName='test-role-base-policy',
            PolicyDocument=json.dumps(policy_document)
        )
    
    @patch('time.sleep')
    def test_attach_base_policy_retries_on_throttling(
        self, mock_sleep, iam_manager, mock_iam_client
    ):
        """Test that attach_base_policy retries on throttling errors."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_iam_client.put_role_policy.side_effect = [
            ClientError(error_response, 'PutRolePolicy'),
            ClientError(error_response, 'PutRolePolicy'),
            None  # Success on third attempt
        ]
        
        policy_document = {"Version": "2012-10-17", "Statement": []}
        iam_manager.attach_base_policy('test-role', policy_document)
        
        assert mock_iam_client.put_role_policy.call_count == 3
        assert mock_sleep.call_count == 2
    
    @patch('time.sleep')
    def test_attach_base_policy_fails_after_max_retries(
        self, mock_sleep, iam_manager, mock_iam_client
    ):
        """Test that attach_base_policy fails after max retries."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_iam_client.put_role_policy.side_effect = ClientError(error_response, 'PutRolePolicy')
        
        policy_document = {"Version": "2012-10-17", "Statement": []}
        
        with pytest.raises(Exception) as exc_info:
            iam_manager.attach_base_policy('test-role', policy_document)
        
        # On the last attempt, throttling error is raised as non-retryable
        assert "Failed to attach base policy to role 'test-role'" in str(exc_info.value)
        assert "Throttling" in str(exc_info.value)
        assert mock_iam_client.put_role_policy.call_count == 5


class TestCreateCrossAgentPolicy:
    """Tests for create_cross_agent_policy method."""
    
    def test_create_cross_agent_policy_with_agents_and_memory(self, iam_manager):
        """Test policy creation with both agent and memory ARNs."""
        agent_arns = [
            'arn:aws:bedrock-agentcore:us-east-1:123456789012:agent/agent1',
            'arn:aws:bedrock-agentcore:us-east-1:123456789012:agent/agent2'
        ]
        memory_arns = [
            'arn:aws:bedrock-agentcore:us-east-1:123456789012:memory/mem1'
        ]
        
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        assert policy['Version'] == '2012-10-17'
        assert len(policy['Statement']) == 2
        
        # Check InvokeRuntime statement
        invoke_statement = policy['Statement'][0]
        assert invoke_statement['Effect'] == 'Allow'
        assert 'bedrock-agentcore:InvokeRuntime' in invoke_statement['Action']
        assert invoke_statement['Resource'] == agent_arns
        
        # Check memory statement
        memory_statement = policy['Statement'][1]
        assert memory_statement['Effect'] == 'Allow'
        assert 'bedrock-agentcore:GetMemory' in memory_statement['Action']
        assert 'bedrock-agentcore:PutMemory' in memory_statement['Action']
        assert memory_statement['Resource'] == memory_arns
    
    def test_create_cross_agent_policy_with_only_agents(self, iam_manager):
        """Test policy creation with only agent ARNs."""
        agent_arns = ['arn:aws:bedrock-agentcore:us-east-1:123456789012:agent/agent1']
        
        policy = iam_manager.create_cross_agent_policy(agent_arns, [])
        
        assert len(policy['Statement']) == 1
        assert 'bedrock-agentcore:InvokeRuntime' in policy['Statement'][0]['Action']
    
    def test_create_cross_agent_policy_with_only_memory(self, iam_manager):
        """Test policy creation with only memory ARNs."""
        memory_arns = ['arn:aws:bedrock-agentcore:us-east-1:123456789012:memory/mem1']
        
        policy = iam_manager.create_cross_agent_policy([], memory_arns)
        
        assert len(policy['Statement']) == 1
        assert 'bedrock-agentcore:GetMemory' in policy['Statement'][0]['Action']
    
    def test_create_cross_agent_policy_with_empty_lists(self, iam_manager):
        """Test policy creation with empty ARN lists."""
        policy = iam_manager.create_cross_agent_policy([], [])
        
        assert policy['Version'] == '2012-10-17'
        assert len(policy['Statement']) == 0


class TestApplyCrossAgentPolicy:
    """Tests for apply_cross_agent_policy method."""
    
    def test_apply_cross_agent_policy_success(self, iam_manager, mock_iam_client):
        """Test successful policy application to multiple roles."""
        role_names = ['role1', 'role2', 'role3']
        policy_document = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": "bedrock-agentcore:InvokeRuntime",
                    "Resource": "*"
                }
            ]
        }
        
        iam_manager.apply_cross_agent_policy(role_names, policy_document)
        
        assert mock_iam_client.put_role_policy.call_count == 3
        
        # Verify each role was called with correct parameters
        expected_calls = [
            call(
                RoleName=role_name,
                PolicyName='cross-agent-communication-policy',
                PolicyDocument=json.dumps(policy_document)
            )
            for role_name in role_names
        ]
        mock_iam_client.put_role_policy.assert_has_calls(expected_calls)
    
    @patch('time.sleep')
    def test_apply_cross_agent_policy_retries_per_role(
        self, mock_sleep, iam_manager, mock_iam_client
    ):
        """Test that policy application retries for each role independently."""
        role_names = ['role1', 'role2']
        policy_document = {"Version": "2012-10-17", "Statement": []}
        
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_iam_client.put_role_policy.side_effect = [
            ClientError(error_response, 'PutRolePolicy'),  # role1 first attempt
            None,  # role1 second attempt - success
            None   # role2 first attempt - success
        ]
        
        iam_manager.apply_cross_agent_policy(role_names, policy_document)
        
        assert mock_iam_client.put_role_policy.call_count == 3
        assert mock_sleep.call_count == 1
    
    @patch('time.sleep')
    def test_apply_cross_agent_policy_fails_on_role_error(
        self, mock_sleep, iam_manager, mock_iam_client
    ):
        """Test that policy application fails if a role encounters max retries."""
        role_names = ['role1', 'role2']
        policy_document = {"Version": "2012-10-17", "Statement": []}
        
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_iam_client.put_role_policy.side_effect = ClientError(error_response, 'PutRolePolicy')
        
        with pytest.raises(Exception) as exc_info:
            iam_manager.apply_cross_agent_policy(role_names, policy_document)
        
        assert "Failed to apply cross-agent policy to role 'role1'" in str(exc_info.value)
        assert "Throttling" in str(exc_info.value)


class TestExponentialBackoff:
    """Tests for exponential backoff behavior."""
    
    @patch('time.sleep')
    def test_exponential_backoff_delays(self, mock_sleep, iam_manager, mock_iam_client):
        """Test that exponential backoff increases delays correctly."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_iam_client.put_role_policy.side_effect = [
            ClientError(error_response, 'PutRolePolicy'),
            ClientError(error_response, 'PutRolePolicy'),
            ClientError(error_response, 'PutRolePolicy'),
            None  # Success on fourth attempt
        ]
        
        policy_document = {"Version": "2012-10-17", "Statement": []}
        iam_manager.attach_base_policy('test-role', policy_document)
        
        # Verify exponential backoff: 1, 2, 4 seconds
        sleep_calls = [call.args[0] for call in mock_sleep.call_args_list]
        assert sleep_calls == [1.0, 2.0, 4.0]
    
    @patch('time.sleep')
    def test_max_delay_cap(self, mock_sleep, iam_manager, mock_iam_client):
        """Test that delay is capped at max_delay."""
        # Set a scenario that would exceed max_delay
        iam_manager.max_delay = 8.0  # Lower max for testing
        
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_iam_client.put_role_policy.side_effect = [
            ClientError(error_response, 'PutRolePolicy'),
            ClientError(error_response, 'PutRolePolicy'),
            ClientError(error_response, 'PutRolePolicy'),
            ClientError(error_response, 'PutRolePolicy'),
            None  # Success on fifth attempt
        ]
        
        policy_document = {"Version": "2012-10-17", "Statement": []}
        iam_manager.attach_base_policy('test-role', policy_document)
        
        # Verify delays are capped: 1, 2, 4, 8 (capped at max_delay)
        sleep_calls = [call.args[0] for call in mock_sleep.call_args_list]
        assert sleep_calls == [1.0, 2.0, 4.0, 8.0]
        assert all(delay <= 8.0 for delay in sleep_calls)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
