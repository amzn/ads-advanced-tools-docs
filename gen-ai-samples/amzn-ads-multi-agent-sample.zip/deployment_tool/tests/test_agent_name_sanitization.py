"""
Tests for agent name sanitization in deployment orchestrator.

Validates that agent names with hyphens are properly converted to underscores
to comply with AgentCore naming requirements.
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path
import tempfile

from deployment_tool.models.data_models import (
    DeploymentConfig,
    AgentConfig
)
from deployment_tool.managers.deployment_orchestrator import AgentDeploymentOrchestrator


class TestAgentNameSanitization(unittest.TestCase):
    """Test agent name sanitization for AgentCore compatibility."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.config = DeploymentConfig(
            aws_account_id="123456789012",
            aws_region="us-east-1",
            agents=[],
            deployment_order=[],
            iam_policies={}
        )
        
        self.mock_iam_manager = Mock()
        self.mock_s3_manager = Mock()
        self.mock_state_manager = Mock()
        
        self.orchestrator = AgentDeploymentOrchestrator(
            config=self.config,
            iam_manager=self.mock_iam_manager,
            s3_manager=self.mock_s3_manager,
            state_manager=self.mock_state_manager
        )
    
    @patch('deployment_tool.managers.deployment_orchestrator.AgentCoreIntegration')
    def test_agent_name_with_hyphens_is_sanitized(self, mock_agentcore_class):
        """Test that agent names with hyphens are converted to underscores."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create agent config with hyphens in name
            agent_config = AgentConfig(
                name="custom-ads-a2a-agent",
                directory=temp_dir,
                entrypoint="agent.py",
                language="python",
                platform="linux/arm64",
                memory_mode="STM_ONLY",
                server_protocol="A2A",
                dependencies=[],
                environment_variables={}
            )
            
            # Create a dummy entrypoint file
            Path(temp_dir).joinpath("agent.py").touch()
            
            # Mock AgentCoreIntegration
            mock_agentcore = Mock()
            mock_agentcore_class.return_value = mock_agentcore
            
            # Mock run_configure (AgentCore handles dependencies internally)
            mock_configure_result = Mock()
            mock_configure_result.stdout = "Execution role: arn:aws:iam::123456789012:role/test-role"
            mock_configure_result.stderr = ""
            mock_agentcore.run_configure.return_value = mock_configure_result
            
            # Mock run_deploy
            mock_deploy_result = Mock()
            mock_deploy_result.stdout = "Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT"
            mock_deploy_result.stderr = ""
            mock_agentcore.run_deploy.return_value = mock_deploy_result
            
            # Mock parse_deploy_output
            mock_agentcore.parse_deploy_output.return_value = {
                'agent_arn': 'arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT',
                'execution_role_arn': 'arn:aws:iam::123456789012:role/test-role',
                'memory_arn': 'arn:aws:bedrock:us-east-1:123456789012:memory/TESTMEMORY'
            }
            
            # Deploy agent
            result = self.orchestrator.deploy_agent(agent_config)
            
            # Verify success
            self.assertTrue(result.success)
            
            # Verify that run_configure was called with sanitized name (underscores)
            mock_agentcore.run_configure.assert_called_once()
            call_kwargs = mock_agentcore.run_configure.call_args[1]
            self.assertEqual(call_kwargs['agent_name'], 'custom_ads_a2a_agent')
            
            # Verify original name is preserved in result
            self.assertEqual(result.agent_name, 'custom-ads-a2a-agent')
    
    @patch('deployment_tool.managers.deployment_orchestrator.AgentCoreIntegration')
    def test_agent_name_without_hyphens_unchanged(self, mock_agentcore_class):
        """Test that agent names without hyphens are not modified."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create agent config without hyphens in name
            agent_config = AgentConfig(
                name="custom_ads_agent",
                directory=temp_dir,
                entrypoint="agent.py",
                language="python",
                platform="linux/arm64",
                memory_mode="STM_ONLY",
                server_protocol="A2A",
                dependencies=[],
                environment_variables={}
            )
            
            # Create a dummy entrypoint file
            Path(temp_dir).joinpath("agent.py").touch()
            
            # Mock AgentCoreIntegration
            mock_agentcore = Mock()
            mock_agentcore_class.return_value = mock_agentcore
            
            # Mock run_configure
            mock_configure_result = Mock()
            mock_configure_result.stdout = "Execution role: arn:aws:iam::123456789012:role/test-role"
            mock_configure_result.stderr = ""
            mock_agentcore.run_configure.return_value = mock_configure_result
            
            # Mock run_deploy
            mock_deploy_result = Mock()
            mock_deploy_result.stdout = "Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT"
            mock_deploy_result.stderr = ""
            mock_agentcore.run_deploy.return_value = mock_deploy_result
            
            # Mock parse_deploy_output
            mock_agentcore.parse_deploy_output.return_value = {
                'agent_arn': 'arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT',
                'execution_role_arn': 'arn:aws:iam::123456789012:role/test-role',
                'memory_arn': 'arn:aws:bedrock:us-east-1:123456789012:memory/TESTMEMORY'
            }
            
            # Deploy agent
            result = self.orchestrator.deploy_agent(agent_config)
            
            # Verify success
            self.assertTrue(result.success)
            
            # Verify that run_configure was called with same name (no change)
            mock_agentcore.run_configure.assert_called_once()
            call_kwargs = mock_agentcore.run_configure.call_args[1]
            self.assertEqual(call_kwargs['agent_name'], 'custom_ads_agent')
            
            # Verify original name is preserved in result
            self.assertEqual(result.agent_name, 'custom_ads_agent')


if __name__ == '__main__':
    unittest.main()
