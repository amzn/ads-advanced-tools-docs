"""
Property-Based Test: ARN Propagation Consistency

This test validates Property 4: For any deployed sub-agent, its ARN must be
captured and made available to the orchestration agent's environment variables.

Validates Requirements: 7.1, 7.2, 7.3, 7.5

Tag: Feature: agentcore-automated-deployment, Property 4: ARN propagation consistency
"""

import pytest
from hypothesis import given, strategies as st, settings
from typing import Dict
import sys
import os
import tempfile
from pathlib import Path

# Add parent directory to path for imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import AgentConfig, DeploymentConfig, IAMPolicyConfig


# Strategy for generating agent ARNs
agent_arn_strategy = st.builds(
    lambda region, account_id, agent_id: f"arn:aws:bedrock:{region}:{account_id}:agent/{agent_id}",
    region=st.sampled_from(["us-east-1", "us-west-2", "eu-west-1"]),
    account_id=st.integers(min_value=100000000000, max_value=999999999999).map(str),
    agent_id=st.text(
        alphabet=st.characters(whitelist_categories=('Lu', 'Nd')),
        min_size=10,
        max_size=20
    )
)


@given(
    num_sub_agents=st.integers(min_value=1, max_value=10),
    sub_agent_arns=st.lists(
        agent_arn_strategy,
        min_size=1,
        max_size=10
    )
)
@settings(max_examples=100, deadline=None)
def test_arn_propagation_to_orchestration_env(
    num_sub_agents: int,
    sub_agent_arns: list
):
    """
    Property 4: ARN Propagation Consistency
    
    For any deployed sub-agent, its ARN must be captured and made available
    to the orchestration agent's environment variables.
    
    This test generates random sub-agent ARNs, updates the orchestration
    agent's .env file, and verifies that all ARNs are present with correct
    environment variable names.
    
    **Validates: Requirements 7.1, 7.2, 7.3, 7.5**
    """
    # Ensure we have the right number of ARNs
    if len(sub_agent_arns) < num_sub_agents:
        sub_agent_arns = sub_agent_arns * ((num_sub_agents // len(sub_agent_arns)) + 1)
    sub_agent_arns = sub_agent_arns[:num_sub_agents]
    
    # Generate sub-agent names
    sub_agent_names = [f"sub-agent-{i}" for i in range(num_sub_agents)]
    
    # Create mapping of agent names to ARNs
    sub_agent_arn_map = dict(zip(sub_agent_names, sub_agent_arns))
    
    # Create temporary directory for orchestration agent
    with tempfile.TemporaryDirectory() as temp_dir:
        orchestration_dir = Path(temp_dir) / "orchestration-agent"
        orchestration_dir.mkdir()
        
        # Create orchestration agent config
        orchestration_agent = AgentConfig(
            name="orchestration-agent",
            directory=str(orchestration_dir),
            entrypoint="orchestration.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=sub_agent_names,
            environment_variables={}
        )
        
        # Create deployment config
        config = DeploymentConfig(
            aws_account_id="123456789012",
            aws_region="us-east-1",
            agents=[orchestration_agent],
            iam_policies=IAMPolicyConfig(
                base_policy={},
                cross_agent_policy_template={}
            ),
            deployment_order=[]
        )
        
        # Import here to avoid circular dependencies
        from managers.deployment_orchestrator import AgentDeploymentOrchestrator
        from unittest.mock import Mock
        
        # Create mock managers
        mock_iam_manager = Mock()
        mock_s3_manager = Mock()
        mock_state_manager = Mock()
        
        # Create orchestrator
        orchestrator = AgentDeploymentOrchestrator(
            config=config,
            iam_manager=mock_iam_manager,
            s3_manager=mock_s3_manager,
            state_manager=mock_state_manager
        )
        
        # Update orchestration .env file with sub-agent ARNs
        orchestrator.update_orchestration_env(
            orchestration_agent_name="orchestration-agent",
            sub_agent_arns=sub_agent_arn_map
        )
        
        # Read .env file
        env_file_path = orchestration_dir / ".env"
        assert env_file_path.exists(), ".env file was not created"
        
        env_vars = {}
        with open(env_file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env_vars[key.strip()] = value.strip()
        
        # Verify property: All sub-agent ARNs are present in .env file
        for agent_name, agent_arn in sub_agent_arn_map.items():
            # Convert agent name to environment variable format
            env_var_name = agent_name.upper().replace('-', '_') + '_ARN'
            
            assert env_var_name in env_vars, \
                f"Environment variable '{env_var_name}' not found in .env file"
            
            assert env_vars[env_var_name] == agent_arn, \
                f"Expected ARN '{agent_arn}' for '{env_var_name}', got '{env_vars[env_var_name]}'"


@given(
    num_sub_agents=st.integers(min_value=1, max_value=8),
    existing_env_vars=st.dictionaries(
        keys=st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Nd'), whitelist_characters='_'),
            min_size=3,
            max_size=20
        ),
        values=st.text(
            alphabet=st.characters(whitelist_categories=('Ll', 'Lu', 'Nd'), whitelist_characters='_-./'),
            min_size=1,
            max_size=50
        ),
        min_size=0,
        max_size=5
    )
)
@settings(max_examples=100, deadline=None)
def test_arn_propagation_preserves_existing_env_vars(
    num_sub_agents: int,
    existing_env_vars: Dict[str, str]
):
    """
    Property 4: ARN Propagation Consistency (Preservation)
    
    When updating the orchestration agent's .env file with sub-agent ARNs,
    existing environment variables must be preserved.
    
    This test creates an .env file with existing variables, updates it with
    sub-agent ARNs, and verifies that all existing variables are still present.
    
    **Validates: Requirements 7.3, 7.5**
    """
    # Generate sub-agent names and ARNs
    sub_agent_names = [f"sub-agent-{i}" for i in range(num_sub_agents)]
    sub_agent_arns = [
        f"arn:aws:bedrock:us-east-1:123456789012:agent/AGENT{i:010d}"
        for i in range(num_sub_agents)
    ]
    sub_agent_arn_map = dict(zip(sub_agent_names, sub_agent_arns))
    
    # Create temporary directory for orchestration agent
    with tempfile.TemporaryDirectory() as temp_dir:
        orchestration_dir = Path(temp_dir) / "orchestration-agent"
        orchestration_dir.mkdir()
        
        # Create .env file with existing variables
        env_file_path = orchestration_dir / ".env"
        with open(env_file_path, 'w') as f:
            for key, value in existing_env_vars.items():
                f.write(f"{key}={value}\n")
        
        # Create orchestration agent config
        orchestration_agent = AgentConfig(
            name="orchestration-agent",
            directory=str(orchestration_dir),
            entrypoint="orchestration.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=sub_agent_names,
            environment_variables={}
        )
        
        # Create deployment config
        config = DeploymentConfig(
            aws_account_id="123456789012",
            aws_region="us-east-1",
            agents=[orchestration_agent],
            iam_policies=IAMPolicyConfig(
                base_policy={},
                cross_agent_policy_template={}
            ),
            deployment_order=[]
        )
        
        # Import here to avoid circular dependencies
        from managers.deployment_orchestrator import AgentDeploymentOrchestrator
        from unittest.mock import Mock
        
        # Create mock managers
        mock_iam_manager = Mock()
        mock_s3_manager = Mock()
        mock_state_manager = Mock()
        
        # Create orchestrator
        orchestrator = AgentDeploymentOrchestrator(
            config=config,
            iam_manager=mock_iam_manager,
            s3_manager=mock_s3_manager,
            state_manager=mock_state_manager
        )
        
        # Update orchestration .env file with sub-agent ARNs
        orchestrator.update_orchestration_env(
            orchestration_agent_name="orchestration-agent",
            sub_agent_arns=sub_agent_arn_map
        )
        
        # Read updated .env file
        updated_env_vars = {}
        with open(env_file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    updated_env_vars[key.strip()] = value.strip()
        
        # Verify property: All existing environment variables are preserved
        for key, value in existing_env_vars.items():
            assert key in updated_env_vars, \
                f"Existing environment variable '{key}' was not preserved"
            
            assert updated_env_vars[key] == value, \
                f"Existing environment variable '{key}' value changed from '{value}' to '{updated_env_vars[key]}'"
        
        # Verify property: All sub-agent ARNs are present
        for agent_name, agent_arn in sub_agent_arn_map.items():
            env_var_name = agent_name.upper().replace('-', '_') + '_ARN'
            
            assert env_var_name in updated_env_vars, \
                f"Sub-agent ARN environment variable '{env_var_name}' not found"
            
            assert updated_env_vars[env_var_name] == agent_arn, \
                f"Sub-agent ARN mismatch for '{env_var_name}'"


@given(
    agent_name=st.text(
        alphabet=st.characters(whitelist_categories=('Ll', 'Nd'), whitelist_characters='-'),
        min_size=5,
        max_size=30
    ).filter(lambda x: x and not x.startswith('-') and not x.endswith('-'))
)
@settings(max_examples=100, deadline=None)
def test_arn_env_var_naming_convention(agent_name: str):
    """
    Property 4: ARN Propagation Consistency (Naming Convention)
    
    The environment variable name for a sub-agent ARN must follow the pattern:
    {AGENT_NAME}_ARN where AGENT_NAME is the agent name in uppercase with
    hyphens replaced by underscores.
    
    This test generates random agent names and verifies that the environment
    variable names follow the correct naming convention.
    
    **Validates: Requirements 7.4**
    """
    # Generate agent ARN
    agent_arn = f"arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT123"
    
    # Create temporary directory for orchestration agent
    with tempfile.TemporaryDirectory() as temp_dir:
        orchestration_dir = Path(temp_dir) / "orchestration-agent"
        orchestration_dir.mkdir()
        
        # Create orchestration agent config
        orchestration_agent = AgentConfig(
            name="orchestration-agent",
            directory=str(orchestration_dir),
            entrypoint="orchestration.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[agent_name],
            environment_variables={}
        )
        
        # Create deployment config
        config = DeploymentConfig(
            aws_account_id="123456789012",
            aws_region="us-east-1",
            agents=[orchestration_agent],
            iam_policies=IAMPolicyConfig(
                base_policy={},
                cross_agent_policy_template={}
            ),
            deployment_order=[]
        )
        
        # Import here to avoid circular dependencies
        from managers.deployment_orchestrator import AgentDeploymentOrchestrator
        from unittest.mock import Mock
        
        # Create mock managers
        mock_iam_manager = Mock()
        mock_s3_manager = Mock()
        mock_state_manager = Mock()
        
        # Create orchestrator
        orchestrator = AgentDeploymentOrchestrator(
            config=config,
            iam_manager=mock_iam_manager,
            s3_manager=mock_s3_manager,
            state_manager=mock_state_manager
        )
        
        # Update orchestration .env file with sub-agent ARN
        orchestrator.update_orchestration_env(
            orchestration_agent_name="orchestration-agent",
            sub_agent_arns={agent_name: agent_arn}
        )
        
        # Read .env file
        env_file_path = orchestration_dir / ".env"
        env_vars = {}
        with open(env_file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env_vars[key.strip()] = value.strip()
        
        # Verify property: Environment variable name follows naming convention
        expected_env_var_name = agent_name.upper().replace('-', '_') + '_ARN'
        
        assert expected_env_var_name in env_vars, \
            f"Expected environment variable '{expected_env_var_name}' not found. Found: {list(env_vars.keys())}"
        
        assert env_vars[expected_env_var_name] == agent_arn, \
            f"Expected ARN '{agent_arn}', got '{env_vars[expected_env_var_name]}'"


if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v"])
