"""
Property-Based Test: Resource Existence Check Before Creation

Property 9: Resource Existence Check Before Creation
For any AWS resource (IAM role, S3 bucket), the system must check for 
existence before attempting creation.

This test validates Requirements 9.2, 9.3, 2.9:
- 9.2: Check existing resources before creating new ones
- 9.3: Skip creation if resource exists with matching configuration
- 2.9: Update policies if execution role already exists

Test Strategy:
- Generate various resource names and configurations
- Verify that existence checks are performed before creation attempts
- Verify that existing resources are detected and handled appropriately
- Verify that creation is skipped when resources already exist

Minimum 100 iterations per property test.
"""

import pytest
from hypothesis import given, strategies as st, settings, HealthCheck
from unittest.mock import Mock, patch, call
from botocore.exceptions import ClientError

from deployment_tool.managers.aws_resource_manager import AWSResourceManager


# Strategy for generating resource names
resource_names = st.text(
    alphabet=st.characters(
        whitelist_categories=('Lu', 'Ll', 'Nd'),
        blacklist_characters='-_'
    ),
    min_size=5,
    max_size=20
).map(lambda s: s if s else 'TestResource')

# Strategy for generating AWS regions
aws_regions = st.sampled_from([
    'us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1'
])

# Strategy for resource existence scenarios
existence_scenarios = st.sampled_from([
    'does_not_exist',
    'exists_same_config',
    'exists_different_config'
])


@given(
    region=aws_regions,
    role_name=resource_names,
    scenario=existence_scenarios
)
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture]
)
def test_property_iam_role_existence_checked_before_creation(region, role_name, scenario):
    """
    Property: IAM role existence must be checked before creation attempts.
    
    For any IAM role operation, role_exists() must be called before any
    creation or modification operations are attempted.
    
    **Validates: Requirements 9.2, 9.3, 2.9**
    """
    with patch('deployment_tool.managers.aws_resource_manager.boto3.Session') as mock_session_class:
        # Setup mock session
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Setup mock IAM client
        mock_iam = Mock()
        
        def client_factory(service_name):
            if service_name == 'iam':
                return mock_iam
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Configure mock based on scenario
        if scenario == 'does_not_exist':
            # Role doesn't exist
            mock_iam.get_role.side_effect = ClientError(
                {
                    'Error': {
                        'Code': 'NoSuchEntity',
                        'Message': 'Role not found'
                    }
                },
                'GetRole'
            )
            
            # Create manager
            manager = AWSResourceManager(region=region)
            
            # Check if role exists
            exists = manager.iam_manager.role_exists(role_name)
            
            # Verify existence check was performed
            mock_iam.get_role.assert_called_once_with(RoleName=role_name)
            
            # Verify result
            assert exists is False
            
        elif scenario == 'exists_same_config':
            # Role exists
            mock_iam.get_role.return_value = {
                'Role': {
                    'RoleName': role_name,
                    'Arn': f'arn:aws:iam::123456789012:role/{role_name}'
                }
            }
            
            # Create manager
            manager = AWSResourceManager(region=region)
            
            # Check if role exists
            exists = manager.iam_manager.role_exists(role_name)
            
            # Verify existence check was performed
            mock_iam.get_role.assert_called_once_with(RoleName=role_name)
            
            # Verify result
            assert exists is True
            
        elif scenario == 'exists_different_config':
            # Role exists with different config
            mock_iam.get_role.return_value = {
                'Role': {
                    'RoleName': role_name,
                    'Arn': f'arn:aws:iam::123456789012:role/{role_name}'
                }
            }
            
            # Create manager
            manager = AWSResourceManager(region=region)
            
            # Check if role exists
            exists = manager.iam_manager.role_exists(role_name)
            
            # Verify existence check was performed first
            mock_iam.get_role.assert_called_once_with(RoleName=role_name)
            
            # Verify result
            assert exists is True


@given(
    region=aws_regions,
    bucket_name=st.text(
        alphabet=st.characters(whitelist_categories=('Ll', 'Nd'), blacklist_characters='-'),
        min_size=3,
        max_size=20
    ).map(lambda s: s if s else 'testbucket'),
    scenario=existence_scenarios
)
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture]
)
def test_property_s3_bucket_existence_checked_before_creation(region, bucket_name, scenario):
    """
    Property: S3 bucket existence must be checked before creation attempts.
    
    For any S3 bucket operation, bucket_exists() must be called before any
    creation or modification operations are attempted.
    
    **Validates: Requirements 9.2, 9.3**
    """
    with patch('deployment_tool.managers.aws_resource_manager.boto3.Session') as mock_session_class:
        # Setup mock session
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Setup mock S3 client
        mock_s3 = Mock()
        
        def client_factory(service_name):
            if service_name == 's3':
                return mock_s3
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Configure mock based on scenario
        if scenario == 'does_not_exist':
            # Bucket doesn't exist
            mock_s3.head_bucket.side_effect = ClientError(
                {
                    'Error': {
                        'Code': '404',
                        'Message': 'Not Found'
                    }
                },
                'HeadBucket'
            )
            
            # Create manager
            manager = AWSResourceManager(region=region)
            
            # Check if bucket exists
            exists = manager.s3_manager.bucket_exists(bucket_name)
            
            # Verify existence check was performed
            mock_s3.head_bucket.assert_called_once_with(Bucket=bucket_name)
            
            # Verify result
            assert exists is False
            
        elif scenario == 'exists_same_config':
            # Bucket exists
            mock_s3.head_bucket.return_value = {}
            
            # Create manager
            manager = AWSResourceManager(region=region)
            
            # Check if bucket exists
            exists = manager.s3_manager.bucket_exists(bucket_name)
            
            # Verify existence check was performed
            mock_s3.head_bucket.assert_called_once_with(Bucket=bucket_name)
            
            # Verify result
            assert exists is True
            
        elif scenario == 'exists_different_config':
            # Bucket exists
            mock_s3.head_bucket.return_value = {}
            
            # Create manager
            manager = AWSResourceManager(region=region)
            
            # Check if bucket exists
            exists = manager.s3_manager.bucket_exists(bucket_name)
            
            # Verify existence check was performed
            mock_s3.head_bucket.assert_called_once_with(Bucket=bucket_name)
            
            # Verify result
            assert exists is True


@given(
    region=aws_regions,
    role_name=resource_names
)
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture]
)
def test_property_existence_check_precedes_all_operations(region, role_name):
    """
    Property: Existence checks must always precede resource operations.
    
    For any resource operation sequence, the existence check must be the
    first operation performed, before any creation or modification attempts.
    
    **Validates: Requirements 9.2, 9.3**
    """
    with patch('deployment_tool.managers.aws_resource_manager.boto3.Session') as mock_session_class:
        # Setup mock session
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Setup mock IAM client with call tracking
        mock_iam = Mock()
        call_order = []
        
        def track_get_role(*args, **kwargs):
            call_order.append('get_role')
            raise ClientError(
                {'Error': {'Code': 'NoSuchEntity', 'Message': 'Not found'}},
                'GetRole'
            )
        
        def track_create_role(*args, **kwargs):
            call_order.append('create_role')
            return {'Role': {'Arn': f'arn:aws:iam::123456789012:role/{role_name}'}}
        
        def track_put_role_policy(*args, **kwargs):
            call_order.append('put_role_policy')
            return {}
        
        mock_iam.get_role.side_effect = track_get_role
        mock_iam.create_role.side_effect = track_create_role
        mock_iam.put_role_policy.side_effect = track_put_role_policy
        
        def client_factory(service_name):
            if service_name == 'iam':
                return mock_iam
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Create manager
        manager = AWSResourceManager(region=region)
        
        # Check if role exists (this should be first operation)
        exists = manager.iam_manager.role_exists(role_name)
        
        # Verify get_role was called first
        assert len(call_order) == 1
        assert call_order[0] == 'get_role'
        assert exists is False
        
        # Now if we were to create the role, get_role should have been called first
        # (In actual usage, the orchestrator would check existence before creating)


@given(
    region=aws_regions,
    bucket_name=st.text(
        alphabet=st.characters(whitelist_categories=('Ll', 'Nd'), blacklist_characters='-'),
        min_size=3,
        max_size=20
    ).map(lambda s: s if s else 'testbucket')
)
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture]
)
def test_property_bucket_creation_skipped_when_exists(region, bucket_name):
    """
    Property: Bucket creation must be skipped when bucket already exists.
    
    For any bucket that already exists, the create_vector_bucket operation
    should detect the existing bucket and return successfully without
    attempting to create a duplicate.
    
    **Validates: Requirements 9.2, 9.3**
    """
    with patch('deployment_tool.managers.aws_resource_manager.boto3.Session') as mock_session_class:
        # Setup mock session
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Setup mock S3 client
        mock_s3 = Mock()
        
        # Bucket already exists and we own it
        mock_s3.create_bucket.side_effect = ClientError(
            {
                'Error': {
                    'Code': 'BucketAlreadyOwnedByYou',
                    'Message': 'Your previous request to create the named bucket succeeded'
                }
            },
            'CreateBucket'
        )
        
        def client_factory(service_name):
            if service_name == 's3':
                return mock_s3
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Create manager
        manager = AWSResourceManager(region=region)
        
        # Attempt to create bucket (should handle existing bucket gracefully)
        result = manager.s3_manager.create_vector_bucket(bucket_name, region)
        
        # Verify creation was attempted
        mock_s3.create_bucket.assert_called_once()
        
        # Verify result is the bucket name (operation succeeded)
        assert result == bucket_name
