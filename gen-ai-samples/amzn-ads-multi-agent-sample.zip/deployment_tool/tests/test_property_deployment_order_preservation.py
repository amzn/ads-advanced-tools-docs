"""
Property-Based Test: Deployment Order Preservation

This test validates Property 3: For any set of agents with dependencies,
the deployment order must ensure that all sub-agents are deployed before
the orchestration agent.

Validates Requirements: 6.1, 6.2, 6.5

Tag: Feature: agentcore-automated-deployment, Property 3: Deployment order preservation
"""

import pytest
from hypothesis import given, strategies as st, settings
from typing import List, Dict
import sys
import os

# Add parent directory to path for imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import AgentConfig, DeploymentConfig, IAMPolicyConfig


# Strategy for generating agent names
agent_name_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Ll', 'Lu', 'Nd'), whitelist_characters='-'),
    min_size=5,
    max_size=30
).filter(lambda x: x and not x.startswith('-') and not x.endswith('-'))


# Strategy for generating agent configurations
def agent_config_strategy(name: str, dependencies: List[str] = None) -> st.SearchStrategy:
    """Generate an AgentConfig with the given name and dependencies."""
    return st.builds(
        AgentConfig,
        name=st.just(name),
        directory=st.just(f"/fake/path/{name}"),
        entrypoint=st.just("agent.py"),
        language=st.just("python"),
        platform=st.just("linux/arm64"),
        memory_mode=st.sampled_from(["STM_ONLY", "DISABLED"]),
        server_protocol=st.sampled_from(["HTTP", "A2A", "MCP"]),
        dependencies=st.just(dependencies or []),
        environment_variables=st.just({})
    )


@given(
    num_sub_agents=st.integers(min_value=1, max_value=10),
    orchestration_agent_name=agent_name_strategy
)
@settings(max_examples=100, deadline=None)
def test_deployment_order_sub_agents_before_orchestration(
    num_sub_agents: int,
    orchestration_agent_name: str
):
    """
    Property 3: Deployment Order Preservation
    
    For any set of agents with dependencies, the deployment order must ensure
    that all sub-agents are deployed before the orchestration agent.
    
    This test generates random agent configurations with an orchestration agent
    that depends on all sub-agents, then verifies that the deployment order
    places all sub-agents before the orchestration agent.
    
    **Validates: Requirements 6.1, 6.2, 6.5**
    """
    # Generate unique sub-agent names
    sub_agent_names = [f"sub-agent-{i}" for i in range(num_sub_agents)]
    
    # Ensure orchestration agent name is unique
    if orchestration_agent_name in sub_agent_names:
        orchestration_agent_name = f"orchestration-{orchestration_agent_name}"
    
    # Create sub-agent configs (no dependencies)
    sub_agents = []
    for name in sub_agent_names:
        config = AgentConfig(
            name=name,
            directory=f"/fake/path/{name}",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        sub_agents.append(config)
    
    # Create orchestration agent config (depends on all sub-agents)
    orchestration_agent = AgentConfig(
        name=orchestration_agent_name,
        directory=f"/fake/path/{orchestration_agent_name}",
        entrypoint="orchestration.py",
        language="python",
        platform="linux/arm64",
        memory_mode="STM_ONLY",
        server_protocol="A2A",
        dependencies=sub_agent_names,
        environment_variables={}
    )
    
    # Create deployment config with explicit deployment order
    deployment_order = sub_agent_names + [orchestration_agent_name]
    
    config = DeploymentConfig(
        aws_account_id="123456789012",
        aws_region="us-east-1",
        agents=sub_agents + [orchestration_agent],
        iam_policies=IAMPolicyConfig(
            base_policy={},
            cross_agent_policy_template={}
        ),
        deployment_order=deployment_order
    )
    
    # Import here to avoid circular dependencies
    from managers.deployment_orchestrator import AgentDeploymentOrchestrator
    from unittest.mock import Mock
    
    # Create mock managers
    mock_iam_manager = Mock()
    mock_s3_manager = Mock()
    mock_state_manager = Mock()
    
    # Create orchestrator
    orchestrator = AgentDeploymentOrchestrator(
        config=config,
        iam_manager=mock_iam_manager,
        s3_manager=mock_s3_manager,
        state_manager=mock_state_manager
    )
    
    # Get agents in deployment order
    ordered_agents = orchestrator._get_agents_in_order()
    
    # Verify property: All sub-agents must come before orchestration agent
    orchestration_index = None
    sub_agent_indices = []
    
    for i, agent in enumerate(ordered_agents):
        if agent.name == orchestration_agent_name:
            orchestration_index = i
        elif agent.name in sub_agent_names:
            sub_agent_indices.append(i)
    
    # Assert orchestration agent is in the list
    assert orchestration_index is not None, \
        f"Orchestration agent '{orchestration_agent_name}' not found in deployment order"
    
    # Assert all sub-agents are in the list
    assert len(sub_agent_indices) == num_sub_agents, \
        f"Expected {num_sub_agents} sub-agents, found {len(sub_agent_indices)}"
    
    # Assert all sub-agents come before orchestration agent
    for sub_index in sub_agent_indices:
        assert sub_index < orchestration_index, \
            f"Sub-agent at index {sub_index} comes after orchestration agent at index {orchestration_index}"


@given(
    num_agents=st.integers(min_value=2, max_value=8)
)
@settings(max_examples=100, deadline=None)
def test_deployment_order_respects_explicit_order(num_agents: int):
    """
    Property 3: Deployment Order Preservation (Explicit Order)
    
    When an explicit deployment order is specified in the configuration,
    the orchestrator must respect that order exactly.
    
    This test generates random agent configurations with an explicit deployment
    order, then verifies that the orchestrator returns agents in that exact order.
    
    **Validates: Requirements 6.1, 6.2**
    """
    # Generate unique agent names
    agent_names = [f"agent-{i}" for i in range(num_agents)]
    
    # Create agent configs
    agents = []
    for name in agent_names:
        config = AgentConfig(
            name=name,
            directory=f"/fake/path/{name}",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        agents.append(config)
    
    # Create deployment config with explicit deployment order
    deployment_order = agent_names.copy()
    
    config = DeploymentConfig(
        aws_account_id="123456789012",
        aws_region="us-east-1",
        agents=agents,
        iam_policies=IAMPolicyConfig(
            base_policy={},
            cross_agent_policy_template={}
        ),
        deployment_order=deployment_order
    )
    
    # Import here to avoid circular dependencies
    from managers.deployment_orchestrator import AgentDeploymentOrchestrator
    from unittest.mock import Mock
    
    # Create mock managers
    mock_iam_manager = Mock()
    mock_s3_manager = Mock()
    mock_state_manager = Mock()
    
    # Create orchestrator
    orchestrator = AgentDeploymentOrchestrator(
        config=config,
        iam_manager=mock_iam_manager,
        s3_manager=mock_s3_manager,
        state_manager=mock_state_manager
    )
    
    # Get agents in deployment order
    ordered_agents = orchestrator._get_agents_in_order()
    
    # Verify property: Agents are in the exact order specified
    actual_order = [agent.name for agent in ordered_agents]
    
    assert actual_order == deployment_order, \
        f"Expected order {deployment_order}, got {actual_order}"


@given(
    num_no_deps=st.integers(min_value=1, max_value=5),
    num_with_deps=st.integers(min_value=1, max_value=5)
)
@settings(max_examples=100, deadline=None)
def test_deployment_order_no_deps_before_with_deps(
    num_no_deps: int,
    num_with_deps: int
):
    """
    Property 3: Deployment Order Preservation (Dependency-Based)
    
    When no explicit deployment order is specified, agents with no dependencies
    should be deployed before agents with dependencies.
    
    This test generates random agent configurations with some having dependencies
    and some not, then verifies that agents without dependencies come first.
    
    **Validates: Requirements 6.1, 6.2**
    """
    # Generate agent names
    no_dep_names = [f"no-dep-{i}" for i in range(num_no_deps)]
    with_dep_names = [f"with-dep-{i}" for i in range(num_with_deps)]
    
    # Create agents without dependencies
    no_dep_agents = []
    for name in no_dep_names:
        config = AgentConfig(
            name=name,
            directory=f"/fake/path/{name}",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        no_dep_agents.append(config)
    
    # Create agents with dependencies (depend on first no-dep agent)
    with_dep_agents = []
    for name in with_dep_names:
        config = AgentConfig(
            name=name,
            directory=f"/fake/path/{name}",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[no_dep_names[0]],  # Depend on first no-dep agent
            environment_variables={}
        )
        with_dep_agents.append(config)
    
    # Create deployment config WITHOUT explicit deployment order
    config = DeploymentConfig(
        aws_account_id="123456789012",
        aws_region="us-east-1",
        agents=no_dep_agents + with_dep_agents,
        iam_policies=IAMPolicyConfig(
            base_policy={},
            cross_agent_policy_template={}
        ),
        deployment_order=[]  # Empty order - use dependency-based ordering
    )
    
    # Import here to avoid circular dependencies
    from managers.deployment_orchestrator import AgentDeploymentOrchestrator
    from unittest.mock import Mock
    
    # Create mock managers
    mock_iam_manager = Mock()
    mock_s3_manager = Mock()
    mock_state_manager = Mock()
    
    # Create orchestrator
    orchestrator = AgentDeploymentOrchestrator(
        config=config,
        iam_manager=mock_iam_manager,
        s3_manager=mock_s3_manager,
        state_manager=mock_state_manager
    )
    
    # Get agents in deployment order
    ordered_agents = orchestrator._get_agents_in_order()
    
    # Verify property: All no-dep agents come before with-dep agents
    no_dep_indices = []
    with_dep_indices = []
    
    for i, agent in enumerate(ordered_agents):
        if agent.name in no_dep_names:
            no_dep_indices.append(i)
        elif agent.name in with_dep_names:
            with_dep_indices.append(i)
    
    # Assert all agents are present
    assert len(no_dep_indices) == num_no_deps
    assert len(with_dep_indices) == num_with_deps
    
    # Assert all no-dep agents come before all with-dep agents
    max_no_dep_index = max(no_dep_indices) if no_dep_indices else -1
    min_with_dep_index = min(with_dep_indices) if with_dep_indices else float('inf')
    
    assert max_no_dep_index < min_with_dep_index, \
        f"Agents with dependencies should come after agents without dependencies"


if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v"])
