"""
Property-Based Test: Error Message Specificity

This test validates Property 12: For any deployment error, the error message
must include the agent name, the operation that failed, and the underlying
AWS error details.

Validates: Requirements 10.1, 10.2

Feature: agentcore-automated-deployment
Property 12: Error Message Specificity
"""

import pytest
from hypothesis import given, strategies as st, settings
from typing import Dict, Any
import re

from deployment_tool.models.data_models import AgentDeploymentResult


# Strategy for generating agent names
agent_name_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Ll', 'Lu', 'Nd'), whitelist_characters='-_'),
    min_size=5,
    max_size=30
).filter(lambda x: x and x[0].isalpha())


# Strategy for generating operation names
operation_strategy = st.sampled_from([
    'configure',
    'deploy',
    'install_dependencies',
    'attach_policy',
    'create_role',
    'create_bucket',
    'parse_output',
    'validate_credentials'
])


# Strategy for generating AWS error codes
aws_error_code_strategy = st.sampled_from([
    'AccessDenied',
    'InvalidClientTokenId',
    'SignatureDoesNotMatch',
    'ResourceNotFoundException',
    'LimitExceededException',
    'ThrottlingException',
    'ServiceUnavailable',
    'InternalError'
])


# Strategy for generating AWS error messages
aws_error_message_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('Ll', 'Lu', 'Nd', 'P'), whitelist_characters=' '),
    min_size=10,
    max_size=100
)


@st.composite
def error_context_strategy(draw):
    """Generate error context with agent name, operation, and AWS error details."""
    agent_name = draw(agent_name_strategy)
    operation = draw(operation_strategy)
    aws_error_code = draw(aws_error_code_strategy)
    aws_error_message = draw(aws_error_message_strategy)
    
    return {
        'agent_name': agent_name,
        'operation': operation,
        'aws_error_code': aws_error_code,
        'aws_error_message': aws_error_message
    }


def create_error_message(context: Dict[str, Any]) -> str:
    """Create an error message from context.
    
    This simulates how the deployment system should format error messages.
    """
    return (
        f"{context['operation']} failed: "
        f"{context['aws_error_code']} - {context['aws_error_message']}"
    )


@given(error_context=error_context_strategy())
@settings(max_examples=100, deadline=None)
def test_property_error_message_contains_agent_name(error_context: Dict[str, Any]):
    """
    Property 12a: Error messages must contain the agent name.
    
    For any deployment error, the error message or the result object must
    clearly identify which agent encountered the error.
    
    Validates: Requirements 10.1, 10.2
    """
    agent_name = error_context['agent_name']
    error_message = create_error_message(error_context)
    
    # Create deployment result
    result = AgentDeploymentResult(
        success=False,
        agent_name=agent_name,
        error_message=error_message
    )
    
    # Property: Agent name must be present in the result
    assert result.agent_name == agent_name, \
        f"Result must contain agent name {agent_name}"
    
    # Property: Agent name must not be empty
    assert result.agent_name and len(result.agent_name) > 0, \
        "Agent name must not be empty"


@given(error_context=error_context_strategy())
@settings(max_examples=100, deadline=None)
def test_property_error_message_contains_operation(error_context: Dict[str, Any]):
    """
    Property 12b: Error messages must contain the operation that failed.
    
    For any deployment error, the error message must clearly indicate which
    operation was being performed when the error occurred.
    
    Validates: Requirements 10.1, 10.2
    """
    operation = error_context['operation']
    error_message = create_error_message(error_context)
    
    # Property: Error message must contain the operation name
    assert operation in error_message, \
        f"Error message must contain operation '{operation}': {error_message}"
    
    # Property: Error message must not be empty
    assert error_message and len(error_message) > 0, \
        "Error message must not be empty"


@given(error_context=error_context_strategy())
@settings(max_examples=100, deadline=None)
def test_property_error_message_contains_aws_error_code(error_context: Dict[str, Any]):
    """
    Property 12c: Error messages must contain AWS error code.
    
    For any AWS API error, the error message must include the specific
    AWS error code (e.g., AccessDenied, InvalidClientTokenId).
    
    Validates: Requirements 10.1, 10.2
    """
    aws_error_code = error_context['aws_error_code']
    error_message = create_error_message(error_context)
    
    # Property: Error message must contain the AWS error code
    assert aws_error_code in error_message, \
        f"Error message must contain AWS error code '{aws_error_code}': {error_message}"


@given(error_context=error_context_strategy())
@settings(max_examples=100, deadline=None)
def test_property_error_message_contains_aws_error_message(error_context: Dict[str, Any]):
    """
    Property 12d: Error messages must contain AWS error message.
    
    For any AWS API error, the error message must include the detailed
    error message from AWS explaining what went wrong.
    
    Validates: Requirements 10.1, 10.2
    """
    aws_error_message = error_context['aws_error_message']
    error_message = create_error_message(error_context)
    
    # Property: Error message must contain the AWS error message
    assert aws_error_message in error_message, \
        f"Error message must contain AWS error message '{aws_error_message}': {error_message}"


@given(error_context=error_context_strategy())
@settings(max_examples=100, deadline=None)
def test_property_error_message_complete_context(error_context: Dict[str, Any]):
    """
    Property 12e: Error messages must provide complete context.
    
    For any deployment error, the complete error context (agent name,
    operation, AWS error code, and AWS error message) must be available
    either in the error message or the result object.
    
    Validates: Requirements 10.1, 10.2
    """
    agent_name = error_context['agent_name']
    operation = error_context['operation']
    aws_error_code = error_context['aws_error_code']
    aws_error_message = error_context['aws_error_message']
    
    error_message = create_error_message(error_context)
    
    result = AgentDeploymentResult(
        success=False,
        agent_name=agent_name,
        error_message=error_message
    )
    
    # Property: Result must indicate failure
    assert not result.success, "Result must indicate failure"
    
    # Property: Agent name must be in result
    assert result.agent_name == agent_name, \
        f"Result must contain agent name {agent_name}"
    
    # Property: Error message must contain operation
    assert operation in result.error_message, \
        f"Error message must contain operation '{operation}'"
    
    # Property: Error message must contain AWS error code
    assert aws_error_code in result.error_message, \
        f"Error message must contain AWS error code '{aws_error_code}'"
    
    # Property: Error message must contain AWS error message
    assert aws_error_message in result.error_message, \
        f"Error message must contain AWS error message"
    
    # Property: All required context elements must be present
    has_agent = result.agent_name is not None and len(result.agent_name) > 0
    has_operation = operation in result.error_message
    has_error_code = aws_error_code in result.error_message
    has_error_message = aws_error_message in result.error_message
    
    assert has_agent and has_operation and has_error_code and has_error_message, \
        "Error context must include agent name, operation, error code, and error message"


@given(error_context=error_context_strategy())
@settings(max_examples=100, deadline=None)
def test_property_error_message_format_consistency(error_context: Dict[str, Any]):
    """
    Property 12f: Error messages must follow consistent format.
    
    For any deployment error, the error message should follow a consistent
    format that makes it easy to parse and understand.
    
    Expected format: "{operation} failed: {error_code} - {error_message}"
    
    Validates: Requirements 10.1, 10.2
    """
    operation = error_context['operation']
    aws_error_code = error_context['aws_error_code']
    error_message = create_error_message(error_context)
    
    # Property: Error message should contain "failed" keyword
    assert 'failed' in error_message.lower(), \
        "Error message should indicate failure"
    
    # Property: Error message should have operation before error code
    operation_pos = error_message.find(operation)
    error_code_pos = error_message.find(aws_error_code)
    
    assert operation_pos < error_code_pos, \
        "Operation should appear before error code in message"
    
    # Property: Error message should use separator between code and message
    # Common separators: " - ", ": ", " | "
    has_separator = ' - ' in error_message or ': ' in error_message or ' | ' in error_message
    assert has_separator, \
        "Error message should use separator between error code and message"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
