"""
Unit tests for AgentCore Integration.

**Validates: Requirements 5.1, 5.2, 5.3, 5.4, 12.1**

This module tests the AgentCoreIntegration class which interfaces with
AWS Bedrock AgentCore SDK for agent configuration and deployment.
"""

import os
import tempfile
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch, call
import pytest

from deployment_tool.managers.agentcore_integration import AgentCoreIntegration


class TestAgentCoreIntegration:
    """Unit tests for AgentCoreIntegration class."""
    
    def test_init_with_valid_directory(self):
        """Test initialization with a valid agent directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            integration = AgentCoreIntegration(temp_dir)
            assert integration.agent_directory == Path(temp_dir)
    
    def test_init_with_invalid_directory_raises_error(self):
        """Test initialization with non-existent directory raises ValueError."""
        with pytest.raises(ValueError, match="Agent directory does not exist"):
            AgentCoreIntegration("/nonexistent/directory")
    
    def test_run_configure_with_minimal_parameters(self):
        """Test run_configure with only required parameters."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Configuration successful"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent"
                )
                
                # Verify subprocess was called
                assert mock_run.called
                call_args = mock_run.call_args[0][0]
                
                # Verify required flags
                assert "agentcore" in call_args
                assert "configure" in call_args
                assert "--entrypoint" in call_args
                assert "agent.py" in call_args
                assert "--name" in call_args
                assert "test-agent" in call_args
                assert "--protocol" in call_args
                assert "HTTP" in call_args  # Default protocol
                assert "--ecr" in call_args
                assert "auto" in call_args
                assert "--deployment-type" in call_args
                assert "container" in call_args
                assert "--non-interactive" in call_args
                
                # Verify result
                assert result.returncode == 0
                assert result.stdout == "Configuration successful"
    
    def test_run_configure_with_all_parameters(self):
        """Test run_configure with all parameters specified."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "langgraph_a2a.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Configuration successful"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.run_configure(
                    entrypoint="langgraph_a2a.py",
                    agent_name="custom-ads-agent",
                    protocol="A2A",
                    enable_memory=True,
                    deployment_type="container",
                    region="us-east-1",
                    non_interactive=True,
                    execution_role_arn="arn:aws:iam::123456789012:role/MyRole"
                )
                
                call_args = mock_run.call_args[0][0]
                
                # Verify all flags are present
                assert "--entrypoint" in call_args
                assert "langgraph_a2a.py" in call_args
                assert "--name" in call_args
                assert "custom-ads-agent" in call_args
                assert "--protocol" in call_args
                assert "A2A" in call_args
                assert "--region" in call_args
                assert "us-east-1" in call_args
                assert "--execution-role" in call_args
                assert "arn:aws:iam::123456789012:role/MyRole" in call_args
                assert "--non-interactive" in call_args
                
                # Memory is enabled, so --disable-memory should NOT be present
                assert "--disable-memory" not in call_args
    
    def test_run_configure_with_memory_disabled(self):
        """Test run_configure with memory disabled."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Configuration successful"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent",
                    enable_memory=False
                )
                
                call_args = mock_run.call_args[0][0]
                
                # Verify --disable-memory flag is present
                assert "--disable-memory" in call_args
    
    def test_run_configure_with_mcp_protocol(self):
        """Test run_configure with MCP protocol."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "mcp_server.py").write_text("# MCP Server\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Configuration successful"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.run_configure(
                    entrypoint="mcp_server.py",
                    agent_name="mcp-agent",
                    protocol="MCP"
                )
                
                call_args = mock_run.call_args[0][0]
                
                # Verify MCP protocol
                assert "--protocol" in call_args
                assert "MCP" in call_args
    
    def test_run_configure_failure_raises_error(self):
        """Test run_configure raises error when agentcore configure fails."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                # Simulate command failure
                mock_run.side_effect = subprocess.CalledProcessError(
                    returncode=1,
                    cmd=["agentcore", "configure"],
                    output="Configuration failed",
                    stderr="Error: Invalid configuration"
                )
                
                integration = AgentCoreIntegration(temp_dir)
                
                with pytest.raises(subprocess.CalledProcessError):
                    integration.run_configure(
                        entrypoint="agent.py",
                        agent_name="test-agent"
                    )
    
    def test_run_deploy_success(self):
        """Test run_deploy executes agentcore deploy successfully."""
        with tempfile.TemporaryDirectory() as temp_dir:
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Deployment successful"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.run_deploy()
                
                # Verify subprocess was called with correct command
                assert mock_run.called
                call_args = mock_run.call_args[0][0]
                assert "agentcore" in call_args
                assert "deploy" in call_args
                
                # Verify working directory
                call_kwargs = mock_run.call_args[1]
                assert call_kwargs['cwd'] == Path(temp_dir)
                
                # Verify result
                assert result.returncode == 0
                assert result.stdout == "Deployment successful"
    
    def test_run_deploy_failure_raises_error(self):
        """Test run_deploy raises error when agentcore deploy fails."""
        with tempfile.TemporaryDirectory() as temp_dir:
            with patch('subprocess.run') as mock_run:
                mock_run.side_effect = subprocess.CalledProcessError(
                    returncode=1,
                    cmd=["agentcore", "deploy"],
                    output="Deployment failed",
                    stderr="Error: Build failed"
                )
                
                integration = AgentCoreIntegration(temp_dir)
                
                with pytest.raises(subprocess.CalledProcessError):
                    integration.run_deploy()
    
    def test_parse_deploy_output_with_all_arns(self):
        """Test parse_deploy_output extracts all ARNs from output."""
        with tempfile.TemporaryDirectory() as temp_dir:
            output = """
Deployment successful!

Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/ABCDEFGHIJ
Execution Role ARN: arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-xyz123
Memory ARN: arn:aws:bedrock:us-east-1:123456789012:memory/KLMNOPQRST
ECR Repository: 123456789012.dkr.ecr.us-east-1.amazonaws.com/bedrock-agentcore-test-agent
CodeBuild Project: bedrock-agentcore-test-agent-builder
"""
            
            integration = AgentCoreIntegration(temp_dir)
            result = integration.parse_deploy_output(output)
            
            # Verify all ARNs are extracted
            assert result["agent_arn"] == "arn:aws:bedrock:us-east-1:123456789012:agent/ABCDEFGHIJ"
            assert result["execution_role_arn"] == "arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-xyz123"
            assert result["memory_arn"] == "arn:aws:bedrock:us-east-1:123456789012:memory/KLMNOPQRST"
            assert result["ecr_repository_uri"] == "123456789012.dkr.ecr.us-east-1.amazonaws.com/bedrock-agentcore-test-agent"
            assert result["codebuild_project_name"] == "bedrock-agentcore-test-agent-builder"
    
    def test_parse_deploy_output_without_memory_arn(self):
        """Test parse_deploy_output when memory ARN is not present."""
        with tempfile.TemporaryDirectory() as temp_dir:
            output = """
Deployment successful!

Agent ARN: arn:aws:bedrock:us-west-2:987654321098:agent/ZYXWVUTSRQ
Execution Role ARN: arn:aws:iam::987654321098:role/MyCustomRole
ECR Repository: 987654321098.dkr.ecr.us-west-2.amazonaws.com/bedrock-agentcore-my-agent
CodeBuild Project: bedrock-agentcore-my-agent-builder
"""
            
            integration = AgentCoreIntegration(temp_dir)
            result = integration.parse_deploy_output(output)
            
            # Verify ARNs are extracted
            assert result["agent_arn"] == "arn:aws:bedrock:us-west-2:987654321098:agent/ZYXWVUTSRQ"
            assert result["execution_role_arn"] == "arn:aws:iam::987654321098:role/MyCustomRole"
            assert result["ecr_repository_uri"] == "987654321098.dkr.ecr.us-west-2.amazonaws.com/bedrock-agentcore-my-agent"
            assert result["codebuild_project_name"] == "bedrock-agentcore-my-agent-builder"
            
            # Memory ARN should not be in result
            assert "memory_arn" not in result or result.get("memory_arn") is None
    
    def test_parse_deploy_output_with_empty_output(self):
        """Test parse_deploy_output with empty output returns empty dict."""
        with tempfile.TemporaryDirectory() as temp_dir:
            integration = AgentCoreIntegration(temp_dir)
            result = integration.parse_deploy_output("")
            
            # Should return empty dict or dict with no values
            assert isinstance(result, dict)
            assert len(result) == 0 or all(v is None for v in result.values())
    
    def test_parse_deploy_output_with_partial_output(self):
        """Test parse_deploy_output with partial output extracts available ARNs."""
        with tempfile.TemporaryDirectory() as temp_dir:
            output = """
Deployment in progress...

Agent ARN: arn:aws:bedrock:eu-west-1:111222333444:agent/TESTID1234
"""
            
            integration = AgentCoreIntegration(temp_dir)
            result = integration.parse_deploy_output(output)
            
            # Should extract agent ARN
            assert result["agent_arn"] == "arn:aws:bedrock:eu-west-1:111222333444:agent/TESTID1234"
            
            # Other fields may not be present
            assert "execution_role_arn" not in result or result.get("execution_role_arn") is None
    
    def test_install_dependencies_success(self):
        """Test install_dependencies installs requirements successfully."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create requirements.txt
            requirements_path = temp_path / "requirements.txt"
            requirements_path.write_text("boto3>=1.34.0\npyyaml>=6.0\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Successfully installed boto3 pyyaml"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.install_dependencies()
                
                # Verify success
                assert result is True
                
                # Verify subprocess was called
                assert mock_run.called
                call_args = mock_run.call_args[0][0]
                assert "pip" in call_args
                assert "install" in call_args
                assert "-r" in call_args
                assert "requirements.txt" in call_args
    
    def test_install_dependencies_with_missing_requirements_file(self):
        """Test install_dependencies returns True when requirements.txt is missing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            integration = AgentCoreIntegration(temp_dir)
            result = integration.install_dependencies()
            
            # Should return True (warning only)
            assert result is True
    
    def test_install_dependencies_failure(self):
        """Test install_dependencies returns False when pip install fails."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create requirements.txt
            requirements_path = temp_path / "requirements.txt"
            requirements_path.write_text("nonexistent-package==999.999.999\n")
            
            with patch('subprocess.run') as mock_run:
                mock_run.side_effect = subprocess.CalledProcessError(
                    returncode=1,
                    cmd=["pip", "install", "-r", "requirements.txt"],
                    output="",
                    stderr="ERROR: Could not find a version that satisfies the requirement"
                )
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.install_dependencies()
                
                # Should return False
                assert result is False
    
    def test_run_configure_working_directory(self):
        """Test run_configure executes in correct working directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Success"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent"
                )
                
                # Verify working directory
                call_kwargs = mock_run.call_args[1]
                assert call_kwargs['cwd'] == temp_path
    
    def test_run_configure_captures_output(self):
        """Test run_configure captures stdout and stderr."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Configuration output"
                mock_result.stderr = "Warning: something"
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                result = integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent"
                )
                
                # Verify output capture flags
                call_kwargs = mock_run.call_args[1]
                assert call_kwargs['capture_output'] is True
                assert call_kwargs['text'] is True
                
                # Verify result contains output
                assert result.stdout == "Configuration output"
                assert result.stderr == "Warning: something"
    
    def test_parse_deploy_output_with_various_formats(self):
        """Test parse_deploy_output handles various output formats."""
        with tempfile.TemporaryDirectory() as temp_dir:
            integration = AgentCoreIntegration(temp_dir)
            
            # Test with different formatting
            outputs = [
                # Format 1: Standard output
                """
Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/ABC123
Execution Role: arn:aws:iam::123456789012:role/MyRole
                """,
                # Format 2: With extra text
                """
Deployment completed successfully!
Your agent has been deployed with the following details:
- Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/XYZ789
- Execution Role ARN: arn:aws:iam::123456789012:role/TestRole
                """,
                # Format 3: Compact format
                """
agent_arn=arn:aws:bedrock:us-east-1:123456789012:agent/TEST123
execution_role_arn=arn:aws:iam::123456789012:role/Role123
                """
            ]
            
            for output in outputs:
                result = integration.parse_deploy_output(output)
                
                # Should extract at least agent ARN
                assert "agent_arn" in result
                assert result["agent_arn"] is not None
                assert result["agent_arn"].startswith("arn:aws:bedrock:")


class TestAgentCoreIntegrationEdgeCases:
    """Edge case tests for AgentCoreIntegration."""
    
    def test_configure_with_direct_code_deploy(self):
        """Test configure with direct_code_deploy deployment type."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Success"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent",
                    deployment_type="direct_code_deploy"
                )
                
                call_args = mock_run.call_args[0][0]
                assert "--deployment-type" in call_args
                assert "direct_code_deploy" in call_args
    
    def test_configure_without_region(self):
        """Test configure without specifying region."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Success"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(temp_dir)
                integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent",
                    region=None
                )
                
                call_args = mock_run.call_args[0][0]
                # Region flag should not be present
                assert "--region" not in call_args
    
    def test_parse_deploy_output_with_multiple_agents(self):
        """Test parse_deploy_output extracts first agent ARN when multiple present."""
        with tempfile.TemporaryDirectory() as temp_dir:
            output = """
Agent 1 ARN: arn:aws:bedrock:us-east-1:123456789012:agent/FIRST123
Agent 2 ARN: arn:aws:bedrock:us-east-1:123456789012:agent/SECOND456
            """
            
            integration = AgentCoreIntegration(temp_dir)
            result = integration.parse_deploy_output(output)
            
            # Should extract first agent ARN
            assert result["agent_arn"] == "arn:aws:bedrock:us-east-1:123456789012:agent/FIRST123"
