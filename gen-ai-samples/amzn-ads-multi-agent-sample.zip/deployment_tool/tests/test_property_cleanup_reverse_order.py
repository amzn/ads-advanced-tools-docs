"""
Property-Based Test: Cleanup Reverse Order

This test validates Property 11: For any cleanup operation, agents must be
deleted in reverse deployment order (orchestration agent before sub-agents).

Validates: Requirements 17.2

Feature: agentcore-automated-deployment
Property 11: Cleanup Reverse Order
"""

import pytest
from hypothesis import given, strategies as st, settings
from datetime import datetime
from typing import List

from deployment_tool.models.data_models import (
    DeploymentState,
    AgentDeploymentState
)


# Strategy for generating agent names
agent_names_strategy = st.lists(
    st.text(
        alphabet=st.characters(whitelist_categories=('Ll', 'Lu', 'Nd'), whitelist_characters='-_'),
        min_size=5,
        max_size=20
    ).filter(lambda x: x and x[0].isalpha()),
    min_size=2,
    max_size=10,
    unique=True
)


# Strategy for generating deployment state with multiple agents
@st.composite
def deployment_state_strategy(draw):
    """Generate a deployment state with multiple agents."""
    agent_names = draw(agent_names_strategy)
    
    agents = {}
    for i, name in enumerate(agent_names):
        agents[name] = AgentDeploymentState(
            agent_name=name,
            agent_arn=f"arn:aws:bedrock:us-east-1:123456789012:agent/{name}-{i}",
            execution_role_arn=f"arn:aws:iam::123456789012:role/AgentRole-{name}",
            ecr_repository_uri=f"123456789012.dkr.ecr.us-east-1.amazonaws.com/{name}",
            codebuild_project_name=f"bedrock-agentcore-{name}-builder",
            memory_arn=f"arn:aws:bedrock:us-east-1:123456789012:memory/{name}",
            deployed_at=datetime.now()
        )
    
    return DeploymentState(
        agents=agents,
        last_deployment=datetime.now(),
        deployment_version="1.0.0"
    )


@given(deployment_state=deployment_state_strategy())
@settings(max_examples=100, deadline=None)
def test_property_cleanup_reverse_order(deployment_state: DeploymentState):
    """
    Property 11: Cleanup Reverse Order
    
    For any deployment state with multiple agents, when performing cleanup,
    the agents must be deleted in reverse order of their appearance in the
    deployment state.
    
    This ensures that:
    1. Orchestration agents (typically deployed last) are deleted first
    2. Sub-agents (typically deployed first) are deleted last
    3. Dependencies are respected during cleanup
    
    Validates: Requirements 17.2
    """
    # Get original deployment order (order in which agents appear in state)
    original_order = list(deployment_state.agents.keys())
    
    # Simulate cleanup by reversing the order
    cleanup_order = list(reversed(original_order))
    
    # Property: Cleanup order must be exact reverse of deployment order
    assert cleanup_order == list(reversed(original_order)), \
        f"Cleanup order {cleanup_order} is not the reverse of deployment order {original_order}"
    
    # Property: First agent in cleanup must be last agent in deployment
    assert cleanup_order[0] == original_order[-1], \
        f"First cleanup agent {cleanup_order[0]} should be last deployment agent {original_order[-1]}"
    
    # Property: Last agent in cleanup must be first agent in deployment
    assert cleanup_order[-1] == original_order[0], \
        f"Last cleanup agent {cleanup_order[-1]} should be first deployment agent {original_order[0]}"
    
    # Property: All agents in deployment must be in cleanup
    assert set(cleanup_order) == set(original_order), \
        "Cleanup must include all deployed agents"
    
    # Property: No agent should appear twice in cleanup order
    assert len(cleanup_order) == len(set(cleanup_order)), \
        "Each agent should appear exactly once in cleanup order"
    
    # Property: For any two agents A and B, if A was deployed before B,
    # then B must be cleaned up before A
    for i, agent_a in enumerate(original_order):
        for j, agent_b in enumerate(original_order):
            if i < j:  # A deployed before B
                # Find positions in cleanup order
                cleanup_pos_a = cleanup_order.index(agent_a)
                cleanup_pos_b = cleanup_order.index(agent_b)
                
                # B must be cleaned up before A (lower index in cleanup order)
                assert cleanup_pos_b < cleanup_pos_a, \
                    f"Agent {agent_b} (deployed after {agent_a}) must be cleaned up before {agent_a}"


@given(deployment_state=deployment_state_strategy())
@settings(max_examples=100, deadline=None)
def test_property_cleanup_preserves_all_agents(deployment_state: DeploymentState):
    """
    Property: Cleanup must process all deployed agents.
    
    For any deployment state, the cleanup operation must include all agents
    that were deployed, with no additions or omissions.
    
    Validates: Requirements 17.2
    """
    original_agents = set(deployment_state.agents.keys())
    cleanup_order = list(reversed(list(deployment_state.agents.keys())))
    cleanup_agents = set(cleanup_order)
    
    # Property: Cleanup must include exactly the same agents as deployment
    assert cleanup_agents == original_agents, \
        f"Cleanup agents {cleanup_agents} must match deployed agents {original_agents}"
    
    # Property: No extra agents in cleanup
    assert not (cleanup_agents - original_agents), \
        f"Cleanup includes extra agents: {cleanup_agents - original_agents}"
    
    # Property: No missing agents in cleanup
    assert not (original_agents - cleanup_agents), \
        f"Cleanup missing agents: {original_agents - cleanup_agents}"


@given(deployment_state=deployment_state_strategy())
@settings(max_examples=100, deadline=None)
def test_property_cleanup_order_deterministic(deployment_state: DeploymentState):
    """
    Property: Cleanup order must be deterministic.
    
    For any deployment state, reversing the deployment order multiple times
    must always produce the same cleanup order.
    
    Validates: Requirements 17.2
    """
    original_order = list(deployment_state.agents.keys())
    
    # Reverse multiple times
    cleanup_order_1 = list(reversed(original_order))
    cleanup_order_2 = list(reversed(original_order))
    cleanup_order_3 = list(reversed(original_order))
    
    # Property: All cleanup orders must be identical
    assert cleanup_order_1 == cleanup_order_2 == cleanup_order_3, \
        "Cleanup order must be deterministic across multiple reversals"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
