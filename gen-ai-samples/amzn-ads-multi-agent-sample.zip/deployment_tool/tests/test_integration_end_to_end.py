"""
Integration tests for end-to-end deployment workflows.

These tests validate the complete deployment system with mocked AWS services,
testing idempotency, partial deployments, configuration updates, and cleanup.

Validates Requirements: 6.1, 6.2, 9.2, 9.3, 9.4, 17.1, 17.2
"""

import pytest
import os
import json
import tempfile
import shutil
import boto3
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

from deployment_tool.managers.config_manager import ConfigurationManager
from deployment_tool.managers.state_manager import StateManager
from deployment_tool.managers.deployment_orchestrator import AgentDeploymentOrchestrator
from deployment_tool.managers.iam_manager import IAMManager
from deployment_tool.managers.s3_manager import S3Manager
from deployment_tool.models.data_models import (
    DeploymentConfig,
    AgentConfig,
    IAMPolicyConfig,
    DeploymentResult,
    AgentDeploymentResult,
    DeploymentState,
    AgentDeploymentState
)


@pytest.fixture
def temp_workspace():
    """Create a temporary workspace with agent directories."""
    workspace = tempfile.mkdtemp()
    
    # Create agent directories
    agents = ['custom-ads-a2a-agent', 'mcp-ads-a2a-agent', 'orchestration-a2a-agent']
    for agent in agents:
        agent_dir = Path(workspace) / agent
        agent_dir.mkdir()
        
        # Create entrypoint file
        entrypoint = agent_dir / 'agent.py'
        entrypoint.write_text('# Agent code')
        
        # Create requirements.txt
        requirements = agent_dir / 'requirements.txt'
        requirements.write_text('boto3>=1.34.0\n')
        
        # Create .env file for orchestration agent
        if 'orchestration' in agent:
            env_file = agent_dir / '.env'
            env_file.write_text('# Environment variables\n')
    
    yield workspace
    
    # Cleanup
    shutil.rmtree(workspace)


@pytest.fixture
def deployment_config_file(temp_workspace):
    """Create a deployment configuration file."""
    config_path = Path(temp_workspace) / 'deployment.yaml'
    
    config_content = f"""
aws_account_id: "123456789012"
aws_region: "us-east-1"

agents:
  - name: custom-ads-a2a-agent
    directory: {temp_workspace}/custom-ads-a2a-agent
    entrypoint: agent.py
    language: python
    platform: linux/arm64
    memory_mode: STM_ONLY
    server_protocol: A2A
    
  - name: mcp-ads-a2a-agent
    directory: {temp_workspace}/mcp-ads-a2a-agent
    entrypoint: agent.py
    language: python
    platform: linux/arm64
    memory_mode: STM_ONLY
    server_protocol: A2A
    
  - name: orchestration-a2a-agent
    directory: {temp_workspace}/orchestration-a2a-agent
    entrypoint: agent.py
    language: python
    platform: linux/arm64
    memory_mode: STM_ONLY
    server_protocol: A2A

iam_policies:
  base_policy:
    Version: "2012-10-17"
    Statement:
      - Effect: Allow
        Action:
          - logs:CreateLogGroup
          - logs:CreateLogStream
          - logs:PutLogEvents
        Resource: "*"
        
  cross_agent_policy_template:
    Version: "2012-10-17"
    Statement:
      - Effect: Allow
        Action:
          - bedrock-agent-runtime:InvokeRuntime
        Resource: "{{AGENT_ARNS}}"

deployment_order:
  - custom-ads-a2a-agent
  - mcp-ads-a2a-agent
  - orchestration-a2a-agent
"""
    
    config_path.write_text(config_content)
    return str(config_path)


@pytest.fixture
def mock_aws_services():
    """Mock AWS service calls."""
    with patch('boto3.Session') as mock_session:
        # Mock IAM client
        mock_iam = MagicMock()
        mock_iam.get_role.side_effect = Exception("Role not found")
        mock_iam.create_role.return_value = {
            'Role': {'Arn': 'arn:aws:iam::123456789012:role/test-role'}
        }
        mock_iam.attach_role_policy.return_value = {}
        mock_iam.put_role_policy.return_value = {}
        
        # Mock S3 client
        mock_s3 = MagicMock()
        mock_s3.head_bucket.side_effect = Exception("Bucket not found")
        mock_s3.create_bucket.return_value = {}
        mock_s3.put_bucket_policy.return_value = {}
        
        # Mock STS client
        mock_sts = MagicMock()
        mock_sts.get_caller_identity.return_value = {
            'Account': '123456789012',
            'Arn': 'arn:aws:iam::123456789012:user/test-user'
        }
        
        # Configure session to return mocked clients
        mock_session_instance = MagicMock()
        mock_session_instance.client.side_effect = lambda service, **kwargs: {
            'iam': mock_iam,
            's3': mock_s3,
            'sts': mock_sts
        }.get(service)
        
        mock_session.return_value = mock_session_instance
        
        yield {
            'session': mock_session,
            'iam': mock_iam,
            's3': mock_s3,
            'sts': mock_sts
        }


@pytest.fixture
def mock_agentcore_commands():
    """Mock agentcore configure and deploy commands."""
    with patch('subprocess.run') as mock_run:
        # Mock successful configure output
        configure_result = MagicMock()
        configure_result.returncode = 0
        configure_result.stdout = """
Configuration created successfully
Execution Role ARN: arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-abc123
ECR Repository: bedrock-agentcore-test-agent
"""
        
        # Mock successful deploy output
        deploy_result = MagicMock()
        deploy_result.returncode = 0
        deploy_result.stdout = """
Deployment successful
Agent ARN: arn:aws:bedrock-agent-runtime:us-east-1:123456789012:agent/test-agent-123
"""
        
        # Return configure result for configure commands, deploy result for deploy
        def side_effect(*args, **kwargs):
            cmd = args[0] if args else kwargs.get('args', [])
            if 'configure' in ' '.join(cmd):
                return configure_result
            elif 'deploy' in ' '.join(cmd):
                return deploy_result
            return MagicMock(returncode=0, stdout="")
        
        mock_run.side_effect = side_effect
        
        yield mock_run


class TestEndToEndDeployment:
    """Test complete end-to-end deployment workflows."""
    
    def test_full_deployment_flow(
        self,
        temp_workspace,
        deployment_config_file,
        mock_aws_services,
        mock_agentcore_commands
    ):
        """
        Test complete deployment flow from configuration to deployed agents.
        
        Validates Requirements: 6.1, 6.2
        """
        # Load configuration
        config_manager = ConfigurationManager(deployment_config_file)
        deployment_config = config_manager.load_config()
        
        # Validate configuration
        config_errors = config_manager.validate_config()
        assert len(config_errors) == 0, "Configuration should be valid"
        
        directory_errors = config_manager.validate_agent_directories()
        assert len(directory_errors) == 0, "Agent directories should exist"
        
        # Initialize managers
        state_file = Path(temp_workspace) / '.deployment_state.json'
        state_manager = StateManager(str(state_file))
        
        # Create boto3 session (will use mocked clients)
        session = boto3.Session(region_name='us-east-1')
        
        iam_manager = IAMManager(boto3_session=session)
        s3_manager = S3Manager(boto3_session=session)
        
        # Initialize orchestrator
        orchestrator = AgentDeploymentOrchestrator(
            config=deployment_config,
            iam_manager=iam_manager,
            s3_manager=s3_manager,
            state_manager=state_manager
        )
        
        # Execute deployment
        result = orchestrator.deploy_all_agents()
        
        # Verify deployment succeeded
        assert result.success, "Deployment should succeed"
        assert len(result.deployed_agents) == 3, "All 3 agents should be deployed"
        assert len(result.failed_agents) == 0, "No agents should fail"
        
        # Verify state was saved
        assert state_file.exists(), "State file should be created"
        
        deployment_state = state_manager.load_state()
        assert len(deployment_state.agents) == 3, "State should contain 3 agents"
        
        # Verify agent ARNs were captured
        for agent_name in ['custom-ads-a2a-agent', 'mcp-ads-a2a-agent', 'orchestration-a2a-agent']:
            assert agent_name in deployment_state.agents, f"{agent_name} should be in state"
            agent_state = deployment_state.agents[agent_name]
            assert agent_state.agent_arn.startswith('arn:aws:bedrock-agent-runtime')
            assert agent_state.execution_role_arn.startswith('arn:aws:iam::')
    
    def test_idempotent_deployment(
        self,
        temp_workspace,
        deployment_config_file,
        mock_aws_services,
        mock_agentcore_commands
    ):
        """
        Test that deploying twice with same configuration is idempotent.
        
        Validates Requirements: 9.2, 9.3
        """
        # Load configuration
        config_manager = ConfigurationManager(deployment_config_file)
        deployment_config = config_manager.load_config()
        
        # Initialize managers
        state_file = Path(temp_workspace) / '.deployment_state.json'
        state_manager = StateManager(str(state_file))
        
        # Create boto3 session (will use mocked clients)
        session = boto3.Session(region_name='us-east-1')
        
        iam_manager = IAMManager(boto3_session=session)
        s3_manager = S3Manager(boto3_session=session)
        
        # First deployment
        orchestrator1 = AgentDeploymentOrchestrator(
            config=deployment_config,
            iam_manager=iam_manager,
            s3_manager=s3_manager,
            state_manager=state_manager
        )
        
        result1 = orchestrator1.deploy_all_agents()
        assert result1.success, "First deployment should succeed"
        
        # Load state after first deployment
        state_after_first = state_manager.load_state()
        first_deployment_time = state_after_first.last_deployment
        
        # Second deployment (should be idempotent)
        orchestrator2 = AgentDeploymentOrchestrator(
            config=deployment_config,
            iam_manager=iam_manager,
            s3_manager=s3_manager,
            state_manager=state_manager
        )
        
        result2 = orchestrator2.deploy_all_agents()
        assert result2.success, "Second deployment should succeed"
        
        # Verify state is consistent
        state_after_second = state_manager.load_state()
        assert len(state_after_second.agents) == 3, "Should still have 3 agents"
        
        # Verify ARNs are the same (idempotent)
        for agent_name in state_after_first.agents.keys():
            assert agent_name in state_after_second.agents
            # ARNs should be the same or updated (both are valid for idempotency)
            assert state_after_second.agents[agent_name].agent_arn is not None
    
    def test_partial_deployment_and_resume(
        self,
        temp_workspace,
        deployment_config_file,
        mock_aws_services
    ):
        """
        Test partial deployment with failure and resume from failure point.
        
        Validates Requirements: 6.4, 9.4
        """
        # Load configuration
        config_manager = ConfigurationManager(deployment_config_file)
        deployment_config = config_manager.load_config()
        
        # Initialize managers
        state_file = Path(temp_workspace) / '.deployment_state.json'
        state_manager = StateManager(str(state_file))
        
        # Create boto3 session (will use mocked clients)
        session = boto3.Session(region_name='us-east-1')
        
        iam_manager = IAMManager(boto3_session=session)
        s3_manager = S3Manager(boto3_session=session)
        
        # Mock agentcore commands to fail on second agent
        with patch('subprocess.run') as mock_run:
            call_count = [0]
            
            def side_effect(*args, **kwargs):
                call_count[0] += 1
                cmd = ' '.join(args[0] if args else kwargs.get('args', []))
                
                # First agent succeeds
                if call_count[0] <= 2:  # configure + deploy
                    result = MagicMock()
                    result.returncode = 0
                    if 'configure' in cmd:
                        result.stdout = "Execution Role ARN: arn:aws:iam::123456789012:role/test-role-1"
                    else:
                        result.stdout = "Agent ARN: arn:aws:bedrock-agent-runtime:us-east-1:123456789012:agent/agent-1"
                    return result
                
                # Second agent fails
                elif call_count[0] == 3:  # configure fails
                    result = MagicMock()
                    result.returncode = 1
                    result.stderr = "Configuration failed"
                    return result
                
                # Subsequent calls succeed (for resume)
                else:
                    result = MagicMock()
                    result.returncode = 0
                    if 'configure' in cmd:
                        result.stdout = f"Execution Role ARN: arn:aws:iam::123456789012:role/test-role-{call_count[0]}"
                    else:
                        result.stdout = f"Agent ARN: arn:aws:bedrock-agent-runtime:us-east-1:123456789012:agent/agent-{call_count[0]}"
                    return result
            
            mock_run.side_effect = side_effect
            
            # First deployment attempt (should fail on second agent)
            orchestrator1 = AgentDeploymentOrchestrator(
                config=deployment_config,
                iam_manager=iam_manager,
                s3_manager=s3_manager,
                state_manager=state_manager
            )
            
            result1 = orchestrator1.deploy_all_agents()
            assert not result1.success, "First deployment should fail"
            assert len(result1.deployed_agents) >= 1, "At least one agent should be deployed"
            assert len(result1.failed_agents) >= 1, "At least one agent should fail"
            
            # Verify state was saved for successful agents
            state_after_failure = state_manager.load_state()
            assert len(state_after_failure.agents) >= 1, "State should contain successful agents"
            
            # Resume deployment (should continue from failure point)
            orchestrator2 = AgentDeploymentOrchestrator(
                config=deployment_config,
                iam_manager=iam_manager,
                s3_manager=s3_manager,
                state_manager=state_manager
            )
            
            result2 = orchestrator2.deploy_all_agents()
            assert result2.success, "Resume deployment should succeed"
            
            # Verify all agents are now deployed
            state_after_resume = state_manager.load_state()
            assert len(state_after_resume.agents) == 3, "All agents should be deployed after resume"
    
    def test_configuration_update(
        self,
        temp_workspace,
        deployment_config_file,
        mock_aws_services,
        mock_agentcore_commands
    ):
        """
        Test updating configuration and redeploying.
        
        Validates Requirements: 9.2, 9.3
        """
        # Load initial configuration
        config_manager = ConfigurationManager(deployment_config_file)
        deployment_config = config_manager.load_config()
        
        # Initialize managers
        state_file = Path(temp_workspace) / '.deployment_state.json'
        state_manager = StateManager(str(state_file))
        
        # Create boto3 session (will use mocked clients)
        session = boto3.Session(region_name='us-east-1')
        
        iam_manager = IAMManager(boto3_session=session)
        s3_manager = S3Manager(boto3_session=session)
        
        # Initial deployment
        orchestrator1 = AgentDeploymentOrchestrator(
            config=deployment_config,
            iam_manager=iam_manager,
            s3_manager=s3_manager,
            state_manager=state_manager
        )
        
        result1 = orchestrator1.deploy_all_agents()
        assert result1.success, "Initial deployment should succeed"
        
        # Modify configuration (change memory mode)
        config_path = Path(deployment_config_file)
        config_content = config_path.read_text()
        updated_content = config_content.replace('memory_mode: STM_ONLY', 'memory_mode: DISABLED')
        config_path.write_text(updated_content)
        
        # Reload configuration
        config_manager2 = ConfigurationManager(deployment_config_file)
        deployment_config2 = config_manager2.load_config()
        
        # Redeploy with updated configuration
        orchestrator2 = AgentDeploymentOrchestrator(
            config=deployment_config2,
            iam_manager=iam_manager,
            s3_manager=s3_manager,
            state_manager=state_manager
        )
        
        result2 = orchestrator2.deploy_all_agents()
        assert result2.success, "Updated deployment should succeed"
        
        # Verify state reflects updates
        state_after_update = state_manager.load_state()
        assert len(state_after_update.agents) == 3, "Should still have 3 agents"
    
    def test_cleanup_operation(
        self,
        temp_workspace,
        deployment_config_file,
        mock_aws_services,
        mock_agentcore_commands
    ):
        """
        Test cleanup operation deletes agents in reverse order.
        
        Validates Requirements: 17.1, 17.2
        """
        # Load configuration
        config_manager = ConfigurationManager(deployment_config_file)
        deployment_config = config_manager.load_config()
        
        # Initialize managers
        state_file = Path(temp_workspace) / '.deployment_state.json'
        state_manager = StateManager(str(state_file))
        
        # Create boto3 session (will use mocked clients)
        session = boto3.Session(region_name='us-east-1')
        
        iam_manager = IAMManager(boto3_session=session)
        s3_manager = S3Manager(boto3_session=session)
        
        # Deploy agents
        orchestrator = AgentDeploymentOrchestrator(
            config=deployment_config,
            iam_manager=iam_manager,
            s3_manager=s3_manager,
            state_manager=state_manager
        )
        
        result = orchestrator.deploy_all_agents()
        assert result.success, "Deployment should succeed"
        
        # Verify state before cleanup
        state_before_cleanup = state_manager.load_state()
        assert len(state_before_cleanup.agents) == 3, "Should have 3 agents before cleanup"
        
        # Get agent names in deployment order
        agent_names = list(state_before_cleanup.agents.keys())
        
        # Cleanup (delete in reverse order)
        cleanup_order = list(reversed(agent_names))
        
        # Verify cleanup order is reverse of deployment order
        assert cleanup_order[0] == 'orchestration-a2a-agent', "Orchestration should be deleted first"
        assert cleanup_order[-1] == 'custom-ads-a2a-agent', "Custom-ads should be deleted last"
        
        # Clear state
        state_manager.clear_state()
        
        # Verify state is cleared
        state_after_cleanup = state_manager.load_state()
        assert len(state_after_cleanup.agents) == 0, "State should be empty after cleanup"


class TestDeploymentOrderPreservation:
    """Test that deployment order is preserved across operations."""
    
    def test_deployment_order_matches_config(
        self,
        temp_workspace,
        deployment_config_file,
        mock_aws_services,
        mock_agentcore_commands
    ):
        """
        Test that agents are deployed in the order specified in configuration.
        
        Validates Requirements: 6.1, 6.2
        """
        # Load configuration
        config_manager = ConfigurationManager(deployment_config_file)
        deployment_config = config_manager.load_config()
        
        # Get agents in deployment order
        agents_in_order = config_manager.get_agents_in_deployment_order()
        
        # Verify order matches configuration
        expected_order = ['custom-ads-a2a-agent', 'mcp-ads-a2a-agent', 'orchestration-a2a-agent']
        actual_order = [agent.name for agent in agents_in_order]
        
        assert actual_order == expected_order, "Deployment order should match configuration"
        
        # Verify orchestration agent is last
        assert actual_order[-1] == 'orchestration-a2a-agent', "Orchestration agent should be deployed last"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
