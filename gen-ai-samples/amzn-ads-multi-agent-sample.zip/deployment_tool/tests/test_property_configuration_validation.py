"""
Property-based tests for configuration validation.

**Validates: Requirements 1.2, 14.1, 14.2, 14.3**

This module implements Property 1: Configuration Validation Completeness
For any deployment configuration, if validation passes, then all required fields 
must be present and all agent directories and entrypoint files must exist.
"""

import os
import tempfile
import shutil
from pathlib import Path
from typing import List, Dict, Any
import pytest
from hypothesis import given, strategies as st, settings, assume, HealthCheck
from hypothesis.strategies import SearchStrategy

from deployment_tool.models.data_models import (
    AgentConfig,
    DeploymentConfig,
    IAMPolicyConfig,
    FrontendConfig
)


# ============================================================================
# Strategy Definitions
# ============================================================================

@st.composite
def valid_aws_account_id(draw) -> str:
    """Generate a valid 12-digit AWS account ID."""
    return str(draw(st.integers(min_value=100000000000, max_value=999999999999)))


@st.composite
def valid_aws_region(draw) -> str:
    """Generate a valid AWS region name."""
    regions = [
        "us-east-1", "us-east-2", "us-west-1", "us-west-2",
        "eu-west-1", "eu-west-2", "eu-central-1",
        "ap-southeast-1", "ap-southeast-2", "ap-northeast-1"
    ]
    return draw(st.sampled_from(regions))


@st.composite
def valid_agent_name(draw) -> str:
    """Generate a valid agent name."""
    # Agent names should be alphanumeric with hyphens
    name = draw(st.text(
        alphabet=st.characters(whitelist_categories=("Ll", "Nd"), whitelist_characters="-"),
        min_size=3,
        max_size=50
    ))
    # Ensure it doesn't start or end with hyphen
    name = name.strip("-")
    assume(len(name) >= 3)
    assume(not name.startswith("-") and not name.endswith("-"))
    return name


@st.composite
def valid_server_protocol(draw) -> str:
    """Generate a valid server protocol."""
    return draw(st.sampled_from(["HTTP", "A2A", "MCP"]))


@st.composite
def valid_memory_mode(draw) -> str:
    """Generate a valid memory mode."""
    return draw(st.sampled_from(["STM_ONLY", "NONE"]))


@st.composite
def valid_iam_policy(draw) -> dict:
    """Generate a valid IAM policy document structure."""
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": draw(st.lists(st.text(min_size=1, max_size=50), min_size=1, max_size=5)),
                "Resource": "*"
            }
        ]
    }


@st.composite
def agent_config_strategy(draw, temp_dir: Path) -> AgentConfig:
    """
    Generate a valid AgentConfig with actual files on disk.
    
    Args:
        temp_dir: Temporary directory where agent files will be created
    """
    agent_name = draw(valid_agent_name())
    
    # Create agent directory
    agent_dir = temp_dir / agent_name
    agent_dir.mkdir(parents=True, exist_ok=True)
    
    # Create entrypoint file
    entrypoint_name = draw(st.sampled_from([
        "agent.py", "langgraph_a2a.py", "main.py", "app.py"
    ]))
    entrypoint_path = agent_dir / entrypoint_name
    entrypoint_path.write_text("# Agent entrypoint\n")
    
    # Create requirements.txt
    requirements_path = agent_dir / "requirements.txt"
    requirements_path.write_text("boto3>=1.34.0\n")
    
    return AgentConfig(
        name=agent_name,
        directory=str(agent_dir),
        entrypoint=entrypoint_name,
        language="python",
        platform=draw(st.sampled_from(["linux/arm64", "linux/amd64"])),
        memory_mode=draw(valid_memory_mode()),
        server_protocol=draw(valid_server_protocol()),
        dependencies=draw(st.lists(valid_agent_name(), max_size=3)),
        environment_variables=draw(st.dictionaries(
            st.text(min_size=1, max_size=20),
            st.text(min_size=1, max_size=50),
            max_size=5
        ))
    )


@st.composite
def deployment_config_strategy(draw, temp_dir: Path) -> DeploymentConfig:
    """
    Generate a valid DeploymentConfig with actual files on disk.
    
    Args:
        temp_dir: Temporary directory where agent files will be created
    """
    # Generate agents with unique names
    num_agents = draw(st.integers(min_value=1, max_value=5))
    agents = []
    used_names = set()
    
    for i in range(num_agents):
        # Keep generating agents until we get a unique name
        max_attempts = 10
        for attempt in range(max_attempts):
            agent = draw(agent_config_strategy(temp_dir))
            if agent.name not in used_names:
                agents.append(agent)
                used_names.add(agent.name)
                break
        else:
            # If we couldn't generate a unique name, use a guaranteed unique one
            unique_name = f"agent-{i}-{draw(st.integers(min_value=0, max_value=9999))}"
            agent_dir = temp_dir / unique_name
            agent_dir.mkdir(parents=True, exist_ok=True)
            entrypoint_path = agent_dir / "agent.py"
            entrypoint_path.write_text("# Agent entrypoint\n")
            
            agent = AgentConfig(
                name=unique_name,
                directory=str(agent_dir),
                entrypoint="agent.py",
                language="python",
                platform="linux/arm64",
                memory_mode="STM_ONLY",
                server_protocol="HTTP",
                dependencies=[],
                environment_variables={}
            )
            agents.append(agent)
            used_names.add(unique_name)
    
    # Generate deployment order (must include all agent names)
    agent_names = [agent.name for agent in agents]
    deployment_order = draw(st.permutations(agent_names))
    
    # Generate IAM policies
    iam_policies = IAMPolicyConfig(
        base_policy=draw(valid_iam_policy()),
        cross_agent_policy_template=draw(valid_iam_policy())
    )
    
    # Optionally generate frontend config
    frontend_config = None
    if draw(st.booleans()):
        frontend_dir = temp_dir / "frontend"
        frontend_dir.mkdir(exist_ok=True)
        frontend_config = FrontendConfig(
            directory=str(frontend_dir),
            env_file=".env.local",
            orchestration_arn_var="ORCHESTRATION_AGENT_ARN"
        )
    
    return DeploymentConfig(
        aws_account_id=draw(valid_aws_account_id()),
        aws_region=draw(valid_aws_region()),
        agents=agents,
        iam_policies=iam_policies,
        deployment_order=list(deployment_order),
        frontend_config=frontend_config
    )


# ============================================================================
# Validation Functions
# ============================================================================

def validate_required_fields(config: DeploymentConfig) -> List[str]:
    """
    Validate that all required fields are present in the configuration.
    
    Returns:
        List of validation error messages (empty if valid)
    """
    errors = []
    
    # Check required top-level fields
    if not config.aws_account_id:
        errors.append("Missing required field: aws_account_id")
    
    if not config.aws_region:
        errors.append("Missing required field: aws_region")
    
    if not config.agents:
        errors.append("Missing required field: agents (must have at least one agent)")
    
    if not config.iam_policies:
        errors.append("Missing required field: iam_policies")
    
    if not config.deployment_order:
        errors.append("Missing required field: deployment_order")
    
    # Validate AWS account ID format (12 digits)
    if config.aws_account_id and not (
        config.aws_account_id.isdigit() and len(config.aws_account_id) == 12
    ):
        errors.append(f"Invalid aws_account_id format: {config.aws_account_id}")
    
    # Validate each agent configuration
    for i, agent in enumerate(config.agents):
        if not agent.name:
            errors.append(f"Agent {i}: Missing required field 'name'")
        
        if not agent.directory:
            errors.append(f"Agent {i} ({agent.name}): Missing required field 'directory'")
        
        if not agent.entrypoint:
            errors.append(f"Agent {i} ({agent.name}): Missing required field 'entrypoint'")
    
    # Validate deployment order matches agent names
    agent_names = {agent.name for agent in config.agents}
    deployment_names = set(config.deployment_order)
    
    if agent_names != deployment_names:
        missing_in_order = agent_names - deployment_names
        extra_in_order = deployment_names - agent_names
        
        if missing_in_order:
            errors.append(f"Agents missing from deployment_order: {missing_in_order}")
        if extra_in_order:
            errors.append(f"Unknown agents in deployment_order: {extra_in_order}")
    
    return errors


def validate_agent_directories(config: DeploymentConfig) -> List[str]:
    """
    Validate that all agent directories and entrypoint files exist.
    
    Returns:
        List of validation error messages (empty if valid)
    """
    errors = []
    
    for agent in config.agents:
        # Check if agent directory exists
        agent_dir = Path(agent.directory)
        if not agent_dir.exists():
            errors.append(f"Agent '{agent.name}': Directory does not exist: {agent.directory}")
            continue
        
        if not agent_dir.is_dir():
            errors.append(f"Agent '{agent.name}': Path is not a directory: {agent.directory}")
            continue
        
        # Check if entrypoint file exists
        entrypoint_path = agent_dir / agent.entrypoint
        if not entrypoint_path.exists():
            errors.append(
                f"Agent '{agent.name}': Entrypoint file does not exist: {entrypoint_path}"
            )
        
        if not entrypoint_path.is_file():
            errors.append(
                f"Agent '{agent.name}': Entrypoint path is not a file: {entrypoint_path}"
            )
        
        # Check if requirements.txt exists (warning, not error)
        requirements_path = agent_dir / "requirements.txt"
        if not requirements_path.exists():
            # This is a warning, not a validation error per requirements
            pass
    
    return errors


def validate_configuration(config: DeploymentConfig) -> List[str]:
    """
    Complete configuration validation.
    
    Returns:
        List of all validation errors (empty if valid)
    """
    errors = []
    errors.extend(validate_required_fields(config))
    errors.extend(validate_agent_directories(config))
    return errors


# ============================================================================
# Property-Based Tests
# ============================================================================

class TestConfigurationValidationCompleteness:
    """
    Property 1: Configuration Validation Completeness
    
    **Validates: Requirements 1.2, 14.1, 14.2, 14.3**
    
    For any deployment configuration, if validation passes, then all required 
    fields must be present and all agent directories and entrypoint files must exist.
    """
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
    )
    def test_valid_configuration_has_all_required_fields(self, data):
        """
        Property: If validation passes, all required fields must be present.
        
        This test generates valid configurations and verifies that:
        1. All required fields are present
        2. All agent directories exist
        3. All entrypoint files exist
        4. Validation returns no errors
        """
        # Create temporary directory for this test iteration
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate a valid configuration with actual files
            config = data.draw(deployment_config_strategy(temp_path))
            
            # Validate the configuration
            errors = validate_configuration(config)
            
            # Property assertion: Valid configuration should have no errors
            assert len(errors) == 0, f"Valid configuration failed validation: {errors}"
            
            # Verify all required fields are present
            assert config.aws_account_id, "aws_account_id must be present"
            assert config.aws_region, "aws_region must be present"
            assert len(config.agents) > 0, "agents list must not be empty"
            assert config.iam_policies, "iam_policies must be present"
            assert len(config.deployment_order) > 0, "deployment_order must not be empty"
            
            # Verify AWS account ID format
            assert config.aws_account_id.isdigit(), "aws_account_id must be numeric"
            assert len(config.aws_account_id) == 12, "aws_account_id must be 12 digits"
            
            # Verify each agent has required fields
            for agent in config.agents:
                assert agent.name, f"Agent must have a name"
                assert agent.directory, f"Agent {agent.name} must have a directory"
                assert agent.entrypoint, f"Agent {agent.name} must have an entrypoint"
                
                # Verify agent directory exists
                agent_dir = Path(agent.directory)
                assert agent_dir.exists(), f"Agent {agent.name} directory must exist"
                assert agent_dir.is_dir(), f"Agent {agent.name} directory must be a directory"
                
                # Verify entrypoint file exists
                entrypoint_path = agent_dir / agent.entrypoint
                assert entrypoint_path.exists(), f"Agent {agent.name} entrypoint must exist"
                assert entrypoint_path.is_file(), f"Agent {agent.name} entrypoint must be a file"
            
            # Verify deployment order matches agent names
            agent_names = {agent.name for agent in config.agents}
            deployment_names = set(config.deployment_order)
            assert agent_names == deployment_names, \
                "deployment_order must contain exactly the same agents as agents list"
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
    )
    def test_missing_required_fields_causes_validation_failure(self, data):
        """
        Property: If required fields are missing, validation must fail.
        
        This test generates configurations with missing required fields and
        verifies that validation correctly identifies the missing fields.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate a valid configuration
            config = data.draw(deployment_config_strategy(temp_path))
            
            # Choose which field to invalidate
            field_to_invalidate = data.draw(st.sampled_from([
                "aws_account_id",
                "aws_region",
                "agents",
                "deployment_order"
            ]))
            
            # Invalidate the chosen field
            if field_to_invalidate == "aws_account_id":
                config.aws_account_id = ""
            elif field_to_invalidate == "aws_region":
                config.aws_region = ""
            elif field_to_invalidate == "agents":
                config.agents = []
            elif field_to_invalidate == "deployment_order":
                config.deployment_order = []
            
            # Validate the configuration
            errors = validate_configuration(config)
            
            # Property assertion: Invalid configuration must have errors
            assert len(errors) > 0, \
                f"Configuration with missing {field_to_invalidate} should fail validation"
            
            # Verify the error message mentions the missing field
            error_text = " ".join(errors).lower()
            assert field_to_invalidate.replace("_", " ") in error_text or \
                   field_to_invalidate in error_text, \
                f"Error message should mention missing field {field_to_invalidate}"
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
    )
    def test_missing_agent_files_causes_validation_failure(self, data):
        """
        Property: If agent directories or entrypoint files don't exist, validation must fail.
        
        This test generates configurations and then removes agent files to verify
        that validation correctly identifies missing files.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate a valid configuration
            config = data.draw(deployment_config_strategy(temp_path))
            
            # Ensure we have at least one agent
            assume(len(config.agents) > 0)
            
            # Choose an agent to invalidate
            agent_to_invalidate = data.draw(st.sampled_from(config.agents))
            
            # Choose what to invalidate
            invalidation_type = data.draw(st.sampled_from([
                "delete_directory",
                "delete_entrypoint"
            ]))
            
            # Perform the invalidation
            if invalidation_type == "delete_directory":
                # Remove the entire agent directory
                agent_dir = Path(agent_to_invalidate.directory)
                if agent_dir.exists():
                    shutil.rmtree(agent_dir)
            elif invalidation_type == "delete_entrypoint":
                # Remove just the entrypoint file
                agent_dir = Path(agent_to_invalidate.directory)
                entrypoint_path = agent_dir / agent_to_invalidate.entrypoint
                if entrypoint_path.exists():
                    entrypoint_path.unlink()
            
            # Validate the configuration
            errors = validate_configuration(config)
            
            # Property assertion: Configuration with missing files must have errors
            assert len(errors) > 0, \
                f"Configuration with missing {invalidation_type} should fail validation"
            
            # Verify the error message mentions the agent and the missing file/directory
            error_text = " ".join(errors).lower()
            assert agent_to_invalidate.name.lower() in error_text, \
                f"Error message should mention agent {agent_to_invalidate.name}"
            
            if invalidation_type == "delete_directory":
                assert "directory" in error_text, \
                    "Error message should mention missing directory"
            elif invalidation_type == "delete_entrypoint":
                assert "entrypoint" in error_text, \
                    "Error message should mention missing entrypoint"
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
    )
    def test_invalid_aws_account_id_causes_validation_failure(self, data):
        """
        Property: If AWS account ID format is invalid, validation must fail.
        
        This test generates configurations with invalid AWS account IDs and
        verifies that validation correctly identifies the format error.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate a valid configuration
            config = data.draw(deployment_config_strategy(temp_path))
            
            # Generate an invalid AWS account ID
            invalid_account_id = data.draw(st.sampled_from([
                "123",  # Too short
                "12345678901234567890",  # Too long
                "abc123456789",  # Contains letters
                "123-456-789-012",  # Contains hyphens
                "",  # Empty
            ]))
            
            config.aws_account_id = invalid_account_id
            
            # Validate the configuration
            errors = validate_configuration(config)
            
            # Property assertion: Invalid AWS account ID must cause validation failure
            assert len(errors) > 0, \
                f"Configuration with invalid AWS account ID '{invalid_account_id}' should fail validation"
            
            # Verify the error message mentions the AWS account ID
            error_text = " ".join(errors).lower()
            assert "aws_account_id" in error_text or "account" in error_text, \
                "Error message should mention AWS account ID"
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
    )
    def test_deployment_order_mismatch_causes_validation_failure(self, data):
        """
        Property: If deployment_order doesn't match agent names, validation must fail.
        
        This test generates configurations where deployment_order has missing or
        extra agent names and verifies that validation catches the mismatch.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate a valid configuration with at least 2 agents
            config = data.draw(deployment_config_strategy(temp_path))
            assume(len(config.agents) >= 2)
            
            # Choose how to create a mismatch
            mismatch_type = data.draw(st.sampled_from([
                "remove_from_order",
                "add_to_order"
            ]))
            
            if mismatch_type == "remove_from_order":
                # Remove one agent from deployment_order
                config.deployment_order = config.deployment_order[:-1]
            elif mismatch_type == "add_to_order":
                # Add a non-existent agent to deployment_order
                fake_agent_name = data.draw(valid_agent_name())
                assume(fake_agent_name not in [a.name for a in config.agents])
                config.deployment_order.append(fake_agent_name)
            
            # Validate the configuration
            errors = validate_configuration(config)
            
            # Property assertion: Mismatched deployment_order must cause validation failure
            assert len(errors) > 0, \
                f"Configuration with mismatched deployment_order should fail validation"
            
            # Verify the error message mentions deployment_order
            error_text = " ".join(errors).lower()
            assert "deployment" in error_text or "order" in error_text, \
                "Error message should mention deployment_order"


# ============================================================================
# Unit Tests for Edge Cases
# ============================================================================

class TestConfigurationValidationEdgeCases:
    """Unit tests for specific edge cases in configuration validation."""
    
    def test_empty_configuration_fails_validation(self):
        """Test that a configuration with all empty fields fails validation."""
        config = DeploymentConfig(
            aws_account_id="",
            aws_region="",
            agents=[],
            iam_policies=IAMPolicyConfig(base_policy={}, cross_agent_policy_template={}),
            deployment_order=[]
        )
        
        errors = validate_configuration(config)
        assert len(errors) > 0, "Empty configuration should fail validation"
        assert any("aws_account_id" in err.lower() for err in errors)
        assert any("aws_region" in err.lower() for err in errors)
        assert any("agents" in err.lower() for err in errors)
    
    def test_single_agent_configuration_validates(self):
        """Test that a configuration with a single agent can be valid."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create agent directory and files
            agent_dir = temp_path / "test-agent"
            agent_dir.mkdir()
            (agent_dir / "agent.py").write_text("# Agent code\n")
            (agent_dir / "requirements.txt").write_text("boto3\n")
            
            config = DeploymentConfig(
                aws_account_id="123456789012",
                aws_region="us-east-1",
                agents=[
                    AgentConfig(
                        name="test-agent",
                        directory=str(agent_dir),
                        entrypoint="agent.py"
                    )
                ],
                iam_policies=IAMPolicyConfig(
                    base_policy={"Version": "2012-10-17"},
                    cross_agent_policy_template={"Version": "2012-10-17"}
                ),
                deployment_order=["test-agent"]
            )
            
            errors = validate_configuration(config)
            assert len(errors) == 0, f"Single agent configuration should be valid: {errors}"
    
    def test_agent_with_relative_path_validates(self):
        """Test that agent directories can use relative paths."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create agent directory
            agent_dir = temp_path / "relative-agent"
            agent_dir.mkdir()
            (agent_dir / "main.py").write_text("# Agent\n")
            
            # Use relative path (relative to temp_dir)
            original_cwd = os.getcwd()
            try:
                os.chdir(temp_dir)
                
                config = DeploymentConfig(
                    aws_account_id="123456789012",
                    aws_region="us-west-2",
                    agents=[
                        AgentConfig(
                            name="relative-agent",
                            directory="relative-agent",  # Relative path
                            entrypoint="main.py"
                        )
                    ],
                    iam_policies=IAMPolicyConfig(
                        base_policy={},
                        cross_agent_policy_template={}
                    ),
                    deployment_order=["relative-agent"]
                )
                
                errors = validate_configuration(config)
                assert len(errors) == 0, f"Relative path should validate: {errors}"
            finally:
                os.chdir(original_cwd)
