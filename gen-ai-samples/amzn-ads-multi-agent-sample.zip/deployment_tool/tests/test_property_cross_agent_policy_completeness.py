"""
Property-based tests for Cross-Agent Policy Completeness.

This module implements Property 5: Cross-Agent Policy Completeness
For any set of deployed agents, the cross-agent communication policy must include
InvokeRuntime permissions for all agent ARNs and memory access permissions for all
memory ARNs.

**Validates: Requirements 2.5, 2.6, 2.7, 2.8**

Testing Strategy:
- Generate random sets of agent and memory ARNs
- Verify cross-agent policy includes all ARNs
- Verify no ARNs are duplicated or omitted
- Verify policy structure is valid and follows AWS IAM policy format
- Test with minimum 100 iterations using hypothesis
"""

import json
from typing import List, Set
from unittest.mock import Mock
import pytest
from hypothesis import given, strategies as st, settings, assume

from deployment_tool.managers.iam_manager import IAMManager


# ============================================================================
# Strategy Definitions
# ============================================================================

@st.composite
def agent_arn_list(draw) -> List[str]:
    """Generate a list of unique agent ARNs.
    
    Agent ARNs follow the format:
    arn:aws:bedrock:{region}:{account}:agent/{agent-id}
    """
    num_arns = draw(st.integers(min_value=0, max_value=10))
    if num_arns == 0:
        return []
    
    # Generate unique agent IDs first to ensure uniqueness
    agent_ids = draw(st.lists(
        st.text(
            alphabet=st.characters(
                whitelist_categories=('Lu', 'Ll', 'Nd'),
                whitelist_characters='-_'
            ),
            min_size=10,
            max_size=30
        ).filter(lambda x: x and not x.startswith('-') and not x.endswith('-')),
        min_size=num_arns,
        max_size=num_arns,
        unique=True
    ))
    
    arns = []
    for agent_id in agent_ids:
        region = draw(st.sampled_from(['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1']))
        account = draw(st.integers(min_value=100000000000, max_value=999999999999))
        arns.append(f"arn:aws:bedrock:{region}:{account}:agent/{agent_id}")
    
    return arns


@st.composite
def memory_arn_list(draw) -> List[str]:
    """Generate a list of unique memory ARNs.
    
    Memory ARNs follow the format:
    arn:aws:bedrock:{region}:{account}:memory/{memory-id}
    """
    num_arns = draw(st.integers(min_value=0, max_value=10))
    if num_arns == 0:
        return []
    
    # Generate unique memory IDs first to ensure uniqueness
    memory_ids = draw(st.lists(
        st.text(
            alphabet=st.characters(
                whitelist_categories=('Lu', 'Ll', 'Nd'),
                whitelist_characters='-_'
            ),
            min_size=10,
            max_size=30
        ).filter(lambda x: x and not x.startswith('-') and not x.endswith('-')),
        min_size=num_arns,
        max_size=num_arns,
        unique=True
    ))
    
    arns = []
    for memory_id in memory_ids:
        region = draw(st.sampled_from(['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1']))
        account = draw(st.integers(min_value=100000000000, max_value=999999999999))
        arns.append(f"arn:aws:bedrock:{region}:{account}:memory/{memory_id}")
    
    return arns


# ============================================================================
# Property-Based Tests
# ============================================================================

class TestPropertyCrossAgentPolicyCompleteness:
    """
    Property 5: Cross-Agent Policy Completeness
    
    **Validates: Requirements 2.5, 2.6, 2.7, 2.8**
    
    For any set of deployed agents, the cross-agent communication policy must include
    InvokeRuntime permissions for all agent ARNs and memory access permissions for all
    memory ARNs.
    """
    
    @given(
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_5_all_agent_arns_included_in_policy(
        self,
        agent_arns: List[str],
        memory_arns: List[str]
    ):
        """
        Property: All agent ARNs are included in the InvokeRuntime statement.
        
        This test verifies that:
        1. Every agent ARN provided is present in the policy
        2. The InvokeRuntime action is specified for agent ARNs
        3. No agent ARNs are omitted from the policy
        4. Agent ARNs appear in the correct statement
        
        **Validates: Requirements 2.5, 2.7**
        """
        # Create mock boto3 session
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        # Property assertion: Policy has correct structure
        assert 'Version' in policy, "Policy must have Version field"
        assert policy['Version'] == '2012-10-17', "Policy must use version 2012-10-17"
        assert 'Statement' in policy, "Policy must have Statement field"
        assert isinstance(policy['Statement'], list), "Statement must be a list"
        
        if agent_arns:
            # Find the InvokeRuntime statement
            agent_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:InvokeRuntime' in s.get('Action', [])),
                None
            )
            
            # Property assertion: InvokeRuntime statement must exist when agent ARNs provided
            assert agent_statement is not None, (
                "Policy must include InvokeRuntime statement when agent ARNs are provided"
            )
            
            # Property assertion: Statement must have correct structure
            assert 'Effect' in agent_statement, "Statement must have Effect field"
            assert agent_statement['Effect'] == 'Allow', "Statement Effect must be Allow"
            assert 'Action' in agent_statement, "Statement must have Action field"
            assert 'Resource' in agent_statement, "Statement must have Resource field"
            
            # Property assertion: All agent ARNs must be present
            policy_agent_arns = set(agent_statement['Resource'])
            expected_agent_arns = set(agent_arns)
            
            assert policy_agent_arns == expected_agent_arns, (
                f"Policy must include all agent ARNs. "
                f"Missing: {expected_agent_arns - policy_agent_arns}, "
                f"Extra: {policy_agent_arns - expected_agent_arns}"
            )
            
            # Property assertion: InvokeRuntime action must be present
            assert 'bedrock-agentcore:InvokeRuntime' in agent_statement['Action'], (
                "Agent statement must include bedrock-agentcore:InvokeRuntime action"
            )
        else:
            # Property assertion: No InvokeRuntime statement when no agent ARNs
            agent_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:InvokeRuntime' in s.get('Action', [])),
                None
            )
            assert agent_statement is None, (
                "Policy must not include InvokeRuntime statement when no agent ARNs provided"
            )
    
    @given(
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_5_all_memory_arns_included_in_policy(
        self,
        agent_arns: List[str],
        memory_arns: List[str]
    ):
        """
        Property: All memory ARNs are included in the memory access statement.
        
        This test verifies that:
        1. Every memory ARN provided is present in the policy
        2. GetMemory and PutMemory actions are specified for memory ARNs
        3. No memory ARNs are omitted from the policy
        4. Memory ARNs appear in the correct statement
        
        **Validates: Requirements 2.6, 2.8**
        """
        # Create mock boto3 session
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        if memory_arns:
            # Find the memory access statement
            memory_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:GetMemory' in s.get('Action', [])),
                None
            )
            
            # Property assertion: Memory statement must exist when memory ARNs provided
            assert memory_statement is not None, (
                "Policy must include memory access statement when memory ARNs are provided"
            )
            
            # Property assertion: Statement must have correct structure
            assert 'Effect' in memory_statement, "Statement must have Effect field"
            assert memory_statement['Effect'] == 'Allow', "Statement Effect must be Allow"
            assert 'Action' in memory_statement, "Statement must have Action field"
            assert 'Resource' in memory_statement, "Statement must have Resource field"
            
            # Property assertion: All memory ARNs must be present
            policy_memory_arns = set(memory_statement['Resource'])
            expected_memory_arns = set(memory_arns)
            
            assert policy_memory_arns == expected_memory_arns, (
                f"Policy must include all memory ARNs. "
                f"Missing: {expected_memory_arns - policy_memory_arns}, "
                f"Extra: {policy_memory_arns - expected_memory_arns}"
            )
            
            # Property assertion: Both GetMemory and PutMemory actions must be present
            expected_actions = {'bedrock-agentcore:GetMemory', 'bedrock-agentcore:PutMemory'}
            actual_actions = set(memory_statement['Action'])
            
            assert actual_actions == expected_actions, (
                f"Memory statement must include GetMemory and PutMemory actions. "
                f"Expected: {expected_actions}, Got: {actual_actions}"
            )
        else:
            # Property assertion: No memory statement when no memory ARNs
            memory_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:GetMemory' in s.get('Action', [])),
                None
            )
            assert memory_statement is None, (
                "Policy must not include memory access statement when no memory ARNs provided"
            )
    
    @given(
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_5_no_duplicate_arns_in_policy(
        self,
        agent_arns: List[str],
        memory_arns: List[str]
    ):
        """
        Property: No ARNs are duplicated in the policy.
        
        This test verifies that:
        1. Each agent ARN appears exactly once in the policy
        2. Each memory ARN appears exactly once in the policy
        3. No ARN is listed multiple times in any statement
        
        **Validates: Requirements 2.7, 2.8**
        """
        # Create mock boto3 session
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        # Check agent ARNs for duplicates
        if agent_arns:
            agent_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:InvokeRuntime' in s.get('Action', [])),
                None
            )
            
            assert agent_statement is not None
            
            # Property assertion: No duplicate agent ARNs
            policy_agent_arns = agent_statement['Resource']
            assert len(policy_agent_arns) == len(set(policy_agent_arns)), (
                f"Policy must not contain duplicate agent ARNs. "
                f"Found {len(policy_agent_arns)} ARNs but only {len(set(policy_agent_arns))} unique"
            )
        
        # Check memory ARNs for duplicates
        if memory_arns:
            memory_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:GetMemory' in s.get('Action', [])),
                None
            )
            
            assert memory_statement is not None
            
            # Property assertion: No duplicate memory ARNs
            policy_memory_arns = memory_statement['Resource']
            assert len(policy_memory_arns) == len(set(policy_memory_arns)), (
                f"Policy must not contain duplicate memory ARNs. "
                f"Found {len(policy_memory_arns)} ARNs but only {len(set(policy_memory_arns))} unique"
            )
    
    @given(
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_5_policy_structure_is_valid_iam_format(
        self,
        agent_arns: List[str],
        memory_arns: List[str]
    ):
        """
        Property: Policy structure is valid and follows AWS IAM policy format.
        
        This test verifies that:
        1. Policy has required top-level fields (Version, Statement)
        2. Version is set to '2012-10-17'
        3. Statement is a list
        4. Each statement has required fields (Effect, Action, Resource)
        5. Effect is 'Allow'
        6. Actions and Resources are properly formatted
        
        **Validates: Requirements 2.5, 2.6, 2.7, 2.8**
        """
        # Create mock boto3 session
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        # Property assertion: Top-level structure
        assert isinstance(policy, dict), "Policy must be a dictionary"
        assert 'Version' in policy, "Policy must have Version field"
        assert 'Statement' in policy, "Policy must have Statement field"
        
        # Property assertion: Version format
        assert policy['Version'] == '2012-10-17', (
            "Policy Version must be '2012-10-17'"
        )
        
        # Property assertion: Statement is a list
        assert isinstance(policy['Statement'], list), (
            "Policy Statement must be a list"
        )
        
        # Property assertion: Correct number of statements
        expected_statement_count = (1 if agent_arns else 0) + (1 if memory_arns else 0)
        assert len(policy['Statement']) == expected_statement_count, (
            f"Policy should have exactly {expected_statement_count} statement(s), "
            f"got {len(policy['Statement'])}"
        )
        
        # Property assertion: Each statement has required fields
        for i, statement in enumerate(policy['Statement']):
            assert isinstance(statement, dict), (
                f"Statement {i} must be a dictionary"
            )
            
            assert 'Effect' in statement, (
                f"Statement {i} must have Effect field"
            )
            assert statement['Effect'] == 'Allow', (
                f"Statement {i} Effect must be 'Allow', got '{statement['Effect']}'"
            )
            
            assert 'Action' in statement, (
                f"Statement {i} must have Action field"
            )
            assert isinstance(statement['Action'], list), (
                f"Statement {i} Action must be a list"
            )
            assert len(statement['Action']) > 0, (
                f"Statement {i} Action must not be empty"
            )
            
            assert 'Resource' in statement, (
                f"Statement {i} must have Resource field"
            )
            assert isinstance(statement['Resource'], list), (
                f"Statement {i} Resource must be a list"
            )
            assert len(statement['Resource']) > 0, (
                f"Statement {i} Resource must not be empty"
            )
            
            # Property assertion: Actions are properly formatted
            for action in statement['Action']:
                assert isinstance(action, str), (
                    f"Statement {i} actions must be strings"
                )
                assert ':' in action, (
                    f"Statement {i} action '{action}' must be in format 'service:action'"
                )
                assert action.startswith('bedrock-agentcore:'), (
                    f"Statement {i} action '{action}' must start with 'bedrock-agentcore:'"
                )
            
            # Property assertion: Resources are properly formatted ARNs
            for resource in statement['Resource']:
                assert isinstance(resource, str), (
                    f"Statement {i} resources must be strings"
                )
                assert resource.startswith('arn:aws:'), (
                    f"Statement {i} resource '{resource}' must be a valid ARN starting with 'arn:aws:'"
                )
    
    @given(
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_5_policy_is_json_serializable(
        self,
        agent_arns: List[str],
        memory_arns: List[str]
    ):
        """
        Property: Policy can be serialized to JSON without errors.
        
        This test verifies that:
        1. Policy can be converted to JSON string
        2. JSON string can be parsed back to dictionary
        3. Parsed policy matches original policy
        4. No data is lost in serialization
        
        **Validates: Requirements 2.5, 2.6, 2.7, 2.8**
        """
        # Create mock boto3 session
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        # Property assertion: Policy can be serialized to JSON
        try:
            policy_json = json.dumps(policy)
        except (TypeError, ValueError) as e:
            pytest.fail(f"Policy must be JSON serializable: {e}")
        
        # Property assertion: JSON can be parsed back
        try:
            parsed_policy = json.loads(policy_json)
        except json.JSONDecodeError as e:
            pytest.fail(f"Serialized policy must be valid JSON: {e}")
        
        # Property assertion: Parsed policy matches original
        assert parsed_policy == policy, (
            "Parsed policy must match original policy after JSON serialization"
        )
        
        # Property assertion: All ARNs preserved in serialization
        if agent_arns:
            agent_statement = next(
                (s for s in parsed_policy['Statement']
                 if 'bedrock-agentcore:InvokeRuntime' in s.get('Action', [])),
                None
            )
            assert agent_statement is not None
            assert set(agent_statement['Resource']) == set(agent_arns), (
                "All agent ARNs must be preserved after JSON serialization"
            )
        
        if memory_arns:
            memory_statement = next(
                (s for s in parsed_policy['Statement']
                 if 'bedrock-agentcore:GetMemory' in s.get('Action', [])),
                None
            )
            assert memory_statement is not None
            assert set(memory_statement['Resource']) == set(memory_arns), (
                "All memory ARNs must be preserved after JSON serialization"
            )
    
    @given(
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_5_policy_statements_are_distinct(
        self,
        agent_arns: List[str],
        memory_arns: List[str]
    ):
        """
        Property: Agent and memory statements are distinct and don't overlap.
        
        This test verifies that:
        1. Agent ARNs only appear in the InvokeRuntime statement
        2. Memory ARNs only appear in the memory access statement
        3. No ARN appears in multiple statements
        4. Statements have different actions
        
        **Validates: Requirements 2.7, 2.8**
        """
        # Skip if both lists are empty
        assume(agent_arns or memory_arns)
        
        # Create mock boto3 session
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        # Collect all resources from all statements
        all_resources_by_statement = []
        for statement in policy['Statement']:
            all_resources_by_statement.append(set(statement['Resource']))
        
        # Property assertion: No resource appears in multiple statements
        if len(all_resources_by_statement) > 1:
            for i in range(len(all_resources_by_statement)):
                for j in range(i + 1, len(all_resources_by_statement)):
                    overlap = all_resources_by_statement[i] & all_resources_by_statement[j]
                    assert len(overlap) == 0, (
                        f"Statements must not share resources. "
                        f"Found overlap: {overlap}"
                    )
        
        # Property assertion: Agent ARNs only in InvokeRuntime statement
        if agent_arns:
            for statement in policy['Statement']:
                if 'bedrock-agentcore:InvokeRuntime' in statement.get('Action', []):
                    # This is the agent statement
                    assert set(statement['Resource']) == set(agent_arns), (
                        "InvokeRuntime statement must contain exactly the agent ARNs"
                    )
                else:
                    # This is not the agent statement
                    for arn in agent_arns:
                        assert arn not in statement['Resource'], (
                            f"Agent ARN {arn} must not appear in non-InvokeRuntime statement"
                        )
        
        # Property assertion: Memory ARNs only in memory access statement
        if memory_arns:
            for statement in policy['Statement']:
                if 'bedrock-agentcore:GetMemory' in statement.get('Action', []):
                    # This is the memory statement
                    assert set(statement['Resource']) == set(memory_arns), (
                        "Memory access statement must contain exactly the memory ARNs"
                    )
                else:
                    # This is not the memory statement
                    for arn in memory_arns:
                        assert arn not in statement['Resource'], (
                            f"Memory ARN {arn} must not appear in non-memory statement"
                        )


# ============================================================================
# Unit Tests for Edge Cases
# ============================================================================

class TestCrossAgentPolicyCompletenessEdgeCases:
    """Unit tests for specific edge cases in cross-agent policy completeness."""
    
    def test_empty_agent_and_memory_arns_produces_empty_statements(self):
        """Test that policy with no ARNs has no statements."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with no ARNs
        policy = iam_manager.create_cross_agent_policy([], [])
        
        # Should have no statements
        assert len(policy['Statement']) == 0
        assert policy['Version'] == '2012-10-17'
    
    def test_single_agent_arn_produces_valid_policy(self):
        """Test that policy with single agent ARN is valid."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with single agent ARN
        agent_arns = ['arn:aws:bedrock:us-east-1:123456789012:agent/test-agent']
        policy = iam_manager.create_cross_agent_policy(agent_arns, [])
        
        # Should have one statement
        assert len(policy['Statement']) == 1
        assert policy['Statement'][0]['Resource'] == agent_arns
        assert 'bedrock-agentcore:InvokeRuntime' in policy['Statement'][0]['Action']
    
    def test_single_memory_arn_produces_valid_policy(self):
        """Test that policy with single memory ARN is valid."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with single memory ARN
        memory_arns = ['arn:aws:bedrock:us-east-1:123456789012:memory/test-memory']
        policy = iam_manager.create_cross_agent_policy([], memory_arns)
        
        # Should have one statement
        assert len(policy['Statement']) == 1
        assert policy['Statement'][0]['Resource'] == memory_arns
        assert 'bedrock-agentcore:GetMemory' in policy['Statement'][0]['Action']
        assert 'bedrock-agentcore:PutMemory' in policy['Statement'][0]['Action']
    
    def test_many_agent_arns_all_included(self):
        """Test that policy with many agent ARNs includes all of them."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with many agent ARNs
        agent_arns = [
            f'arn:aws:bedrock:us-east-1:123456789012:agent/agent-{i}'
            for i in range(20)
        ]
        policy = iam_manager.create_cross_agent_policy(agent_arns, [])
        
        # All ARNs should be included
        agent_statement = policy['Statement'][0]
        assert set(agent_statement['Resource']) == set(agent_arns)
        assert len(agent_statement['Resource']) == 20
    
    def test_many_memory_arns_all_included(self):
        """Test that policy with many memory ARNs includes all of them."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with many memory ARNs
        memory_arns = [
            f'arn:aws:bedrock:us-east-1:123456789012:memory/memory-{i}'
            for i in range(20)
        ]
        policy = iam_manager.create_cross_agent_policy([], memory_arns)
        
        # All ARNs should be included
        memory_statement = policy['Statement'][0]
        assert set(memory_statement['Resource']) == set(memory_arns)
        assert len(memory_statement['Resource']) == 20
    
    def test_mixed_regions_and_accounts_in_arns(self):
        """Test that policy handles ARNs from different regions and accounts."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create ARNs with different regions and accounts
        agent_arns = [
            'arn:aws:bedrock:us-east-1:111111111111:agent/agent-1',
            'arn:aws:bedrock:us-west-2:222222222222:agent/agent-2',
            'arn:aws:bedrock:eu-west-1:333333333333:agent/agent-3',
        ]
        memory_arns = [
            'arn:aws:bedrock:us-east-1:111111111111:memory/memory-1',
            'arn:aws:bedrock:ap-southeast-1:444444444444:memory/memory-2',
        ]
        
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        # All ARNs should be included regardless of region/account
        agent_statement = next(
            s for s in policy['Statement']
            if 'bedrock-agentcore:InvokeRuntime' in s['Action']
        )
        memory_statement = next(
            s for s in policy['Statement']
            if 'bedrock-agentcore:GetMemory' in s['Action']
        )
        
        assert set(agent_statement['Resource']) == set(agent_arns)
        assert set(memory_statement['Resource']) == set(memory_arns)
