"""
Unit tests for ConfigurationManager.

Tests configuration loading, validation, and deployment order calculation.
"""

import os
import pytest
import tempfile
import yaml
from pathlib import Path

# Import from parent package
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from managers.config_manager import ConfigurationManager, ValidationError
from models import AgentConfig, DeploymentConfig


class TestConfigurationManager:
    """Test suite for ConfigurationManager class."""
    
    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    def valid_config_dict(self):
        """Return a valid configuration dictionary."""
        return {
            'aws_account_id': '123456789012',
            'aws_region': 'us-east-1',
            'agents': [
                {
                    'name': 'custom-ads-a2a-agent',
                    'directory': 'custom-ads-a2a-agent',
                    'entrypoint': 'langgraph_a2a.py',
                    'language': 'python',
                    'platform': 'linux/arm64',
                    'memory_mode': 'STM_ONLY',
                    'server_protocol': 'A2A',
                    'dependencies': [],
                    'environment_variables': {}
                },
                {
                    'name': 'orchestration-a2a-agent',
                    'directory': 'orchestration-a2a-agent',
                    'entrypoint': 'orchestration_a2a.py',
                    'language': 'python',
                    'platform': 'linux/arm64',
                    'memory_mode': 'STM_ONLY',
                    'server_protocol': 'A2A',
                    'dependencies': ['custom-ads-a2a-agent'],
                    'environment_variables': {}
                }
            ],
            'iam_policies': {
                'base_policy': {
                    'Version': '2012-10-17',
                    'Statement': []
                },
                'cross_agent_policy_template': {
                    'Version': '2012-10-17',
                    'Statement': []
                }
            },
            'deployment_order': ['custom-ads-a2a-agent', 'orchestration-a2a-agent']
        }
    
    @pytest.fixture
    def config_file(self, temp_dir, valid_config_dict):
        """Create a valid configuration file."""
        config_path = temp_dir / "deployment.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        return config_path
    
    @pytest.fixture
    def config_with_agent_dirs(self, temp_dir, valid_config_dict):
        """Create a configuration file with actual agent directories."""
        # Create agent directories
        for agent in valid_config_dict['agents']:
            agent_dir = temp_dir / agent['directory']
            agent_dir.mkdir(parents=True, exist_ok=True)
            
            # Create entrypoint file
            entrypoint = agent_dir / agent['entrypoint']
            entrypoint.write_text("# Agent entrypoint")
            
            # Create requirements.txt
            requirements = agent_dir / "requirements.txt"
            requirements.write_text("boto3\npyyaml\n")
        
        # Create config file
        config_path = temp_dir / "deployment.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        return config_path
    
    def test_init(self, config_file):
        """Test ConfigurationManager initialization."""
        manager = ConfigurationManager(str(config_file))
        assert manager.config_path == config_file
        assert manager.config is None
        assert manager._raw_config is None
    
    def test_load_config_success(self, config_file):
        """Test successful configuration loading."""
        manager = ConfigurationManager(str(config_file))
        config = manager.load_config()
        
        assert isinstance(config, DeploymentConfig)
        assert config.aws_account_id == '123456789012'
        assert config.aws_region == 'us-east-1'
        assert len(config.agents) == 2
        assert config.agents[0].name == 'custom-ads-a2a-agent'
        assert config.agents[1].name == 'orchestration-a2a-agent'
    
    def test_load_config_file_not_found(self, temp_dir):
        """Test loading non-existent configuration file."""
        manager = ConfigurationManager(str(temp_dir / "nonexistent.yaml"))
        
        with pytest.raises(FileNotFoundError):
            manager.load_config()
    
    def test_load_config_invalid_yaml(self, temp_dir):
        """Test loading invalid YAML file."""
        config_path = temp_dir / "invalid.yaml"
        config_path.write_text("invalid: yaml: content: [")
        
        manager = ConfigurationManager(str(config_path))
        
        with pytest.raises(ValidationError) as exc_info:
            manager.load_config()
        assert "yaml_parsing" in str(exc_info.value)
    
    def test_load_config_not_dict(self, temp_dir):
        """Test loading YAML that's not a dictionary."""
        config_path = temp_dir / "list.yaml"
        config_path.write_text("- item1\n- item2\n")
        
        manager = ConfigurationManager(str(config_path))
        
        with pytest.raises(ValidationError) as exc_info:
            manager.load_config()
        assert "config_root" in str(exc_info.value)
    
    def test_validate_config_success(self, config_file):
        """Test successful configuration validation."""
        manager = ConfigurationManager(str(config_file))
        manager.load_config()
        
        errors = manager.validate_config()
        assert len(errors) == 0
    
    def test_validate_config_not_loaded(self):
        """Test validation without loading config first."""
        manager = ConfigurationManager("dummy.yaml")
        
        errors = manager.validate_config()
        assert len(errors) == 1
        assert "config" in errors[0].field
    
    def test_validate_config_missing_aws_account_id(self, temp_dir, valid_config_dict):
        """Test validation with missing AWS account ID."""
        valid_config_dict['aws_account_id'] = ''
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('aws_account_id' in e.field for e in errors)
    
    def test_validate_config_invalid_aws_account_id(self, temp_dir, valid_config_dict):
        """Test validation with invalid AWS account ID."""
        valid_config_dict['aws_account_id'] = 'abc123'
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('aws_account_id' in e.field for e in errors)
    
    def test_validate_config_wrong_length_account_id(self, temp_dir, valid_config_dict):
        """Test validation with wrong length AWS account ID."""
        valid_config_dict['aws_account_id'] = '12345'
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('aws_account_id' in e.field and '12 digits' in e.message for e in errors)
    
    def test_validate_config_missing_region(self, temp_dir, valid_config_dict):
        """Test validation with missing AWS region."""
        valid_config_dict['aws_region'] = ''
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('aws_region' in e.field for e in errors)
    
    def test_validate_config_invalid_region(self, temp_dir, valid_config_dict):
        """Test validation with invalid AWS region format."""
        valid_config_dict['aws_region'] = 'invalid-region'
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('aws_region' in e.field for e in errors)
    
    def test_validate_config_no_agents(self, temp_dir, valid_config_dict):
        """Test validation with no agents defined."""
        valid_config_dict['agents'] = []
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('agents' in e.field for e in errors)
    
    def test_validate_config_agent_missing_name(self, temp_dir, valid_config_dict):
        """Test validation with agent missing name."""
        valid_config_dict['agents'][0]['name'] = ''
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('name' in e.field for e in errors)
    
    def test_validate_config_agent_missing_directory(self, temp_dir, valid_config_dict):
        """Test validation with agent missing directory."""
        valid_config_dict['agents'][0]['directory'] = ''
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('directory' in e.field for e in errors)
    
    def test_validate_config_agent_missing_entrypoint(self, temp_dir, valid_config_dict):
        """Test validation with agent missing entrypoint."""
        valid_config_dict['agents'][0]['entrypoint'] = ''
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('entrypoint' in e.field for e in errors)
    
    def test_validate_config_invalid_protocol(self, temp_dir, valid_config_dict):
        """Test validation with invalid server protocol."""
        valid_config_dict['agents'][0]['server_protocol'] = 'INVALID'
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('server_protocol' in e.field for e in errors)
    
    def test_validate_config_invalid_memory_mode(self, temp_dir, valid_config_dict):
        """Test validation with invalid memory mode."""
        valid_config_dict['agents'][0]['memory_mode'] = 'INVALID'
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('memory_mode' in e.field for e in errors)
    
    def test_validate_config_deployment_order_mismatch(self, temp_dir, valid_config_dict):
        """Test validation with deployment order referencing non-existent agent."""
        valid_config_dict['deployment_order'].append('nonexistent-agent')
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_config()
        
        assert any('deployment_order' in e.field for e in errors)
    
    def test_validate_agent_directories_success(self, config_with_agent_dirs):
        """Test successful agent directory validation."""
        manager = ConfigurationManager(str(config_with_agent_dirs))
        manager.load_config()
        
        errors = manager.validate_agent_directories()
        assert len(errors) == 0
    
    def test_validate_agent_directories_missing_directory(self, config_file):
        """Test validation with missing agent directory."""
        manager = ConfigurationManager(str(config_file))
        manager.load_config()
        
        errors = manager.validate_agent_directories()
        assert len(errors) > 0
        assert any('directory' in e.field for e in errors)
    
    def test_validate_agent_directories_missing_entrypoint(self, temp_dir, valid_config_dict):
        """Test validation with missing entrypoint file."""
        # Create agent directories but not entrypoint files
        for agent in valid_config_dict['agents']:
            agent_dir = temp_dir / agent['directory']
            agent_dir.mkdir(parents=True, exist_ok=True)
        
        config_path = temp_dir / "deployment.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_agent_directories()
        
        assert any('entrypoint' in e.field for e in errors)
    
    def test_validate_agent_directories_missing_requirements(self, temp_dir, valid_config_dict):
        """Test validation with missing requirements.txt (should be warning)."""
        # Create agent directories and entrypoints but not requirements.txt
        for agent in valid_config_dict['agents']:
            agent_dir = temp_dir / agent['directory']
            agent_dir.mkdir(parents=True, exist_ok=True)
            
            entrypoint = agent_dir / agent['entrypoint']
            entrypoint.write_text("# Agent entrypoint")
        
        config_path = temp_dir / "deployment.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        errors = manager.validate_agent_directories()
        
        assert any('requirements' in e.field for e in errors)
    
    def test_get_agents_in_deployment_order_explicit(self, config_file):
        """Test getting agents in explicit deployment order."""
        manager = ConfigurationManager(str(config_file))
        manager.load_config()
        
        ordered_agents = manager.get_agents_in_deployment_order()
        
        assert len(ordered_agents) == 2
        assert ordered_agents[0].name == 'custom-ads-a2a-agent'
        assert ordered_agents[1].name == 'orchestration-a2a-agent'
    
    def test_get_agents_in_deployment_order_topological(self, temp_dir, valid_config_dict):
        """Test getting agents in topological order (no explicit order)."""
        # Remove explicit deployment order
        del valid_config_dict['deployment_order']
        
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        
        ordered_agents = manager.get_agents_in_deployment_order()
        
        # Sub-agent should come before orchestration agent
        assert len(ordered_agents) == 2
        assert ordered_agents[0].name == 'custom-ads-a2a-agent'
        assert ordered_agents[1].name == 'orchestration-a2a-agent'
    
    def test_get_agents_in_deployment_order_circular_dependency(self, temp_dir, valid_config_dict):
        """Test detection of circular dependencies."""
        # Create circular dependency
        valid_config_dict['agents'][0]['dependencies'] = ['orchestration-a2a-agent']
        del valid_config_dict['deployment_order']
        
        config_path = temp_dir / "config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(valid_config_dict, f)
        
        manager = ConfigurationManager(str(config_path))
        manager.load_config()
        
        with pytest.raises(ValidationError) as exc_info:
            manager.get_agents_in_deployment_order()
        assert "Circular dependencies" in str(exc_info.value)
    
    def test_get_agents_in_deployment_order_not_loaded(self):
        """Test getting deployment order without loading config first."""
        manager = ConfigurationManager("dummy.yaml")
        
        with pytest.raises(ValueError):
            manager.get_agents_in_deployment_order()
    
    def test_is_valid_aws_region(self, config_file):
        """Test AWS region validation."""
        manager = ConfigurationManager(str(config_file))
        
        # Valid regions
        assert manager._is_valid_aws_region('us-east-1')
        assert manager._is_valid_aws_region('eu-west-2')
        assert manager._is_valid_aws_region('ap-southeast-1')
        assert manager._is_valid_aws_region('sa-east-1')
        
        # Invalid regions
        assert not manager._is_valid_aws_region('')
        assert not manager._is_valid_aws_region('invalid')
        assert not manager._is_valid_aws_region('us-east')
        assert not manager._is_valid_aws_region('xx-west-1')
        assert not manager._is_valid_aws_region('us-east-x')
