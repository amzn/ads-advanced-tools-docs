"""
Unit tests for StateManager.

Tests state persistence, loading, saving, and cleanup operations.
Validates Requirements: 9.1, 9.2
"""

import json
import os
import pytest
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

from deployment_tool.managers.state_manager import StateManager
from deployment_tool.models.data_models import (
    DeploymentState,
    AgentDeploymentState
)


class TestStateManager:
    """Test suite for StateManager class."""
    
    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test state files."""
        with TemporaryDirectory() as tmpdir:
            yield tmpdir
    
    @pytest.fixture
    def state_file_path(self, temp_dir):
        """Create a temporary state file path."""
        return os.path.join(temp_dir, "test_state.json")
    
    @pytest.fixture
    def state_manager(self, state_file_path):
        """Create a StateManager instance with temporary state file."""
        return StateManager(state_file_path)
    
    @pytest.fixture
    def sample_agent_state(self):
        """Create a sample agent deployment state."""
        return AgentDeploymentState(
            agent_name="test-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/test-agent-id",
            execution_role_arn="arn:aws:iam::123456789012:role/TestRole",
            ecr_repository_uri="123456789012.dkr.ecr.us-east-1.amazonaws.com/test-agent",
            codebuild_project_name="test-agent-builder",
            memory_arn="arn:aws:bedrock:us-east-1:123456789012:memory/test-memory",
            deployed_at=datetime.now()
        )
    
    def test_init_creates_state_manager(self, state_file_path):
        """Test StateManager initialization."""
        manager = StateManager(state_file_path)
        assert manager.state_file_path == Path(state_file_path)
    
    def test_init_default_path(self):
        """Test StateManager initialization with default path."""
        manager = StateManager()
        assert manager.state_file_path == Path(".deployment_state.json")
    
    def test_load_state_empty_when_file_not_exists(self, state_manager):
        """Test loading state returns empty state when file doesn't exist."""
        state = state_manager.load_state()
        
        assert isinstance(state, DeploymentState)
        assert len(state.agents) == 0
        assert isinstance(state.last_deployment, datetime)
        assert state.deployment_version == "1.0.0"
    
    def test_save_and_load_state(self, state_manager, sample_agent_state):
        """Test saving and loading state."""
        # Create state with sample agent
        state = DeploymentState(
            agents={"test-agent": sample_agent_state},
            last_deployment=datetime.now(),
            deployment_version="1.0.0"
        )
        
        # Save state
        state_manager.save_state(state)
        
        # Load state
        loaded_state = state_manager.load_state()
        
        # Verify loaded state matches saved state
        assert len(loaded_state.agents) == 1
        assert "test-agent" in loaded_state.agents
        
        loaded_agent = loaded_state.agents["test-agent"]
        assert loaded_agent.agent_name == sample_agent_state.agent_name
        assert loaded_agent.agent_arn == sample_agent_state.agent_arn
        assert loaded_agent.execution_role_arn == sample_agent_state.execution_role_arn
        assert loaded_agent.ecr_repository_uri == sample_agent_state.ecr_repository_uri
        assert loaded_agent.codebuild_project_name == sample_agent_state.codebuild_project_name
        assert loaded_agent.memory_arn == sample_agent_state.memory_arn
    
    def test_save_state_creates_file(self, state_manager, sample_agent_state):
        """Test that save_state creates the state file."""
        state = DeploymentState(
            agents={"test-agent": sample_agent_state},
            last_deployment=datetime.now(),
            deployment_version="1.0.0"
        )
        
        state_manager.save_state(state)
        
        assert state_manager.state_file_path.exists()
    
    def test_save_state_json_format(self, state_manager, sample_agent_state):
        """Test that saved state is valid JSON with correct structure."""
        state = DeploymentState(
            agents={"test-agent": sample_agent_state},
            last_deployment=datetime.now(),
            deployment_version="1.0.0"
        )
        
        state_manager.save_state(state)
        
        # Read and parse JSON
        with open(state_manager.state_file_path, 'r') as f:
            data = json.load(f)
        
        # Verify structure
        assert 'agents' in data
        assert 'last_deployment' in data
        assert 'deployment_version' in data
        assert 'test-agent' in data['agents']
        
        agent_data = data['agents']['test-agent']
        assert agent_data['agent_name'] == "test-agent"
        assert agent_data['agent_arn'] == sample_agent_state.agent_arn
        assert agent_data['execution_role_arn'] == sample_agent_state.execution_role_arn
    
    def test_record_agent_deployment(self, state_manager):
        """Test recording a new agent deployment."""
        state_manager.record_agent_deployment(
            agent_name="new-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/new-agent-id",
            execution_role_arn="arn:aws:iam::123456789012:role/NewRole",
            ecr_repository_uri="123456789012.dkr.ecr.us-east-1.amazonaws.com/new-agent",
            codebuild_project_name="new-agent-builder",
            memory_arn="arn:aws:bedrock:us-east-1:123456789012:memory/new-memory"
        )
        
        # Verify agent was recorded
        state = state_manager.load_state()
        assert "new-agent" in state.agents
        
        agent = state.agents["new-agent"]
        assert agent.agent_name == "new-agent"
        assert agent.agent_arn == "arn:aws:bedrock:us-east-1:123456789012:agent/new-agent-id"
        assert agent.execution_role_arn == "arn:aws:iam::123456789012:role/NewRole"
        assert agent.memory_arn == "arn:aws:bedrock:us-east-1:123456789012:memory/new-memory"
    
    def test_record_agent_deployment_without_memory(self, state_manager):
        """Test recording agent deployment without memory ARN."""
        state_manager.record_agent_deployment(
            agent_name="no-memory-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/no-memory-id",
            execution_role_arn="arn:aws:iam::123456789012:role/NoMemoryRole",
            ecr_repository_uri="123456789012.dkr.ecr.us-east-1.amazonaws.com/no-memory",
            codebuild_project_name="no-memory-builder"
        )
        
        state = state_manager.load_state()
        agent = state.agents["no-memory-agent"]
        assert agent.memory_arn is None
    
    def test_record_agent_deployment_updates_existing(self, state_manager):
        """Test that recording an agent deployment updates existing entry."""
        # Record first deployment
        state_manager.record_agent_deployment(
            agent_name="update-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/old-id",
            execution_role_arn="arn:aws:iam::123456789012:role/OldRole",
            ecr_repository_uri="old-uri",
            codebuild_project_name="old-builder"
        )
        
        # Record updated deployment
        state_manager.record_agent_deployment(
            agent_name="update-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/new-id",
            execution_role_arn="arn:aws:iam::123456789012:role/NewRole",
            ecr_repository_uri="new-uri",
            codebuild_project_name="new-builder"
        )
        
        # Verify only one entry exists with updated values
        state = state_manager.load_state()
        assert len(state.agents) == 1
        
        agent = state.agents["update-agent"]
        assert agent.agent_arn == "arn:aws:bedrock:us-east-1:123456789012:agent/new-id"
        assert agent.execution_role_arn == "arn:aws:iam::123456789012:role/NewRole"
    
    def test_get_agent_arn_existing(self, state_manager):
        """Test retrieving ARN for existing agent."""
        state_manager.record_agent_deployment(
            agent_name="existing-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/existing-id",
            execution_role_arn="arn:aws:iam::123456789012:role/ExistingRole",
            ecr_repository_uri="uri",
            codebuild_project_name="builder"
        )
        
        arn = state_manager.get_agent_arn("existing-agent")
        assert arn == "arn:aws:bedrock:us-east-1:123456789012:agent/existing-id"
    
    def test_get_agent_arn_nonexistent(self, state_manager):
        """Test retrieving ARN for non-existent agent returns None."""
        arn = state_manager.get_agent_arn("nonexistent-agent")
        assert arn is None
    
    def test_get_agent_state_existing(self, state_manager):
        """Test retrieving full state for existing agent."""
        state_manager.record_agent_deployment(
            agent_name="state-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/state-id",
            execution_role_arn="arn:aws:iam::123456789012:role/StateRole",
            ecr_repository_uri="state-uri",
            codebuild_project_name="state-builder",
            memory_arn="arn:aws:bedrock:us-east-1:123456789012:memory/state-memory"
        )
        
        agent_state = state_manager.get_agent_state("state-agent")
        
        assert agent_state is not None
        assert agent_state.agent_name == "state-agent"
        assert agent_state.agent_arn == "arn:aws:bedrock:us-east-1:123456789012:agent/state-id"
        assert agent_state.execution_role_arn == "arn:aws:iam::123456789012:role/StateRole"
        assert agent_state.memory_arn == "arn:aws:bedrock:us-east-1:123456789012:memory/state-memory"
    
    def test_get_agent_state_nonexistent(self, state_manager):
        """Test retrieving state for non-existent agent returns None."""
        agent_state = state_manager.get_agent_state("nonexistent-agent")
        assert agent_state is None
    
    def test_clear_state_removes_file(self, state_manager, sample_agent_state):
        """Test that clear_state removes the state file."""
        # Create state file
        state = DeploymentState(
            agents={"test-agent": sample_agent_state},
            last_deployment=datetime.now(),
            deployment_version="1.0.0"
        )
        state_manager.save_state(state)
        
        assert state_manager.state_file_path.exists()
        
        # Clear state
        state_manager.clear_state()
        
        assert not state_manager.state_file_path.exists()
    
    def test_clear_state_when_file_not_exists(self, state_manager):
        """Test that clear_state doesn't raise error when file doesn't exist."""
        # Should not raise an error
        state_manager.clear_state()
        assert not state_manager.state_file_path.exists()
    
    def test_get_all_agent_arns(self, state_manager):
        """Test retrieving all agent ARNs as dictionary."""
        # Record multiple agents
        state_manager.record_agent_deployment(
            agent_name="agent1",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/agent1-id",
            execution_role_arn="arn:aws:iam::123456789012:role/Role1",
            ecr_repository_uri="uri1",
            codebuild_project_name="builder1"
        )
        
        state_manager.record_agent_deployment(
            agent_name="agent2",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/agent2-id",
            execution_role_arn="arn:aws:iam::123456789012:role/Role2",
            ecr_repository_uri="uri2",
            codebuild_project_name="builder2"
        )
        
        arns = state_manager.get_all_agent_arns()
        
        assert len(arns) == 2
        assert arns["agent1"] == "arn:aws:bedrock:us-east-1:123456789012:agent/agent1-id"
        assert arns["agent2"] == "arn:aws:bedrock:us-east-1:123456789012:agent/agent2-id"
    
    def test_get_all_agent_arns_empty(self, state_manager):
        """Test retrieving all agent ARNs when no agents deployed."""
        arns = state_manager.get_all_agent_arns()
        assert len(arns) == 0
        assert arns == {}
    
    def test_has_agent_true(self, state_manager):
        """Test has_agent returns True for deployed agent."""
        state_manager.record_agent_deployment(
            agent_name="deployed-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/deployed-id",
            execution_role_arn="arn:aws:iam::123456789012:role/DeployedRole",
            ecr_repository_uri="uri",
            codebuild_project_name="builder"
        )
        
        assert state_manager.has_agent("deployed-agent") is True
    
    def test_has_agent_false(self, state_manager):
        """Test has_agent returns False for non-deployed agent."""
        assert state_manager.has_agent("nonexistent-agent") is False
    
    def test_load_state_corrupted_json(self, state_manager):
        """Test loading state with corrupted JSON raises error."""
        # Write invalid JSON
        with open(state_manager.state_file_path, 'w') as f:
            f.write("{ invalid json }")
        
        with pytest.raises(json.JSONDecodeError):
            state_manager.load_state()
    
    def test_load_state_missing_agents_field(self, state_manager):
        """Test loading state with missing agents field raises error."""
        # Write JSON without agents field
        with open(state_manager.state_file_path, 'w') as f:
            json.dump({
                "last_deployment": datetime.now().isoformat(),
                "deployment_version": "1.0.0"
            }, f)
        
        with pytest.raises(ValueError, match="missing 'agents' field"):
            state_manager.load_state()
    
    def test_load_state_invalid_structure(self, state_manager):
        """Test loading state with invalid structure raises error."""
        # Write JSON that's not an object
        with open(state_manager.state_file_path, 'w') as f:
            json.dump(["not", "an", "object"], f)
        
        with pytest.raises(ValueError, match="must contain a JSON object"):
            state_manager.load_state()
    
    def test_multiple_agents_deployment(self, state_manager):
        """Test recording multiple agent deployments."""
        agents = [
            ("agent1", "arn1", "role1"),
            ("agent2", "arn2", "role2"),
            ("agent3", "arn3", "role3"),
        ]
        
        for name, arn, role in agents:
            state_manager.record_agent_deployment(
                agent_name=name,
                agent_arn=arn,
                execution_role_arn=role,
                ecr_repository_uri=f"{name}-uri",
                codebuild_project_name=f"{name}-builder"
            )
        
        state = state_manager.load_state()
        assert len(state.agents) == 3
        
        for name, arn, role in agents:
            assert name in state.agents
            assert state.agents[name].agent_arn == arn
            assert state.agents[name].execution_role_arn == role
    
    def test_state_persistence_across_instances(self, state_file_path):
        """Test that state persists across different StateManager instances."""
        # Create first instance and record deployment
        manager1 = StateManager(state_file_path)
        manager1.record_agent_deployment(
            agent_name="persistent-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/persistent-id",
            execution_role_arn="arn:aws:iam::123456789012:role/PersistentRole",
            ecr_repository_uri="persistent-uri",
            codebuild_project_name="persistent-builder"
        )
        
        # Create second instance and verify state
        manager2 = StateManager(state_file_path)
        arn = manager2.get_agent_arn("persistent-agent")
        
        assert arn == "arn:aws:bedrock:us-east-1:123456789012:agent/persistent-id"
    
    def test_timestamp_preservation(self, state_manager):
        """Test that deployment timestamps are preserved correctly."""
        before_deployment = datetime.now()
        
        state_manager.record_agent_deployment(
            agent_name="timestamp-agent",
            agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/timestamp-id",
            execution_role_arn="arn:aws:iam::123456789012:role/TimestampRole",
            ecr_repository_uri="timestamp-uri",
            codebuild_project_name="timestamp-builder"
        )
        
        after_deployment = datetime.now()
        
        agent_state = state_manager.get_agent_state("timestamp-agent")
        
        # Verify timestamp is between before and after
        assert before_deployment <= agent_state.deployed_at <= after_deployment
