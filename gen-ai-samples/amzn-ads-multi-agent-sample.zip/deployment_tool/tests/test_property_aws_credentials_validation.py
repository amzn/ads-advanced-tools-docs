"""
Property-Based Test: AWS Credentials Validation

Property 10: AWS Credentials Validation
For any deployment execution, AWS credentials must be validated before any 
resource creation operations begin.

This test validates Requirements 11.1, 11.6, 14.4:
- 11.1: Use AWS credentials from standard locations
- 11.6: Validate AWS credentials before starting deployment
- 14.4: Verify AWS credentials are valid

Test Strategy:
- Generate various credential configurations (valid, invalid, missing)
- Verify that validate_credentials() is called before any operations
- Verify that invalid credentials are detected and reported
- Verify that valid credentials return proper identity information

Minimum 100 iterations per property test.
"""

import pytest
from hypothesis import given, strategies as st, settings, HealthCheck
from unittest.mock import Mock, patch, MagicMock
from botocore.exceptions import ClientError, NoCredentialsError

from deployment_tool.managers.aws_resource_manager import AWSResourceManager


# Strategy for generating AWS regions
aws_regions = st.sampled_from([
    'us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1'
])

# Strategy for generating credential scenarios
credential_scenarios = st.sampled_from([
    'valid',
    'invalid_key_id',
    'invalid_secret',
    'no_credentials',
    'access_denied'
])


@given(
    region=aws_regions,
    scenario=credential_scenarios
)
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture]
)
def test_property_credentials_validated_before_operations(region, scenario):
    """
    Property: AWS credentials must be validated before any resource operations.
    
    For any credential configuration, validate_credentials() must be called
    and must correctly identify valid vs invalid credentials before allowing
    any resource creation operations.
    
    **Validates: Requirements 11.1, 11.6, 14.4**
    """
    with patch('deployment_tool.managers.aws_resource_manager.boto3.Session') as mock_session_class:
        # Setup mock session
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Setup mock STS client
        mock_sts = Mock()
        mock_session.client.return_value = mock_sts
        
        # Configure mock based on scenario
        if scenario == 'valid':
            # Valid credentials - return proper identity
            mock_sts.get_caller_identity.return_value = {
                'Account': '123456789012',
                'UserId': 'AIDAI123456789EXAMPLE',
                'Arn': 'arn:aws:iam::123456789012:user/testuser'
            }
            
            # Create manager and validate
            manager = AWSResourceManager(region=region)
            result = manager.validate_credentials()
            
            # Verify validation was called
            mock_sts.get_caller_identity.assert_called_once()
            
            # Verify result contains expected fields
            assert 'account_id' in result
            assert 'user_id' in result
            assert 'arn' in result
            assert result['account_id'] == '123456789012'
            
        elif scenario == 'invalid_key_id':
            # Invalid access key ID
            mock_sts.get_caller_identity.side_effect = ClientError(
                {
                    'Error': {
                        'Code': 'InvalidClientTokenId',
                        'Message': 'The security token included in the request is invalid'
                    }
                },
                'GetCallerIdentity'
            )
            
            manager = AWSResourceManager(region=region)
            
            # Validation should raise exception with specific message
            with pytest.raises(Exception) as exc_info:
                manager.validate_credentials()
            
            assert 'access key ID does not exist' in str(exc_info.value)
            mock_sts.get_caller_identity.assert_called_once()
            
        elif scenario == 'invalid_secret':
            # Invalid secret access key
            mock_sts.get_caller_identity.side_effect = ClientError(
                {
                    'Error': {
                        'Code': 'SignatureDoesNotMatch',
                        'Message': 'The request signature we calculated does not match'
                    }
                },
                'GetCallerIdentity'
            )
            
            manager = AWSResourceManager(region=region)
            
            # Validation should raise exception with specific message
            with pytest.raises(Exception) as exc_info:
                manager.validate_credentials()
            
            assert 'secret access key is incorrect' in str(exc_info.value)
            mock_sts.get_caller_identity.assert_called_once()
            
        elif scenario == 'no_credentials':
            # No credentials configured
            mock_sts.get_caller_identity.side_effect = NoCredentialsError()
            
            manager = AWSResourceManager(region=region)
            
            # Validation should raise exception about missing credentials
            with pytest.raises(Exception) as exc_info:
                manager.validate_credentials()
            
            assert 'credentials not found' in str(exc_info.value).lower()
            mock_sts.get_caller_identity.assert_called_once()
            
        elif scenario == 'access_denied':
            # Credentials valid but no permission
            mock_sts.get_caller_identity.side_effect = ClientError(
                {
                    'Error': {
                        'Code': 'AccessDenied',
                        'Message': 'User is not authorized to perform: sts:GetCallerIdentity'
                    }
                },
                'GetCallerIdentity'
            )
            
            manager = AWSResourceManager(region=region)
            
            # Validation should raise exception about permissions
            with pytest.raises(Exception) as exc_info:
                manager.validate_credentials()
            
            assert 'permission' in str(exc_info.value).lower()
            mock_sts.get_caller_identity.assert_called_once()


@given(
    region=aws_regions,
    account_id=st.text(
        alphabet=st.characters(whitelist_categories=('Nd',)),
        min_size=12,
        max_size=12
    )
)
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture]
)
def test_property_validation_returns_consistent_identity(region, account_id):
    """
    Property: Credential validation must return consistent identity information.
    
    For any valid credentials, validate_credentials() must return the same
    identity information (account_id, user_id, arn) on repeated calls.
    
    **Validates: Requirements 11.6, 14.4**
    """
    with patch('deployment_tool.managers.aws_resource_manager.boto3.Session') as mock_session_class:
        # Setup mock session
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Setup mock STS client with consistent response
        mock_sts = Mock()
        mock_session.client.return_value = mock_sts
        
        expected_response = {
            'Account': account_id,
            'UserId': f'AIDAI{account_id[:17]}',
            'Arn': f'arn:aws:iam::{account_id}:user/testuser'
        }
        mock_sts.get_caller_identity.return_value = expected_response
        
        # Create manager
        manager = AWSResourceManager(region=region)
        
        # Call validation multiple times
        result1 = manager.validate_credentials()
        result2 = manager.validate_credentials()
        result3 = manager.validate_credentials()
        
        # All results should be identical
        assert result1 == result2 == result3
        
        # All results should contain expected account ID
        assert result1['account_id'] == account_id
        assert result2['account_id'] == account_id
        assert result3['account_id'] == account_id
        
        # Verify validation was called each time
        assert mock_sts.get_caller_identity.call_count == 3


@given(region=aws_regions)
@settings(
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.function_scoped_fixture]
)
def test_property_validation_fails_fast_on_invalid_credentials(region):
    """
    Property: Invalid credentials must be detected immediately.
    
    For any invalid credential configuration, validate_credentials() must
    fail immediately without attempting any resource operations.
    
    **Validates: Requirements 11.6, 14.4**
    """
    with patch('deployment_tool.managers.aws_resource_manager.boto3.Session') as mock_session_class:
        # Setup mock session
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Setup mock clients
        mock_sts = Mock()
        mock_iam = Mock()
        mock_s3 = Mock()
        
        def client_factory(service_name):
            if service_name == 'sts':
                return mock_sts
            elif service_name == 'iam':
                return mock_iam
            elif service_name == 's3':
                return mock_s3
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Configure STS to fail
        mock_sts.get_caller_identity.side_effect = ClientError(
            {
                'Error': {
                    'Code': 'InvalidClientTokenId',
                    'Message': 'Invalid credentials'
                }
            },
            'GetCallerIdentity'
        )
        
        # Create manager
        manager = AWSResourceManager(region=region)
        
        # Validation should fail
        with pytest.raises(Exception):
            manager.validate_credentials()
        
        # Verify no other AWS operations were attempted
        mock_iam.get_role.assert_not_called()
        mock_iam.create_role.assert_not_called()
        mock_s3.head_bucket.assert_not_called()
        mock_s3.create_bucket.assert_not_called()
        
        # Only STS GetCallerIdentity should have been called
        mock_sts.get_caller_identity.assert_called_once()
