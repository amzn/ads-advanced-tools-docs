"""
Unit Tests for AgentDeploymentOrchestrator

This module tests the AgentDeploymentOrchestrator class, which coordinates
the deployment of multiple agents with dependency management.

Validates Requirements: 6.1, 6.2, 6.4, 7.1, 7.2
"""

import pytest
from unittest.mock import Mock, MagicMock, patch, call
import tempfile
from pathlib import Path
import sys
import os

# Add parent directory to path for imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import (
    AgentConfig,
    DeploymentConfig,
    IAMPolicyConfig,
    AgentDeploymentResult
)
from managers.deployment_orchestrator import AgentDeploymentOrchestrator


class TestAgentDeploymentOrchestrator:
    """Test suite for AgentDeploymentOrchestrator class."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Create mock managers
        self.mock_iam_manager = Mock()
        self.mock_s3_manager = Mock()
        self.mock_state_manager = Mock()
        
        # Create sample agent configs
        self.sub_agent1 = AgentConfig(
            name="sub-agent-1",
            directory="/fake/path/sub-agent-1",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        
        self.sub_agent2 = AgentConfig(
            name="sub-agent-2",
            directory="/fake/path/sub-agent-2",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        
        self.orchestration_agent = AgentConfig(
            name="orchestration-agent",
            directory="/fake/path/orchestration-agent",
            entrypoint="orchestration.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=["sub-agent-1", "sub-agent-2"],
            environment_variables={}
        )
        
        # Create deployment config
        self.config = DeploymentConfig(
            aws_account_id="123456789012",
            aws_region="us-east-1",
            agents=[self.sub_agent1, self.sub_agent2, self.orchestration_agent],
            iam_policies=IAMPolicyConfig(
                base_policy={
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Effect": "Allow",
                            "Action": ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"],
                            "Resource": "*"
                        }
                    ]
                },
                cross_agent_policy_template={}
            ),
            deployment_order=["sub-agent-1", "sub-agent-2", "orchestration-agent"]
        )
    
    def test_initialization(self):
        """Test AgentDeploymentOrchestrator initialization."""
        orchestrator = AgentDeploymentOrchestrator(
            config=self.config,
            iam_manager=self.mock_iam_manager,
            s3_manager=self.mock_s3_manager,
            state_manager=self.mock_state_manager
        )
        
        assert orchestrator.config == self.config
        assert orchestrator.iam_manager == self.mock_iam_manager
        assert orchestrator.s3_manager == self.mock_s3_manager
        assert orchestrator.state_manager == self.mock_state_manager
    
    def test_get_agents_in_order_with_explicit_order(self):
        """Test _get_agents_in_order returns agents in explicit deployment order."""
        orchestrator = AgentDeploymentOrchestrator(
            config=self.config,
            iam_manager=self.mock_iam_manager,
            s3_manager=self.mock_s3_manager,
            state_manager=self.mock_state_manager
        )
        
        ordered_agents = orchestrator._get_agents_in_order()
        
        # Verify order matches deployment_order
        assert len(ordered_agents) == 3
        assert ordered_agents[0].name == "sub-agent-1"
        assert ordered_agents[1].name == "sub-agent-2"
        assert ordered_agents[2].name == "orchestration-agent"
    
    def test_get_agents_in_order_without_explicit_order(self):
        """Test _get_agents_in_order with dependency-based ordering."""
        # Create config without explicit deployment order
        config_no_order = DeploymentConfig(
            aws_account_id="123456789012",
            aws_region="us-east-1",
            agents=[self.sub_agent1, self.sub_agent2, self.orchestration_agent],
            iam_policies=IAMPolicyConfig(
                base_policy={},
                cross_agent_policy_template={}
            ),
            deployment_order=[]  # Empty order
        )
        
        orchestrator = AgentDeploymentOrchestrator(
            config=config_no_order,
            iam_manager=self.mock_iam_manager,
            s3_manager=self.mock_s3_manager,
            state_manager=self.mock_state_manager
        )
        
        ordered_agents = orchestrator._get_agents_in_order()
        
        # Verify agents without dependencies come first
        assert len(ordered_agents) == 3
        no_dep_agents = [a for a in ordered_agents if not a.dependencies]
        with_dep_agents = [a for a in ordered_agents if a.dependencies]
        
        assert len(no_dep_agents) == 2
        assert len(with_dep_agents) == 1
        
        # Verify orchestration agent (with dependencies) comes last
        assert ordered_agents[-1].name == "orchestration-agent"
    
    def test_extract_execution_role_arn(self):
        """Test _extract_execution_role_arn extracts ARN from output."""
        orchestrator = AgentDeploymentOrchestrator(
            config=self.config,
            iam_manager=self.mock_iam_manager,
            s3_manager=self.mock_s3_manager,
            state_manager=self.mock_state_manager
        )
        
        # Test with valid output
        output = """
        Configuration complete!
        Execution role: arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-abc123
        Agent configured successfully.
        """
        
        arn = orchestrator._extract_execution_role_arn(output)
        assert arn == "arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-abc123"
        
        # Test with no ARN in output
        output_no_arn = "Configuration complete!"
        arn_none = orchestrator._extract_execution_role_arn(output_no_arn)
        assert arn_none is None
    
    def test_update_orchestration_env(self):
        """Test update_orchestration_env writes ARNs to .env file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create orchestration agent directory
            orch_dir = Path(temp_dir) / "orchestration-agent"
            orch_dir.mkdir()
            
            # Update config with temp directory
            self.orchestration_agent.directory = str(orch_dir)
            
            orchestrator = AgentDeploymentOrchestrator(
                config=self.config,
                iam_manager=self.mock_iam_manager,
                s3_manager=self.mock_s3_manager,
                state_manager=self.mock_state_manager
            )
            
            # Sub-agent ARNs
            sub_agent_arns = {
                "sub-agent-1": "arn:aws:bedrock:us-east-1:123456789012:agent/SUBAGENT1",
                "sub-agent-2": "arn:aws:bedrock:us-east-1:123456789012:agent/SUBAGENT2"
            }
            
            # Update .env file
            orchestrator.update_orchestration_env(
                orchestration_agent_name="orchestration-agent",
                sub_agent_arns=sub_agent_arns
            )
            
            # Verify .env file was created
            env_file = orch_dir / ".env"
            assert env_file.exists()
            
            # Read and verify contents
            env_vars = {}
            with open(env_file, 'r') as f:
                for line in f:
                    if line.strip() and '=' in line:
                        key, value = line.strip().split('=', 1)
                        env_vars[key] = value
            
            assert "SUB_AGENT_1_ARN" in env_vars
            assert env_vars["SUB_AGENT_1_ARN"] == "arn:aws:bedrock:us-east-1:123456789012:agent/SUBAGENT1"
            assert "SUB_AGENT_2_ARN" in env_vars
            assert env_vars["SUB_AGENT_2_ARN"] == "arn:aws:bedrock:us-east-1:123456789012:agent/SUBAGENT2"
    
    def test_update_orchestration_env_preserves_existing_vars(self):
        """Test update_orchestration_env preserves existing environment variables."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create orchestration agent directory
            orch_dir = Path(temp_dir) / "orchestration-agent"
            orch_dir.mkdir()
            
            # Create existing .env file
            env_file = orch_dir / ".env"
            with open(env_file, 'w') as f:
                f.write("EXISTING_VAR=existing_value\n")
                f.write("ANOTHER_VAR=another_value\n")
            
            # Update config with temp directory
            self.orchestration_agent.directory = str(orch_dir)
            
            orchestrator = AgentDeploymentOrchestrator(
                config=self.config,
                iam_manager=self.mock_iam_manager,
                s3_manager=self.mock_s3_manager,
                state_manager=self.mock_state_manager
            )
            
            # Sub-agent ARNs
            sub_agent_arns = {
                "sub-agent-1": "arn:aws:bedrock:us-east-1:123456789012:agent/SUBAGENT1"
            }
            
            # Update .env file
            orchestrator.update_orchestration_env(
                orchestration_agent_name="orchestration-agent",
                sub_agent_arns=sub_agent_arns
            )
            
            # Read and verify contents
            env_vars = {}
            with open(env_file, 'r') as f:
                for line in f:
                    if line.strip() and '=' in line:
                        key, value = line.strip().split('=', 1)
                        env_vars[key] = value
            
            # Verify existing vars are preserved
            assert "EXISTING_VAR" in env_vars
            assert env_vars["EXISTING_VAR"] == "existing_value"
            assert "ANOTHER_VAR" in env_vars
            assert env_vars["ANOTHER_VAR"] == "another_value"
            
            # Verify new ARN was added
            assert "SUB_AGENT_1_ARN" in env_vars
            assert env_vars["SUB_AGENT_1_ARN"] == "arn:aws:bedrock:us-east-1:123456789012:agent/SUBAGENT1"
    
    @patch('managers.deployment_orchestrator.AgentCoreIntegration')
    def test_deploy_agent_success(self, mock_agentcore_class):
        """Test deploy_agent successfully deploys an agent."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create agent directory
            agent_dir = Path(temp_dir) / "sub-agent-1"
            agent_dir.mkdir()
            
            # Update agent config with temp directory
            test_agent = AgentConfig(
                name="sub-agent-1",
                directory=str(agent_dir),
                entrypoint="agent.py",
                language="python",
                platform="linux/arm64",
                memory_mode="STM_ONLY",
                server_protocol="A2A",
                dependencies=[],
                environment_variables={}
            )
            
            # Mock AgentCoreIntegration
            mock_agentcore = Mock()
            mock_agentcore_class.return_value = mock_agentcore
            
            # Mock run_configure (AgentCore handles dependencies internally)
            mock_configure_result = Mock()
            mock_configure_result.stdout = "Execution role: arn:aws:iam::123456789012:role/test-role"
            mock_configure_result.stderr = ""
            mock_agentcore.run_configure.return_value = mock_configure_result
            
            # Mock run_deploy
            mock_deploy_result = Mock()
            mock_deploy_result.stdout = "Agent ARN: arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT"
            mock_deploy_result.stderr = ""
            mock_agentcore.run_deploy.return_value = mock_deploy_result
            
            # Mock parse_deploy_output
            mock_agentcore.parse_deploy_output.return_value = {
                'agent_arn': 'arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT',
                'execution_role_arn': 'arn:aws:iam::123456789012:role/test-role',
                'memory_arn': None,
                'ecr_repository_uri': '123456789012.dkr.ecr.us-east-1.amazonaws.com/test-agent',
                'codebuild_project_name': 'bedrock-agentcore-test-agent-builder'
            }
            
            # Create orchestrator
            orchestrator = AgentDeploymentOrchestrator(
                config=self.config,
                iam_manager=self.mock_iam_manager,
                s3_manager=self.mock_s3_manager,
                state_manager=self.mock_state_manager
            )
            
            # Deploy agent
            result = orchestrator.deploy_agent(test_agent)
            
            # Verify success
            assert result.success
            assert result.agent_name == "sub-agent-1"
            assert result.agent_arn == "arn:aws:bedrock:us-east-1:123456789012:agent/TESTAGENT"
            assert result.execution_role_arn == "arn:aws:iam::123456789012:role/test-role"
            
            # Verify base policy was attached
            self.mock_iam_manager.attach_base_policy.assert_called_once()
            
            # Verify state was recorded
            self.mock_state_manager.record_agent_deployment.assert_called_once()
    
    @patch('managers.deployment_orchestrator.AgentCoreIntegration')
    def test_deploy_agent_failure_missing_directory(self, mock_agentcore_class):
        """Test deploy_agent fails when agent directory doesn't exist."""
        # Create agent with non-existent directory
        bad_agent = AgentConfig(
            name="bad-agent",
            directory="/nonexistent/path",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        
        orchestrator = AgentDeploymentOrchestrator(
            config=self.config,
            iam_manager=self.mock_iam_manager,
            s3_manager=self.mock_s3_manager,
            state_manager=self.mock_state_manager
        )
        
        # Deploy agent
        result = orchestrator.deploy_agent(bad_agent)
        
        # Verify failure
        assert not result.success
        assert result.agent_name == "bad-agent"
        assert "does not exist" in result.error_message
    
    def test_apply_cross_agent_policies(self):
        """Test _apply_cross_agent_policies creates and applies policies."""
        orchestrator = AgentDeploymentOrchestrator(
            config=self.config,
            iam_manager=self.mock_iam_manager,
            s3_manager=self.mock_s3_manager,
            state_manager=self.mock_state_manager
        )
        
        # Create deployed agents
        deployed_agents = [
            AgentDeploymentResult(
                success=True,
                agent_name="sub-agent-1",
                agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/AGENT1",
                execution_role_arn="arn:aws:iam::123456789012:role/role1",
                memory_arn="arn:aws:bedrock:us-east-1:123456789012:memory/MEM1"
            ),
            AgentDeploymentResult(
                success=True,
                agent_name="sub-agent-2",
                agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/AGENT2",
                execution_role_arn="arn:aws:iam::123456789012:role/role2",
                memory_arn=None
            )
        ]
        
        # Mock create_cross_agent_policy
        mock_policy = {"Version": "2012-10-17", "Statement": []}
        self.mock_iam_manager.create_cross_agent_policy.return_value = mock_policy
        
        # Apply policies
        orchestrator._apply_cross_agent_policies(deployed_agents)
        
        # Verify create_cross_agent_policy was called with correct ARNs
        self.mock_iam_manager.create_cross_agent_policy.assert_called_once()
        call_args = self.mock_iam_manager.create_cross_agent_policy.call_args
        
        assert "arn:aws:bedrock:us-east-1:123456789012:agent/AGENT1" in call_args[1]['agent_arns']
        assert "arn:aws:bedrock:us-east-1:123456789012:agent/AGENT2" in call_args[1]['agent_arns']
        assert "arn:aws:bedrock:us-east-1:123456789012:memory/MEM1" in call_args[1]['memory_arns']
        
        # Verify apply_cross_agent_policy was called with correct role names
        self.mock_iam_manager.apply_cross_agent_policy.assert_called_once()
        call_args = self.mock_iam_manager.apply_cross_agent_policy.call_args
        
        assert "role1" in call_args[1]['role_names']
        assert "role2" in call_args[1]['role_names']
        assert call_args[1]['policy_document'] == mock_policy


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
