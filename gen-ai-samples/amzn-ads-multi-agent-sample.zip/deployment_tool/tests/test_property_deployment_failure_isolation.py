"""
Property-Based Test: Deployment Failure Isolation

This test validates Property 7: For any agent deployment failure, subsequent
agents in the deployment order must not be deployed, and the failure must be
reported with specific error details.

Validates Requirements: 6.4, 6.5, 10.1, 10.2

Tag: Feature: agentcore-automated-deployment, Property 7: Deployment failure isolation
"""

import pytest
from hypothesis import given, strategies as st, settings, assume
from typing import List
import sys
import os
from unittest.mock import Mock, patch, MagicMock

# Add parent directory to path for imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from models import (
    AgentConfig,
    DeploymentConfig,
    IAMPolicyConfig,
    AgentDeploymentResult
)


@given(
    num_agents=st.integers(min_value=3, max_value=10),
    failure_index=st.integers(min_value=0, max_value=9)
)
@settings(max_examples=100, deadline=None)
def test_deployment_halts_on_failure(
    num_agents: int,
    failure_index: int
):
    """
    Property 7: Deployment Failure Isolation
    
    For any agent deployment failure, subsequent agents in the deployment order
    must not be deployed, and the deployment must halt immediately.
    
    This test generates random agent configurations, simulates a failure at a
    specific index, and verifies that no agents after the failure are deployed.
    
    **Validates: Requirements 6.4, 6.5**
    """
    # Ensure failure_index is within bounds
    assume(failure_index < num_agents)
    
    # Generate agent names
    agent_names = [f"agent-{i}" for i in range(num_agents)]
    
    # Create agent configs
    agents = []
    for name in agent_names:
        config = AgentConfig(
            name=name,
            directory=f"/fake/path/{name}",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        agents.append(config)
    
    # Create deployment config
    config = DeploymentConfig(
        aws_account_id="123456789012",
        aws_region="us-east-1",
        agents=agents,
        iam_policies=IAMPolicyConfig(
            base_policy={},
            cross_agent_policy_template={}
        ),
        deployment_order=agent_names
    )
    
    # Import here to avoid circular dependencies
    from managers.deployment_orchestrator import AgentDeploymentOrchestrator
    
    # Create mock managers
    mock_iam_manager = Mock()
    mock_s3_manager = Mock()
    mock_state_manager = Mock()
    
    # Create orchestrator
    orchestrator = AgentDeploymentOrchestrator(
        config=config,
        iam_manager=mock_iam_manager,
        s3_manager=mock_s3_manager,
        state_manager=mock_state_manager
    )
    
    # Mock deploy_agent to succeed for agents before failure_index,
    # fail at failure_index, and should not be called after
    deploy_call_count = 0
    
    def mock_deploy_agent(agent_config):
        nonlocal deploy_call_count
        current_index = deploy_call_count
        deploy_call_count += 1
        
        if current_index == failure_index:
            # Simulate failure
            return AgentDeploymentResult(
                success=False,
                agent_name=agent_config.name,
                error_message=f"Simulated failure for {agent_config.name}"
            )
        else:
            # Simulate success
            return AgentDeploymentResult(
                success=True,
                agent_name=agent_config.name,
                agent_arn=f"arn:aws:bedrock:us-east-1:123456789012:agent/{agent_config.name.upper()}",
                execution_role_arn=f"arn:aws:iam::123456789012:role/{agent_config.name}-role",
                memory_arn=None
            )
    
    # Patch deploy_agent method
    orchestrator.deploy_agent = mock_deploy_agent
    
    # Execute deployment
    result = orchestrator.deploy_all_agents()
    
    # Verify property: Deployment halted after failure
    assert not result.success, "Deployment should fail when any agent fails"
    
    # Verify property: Only agents up to and including failure_index were deployed
    assert deploy_call_count == failure_index + 1, \
        f"Expected {failure_index + 1} deploy attempts, got {deploy_call_count}"
    
    # Verify property: Failed agents list contains the failed agent
    assert len(result.failed_agents) > 0, "Failed agents list should not be empty"
    assert result.failed_agents[0].agent_name == agent_names[failure_index], \
        f"Failed agent should be {agent_names[failure_index]}"
    
    # Verify property: Deployed agents list contains only agents before failure
    assert len(result.deployed_agents) == failure_index, \
        f"Expected {failure_index} deployed agents, got {len(result.deployed_agents)}"


@given(
    num_agents=st.integers(min_value=2, max_value=8),
    failure_index=st.integers(min_value=0, max_value=7)
)
@settings(max_examples=100, deadline=None)
def test_failure_error_message_specificity(
    num_agents: int,
    failure_index: int
):
    """
    Property 7: Deployment Failure Isolation (Error Message Specificity)
    
    When an agent deployment fails, the error message must include:
    - The agent name
    - Specific error details
    
    This test generates random agent configurations, simulates a failure with
    a specific error message, and verifies that the error details are preserved.
    
    **Validates: Requirements 10.1, 10.2**
    """
    # Ensure failure_index is within bounds
    assume(failure_index < num_agents)
    
    # Generate agent names
    agent_names = [f"agent-{i}" for i in range(num_agents)]
    
    # Create agent configs
    agents = []
    for name in agent_names:
        config = AgentConfig(
            name=name,
            directory=f"/fake/path/{name}",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        agents.append(config)
    
    # Create deployment config
    config = DeploymentConfig(
        aws_account_id="123456789012",
        aws_region="us-east-1",
        agents=agents,
        iam_policies=IAMPolicyConfig(
            base_policy={},
            cross_agent_policy_template={}
        ),
        deployment_order=agent_names
    )
    
    # Import here to avoid circular dependencies
    from managers.deployment_orchestrator import AgentDeploymentOrchestrator
    
    # Create mock managers
    mock_iam_manager = Mock()
    mock_s3_manager = Mock()
    mock_state_manager = Mock()
    
    # Create orchestrator
    orchestrator = AgentDeploymentOrchestrator(
        config=config,
        iam_manager=mock_iam_manager,
        s3_manager=mock_s3_manager,
        state_manager=mock_state_manager
    )
    
    # Specific error message for the failing agent
    specific_error = f"AWS API error: InvalidParameterException - Invalid region specified"
    
    # Mock deploy_agent
    deploy_call_count = 0
    
    def mock_deploy_agent(agent_config):
        nonlocal deploy_call_count
        current_index = deploy_call_count
        deploy_call_count += 1
        
        if current_index == failure_index:
            # Simulate failure with specific error
            return AgentDeploymentResult(
                success=False,
                agent_name=agent_config.name,
                error_message=specific_error
            )
        else:
            # Simulate success
            return AgentDeploymentResult(
                success=True,
                agent_name=agent_config.name,
                agent_arn=f"arn:aws:bedrock:us-east-1:123456789012:agent/{agent_config.name.upper()}",
                execution_role_arn=f"arn:aws:iam::123456789012:role/{agent_config.name}-role",
                memory_arn=None
            )
    
    # Patch deploy_agent method
    orchestrator.deploy_agent = mock_deploy_agent
    
    # Execute deployment
    result = orchestrator.deploy_all_agents()
    
    # Verify property: Error message includes agent name
    failed_agent = result.failed_agents[0]
    assert failed_agent.agent_name == agent_names[failure_index], \
        "Failed agent name should be preserved"
    
    # Verify property: Error message includes specific error details
    assert failed_agent.error_message == specific_error, \
        f"Expected error message '{specific_error}', got '{failed_agent.error_message}'"


@given(
    num_agents=st.integers(min_value=3, max_value=8),
    failure_index=st.integers(min_value=0, max_value=7)
)
@settings(max_examples=100, deadline=None)
def test_state_preserved_on_failure(
    num_agents: int,
    failure_index: int
):
    """
    Property 7: Deployment Failure Isolation (State Preservation)
    
    When an agent deployment fails, the deployment state must be preserved
    for all successfully deployed agents before the failure.
    
    This test generates random agent configurations, simulates a failure,
    and verifies that state is recorded for all successful deployments.
    
    **Validates: Requirements 6.4, 6.5, 9.1**
    """
    # Ensure failure_index is within bounds
    assume(failure_index < num_agents)
    
    # Generate agent names
    agent_names = [f"agent-{i}" for i in range(num_agents)]
    
    # Create agent configs
    agents = []
    for name in agent_names:
        config = AgentConfig(
            name=name,
            directory=f"/fake/path/{name}",
            entrypoint="agent.py",
            language="python",
            platform="linux/arm64",
            memory_mode="STM_ONLY",
            server_protocol="A2A",
            dependencies=[],
            environment_variables={}
        )
        agents.append(config)
    
    # Create deployment config
    config = DeploymentConfig(
        aws_account_id="123456789012",
        aws_region="us-east-1",
        agents=agents,
        iam_policies=IAMPolicyConfig(
            base_policy={},
            cross_agent_policy_template={}
        ),
        deployment_order=agent_names
    )
    
    # Import here to avoid circular dependencies
    from managers.deployment_orchestrator import AgentDeploymentOrchestrator
    
    # Create mock managers
    mock_iam_manager = Mock()
    mock_s3_manager = Mock()
    mock_state_manager = Mock()
    
    # Track state recording calls
    state_record_calls = []
    
    def mock_record_agent_deployment(**kwargs):
        state_record_calls.append(kwargs['agent_name'])
    
    mock_state_manager.record_agent_deployment = mock_record_agent_deployment
    
    # Create orchestrator
    orchestrator = AgentDeploymentOrchestrator(
        config=config,
        iam_manager=mock_iam_manager,
        s3_manager=mock_s3_manager,
        state_manager=mock_state_manager
    )
    
    # Mock deploy_agent
    deploy_call_count = 0
    
    def mock_deploy_agent(agent_config):
        nonlocal deploy_call_count
        current_index = deploy_call_count
        deploy_call_count += 1
        
        if current_index == failure_index:
            # Simulate failure
            return AgentDeploymentResult(
                success=False,
                agent_name=agent_config.name,
                error_message=f"Simulated failure for {agent_config.name}"
            )
        else:
            # Simulate success
            result = AgentDeploymentResult(
                success=True,
                agent_name=agent_config.name,
                agent_arn=f"arn:aws:bedrock:us-east-1:123456789012:agent/{agent_config.name.upper()}",
                execution_role_arn=f"arn:aws:iam::123456789012:role/{agent_config.name}-role",
                memory_arn=None
            )
            # Record state for successful deployment
            mock_state_manager.record_agent_deployment(
                agent_name=agent_config.name,
                agent_arn=result.agent_arn,
                execution_role_arn=result.execution_role_arn,
                ecr_repository_uri="",
                codebuild_project_name="",
                memory_arn=result.memory_arn
            )
            return result
    
    # Patch deploy_agent method
    orchestrator.deploy_agent = mock_deploy_agent
    
    # Execute deployment
    result = orchestrator.deploy_all_agents()
    
    # Verify property: State was recorded for all successful deployments
    assert len(state_record_calls) == failure_index, \
        f"Expected {failure_index} state records, got {len(state_record_calls)}"
    
    # Verify property: State was recorded for correct agents
    for i in range(failure_index):
        assert agent_names[i] in state_record_calls, \
            f"State should be recorded for {agent_names[i]}"
    
    # Verify property: State was not recorded for failed agent or subsequent agents
    for i in range(failure_index, num_agents):
        assert agent_names[i] not in state_record_calls, \
            f"State should not be recorded for {agent_names[i]}"


if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v"])
