"""
Comprehensive tests for S3Manager class.

Tests all methods including error handling, retry logic, and edge cases.
Requirements: 16.1, 16.2, 16.3, 16.4
"""

import pytest
from unittest.mock import Mock, patch, call
import boto3
from botocore.exceptions import ClientError, BotoCoreError
import json

from managers.s3_manager import S3Manager


@pytest.fixture
def mock_session():
    """Create a mock boto3 session."""
    session = Mock(spec=boto3.Session)
    return session


@pytest.fixture
def mock_s3_client():
    """Create a mock S3 client."""
    return Mock()


@pytest.fixture
def s3_manager(mock_session, mock_s3_client):
    """Create an S3Manager instance with mocked dependencies."""
    mock_session.client.return_value = mock_s3_client
    return S3Manager(mock_session)


class TestBucketExists:
    """Tests for bucket_exists method."""
    
    def test_bucket_exists_returns_true(self, s3_manager, mock_s3_client):
        """Test that bucket_exists returns True when bucket exists."""
        mock_s3_client.head_bucket.return_value = {}
        
        result = s3_manager.bucket_exists('test-bucket')
        
        assert result is True
        mock_s3_client.head_bucket.assert_called_once_with(Bucket='test-bucket')
    
    def test_bucket_exists_returns_false_for_404(self, s3_manager, mock_s3_client):
        """Test that bucket_exists returns False when bucket returns 404."""
        error_response = {'Error': {'Code': '404', 'Message': 'Not Found'}}
        mock_s3_client.head_bucket.side_effect = ClientError(error_response, 'HeadBucket')
        
        result = s3_manager.bucket_exists('nonexistent-bucket')
        
        assert result is False
    
    def test_bucket_exists_returns_false_for_no_such_bucket(self, s3_manager, mock_s3_client):
        """Test that bucket_exists returns False for NoSuchBucket error."""
        error_response = {'Error': {'Code': 'NoSuchBucket', 'Message': 'Bucket not found'}}
        mock_s3_client.head_bucket.side_effect = ClientError(error_response, 'HeadBucket')
        
        result = s3_manager.bucket_exists('nonexistent-bucket')
        
        assert result is False
    
    def test_bucket_exists_raises_on_permission_error(self, s3_manager, mock_s3_client):
        """Test that bucket_exists raises exception on permission errors."""
        error_response = {'Error': {'Code': 'AccessDenied', 'Message': 'Access denied'}}
        mock_s3_client.head_bucket.side_effect = ClientError(error_response, 'HeadBucket')
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.bucket_exists('test-bucket')
        
        assert "Failed to check if bucket 'test-bucket' exists" in str(exc_info.value)
        assert "AccessDenied" in str(exc_info.value)
    
    def test_bucket_exists_raises_on_botocore_error(self, s3_manager, mock_s3_client):
        """Test that bucket_exists raises exception on BotoCoreError."""
        mock_s3_client.head_bucket.side_effect = BotoCoreError()
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.bucket_exists('test-bucket')
        
        assert "AWS API error checking bucket 'test-bucket'" in str(exc_info.value)


class TestCreateVectorBucket:
    """Tests for create_vector_bucket method."""
    
    def test_create_vector_bucket_success_us_east_1(self, s3_manager, mock_s3_client):
        """Test successful bucket creation in us-east-1 (no LocationConstraint)."""
        result = s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        assert result == 'test-bucket'
        mock_s3_client.create_bucket.assert_called_once_with(Bucket='test-bucket')
        mock_s3_client.put_bucket_versioning.assert_called_once_with(
            Bucket='test-bucket',
            VersioningConfiguration={'Status': 'Enabled'}
        )
    
    def test_create_vector_bucket_success_other_region(self, s3_manager, mock_s3_client):
        """Test successful bucket creation in non-us-east-1 region."""
        result = s3_manager.create_vector_bucket('test-bucket', 'us-west-2')
        
        assert result == 'test-bucket'
        mock_s3_client.create_bucket.assert_called_once_with(
            Bucket='test-bucket',
            CreateBucketConfiguration={'LocationConstraint': 'us-west-2'}
        )
        mock_s3_client.put_bucket_versioning.assert_called_once()
    
    def test_create_vector_bucket_already_owned(self, s3_manager, mock_s3_client):
        """Test that bucket creation succeeds if bucket already owned by us."""
        error_response = {
            'Error': {'Code': 'BucketAlreadyOwnedByYou', 'Message': 'Bucket exists'}
        }
        mock_s3_client.create_bucket.side_effect = ClientError(error_response, 'CreateBucket')
        
        result = s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        assert result == 'test-bucket'
        # Versioning should not be called if bucket already exists
        mock_s3_client.put_bucket_versioning.assert_not_called()
    
    @patch('time.sleep')
    def test_create_vector_bucket_retries_on_throttling(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that create_vector_bucket retries on throttling errors."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_s3_client.create_bucket.side_effect = [
            ClientError(error_response, 'CreateBucket'),
            ClientError(error_response, 'CreateBucket'),
            None  # Success on third attempt
        ]
        
        result = s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        assert result == 'test-bucket'
        assert mock_s3_client.create_bucket.call_count == 3
        assert mock_sleep.call_count == 2
    
    @patch('time.sleep')
    def test_create_vector_bucket_retries_on_service_unavailable(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that create_vector_bucket retries on ServiceUnavailable errors."""
        error_response = {
            'Error': {'Code': 'ServiceUnavailable', 'Message': 'Service unavailable'}
        }
        mock_s3_client.create_bucket.side_effect = [
            ClientError(error_response, 'CreateBucket'),
            None  # Success on second attempt
        ]
        
        result = s3_manager.create_vector_bucket('test-bucket', 'us-west-2')
        
        assert result == 'test-bucket'
        assert mock_s3_client.create_bucket.call_count == 2
        assert mock_sleep.call_count == 1
    
    @patch('time.sleep')
    def test_create_vector_bucket_retries_on_botocore_error(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that create_vector_bucket retries on BotoCoreError."""
        mock_s3_client.create_bucket.side_effect = [
            BotoCoreError(),
            None  # Success on second attempt
        ]
        
        result = s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        assert result == 'test-bucket'
        assert mock_s3_client.create_bucket.call_count == 2
        assert mock_sleep.call_count == 1
    
    @patch('time.sleep')
    def test_create_vector_bucket_fails_after_max_retries(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that create_vector_bucket fails after max retries."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_s3_client.create_bucket.side_effect = ClientError(error_response, 'CreateBucket')
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        assert "Failed to create bucket 'test-bucket'" in str(exc_info.value)
        assert mock_s3_client.create_bucket.call_count == 5
        assert mock_sleep.call_count == 4
    
    def test_create_vector_bucket_fails_on_non_retryable_error(
        self, s3_manager, mock_s3_client
    ):
        """Test that create_vector_bucket fails immediately on non-retryable errors."""
        error_response = {
            'Error': {'Code': 'InvalidBucketName', 'Message': 'Invalid bucket name'}
        }
        mock_s3_client.create_bucket.side_effect = ClientError(error_response, 'CreateBucket')
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        assert "Failed to create bucket 'test-bucket'" in str(exc_info.value)
        assert "InvalidBucketName" in str(exc_info.value)
        # Should not retry on non-retryable errors
        assert mock_s3_client.create_bucket.call_count == 1
    
    @patch('time.sleep')
    def test_create_vector_bucket_exponential_backoff(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that exponential backoff increases delays correctly."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_s3_client.create_bucket.side_effect = [
            ClientError(error_response, 'CreateBucket'),
            ClientError(error_response, 'CreateBucket'),
            ClientError(error_response, 'CreateBucket'),
            None  # Success on fourth attempt
        ]
        
        s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        # Verify exponential backoff: 1, 2, 4 seconds
        sleep_calls = [call.args[0] for call in mock_sleep.call_args_list]
        assert sleep_calls == [1.0, 2.0, 4.0]


class TestConfigureBucketPolicy:
    """Tests for configure_bucket_policy method."""
    
    def test_configure_bucket_policy_success(self, s3_manager, mock_s3_client):
        """Test successful bucket policy configuration."""
        execution_role_arn = 'arn:aws:iam::123456789012:role/test-role'
        
        s3_manager.configure_bucket_policy('test-bucket', execution_role_arn)
        
        # Verify put_bucket_policy was called
        assert mock_s3_client.put_bucket_policy.call_count == 1
        
        # Verify the policy document structure
        call_args = mock_s3_client.put_bucket_policy.call_args
        assert call_args[1]['Bucket'] == 'test-bucket'
        
        policy = json.loads(call_args[1]['Policy'])
        assert policy['Version'] == '2012-10-17'
        assert len(policy['Statement']) == 1
        
        statement = policy['Statement'][0]
        assert statement['Effect'] == 'Allow'
        assert statement['Principal']['AWS'] == execution_role_arn
        assert 's3:GetObject' in statement['Action']
        assert 's3:PutObject' in statement['Action']
        assert 's3:ListBucket' in statement['Action']
        assert f'arn:aws:s3:::test-bucket' in statement['Resource']
        assert f'arn:aws:s3:::test-bucket/*' in statement['Resource']
    
    @patch('time.sleep')
    def test_configure_bucket_policy_retries_on_throttling(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that configure_bucket_policy retries on throttling errors."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_s3_client.put_bucket_policy.side_effect = [
            ClientError(error_response, 'PutBucketPolicy'),
            ClientError(error_response, 'PutBucketPolicy'),
            None  # Success on third attempt
        ]
        
        execution_role_arn = 'arn:aws:iam::123456789012:role/test-role'
        s3_manager.configure_bucket_policy('test-bucket', execution_role_arn)
        
        assert mock_s3_client.put_bucket_policy.call_count == 3
        assert mock_sleep.call_count == 2
    
    @patch('time.sleep')
    def test_configure_bucket_policy_retries_on_request_limit_exceeded(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that configure_bucket_policy retries on RequestLimitExceeded."""
        error_response = {
            'Error': {'Code': 'RequestLimitExceeded', 'Message': 'Request limit exceeded'}
        }
        mock_s3_client.put_bucket_policy.side_effect = [
            ClientError(error_response, 'PutBucketPolicy'),
            None  # Success on second attempt
        ]
        
        execution_role_arn = 'arn:aws:iam::123456789012:role/test-role'
        s3_manager.configure_bucket_policy('test-bucket', execution_role_arn)
        
        assert mock_s3_client.put_bucket_policy.call_count == 2
        assert mock_sleep.call_count == 1
    
    @patch('time.sleep')
    def test_configure_bucket_policy_retries_on_botocore_error(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that configure_bucket_policy retries on BotoCoreError."""
        mock_s3_client.put_bucket_policy.side_effect = [
            BotoCoreError(),
            None  # Success on second attempt
        ]
        
        execution_role_arn = 'arn:aws:iam::123456789012:role/test-role'
        s3_manager.configure_bucket_policy('test-bucket', execution_role_arn)
        
        assert mock_s3_client.put_bucket_policy.call_count == 2
        assert mock_sleep.call_count == 1
    
    @patch('time.sleep')
    def test_configure_bucket_policy_fails_after_max_retries(
        self, mock_sleep, s3_manager, mock_s3_client
    ):
        """Test that configure_bucket_policy fails after max retries."""
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_s3_client.put_bucket_policy.side_effect = ClientError(
            error_response, 'PutBucketPolicy'
        )
        
        execution_role_arn = 'arn:aws:iam::123456789012:role/test-role'
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.configure_bucket_policy('test-bucket', execution_role_arn)
        
        assert "Failed to configure bucket policy for 'test-bucket'" in str(exc_info.value)
        assert mock_s3_client.put_bucket_policy.call_count == 5
        assert mock_sleep.call_count == 4
    
    def test_configure_bucket_policy_fails_on_non_retryable_error(
        self, s3_manager, mock_s3_client
    ):
        """Test that configure_bucket_policy fails immediately on non-retryable errors."""
        error_response = {
            'Error': {'Code': 'MalformedPolicy', 'Message': 'Policy is malformed'}
        }
        mock_s3_client.put_bucket_policy.side_effect = ClientError(
            error_response, 'PutBucketPolicy'
        )
        
        execution_role_arn = 'arn:aws:iam::123456789012:role/test-role'
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.configure_bucket_policy('test-bucket', execution_role_arn)
        
        assert "Failed to configure bucket policy for 'test-bucket'" in str(exc_info.value)
        assert "MalformedPolicy" in str(exc_info.value)
        # Should not retry on non-retryable errors
        assert mock_s3_client.put_bucket_policy.call_count == 1


class TestVerifyVectorIndex:
    """Tests for verify_vector_index method."""
    
    def test_verify_vector_index_with_tag(self, s3_manager, mock_s3_client):
        """Test that verify_vector_index returns True when VectorIndexEnabled tag exists."""
        mock_s3_client.head_bucket.return_value = {}
        mock_s3_client.get_bucket_tagging.return_value = {
            'TagSet': [
                {'Key': 'VectorIndexEnabled', 'Value': 'true'},
                {'Key': 'Environment', 'Value': 'production'}
            ]
        }
        
        result = s3_manager.verify_vector_index('test-bucket')
        
        assert result is True
        mock_s3_client.head_bucket.assert_called_once_with(Bucket='test-bucket')
        mock_s3_client.get_bucket_tagging.assert_called_once_with(Bucket='test-bucket')
    
    def test_verify_vector_index_without_tag(self, s3_manager, mock_s3_client):
        """Test that verify_vector_index returns True even without tag (bucket exists)."""
        mock_s3_client.head_bucket.return_value = {}
        mock_s3_client.get_bucket_tagging.return_value = {
            'TagSet': [
                {'Key': 'Environment', 'Value': 'production'}
            ]
        }
        
        result = s3_manager.verify_vector_index('test-bucket')
        
        assert result is True
    
    def test_verify_vector_index_no_tags(self, s3_manager, mock_s3_client):
        """Test that verify_vector_index returns True when no tags exist."""
        mock_s3_client.head_bucket.return_value = {}
        error_response = {'Error': {'Code': 'NoSuchTagSet', 'Message': 'No tags'}}
        mock_s3_client.get_bucket_tagging.side_effect = ClientError(
            error_response, 'GetBucketTagging'
        )
        
        result = s3_manager.verify_vector_index('test-bucket')
        
        assert result is True
    
    def test_verify_vector_index_bucket_not_found(self, s3_manager, mock_s3_client):
        """Test that verify_vector_index returns False when bucket doesn't exist."""
        error_response = {'Error': {'Code': '404', 'Message': 'Not Found'}}
        mock_s3_client.head_bucket.side_effect = ClientError(error_response, 'HeadBucket')
        
        result = s3_manager.verify_vector_index('nonexistent-bucket')
        
        assert result is False
    
    def test_verify_vector_index_no_such_bucket(self, s3_manager, mock_s3_client):
        """Test that verify_vector_index returns False for NoSuchBucket error."""
        error_response = {'Error': {'Code': 'NoSuchBucket', 'Message': 'Bucket not found'}}
        mock_s3_client.head_bucket.side_effect = ClientError(error_response, 'HeadBucket')
        
        result = s3_manager.verify_vector_index('nonexistent-bucket')
        
        assert result is False
    
    def test_verify_vector_index_raises_on_other_errors(self, s3_manager, mock_s3_client):
        """Test that verify_vector_index raises exception on non-404 errors."""
        error_response = {'Error': {'Code': 'AccessDenied', 'Message': 'Access denied'}}
        mock_s3_client.head_bucket.side_effect = ClientError(error_response, 'HeadBucket')
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.verify_vector_index('test-bucket')
        
        assert "Failed to verify vector index for bucket 'test-bucket'" in str(exc_info.value)
        assert "AccessDenied" in str(exc_info.value)
    
    def test_verify_vector_index_raises_on_botocore_error(self, s3_manager, mock_s3_client):
        """Test that verify_vector_index raises exception on BotoCoreError."""
        mock_s3_client.head_bucket.side_effect = BotoCoreError()
        
        with pytest.raises(Exception) as exc_info:
            s3_manager.verify_vector_index('test-bucket')
        
        assert "AWS API error verifying vector index for bucket 'test-bucket'" in str(
            exc_info.value
        )
    
    def test_verify_vector_index_handles_tagging_errors_gracefully(
        self, s3_manager, mock_s3_client
    ):
        """Test that verify_vector_index handles tagging errors gracefully."""
        mock_s3_client.head_bucket.return_value = {}
        error_response = {'Error': {'Code': 'AccessDenied', 'Message': 'Access denied'}}
        mock_s3_client.get_bucket_tagging.side_effect = ClientError(
            error_response, 'GetBucketTagging'
        )
        
        # Should still return True since bucket exists
        result = s3_manager.verify_vector_index('test-bucket')
        
        assert result is True


class TestExponentialBackoff:
    """Tests for exponential backoff behavior across methods."""
    
    @patch('time.sleep')
    def test_max_delay_cap(self, mock_sleep, s3_manager, mock_s3_client):
        """Test that delay is capped at max_delay."""
        # Set a scenario that would exceed max_delay
        s3_manager.max_delay = 8.0  # Lower max for testing
        
        error_response = {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}}
        mock_s3_client.create_bucket.side_effect = [
            ClientError(error_response, 'CreateBucket'),
            ClientError(error_response, 'CreateBucket'),
            ClientError(error_response, 'CreateBucket'),
            ClientError(error_response, 'CreateBucket'),
            None  # Success on fifth attempt
        ]
        
        s3_manager.create_vector_bucket('test-bucket', 'us-east-1')
        
        # Verify delays are capped: 1, 2, 4, 8 (capped at max_delay)
        sleep_calls = [call.args[0] for call in mock_sleep.call_args_list]
        assert sleep_calls == [1.0, 2.0, 4.0, 8.0]
        assert all(delay <= 8.0 for delay in sleep_calls)


class TestEdgeCases:
    """Tests for edge cases and boundary conditions."""
    
    def test_empty_bucket_name(self, s3_manager, mock_s3_client):
        """Test handling of empty bucket name."""
        error_response = {
            'Error': {'Code': 'InvalidBucketName', 'Message': 'Invalid bucket name'}
        }
        mock_s3_client.head_bucket.side_effect = ClientError(error_response, 'HeadBucket')
        
        with pytest.raises(Exception):
            s3_manager.bucket_exists('')
    
    def test_very_long_bucket_name(self, s3_manager, mock_s3_client):
        """Test handling of very long bucket name."""
        long_name = 'a' * 100  # S3 bucket names have max length of 63
        error_response = {
            'Error': {'Code': 'InvalidBucketName', 'Message': 'Invalid bucket name'}
        }
        mock_s3_client.create_bucket.side_effect = ClientError(error_response, 'CreateBucket')
        
        with pytest.raises(Exception):
            s3_manager.create_vector_bucket(long_name, 'us-east-1')
    
    def test_special_characters_in_bucket_name(self, s3_manager, mock_s3_client):
        """Test handling of special characters in bucket name."""
        special_name = 'test_bucket@#$'
        error_response = {
            'Error': {'Code': 'InvalidBucketName', 'Message': 'Invalid bucket name'}
        }
        mock_s3_client.create_bucket.side_effect = ClientError(error_response, 'CreateBucket')
        
        with pytest.raises(Exception):
            s3_manager.create_vector_bucket(special_name, 'us-east-1')
    
    def test_invalid_region(self, s3_manager, mock_s3_client):
        """Test handling of invalid region."""
        error_response = {
            'Error': {'Code': 'InvalidLocationConstraint', 'Message': 'Invalid region'}
        }
        mock_s3_client.create_bucket.side_effect = ClientError(error_response, 'CreateBucket')
        
        with pytest.raises(Exception):
            s3_manager.create_vector_bucket('test-bucket', 'invalid-region')


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
