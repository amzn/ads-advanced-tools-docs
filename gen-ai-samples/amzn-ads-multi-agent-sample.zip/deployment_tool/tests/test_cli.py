"""
Unit Tests for CLI Interface

This module tests the CLI commands for the AgentCore Automated Deployment System.

Validates Requirements: 10.1, 10.2, 10.5, 17.1, 17.2
"""

import pytest
import os
import sys
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch, call
from datetime import datetime
from click.testing import CliRunner

# Add parent directory to path
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from cli.cli import main, deploy_command, validate_command, status_command, cleanup_command
from models.data_models import (
    DeploymentConfig,
    AgentConfig,
    IAMPolicyConfig,
    DeploymentState,
    AgentDeploymentState,
    DeploymentResult,
    AgentDeploymentResult
)


@pytest.fixture
def mock_config():
    """Create a mock deployment configuration."""
    return DeploymentConfig(
        aws_account_id="123456789012",
        aws_region="us-east-1",
        agents=[
            AgentConfig(
                name="test-agent-1",
                directory="test-agent-1",
                entrypoint="agent.py",
                server_protocol="A2A"
            ),
            AgentConfig(
                name="test-agent-2",
                directory="test-agent-2",
                entrypoint="agent.py",
                server_protocol="A2A"
            )
        ],
        iam_policies=IAMPolicyConfig(
            base_policy={},
            cross_agent_policy_template={}
        ),
        deployment_order=["test-agent-1", "test-agent-2"]
    )


@pytest.fixture
def mock_deployment_state():
    """Create a mock deployment state."""
    return DeploymentState(
        agents={
            "test-agent-1": AgentDeploymentState(
                agent_name="test-agent-1",
                agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/test-agent-1",
                execution_role_arn="arn:aws:iam::123456789012:role/TestRole1",
                ecr_repository_uri="123456789012.dkr.ecr.us-east-1.amazonaws.com/test-agent-1",
                codebuild_project_name="bedrock-agentcore-test-agent-1-builder",
                memory_arn="arn:aws:bedrock:us-east-1:123456789012:memory/test-agent-1",
                deployed_at=datetime.now()
            ),
            "test-agent-2": AgentDeploymentState(
                agent_name="test-agent-2",
                agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/test-agent-2",
                execution_role_arn="arn:aws:iam::123456789012:role/TestRole2",
                ecr_repository_uri="123456789012.dkr.ecr.us-east-1.amazonaws.com/test-agent-2",
                codebuild_project_name="bedrock-agentcore-test-agent-2-builder",
                memory_arn=None,
                deployed_at=datetime.now()
            )
        },
        last_deployment=datetime.now(),
        deployment_version="1.0.0"
    )


class TestCLIMain:
    """Test the main CLI entry point."""
    
    def test_main_help(self):
        """Test that main CLI shows help."""
        runner = CliRunner()
        result = runner.invoke(main, ['--help'])
        
        assert result.exit_code == 0
        assert 'AgentCore Automated Deployment System' in result.output
        assert 'deploy' in result.output
        assert 'validate' in result.output
        assert 'status' in result.output
        assert 'cleanup' in result.output
    
    def test_main_version(self):
        """Test that main CLI shows version."""
        runner = CliRunner()
        result = runner.invoke(main, ['--version'])
        
        assert result.exit_code == 0
        assert '1.0.0' in result.output


class TestDeployCommand:
    """Test the deploy command."""
    
    @patch('cli.cli.ConfigurationManager')
    @patch('cli.cli.AWSResourceManager')
    @patch('cli.cli.StateManager')
    @patch('cli.cli.AgentDeploymentOrchestrator')
    def test_deploy_command_success(
        self,
        mock_orchestrator_class,
        mock_state_manager_class,
        mock_aws_manager_class,
        mock_config_manager_class,
        mock_config,
        tmp_path
    ):
        """Test successful deployment."""
        # Setup mocks
        config_file = tmp_path / "deployment.yaml"
        config_file.write_text("test: config")
        
        mock_config_manager = Mock()
        mock_config_manager.load_config.return_value = mock_config
        mock_config_manager.validate_config.return_value = []
        mock_config_manager.validate_agent_directories.return_value = []
        mock_config_manager_class.return_value = mock_config_manager
        
        mock_aws_manager = Mock()
        mock_aws_manager.validate_credentials.return_value = {
            'account_id': '123456789012',
            'user_id': 'test-user',
            'arn': 'arn:aws:iam::123456789012:user/test'
        }
        mock_aws_manager.check_service_quotas.return_value = {'warnings': []}
        mock_aws_manager_class.return_value = mock_aws_manager
        
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = DeploymentState(
            agents={},
            last_deployment=datetime.now(),
            deployment_version="1.0.0"
        )
        mock_state_manager_class.return_value = mock_state_manager
        
        mock_orchestrator = Mock()
        mock_orchestrator.deploy_all_agents.return_value = DeploymentResult(
            success=True,
            deployed_agents=[
                AgentDeploymentResult(
                    success=True,
                    agent_name="test-agent-1",
                    agent_arn="arn:aws:bedrock:us-east-1:123456789012:agent/test-agent-1",
                    execution_role_arn="arn:aws:iam::123456789012:role/TestRole1"
                )
            ],
            failed_agents=[],
            total_duration=10.5
        )
        mock_orchestrator_class.return_value = mock_orchestrator
        
        # Run command
        runner = CliRunner()
        result = runner.invoke(main, ['deploy', '--config', str(config_file)])
        
        # Assertions
        assert result.exit_code == 0
        assert 'Deployment completed successfully' in result.output
        mock_config_manager.load_config.assert_called_once()
        mock_config_manager.validate_config.assert_called_once()
        mock_aws_manager.validate_credentials.assert_called_once()
        mock_orchestrator.deploy_all_agents.assert_called_once()
    
    @patch('cli.cli.ConfigurationManager')
    def test_deploy_command_config_validation_failure(
        self,
        mock_config_manager_class,
        tmp_path
    ):
        """Test deployment with configuration validation failure."""
        config_file = tmp_path / "deployment.yaml"
        config_file.write_text("test: config")
        
        mock_config_manager = Mock()
        mock_config_manager.load_config.return_value = Mock()
        mock_config_manager.validate_config.return_value = [
            Exception("aws_account_id: AWS account ID is required")
        ]
        mock_config_manager_class.return_value = mock_config_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['deploy', '--config', str(config_file)])
        
        assert result.exit_code == 1
        assert 'Configuration validation failed' in result.output
    
    @patch('cli.cli.ConfigurationManager')
    @patch('cli.cli.AWSResourceManager')
    def test_deploy_command_aws_credentials_failure(
        self,
        mock_aws_manager_class,
        mock_config_manager_class,
        mock_config,
        tmp_path
    ):
        """Test deployment with AWS credentials validation failure."""
        config_file = tmp_path / "deployment.yaml"
        config_file.write_text("test: config")
        
        mock_config_manager = Mock()
        mock_config_manager.load_config.return_value = mock_config
        mock_config_manager.validate_config.return_value = []
        mock_config_manager.validate_agent_directories.return_value = []
        mock_config_manager_class.return_value = mock_config_manager
        
        mock_aws_manager = Mock()
        mock_aws_manager.validate_credentials.side_effect = Exception(
            "AWS credentials are invalid"
        )
        mock_aws_manager_class.return_value = mock_aws_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['deploy', '--config', str(config_file)])
        
        assert result.exit_code == 1
        assert 'AWS credentials are invalid' in result.output


class TestValidateCommand:
    """Test the validate command."""
    
    @patch('cli.cli.ConfigurationManager')
    def test_validate_command_success(
        self,
        mock_config_manager_class,
        mock_config,
        tmp_path
    ):
        """Test successful configuration validation."""
        config_file = tmp_path / "deployment.yaml"
        config_file.write_text("test: config")
        
        mock_config_manager = Mock()
        mock_config_manager.load_config.return_value = mock_config
        mock_config_manager.validate_config.return_value = []
        mock_config_manager.validate_agent_directories.return_value = []
        mock_config_manager_class.return_value = mock_config_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['validate', '--config', str(config_file)])
        
        assert result.exit_code == 0
        assert 'Configuration is valid' in result.output
        mock_config_manager.load_config.assert_called_once()
        mock_config_manager.validate_config.assert_called_once()
        mock_config_manager.validate_agent_directories.assert_called_once()
    
    @patch('cli.cli.ConfigurationManager')
    def test_validate_command_failure(
        self,
        mock_config_manager_class,
        tmp_path
    ):
        """Test configuration validation with errors."""
        config_file = tmp_path / "deployment.yaml"
        config_file.write_text("test: config")
        
        mock_config_manager = Mock()
        mock_config_manager.load_config.return_value = Mock()
        mock_config_manager.validate_config.return_value = [
            Exception("aws_region: AWS region is required")
        ]
        mock_config_manager_class.return_value = mock_config_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['validate', '--config', str(config_file)])
        
        assert result.exit_code == 1
        assert 'validation error' in result.output


class TestStatusCommand:
    """Test the status command."""
    
    @patch('cli.cli.StateManager')
    def test_status_command_with_agents(
        self,
        mock_state_manager_class,
        mock_deployment_state
    ):
        """Test status command with deployed agents."""
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = mock_deployment_state
        mock_state_manager_class.return_value = mock_state_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['status'])
        
        assert result.exit_code == 0
        assert 'Deployment Status' in result.output
        assert 'test-agent-1' in result.output
        assert 'test-agent-2' in result.output
        mock_state_manager.load_state.assert_called_once()
    
    @patch('cli.cli.StateManager')
    def test_status_command_no_agents(
        self,
        mock_state_manager_class
    ):
        """Test status command with no deployed agents."""
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = DeploymentState(
            agents={},
            last_deployment=datetime.now(),
            deployment_version="1.0.0"
        )
        mock_state_manager_class.return_value = mock_state_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['status'])
        
        assert result.exit_code == 0
        assert 'No agents have been deployed' in result.output


class TestCleanupCommand:
    """Test the cleanup command."""
    
    @patch('cli.cli.StateManager')
    @patch('cli.cli.click.confirm')
    def test_cleanup_command_with_confirmation(
        self,
        mock_confirm,
        mock_state_manager_class,
        mock_deployment_state
    ):
        """Test cleanup command with user confirmation."""
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = mock_deployment_state
        mock_state_manager_class.return_value = mock_state_manager
        
        mock_confirm.return_value = True
        
        runner = CliRunner()
        result = runner.invoke(main, ['cleanup'])
        
        assert result.exit_code == 0
        assert 'Cleanup completed' in result.output
        mock_state_manager.clear_state.assert_called_once()
    
    @patch('cli.cli.StateManager')
    @patch('cli.cli.click.confirm')
    def test_cleanup_command_cancelled(
        self,
        mock_confirm,
        mock_state_manager_class,
        mock_deployment_state
    ):
        """Test cleanup command cancelled by user."""
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = mock_deployment_state
        mock_state_manager_class.return_value = mock_state_manager
        
        mock_confirm.return_value = False
        
        runner = CliRunner()
        result = runner.invoke(main, ['cleanup'])
        
        assert result.exit_code == 0
        assert 'Cleanup cancelled' in result.output
        mock_state_manager.clear_state.assert_not_called()
    
    @patch('cli.cli.StateManager')
    def test_cleanup_command_with_yes_flag(
        self,
        mock_state_manager_class,
        mock_deployment_state
    ):
        """Test cleanup command with --yes flag (skip confirmation)."""
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = mock_deployment_state
        mock_state_manager_class.return_value = mock_state_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['cleanup', '--yes'])
        
        assert result.exit_code == 0
        assert 'Cleanup completed' in result.output
        mock_state_manager.clear_state.assert_called_once()
    
    @patch('cli.cli.StateManager')
    def test_cleanup_command_no_agents(
        self,
        mock_state_manager_class
    ):
        """Test cleanup command with no deployed agents."""
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = DeploymentState(
            agents={},
            last_deployment=datetime.now(),
            deployment_version="1.0.0"
        )
        mock_state_manager_class.return_value = mock_state_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['cleanup'])
        
        assert result.exit_code == 0
        assert 'No agents have been deployed' in result.output
    
    @patch('cli.cli.StateManager')
    @patch('cli.cli.AWSResourceManager')
    def test_cleanup_command_with_delete_flags(
        self,
        mock_aws_manager_class,
        mock_state_manager_class,
        mock_deployment_state
    ):
        """Test cleanup command with resource deletion flags."""
        mock_state_manager = Mock()
        mock_state_manager.load_state.return_value = mock_deployment_state
        mock_state_manager_class.return_value = mock_state_manager
        
        mock_aws_manager = Mock()
        mock_aws_manager_class.return_value = mock_aws_manager
        
        runner = CliRunner()
        result = runner.invoke(main, [
            'cleanup',
            '--yes',
            '--delete-ecr',
            '--delete-codebuild',
            '--delete-iam'
        ])
        
        assert result.exit_code == 0
        assert 'Cleanup completed' in result.output


class TestErrorHandling:
    """Test error handling in CLI commands."""
    
    @patch('cli.cli.ConfigurationManager')
    def test_deploy_command_handles_keyboard_interrupt(
        self,
        mock_config_manager_class,
        tmp_path
    ):
        """Test that deploy command handles keyboard interrupt gracefully."""
        config_file = tmp_path / "deployment.yaml"
        config_file.write_text("test: config")
        
        mock_config_manager = Mock()
        mock_config_manager.load_config.side_effect = KeyboardInterrupt()
        mock_config_manager_class.return_value = mock_config_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['deploy', '--config', str(config_file)])
        
        assert result.exit_code == 130
        assert 'interrupted' in result.output.lower()
    
    @patch('cli.cli.ConfigurationManager')
    def test_deploy_command_handles_unexpected_error(
        self,
        mock_config_manager_class,
        tmp_path
    ):
        """Test that deploy command handles unexpected errors."""
        config_file = tmp_path / "deployment.yaml"
        config_file.write_text("test: config")
        
        mock_config_manager = Mock()
        mock_config_manager.load_config.side_effect = Exception("Unexpected error")
        mock_config_manager_class.return_value = mock_config_manager
        
        runner = CliRunner()
        result = runner.invoke(main, ['deploy', '--config', str(config_file)])
        
        assert result.exit_code == 1
        assert 'Unexpected error' in result.output


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
