"""
Unit Tests for AWSResourceManager

Tests the AWS Resource Manager coordinator class that manages IAM and S3
operations with credential validation and service quota checking.

Requirements: 11.1, 11.6, 14.4
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from botocore.exceptions import ClientError, NoCredentialsError

from deployment_tool.managers.aws_resource_manager import AWSResourceManager


class TestAWSResourceManagerInitialization:
    """Test AWSResourceManager initialization and session creation."""
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_init_with_region_only(self, mock_session_class):
        """Test initialization with region only (uses default credentials)."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock client creation
        mock_sts = Mock()
        mock_iam = Mock()
        mock_s3 = Mock()
        
        def client_factory(service_name):
            if service_name == 'sts':
                return mock_sts
            elif service_name == 'iam':
                return mock_iam
            elif service_name == 's3':
                return mock_s3
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Create manager
        manager = AWSResourceManager(region='us-east-1')
        
        # Verify session created with region
        mock_session_class.assert_called_once_with(region_name='us-east-1')
        
        # Verify managers initialized
        assert manager.iam_manager is not None
        assert manager.s3_manager is not None
        assert manager.region == 'us-east-1'
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_init_with_explicit_credentials(self, mock_session_class):
        """Test initialization with explicit AWS credentials."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock client creation
        mock_session.client.return_value = Mock()
        
        # Create manager with explicit credentials
        manager = AWSResourceManager(
            region='us-west-2',
            aws_access_key_id='AKIAIOSFODNN7EXAMPLE',
            aws_secret_access_key='wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'
        )
        
        # Verify session created with credentials
        mock_session_class.assert_called_once_with(
            region_name='us-west-2',
            aws_access_key_id='AKIAIOSFODNN7EXAMPLE',
            aws_secret_access_key='wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'
        )
        
        assert manager.region == 'us-west-2'
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_init_with_profile(self, mock_session_class):
        """Test initialization with AWS profile name."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock client creation
        mock_session.client.return_value = Mock()
        
        # Create manager with profile
        manager = AWSResourceManager(
            region='eu-west-1',
            profile_name='my-profile'
        )
        
        # Verify session created with profile
        mock_session_class.assert_called_once_with(
            region_name='eu-west-1',
            profile_name='my-profile'
        )
        
        assert manager.region == 'eu-west-1'
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_init_with_session_token(self, mock_session_class):
        """Test initialization with session token (temporary credentials)."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock client creation
        mock_session.client.return_value = Mock()
        
        # Create manager with session token
        manager = AWSResourceManager(
            region='ap-southeast-1',
            aws_access_key_id='AKIAIOSFODNN7EXAMPLE',
            aws_secret_access_key='wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
            aws_session_token='FwoGZXIvYXdzEBYaDH...'
        )
        
        # Verify session created with session token
        mock_session_class.assert_called_once_with(
            region_name='ap-southeast-1',
            aws_access_key_id='AKIAIOSFODNN7EXAMPLE',
            aws_secret_access_key='wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
            aws_session_token='FwoGZXIvYXdzEBYaDH...'
        )
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_init_fails_with_no_credentials(self, mock_session_class):
        """Test initialization fails gracefully when no credentials available."""
        mock_session_class.side_effect = NoCredentialsError()
        
        # Attempt to create manager should raise exception
        with pytest.raises(Exception) as exc_info:
            AWSResourceManager(region='us-east-1')
        
        assert 'credentials not found' in str(exc_info.value).lower()


class TestCredentialValidation:
    """Test AWS credential validation functionality."""
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_validate_credentials_success(self, mock_session_class):
        """Test successful credential validation."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock STS client
        mock_sts = Mock()
        mock_sts.get_caller_identity.return_value = {
            'Account': '123456789012',
            'UserId': 'AIDAI123456789EXAMPLE',
            'Arn': 'arn:aws:iam::123456789012:user/testuser'
        }
        
        mock_session.client.return_value = mock_sts
        
        # Create manager and validate
        manager = AWSResourceManager(region='us-east-1')
        result = manager.validate_credentials()
        
        # Verify result
        assert result['account_id'] == '123456789012'
        assert result['user_id'] == 'AIDAI123456789EXAMPLE'
        assert result['arn'] == 'arn:aws:iam::123456789012:user/testuser'
        
        # Verify STS was called
        mock_sts.get_caller_identity.assert_called_once()
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_validate_credentials_invalid_key_id(self, mock_session_class):
        """Test validation with invalid access key ID."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock STS client to return invalid key error
        mock_sts = Mock()
        mock_sts.get_caller_identity.side_effect = ClientError(
            {
                'Error': {
                    'Code': 'InvalidClientTokenId',
                    'Message': 'The security token included in the request is invalid'
                }
            },
            'GetCallerIdentity'
        )
        
        mock_session.client.return_value = mock_sts
        
        # Create manager and validate
        manager = AWSResourceManager(region='us-east-1')
        
        with pytest.raises(Exception) as exc_info:
            manager.validate_credentials()
        
        assert 'access key ID does not exist' in str(exc_info.value)
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_validate_credentials_invalid_secret(self, mock_session_class):
        """Test validation with invalid secret access key."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock STS client to return signature mismatch error
        mock_sts = Mock()
        mock_sts.get_caller_identity.side_effect = ClientError(
            {
                'Error': {
                    'Code': 'SignatureDoesNotMatch',
                    'Message': 'The request signature we calculated does not match'
                }
            },
            'GetCallerIdentity'
        )
        
        mock_session.client.return_value = mock_sts
        
        # Create manager and validate
        manager = AWSResourceManager(region='us-east-1')
        
        with pytest.raises(Exception) as exc_info:
            manager.validate_credentials()
        
        assert 'secret access key is incorrect' in str(exc_info.value)
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_validate_credentials_access_denied(self, mock_session_class):
        """Test validation when credentials lack permissions."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock STS client to return access denied error
        mock_sts = Mock()
        mock_sts.get_caller_identity.side_effect = ClientError(
            {
                'Error': {
                    'Code': 'AccessDenied',
                    'Message': 'User is not authorized to perform: sts:GetCallerIdentity'
                }
            },
            'GetCallerIdentity'
        )
        
        mock_session.client.return_value = mock_sts
        
        # Create manager and validate
        manager = AWSResourceManager(region='us-east-1')
        
        with pytest.raises(Exception) as exc_info:
            manager.validate_credentials()
        
        assert 'permission' in str(exc_info.value).lower()
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_validate_credentials_no_credentials(self, mock_session_class):
        """Test validation when no credentials are configured."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock STS client to raise NoCredentialsError
        mock_sts = Mock()
        mock_sts.get_caller_identity.side_effect = NoCredentialsError()
        
        mock_session.client.return_value = mock_sts
        
        # Create manager and validate
        manager = AWSResourceManager(region='us-east-1')
        
        with pytest.raises(Exception) as exc_info:
            manager.validate_credentials()
        
        assert 'credentials not found' in str(exc_info.value).lower()


class TestServiceQuotaChecking:
    """Test service quota checking functionality."""
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_check_service_quotas_success(self, mock_session_class):
        """Test successful service quota checking."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock IAM client
        mock_iam = Mock()
        mock_iam.get_account_summary.return_value = {
            'SummaryMap': {
                'RolesQuota': 1000,
                'Roles': 50
            }
        }
        
        # Mock ECR client
        mock_ecr = Mock()
        mock_paginator = Mock()
        mock_paginator.paginate.return_value = [
            {'repositories': [{'repositoryName': f'repo{i}'} for i in range(10)]}
        ]
        mock_ecr.get_paginator.return_value = mock_paginator
        
        def client_factory(service_name):
            if service_name == 'iam':
                return mock_iam
            elif service_name == 'ecr':
                return mock_ecr
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Create manager and check quotas
        manager = AWSResourceManager(region='us-east-1')
        result = manager.check_service_quotas()
        
        # Verify result structure
        assert 'iam_roles' in result
        assert 'ecr_repositories' in result
        assert 'warnings' in result
        
        # Verify IAM quota info
        assert result['iam_roles']['current'] == 50
        assert result['iam_roles']['limit'] == 1000
        assert result['iam_roles']['available'] == 950
        
        # Verify ECR quota info
        assert result['ecr_repositories']['current'] == 10
        assert result['ecr_repositories']['limit'] == 10000
        
        # No warnings expected
        assert len(result['warnings']) == 0
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_check_service_quotas_approaching_limit(self, mock_session_class):
        """Test quota checking when approaching limits."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock IAM client with high usage
        mock_iam = Mock()
        mock_iam.get_account_summary.return_value = {
            'SummaryMap': {
                'RolesQuota': 1000,
                'Roles': 950  # 95% usage
            }
        }
        
        # Mock ECR client
        mock_ecr = Mock()
        mock_paginator = Mock()
        mock_paginator.paginate.return_value = [
            {'repositories': []}
        ]
        mock_ecr.get_paginator.return_value = mock_paginator
        
        def client_factory(service_name):
            if service_name == 'iam':
                return mock_iam
            elif service_name == 'ecr':
                return mock_ecr
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Create manager and check quotas
        manager = AWSResourceManager(region='us-east-1')
        result = manager.check_service_quotas()
        
        # Verify warning generated
        assert len(result['warnings']) > 0
        assert any('IAM roles quota' in w for w in result['warnings'])
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_check_service_quotas_handles_api_errors(self, mock_session_class):
        """Test quota checking handles API errors gracefully."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        # Mock IAM client to fail
        mock_iam = Mock()
        mock_iam.get_account_summary.side_effect = ClientError(
            {
                'Error': {
                    'Code': 'AccessDenied',
                    'Message': 'Not authorized'
                }
            },
            'GetAccountSummary'
        )
        
        # Mock ECR client to succeed
        mock_ecr = Mock()
        mock_paginator = Mock()
        mock_paginator.paginate.return_value = [
            {'repositories': []}
        ]
        mock_ecr.get_paginator.return_value = mock_paginator
        
        def client_factory(service_name):
            if service_name == 'iam':
                return mock_iam
            elif service_name == 'ecr':
                return mock_ecr
            return Mock()
        
        mock_session.client.side_effect = client_factory
        
        # Create manager and check quotas
        manager = AWSResourceManager(region='us-east-1')
        result = manager.check_service_quotas()
        
        # Should have warning about IAM quota check failure
        assert len(result['warnings']) > 0
        assert any('Could not check IAM quotas' in w for w in result['warnings'])
        
        # ECR quota should still be present
        assert 'ecr_repositories' in result


class TestManagerIntegration:
    """Test integration between AWSResourceManager and sub-managers."""
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_iam_manager_accessible(self, mock_session_class):
        """Test that IAM manager is properly initialized and accessible."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        mock_session.client.return_value = Mock()
        
        manager = AWSResourceManager(region='us-east-1')
        
        # Verify IAM manager is accessible
        assert manager.iam_manager is not None
        assert hasattr(manager.iam_manager, 'role_exists')
        assert hasattr(manager.iam_manager, 'attach_base_policy')
        assert hasattr(manager.iam_manager, 'create_cross_agent_policy')
    
    @patch('deployment_tool.managers.aws_resource_manager.boto3.Session')
    def test_s3_manager_accessible(self, mock_session_class):
        """Test that S3 manager is properly initialized and accessible."""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        mock_session.client.return_value = Mock()
        
        manager = AWSResourceManager(region='us-east-1')
        
        # Verify S3 manager is accessible
        assert manager.s3_manager is not None
        assert hasattr(manager.s3_manager, 'bucket_exists')
        assert hasattr(manager.s3_manager, 'create_vector_bucket')
        assert hasattr(manager.s3_manager, 'configure_bucket_policy')
