"""
Property-based tests for IAM Role Creation Idempotency.

This module implements Property 2: IAM Role Creation Idempotency
For any execution role name, creating the role multiple times should result in
the same role ARN and the role should have all required policies attached.

**Validates: Requirements 2.1, 2.9, 9.2, 9.3**

Testing Strategy:
- Generate random role names and policy documents
- Verify that checking if a role exists multiple times returns consistent results
- Verify that attaching the same policy multiple times doesn't cause errors
- Verify that role operations can be safely retried
- Test with minimum 100 iterations using hypothesis
"""

import json
from typing import Dict, List
from unittest.mock import Mock, MagicMock, patch, call
import pytest
from hypothesis import given, strategies as st, settings, assume
from botocore.exceptions import ClientError

from deployment_tool.managers.iam_manager import IAMManager


# ============================================================================
# Strategy Definitions
# ============================================================================

@st.composite
def valid_role_name(draw) -> str:
    """Generate a valid IAM role name.
    
    IAM role names must be:
    - 1-64 characters long
    - Alphanumeric plus: + = , . @ - _
    """
    # Use a subset of allowed characters for simplicity
    name = draw(st.text(
        alphabet=st.characters(
            whitelist_categories=('Lu', 'Ll', 'Nd'),
            whitelist_characters='-_'
        ),
        min_size=3,
        max_size=64
    ))
    # Ensure it doesn't start or end with special characters
    name = name.strip('-_')
    assume(len(name) >= 3)
    return name


@st.composite
def valid_iam_policy_document(draw) -> dict:
    """Generate a valid IAM policy document."""
    # Generate 1-5 actions
    actions = draw(st.lists(
        st.sampled_from([
            "s3:GetObject",
            "s3:PutObject",
            "s3:ListBucket",
            "bedrock-agentcore:InvokeRuntime",
            "bedrock-agentcore:GetMemory",
            "bedrock-agentcore:PutMemory",
            "logs:CreateLogGroup",
            "logs:CreateLogStream",
            "logs:PutLogEvents"
        ]),
        min_size=1,
        max_size=5,
        unique=True
    ))
    
    # Generate resource ARNs or use wildcard
    use_wildcard = draw(st.booleans())
    if use_wildcard:
        resources = "*"
    else:
        resources = draw(st.lists(
            st.builds(
                lambda service, resource: f"arn:aws:{service}:*:*:{resource}/*",
                service=st.sampled_from(['s3', 'bedrock', 'logs']),
                resource=st.text(
                    alphabet=st.characters(whitelist_categories=('Ll', 'Nd'), whitelist_characters='-'),
                    min_size=3,
                    max_size=20
                )
            ),
            min_size=1,
            max_size=3
        ))
    
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": actions,
                "Resource": resources
            }
        ]
    }


@st.composite
def agent_arn_list(draw) -> List[str]:
    """Generate a list of unique agent ARNs."""
    # Generate unique agent IDs first
    num_arns = draw(st.integers(min_value=1, max_value=5))
    agent_ids = draw(st.lists(
        st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='-'),
            min_size=10,
            max_size=30
        ).filter(lambda x: x and not x.startswith('-') and not x.endswith('-')),
        min_size=num_arns,
        max_size=num_arns,
        unique=True
    ))
    
    arns = []
    for agent_id in agent_ids:
        region = draw(st.sampled_from(['us-east-1', 'us-west-2', 'eu-west-1']))
        account = draw(st.integers(min_value=100000000000, max_value=999999999999))
        arns.append(f"arn:aws:bedrock:{region}:{account}:agent/{agent_id}")
    return arns


@st.composite
def memory_arn_list(draw) -> List[str]:
    """Generate a list of unique memory ARNs."""
    num_arns = draw(st.integers(min_value=0, max_value=5))
    if num_arns == 0:
        return []
    
    # Generate unique memory IDs first
    memory_ids = draw(st.lists(
        st.text(
            alphabet=st.characters(whitelist_categories=('Lu', 'Ll', 'Nd'), whitelist_characters='-'),
            min_size=10,
            max_size=30
        ).filter(lambda x: x and not x.startswith('-') and not x.endswith('-')),
        min_size=num_arns,
        max_size=num_arns,
        unique=True
    ))
    
    arns = []
    for memory_id in memory_ids:
        region = draw(st.sampled_from(['us-east-1', 'us-west-2', 'eu-west-1']))
        account = draw(st.integers(min_value=100000000000, max_value=999999999999))
        arns.append(f"arn:aws:bedrock:{region}:{account}:memory/{memory_id}")
    return arns


# ============================================================================
# Property-Based Tests
# ============================================================================

class TestPropertyIAMRoleIdempotency:
    """
    Property 2: IAM Role Creation Idempotency
    
    **Validates: Requirements 2.1, 2.9, 9.2, 9.3**
    
    For any execution role name, creating the role multiple times should result in
    the same role ARN and the role should have all required policies attached.
    """
    
    @given(role_name=valid_role_name())
    @settings(max_examples=100, deadline=None)
    def test_property_2_role_exists_check_is_idempotent(self, role_name):
        """
        Property: Checking if a role exists multiple times returns consistent results.
        
        This test verifies that:
        1. Calling role_exists() multiple times with the same role name returns the same result
        2. The operation is safe to retry without side effects
        3. Both existing and non-existing roles are handled consistently
        
        **Validates: Requirements 2.9, 9.2**
        """
        # Create mock boto3 session and IAM client
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        # Test case 1: Role exists
        mock_iam_client.get_role.return_value = {
            'Role': {
                'RoleName': role_name,
                'Arn': f'arn:aws:iam::123456789012:role/{role_name}'
            }
        }
        
        iam_manager = IAMManager(mock_session)
        
        # Call role_exists multiple times
        results = [iam_manager.role_exists(role_name) for _ in range(5)]
        
        # Property assertion: All calls should return the same result
        assert all(result == results[0] for result in results), (
            f"role_exists() must return consistent results for role '{role_name}'"
        )
        assert results[0] is True, "Role should exist in this test case"
        
        # Verify get_role was called the expected number of times
        assert mock_iam_client.get_role.call_count == 5, (
            "get_role should be called once per role_exists call"
        )
        
        # Test case 2: Role does not exist
        mock_iam_client.reset_mock()
        mock_iam_client.get_role.side_effect = ClientError(
            {'Error': {'Code': 'NoSuchEntity', 'Message': 'Role not found'}},
            'GetRole'
        )
        
        iam_manager2 = IAMManager(mock_session)
        
        # Call role_exists multiple times
        results2 = [iam_manager2.role_exists(role_name) for _ in range(5)]
        
        # Property assertion: All calls should return the same result
        assert all(result == results2[0] for result in results2), (
            f"role_exists() must return consistent results for non-existent role '{role_name}'"
        )
        assert results2[0] is False, "Role should not exist in this test case"
    
    @given(
        role_name=valid_role_name(),
        policy_document=valid_iam_policy_document()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_2_attach_policy_is_idempotent(self, role_name, policy_document):
        """
        Property: Attaching the same policy multiple times doesn't cause errors.
        
        This test verifies that:
        1. Calling attach_base_policy() multiple times with the same policy succeeds
        2. The operation can be safely retried
        3. No duplicate policies are created
        4. The final state is consistent regardless of retry count
        
        **Validates: Requirements 2.5, 2.9, 9.3**
        """
        # Create mock boto3 session and IAM client
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        # Mock successful policy attachment
        mock_iam_client.put_role_policy.return_value = {}
        
        iam_manager = IAMManager(mock_session)
        
        # Attach the same policy multiple times
        for i in range(5):
            try:
                iam_manager.attach_base_policy(role_name, policy_document)
            except Exception as e:
                pytest.fail(
                    f"attach_base_policy() should not raise exception on retry {i+1}: {e}"
                )
        
        # Property assertion: put_role_policy should be called 5 times
        assert mock_iam_client.put_role_policy.call_count == 5, (
            "put_role_policy should be called once per attach_base_policy call"
        )
        
        # Property assertion: All calls should use the same policy document
        for call_args in mock_iam_client.put_role_policy.call_args_list:
            kwargs = call_args[1]
            assert kwargs['RoleName'] == role_name
            assert kwargs['PolicyName'] == f"{role_name}-base-policy"
            
            # Parse and compare policy documents
            actual_policy = json.loads(kwargs['PolicyDocument'])
            assert actual_policy == policy_document, (
                "Policy document must remain consistent across retries"
            )
    
    @given(
        role_names=st.lists(valid_role_name(), min_size=1, max_size=5, unique=True),
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_2_cross_agent_policy_application_is_idempotent(
        self,
        role_names,
        agent_arns,
        memory_arns
    ):
        """
        Property: Applying cross-agent policy multiple times is safe and idempotent.
        
        This test verifies that:
        1. Creating cross-agent policy multiple times produces the same result
        2. Applying the policy to roles multiple times doesn't cause errors
        3. The policy content remains consistent across applications
        4. All specified ARNs are included in the policy
        
        **Validates: Requirements 2.7, 2.8, 2.10, 9.3**
        """
        # Create mock boto3 session and IAM client
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        # Mock successful policy attachment
        mock_iam_client.put_role_policy.return_value = {}
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy multiple times
        policies = [
            iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
            for _ in range(5)
        ]
        
        # Property assertion: All generated policies should be identical
        for policy in policies[1:]:
            assert policy == policies[0], (
                "create_cross_agent_policy() must produce consistent results"
            )
        
        # Verify policy structure
        policy = policies[0]
        assert 'Version' in policy
        assert 'Statement' in policy
        assert isinstance(policy['Statement'], list)
        
        # Verify agent ARNs are included
        if agent_arns:
            agent_statement = next(
                (s for s in policy['Statement'] 
                 if 'bedrock-agentcore:InvokeRuntime' in s.get('Action', [])),
                None
            )
            assert agent_statement is not None, (
                "Policy must include InvokeRuntime statement when agent ARNs provided"
            )
            assert set(agent_statement['Resource']) == set(agent_arns), (
                "Policy must include all agent ARNs"
            )
        
        # Verify memory ARNs are included
        if memory_arns:
            memory_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:GetMemory' in s.get('Action', [])),
                None
            )
            assert memory_statement is not None, (
                "Policy must include memory access statement when memory ARNs provided"
            )
            assert set(memory_statement['Resource']) == set(memory_arns), (
                "Policy must include all memory ARNs"
            )
        
        # Apply the policy to all roles multiple times
        for attempt in range(3):
            try:
                iam_manager.apply_cross_agent_policy(role_names, policy)
            except Exception as e:
                pytest.fail(
                    f"apply_cross_agent_policy() should not raise exception on retry {attempt+1}: {e}"
                )
        
        # Property assertion: put_role_policy should be called for each role on each attempt
        expected_calls = len(role_names) * 3
        assert mock_iam_client.put_role_policy.call_count == expected_calls, (
            f"put_role_policy should be called {expected_calls} times "
            f"({len(role_names)} roles × 3 attempts)"
        )
        
        # Verify all roles received the policy
        called_roles = set()
        for call_args in mock_iam_client.put_role_policy.call_args_list:
            kwargs = call_args[1]
            called_roles.add(kwargs['RoleName'])
            assert kwargs['PolicyName'] == 'cross-agent-communication-policy'
            
            # Verify policy document is consistent
            actual_policy = json.loads(kwargs['PolicyDocument'])
            assert actual_policy == policy, (
                "Policy document must remain consistent across all applications"
            )
        
        assert called_roles == set(role_names), (
            "All roles must receive the cross-agent policy"
        )
    
    @given(
        role_name=valid_role_name(),
        policy_document=valid_iam_policy_document(),
        num_retries=st.integers(min_value=1, max_value=5)
    )
    @settings(max_examples=100, deadline=None)
    @patch('time.sleep')  # Mock sleep to avoid delays in tests
    def test_property_2_policy_attachment_retries_on_throttling(
        self,
        mock_sleep,
        role_name,
        policy_document,
        num_retries
    ):
        """
        Property: Policy attachment operations retry on transient errors.
        
        This test verifies that:
        1. Throttling errors trigger automatic retries
        2. Operations eventually succeed after transient failures
        3. Retry logic uses exponential backoff
        4. Final result is consistent regardless of retry count
        
        **Validates: Requirements 2.9, 9.3**
        """
        # Create mock boto3 session and IAM client
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        # Simulate throttling for first few attempts, then success
        throttle_error = ClientError(
            {'Error': {'Code': 'Throttling', 'Message': 'Rate exceeded'}},
            'PutRolePolicy'
        )
        
        # Create side effect: fail num_retries-1 times, then succeed
        side_effects = [throttle_error] * (num_retries - 1) + [{}]
        mock_iam_client.put_role_policy.side_effect = side_effects
        
        iam_manager = IAMManager(mock_session)
        
        # Attempt to attach policy (should succeed after retries)
        try:
            iam_manager.attach_base_policy(role_name, policy_document)
        except Exception as e:
            pytest.fail(
                f"attach_base_policy() should succeed after {num_retries-1} throttling errors: {e}"
            )
        
        # Property assertion: put_role_policy should be called num_retries times
        assert mock_iam_client.put_role_policy.call_count == num_retries, (
            f"put_role_policy should be called {num_retries} times "
            f"({num_retries-1} failures + 1 success)"
        )
        
        # Verify all calls used the same parameters
        for call_args in mock_iam_client.put_role_policy.call_args_list:
            kwargs = call_args[1]
            assert kwargs['RoleName'] == role_name
            assert kwargs['PolicyName'] == f"{role_name}-base-policy"
            actual_policy = json.loads(kwargs['PolicyDocument'])
            assert actual_policy == policy_document
        
        # Verify sleep was called for retries (exponential backoff)
        if num_retries > 1:
            assert mock_sleep.call_count == num_retries - 1, (
                f"sleep should be called {num_retries - 1} times for retries"
            )
    
    @given(
        role_name=valid_role_name(),
        policy_document=valid_iam_policy_document()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_2_policy_attachment_fails_on_non_retryable_errors(
        self,
        role_name,
        policy_document
    ):
        """
        Property: Policy attachment fails fast on non-retryable errors.
        
        This test verifies that:
        1. Non-retryable errors (e.g., NoSuchEntity) are not retried
        2. Appropriate exceptions are raised with context
        3. Error messages include role name and error details
        
        **Validates: Requirements 2.9, 10.1, 10.2**
        """
        # Create mock boto3 session and IAM client
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        # Simulate non-retryable error
        no_such_entity_error = ClientError(
            {'Error': {'Code': 'NoSuchEntity', 'Message': 'Role does not exist'}},
            'PutRolePolicy'
        )
        mock_iam_client.put_role_policy.side_effect = no_such_entity_error
        
        iam_manager = IAMManager(mock_session)
        
        # Attempt to attach policy (should fail immediately)
        with pytest.raises(Exception) as exc_info:
            iam_manager.attach_base_policy(role_name, policy_document)
        
        # Property assertion: Error message should include role name
        error_message = str(exc_info.value)
        assert role_name in error_message, (
            f"Error message must include role name '{role_name}'"
        )
        
        # Property assertion: Error message should include error code
        assert 'NoSuchEntity' in error_message, (
            "Error message must include AWS error code"
        )
        
        # Property assertion: Should only attempt once (no retries for non-retryable errors)
        assert mock_iam_client.put_role_policy.call_count == 1, (
            "Non-retryable errors should not trigger retries"
        )
    
    @given(
        role_names=st.lists(valid_role_name(), min_size=2, max_size=5, unique=True),
        agent_arns=agent_arn_list(),
        memory_arns=memory_arn_list()
    )
    @settings(max_examples=100, deadline=None)
    def test_property_2_cross_agent_policy_includes_all_arns(
        self,
        role_names,
        agent_arns,
        memory_arns
    ):
        """
        Property: Cross-agent policy includes all provided ARNs.
        
        This test verifies that:
        1. All agent ARNs are included in the InvokeRuntime statement
        2. All memory ARNs are included in the memory access statement
        3. No ARNs are duplicated or omitted
        4. Policy structure is valid
        
        **Validates: Requirements 2.7, 2.8**
        """
        # Create mock boto3 session
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create cross-agent policy
        policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
        
        # Property assertion: Policy has correct structure
        assert 'Version' in policy
        assert policy['Version'] == '2012-10-17'
        assert 'Statement' in policy
        assert isinstance(policy['Statement'], list)
        
        # Property assertion: All agent ARNs are included
        if agent_arns:
            agent_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:InvokeRuntime' in s.get('Action', [])),
                None
            )
            assert agent_statement is not None, (
                "Policy must include InvokeRuntime statement when agent ARNs provided"
            )
            
            # Verify all agent ARNs are present
            policy_agent_arns = set(agent_statement['Resource'])
            expected_agent_arns = set(agent_arns)
            assert policy_agent_arns == expected_agent_arns, (
                f"Policy must include all agent ARNs. "
                f"Expected: {expected_agent_arns}, Got: {policy_agent_arns}"
            )
            
            # Verify no duplicates
            assert len(agent_statement['Resource']) == len(set(agent_statement['Resource'])), (
                "Policy must not contain duplicate agent ARNs"
            )
        
        # Property assertion: All memory ARNs are included
        if memory_arns:
            memory_statement = next(
                (s for s in policy['Statement']
                 if 'bedrock-agentcore:GetMemory' in s.get('Action', [])),
                None
            )
            assert memory_statement is not None, (
                "Policy must include memory access statement when memory ARNs provided"
            )
            
            # Verify all memory ARNs are present
            policy_memory_arns = set(memory_statement['Resource'])
            expected_memory_arns = set(memory_arns)
            assert policy_memory_arns == expected_memory_arns, (
                f"Policy must include all memory ARNs. "
                f"Expected: {expected_memory_arns}, Got: {policy_memory_arns}"
            )
            
            # Verify no duplicates
            assert len(memory_statement['Resource']) == len(set(memory_statement['Resource'])), (
                "Policy must not contain duplicate memory ARNs"
            )
            
            # Verify correct actions
            expected_actions = {'bedrock-agentcore:GetMemory', 'bedrock-agentcore:PutMemory'}
            actual_actions = set(memory_statement['Action'])
            assert actual_actions == expected_actions, (
                f"Memory statement must include GetMemory and PutMemory actions. "
                f"Expected: {expected_actions}, Got: {actual_actions}"
            )
        
        # Property assertion: No extra statements
        expected_statement_count = (1 if agent_arns else 0) + (1 if memory_arns else 0)
        assert len(policy['Statement']) == expected_statement_count, (
            f"Policy should have exactly {expected_statement_count} statement(s)"
        )


# ============================================================================
# Unit Tests for Edge Cases
# ============================================================================

class TestIAMRoleIdempotencyEdgeCases:
    """Unit tests for specific edge cases in IAM role idempotency."""
    
    def test_empty_agent_arns_produces_valid_policy(self):
        """Test that cross-agent policy with empty agent ARNs is valid."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with empty agent ARNs but some memory ARNs
        memory_arns = ['arn:aws:bedrock:us-east-1:123456789012:memory/mem-1']
        policy = iam_manager.create_cross_agent_policy([], memory_arns)
        
        # Should only have memory statement
        assert len(policy['Statement']) == 1
        assert 'bedrock-agentcore:GetMemory' in policy['Statement'][0]['Action']
    
    def test_empty_memory_arns_produces_valid_policy(self):
        """Test that cross-agent policy with empty memory ARNs is valid."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with some agent ARNs but empty memory ARNs
        agent_arns = ['arn:aws:bedrock:us-east-1:123456789012:agent/agent-1']
        policy = iam_manager.create_cross_agent_policy(agent_arns, [])
        
        # Should only have agent statement
        assert len(policy['Statement']) == 1
        assert 'bedrock-agentcore:InvokeRuntime' in policy['Statement'][0]['Action']
    
    def test_both_empty_arns_produces_empty_policy(self):
        """Test that cross-agent policy with no ARNs has no statements."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        iam_manager = IAMManager(mock_session)
        
        # Create policy with no ARNs
        policy = iam_manager.create_cross_agent_policy([], [])
        
        # Should have no statements
        assert len(policy['Statement']) == 0
        assert policy['Version'] == '2012-10-17'
    
    def test_role_exists_handles_access_denied_error(self):
        """Test that role_exists raises exception on AccessDenied error."""
        mock_session = Mock()
        mock_iam_client = Mock()
        mock_session.client.return_value = mock_iam_client
        
        # Simulate AccessDenied error
        access_denied_error = ClientError(
            {'Error': {'Code': 'AccessDenied', 'Message': 'Not authorized'}},
            'GetRole'
        )
        mock_iam_client.get_role.side_effect = access_denied_error
        
        iam_manager = IAMManager(mock_session)
        
        # Should raise exception (not return False)
        with pytest.raises(Exception) as exc_info:
            iam_manager.role_exists('test-role')
        
        assert 'test-role' in str(exc_info.value)
        assert 'AccessDenied' in str(exc_info.value) or 'Not authorized' in str(exc_info.value)
