"""
Property-based tests for AgentCore configuration file generation.

**Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8**

This module implements Property 6: Configuration File Generation Correctness
For any agent configuration, the generated .bedrock_agentcore.yaml file must 
include all required fields (name, entrypoint, execution role, ECR repository, 
platform, memory mode).
"""

import os
import tempfile
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
import pytest
from hypothesis import given, strategies as st, settings, assume, HealthCheck
from unittest.mock import Mock, patch, MagicMock
import subprocess

from deployment_tool.managers.agentcore_integration import AgentCoreIntegration


# ============================================================================
# Strategy Definitions
# ============================================================================

@st.composite
def valid_agent_name(draw) -> str:
    """Generate a valid agent name (ASCII only)."""
    # Use only ASCII lowercase letters, digits, and hyphens
    name = draw(st.text(
        alphabet="abcdefghijklmnopqrstuvwxyz0123456789-",
        min_size=3,
        max_size=50
    ))
    name = name.strip("-")
    assume(len(name) >= 3)
    assume(not name.startswith("-") and not name.endswith("-"))
    # Ensure at least one letter (not just numbers and hyphens)
    assume(any(c.isalpha() for c in name))
    return name


@st.composite
def valid_entrypoint(draw) -> str:
    """Generate a valid entrypoint filename."""
    return draw(st.sampled_from([
        "agent.py",
        "langgraph_a2a.py",
        "main.py",
        "app.py",
        "server.py"
    ]))


@st.composite
def valid_protocol(draw) -> str:
    """Generate a valid server protocol."""
    return draw(st.sampled_from(["HTTP", "A2A", "MCP"]))


@st.composite
def valid_aws_region(draw) -> str:
    """Generate a valid AWS region."""
    regions = [
        "us-east-1", "us-east-2", "us-west-1", "us-west-2",
        "eu-west-1", "eu-west-2", "eu-central-1",
        "ap-southeast-1", "ap-southeast-2", "ap-northeast-1"
    ]
    return draw(st.sampled_from(regions))


@st.composite
def valid_execution_role_arn(draw) -> str:
    """Generate a valid IAM execution role ARN (ASCII only)."""
    account_id = draw(st.integers(min_value=100000000000, max_value=999999999999))
    # Use only ASCII letters, digits, hyphens, and underscores
    role_name = draw(st.text(
        alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
        min_size=5,
        max_size=30
    ))
    # Ensure role name is not empty after stripping
    assume(len(role_name) >= 5)
    return f"arn:aws:iam::{account_id}:role/{role_name}"


@st.composite
def agent_config_params(draw) -> Dict[str, Any]:
    """Generate parameters for agent configuration."""
    return {
        "entrypoint": draw(valid_entrypoint()),
        "agent_name": draw(valid_agent_name()),
        "protocol": draw(valid_protocol()),
        "enable_memory": draw(st.booleans()),
        "deployment_type": draw(st.sampled_from(["container", "direct_code_deploy"])),
        "region": draw(valid_aws_region()),
        "non_interactive": True,
        "execution_role_arn": draw(st.one_of(st.none(), valid_execution_role_arn()))
    }


@st.composite
def mock_agentcore_output(draw, params: Dict[str, Any]) -> str:
    """Generate mock output from agentcore configure command (ASCII only)."""
    account_id = draw(st.integers(min_value=100000000000, max_value=999999999999))
    region = params.get("region", "us-east-1")
    agent_name = params.get("agent_name", "test-agent")
    
    # Generate execution role ARN
    if params.get("execution_role_arn"):
        role_arn = params["execution_role_arn"]
    else:
        # Use only ASCII uppercase letters and digits
        unique_id = draw(st.text(alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", min_size=10, max_size=20))
        role_arn = f"arn:aws:iam::{account_id}:role/AmazonBedrockAgentCoreSDKRuntime-{region}-{unique_id}"
    
    # Generate ECR repository URI
    ecr_uri = f"{account_id}.dkr.ecr.{region}.amazonaws.com/bedrock-agentcore-{agent_name}"
    
    # Generate CodeBuild project name
    codebuild_name = f"bedrock-agentcore-{agent_name}-builder"
    
    output = f"""
Configuration successful!

Agent Configuration:
  Name: {agent_name}
  Entrypoint: {params.get('entrypoint', 'agent.py')}
  Protocol: {params.get('protocol', 'HTTP')}
  Deployment Type: {params.get('deployment_type', 'container')}
  Region: {region}

IAM Execution Role:
  ARN: {role_arn}

ECR Repository:
  URI: {ecr_uri}

CodeBuild Project:
  Name: {codebuild_name}

Memory: {'Enabled (STM_ONLY)' if params.get('enable_memory', True) else 'Disabled'}

Configuration file written to: .bedrock_agentcore.yaml
"""
    return output


def create_mock_config_file(
    agent_dir: Path,
    params: Dict[str, Any],
    execution_role_arn: str,
    ecr_uri: str,
    codebuild_name: str
) -> Dict[str, Any]:
    """Create a mock .bedrock_agentcore.yaml file."""
    config = {
        "name": params["agent_name"],
        "language": "python",
        "entrypoint": params["entrypoint"],
        "deployment_type": params["deployment_type"],
        "platform": "linux/arm64",
        "server_protocol": params["protocol"],
        "aws_account": params.get("aws_account_id", "123456789012"),
        "aws_region": params["region"],
        "execution_role_arn": execution_role_arn,
        "ecr_repository_uri": ecr_uri,
        "codebuild_project_name": codebuild_name,
    }
    
    if params.get("enable_memory", True):
        config["memory_mode"] = "STM_ONLY"
    
    # Write config file
    config_path = agent_dir / ".bedrock_agentcore.yaml"
    with open(config_path, 'w') as f:
        yaml.dump(config, f)
    
    return config


# ============================================================================
# Property-Based Tests
# ============================================================================

class TestConfigurationFileGenerationCorrectness:
    """
    Property 6: Configuration File Generation Correctness
    
    **Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8**
    
    For any agent configuration, the generated .bedrock_agentcore.yaml file must 
    include all required fields (name, entrypoint, execution role, ECR repository, 
    platform, memory mode).
    """
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow, HealthCheck.filter_too_much]
    )
    def test_configure_generates_complete_config_file(self, data):
        """
        Property: agentcore configure must generate a complete configuration file.
        
        This test verifies that when run_configure is called with valid parameters,
        it generates a .bedrock_agentcore.yaml file containing all required fields.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate agent configuration parameters
            params = data.draw(agent_config_params())
            
            # Create agent directory and entrypoint file
            agent_dir = temp_path / params["agent_name"]
            agent_dir.mkdir()
            entrypoint_path = agent_dir / params["entrypoint"]
            entrypoint_path.write_text("# Agent entrypoint\n")
            
            # Generate mock agentcore output
            mock_output = data.draw(mock_agentcore_output(params))
            
            # Extract ARNs from mock output
            import re
            role_match = re.search(r'arn:aws:iam::\d+:role/[A-Za-z0-9-_]+', mock_output)
            ecr_match = re.search(r'\d+\.dkr\.ecr\.[a-z0-9-]+\.amazonaws\.com/[a-z0-9-]+', mock_output)
            codebuild_match = re.search(r'bedrock-agentcore-[a-z0-9-]+-builder', mock_output)
            
            assume(role_match is not None)
            assume(ecr_match is not None)
            assume(codebuild_match is not None)
            
            execution_role_arn = role_match.group(0)
            ecr_uri = ecr_match.group(0)
            codebuild_name = codebuild_match.group(0)
            
            # Create mock config file
            config_data = create_mock_config_file(
                agent_dir,
                params,
                execution_role_arn,
                ecr_uri,
                codebuild_name
            )
            
            # Mock subprocess.run to return our mock output
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = mock_output
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                # Create AgentCoreIntegration instance
                integration = AgentCoreIntegration(str(agent_dir))
                
                # Run configure
                result = integration.run_configure(**params)
                
                # Verify subprocess was called with correct arguments
                assert mock_run.called, "subprocess.run should be called"
                call_args = mock_run.call_args[0][0]
                
                # Verify command structure
                assert "agentcore" in call_args, "Command should include 'agentcore'"
                assert "configure" in call_args, "Command should include 'configure'"
                assert "--entrypoint" in call_args, "Command should include --entrypoint"
                assert params["entrypoint"] in call_args, "Command should include entrypoint value"
                assert "--name" in call_args, "Command should include --name"
                assert params["agent_name"] in call_args, "Command should include agent name"
                assert "--protocol" in call_args, "Command should include --protocol"
                assert params["protocol"] in call_args, "Command should include protocol value"
                
                # Verify ECR auto flag
                assert "--ecr" in call_args, "Command should include --ecr"
                assert "auto" in call_args, "Command should include 'auto' for ECR"
                
                # Verify deployment type
                assert "--deployment-type" in call_args, "Command should include --deployment-type"
                assert params["deployment_type"] in call_args, "Command should include deployment type value"
                
                # Verify region
                if params.get("region"):
                    assert "--region" in call_args, "Command should include --region"
                    assert params["region"] in call_args, "Command should include region value"
                
                # Verify non-interactive flag
                if params.get("non_interactive", True):
                    assert "--non-interactive" in call_args, "Command should include --non-interactive"
                
                # Verify memory flag
                if not params.get("enable_memory", True):
                    assert "--disable-memory" in call_args, "Command should include --disable-memory when memory disabled"
                
                # Verify execution role if provided
                if params.get("execution_role_arn"):
                    assert "--execution-role" in call_args, "Command should include --execution-role"
                    assert params["execution_role_arn"] in call_args, "Command should include execution role ARN"
            
            # Verify configuration file exists and contains required fields
            config_path = agent_dir / ".bedrock_agentcore.yaml"
            assert config_path.exists(), "Configuration file should exist"
            
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            
            # Property assertions: All required fields must be present
            assert "name" in config, "Config must include 'name'"
            assert config["name"] == params["agent_name"], "Config name must match agent name"
            
            assert "entrypoint" in config, "Config must include 'entrypoint'"
            assert config["entrypoint"] == params["entrypoint"], "Config entrypoint must match"
            
            assert "execution_role_arn" in config, "Config must include 'execution_role_arn'"
            assert config["execution_role_arn"], "Execution role ARN must not be empty"
            assert config["execution_role_arn"].startswith("arn:aws:iam::"), "Execution role must be valid ARN"
            
            assert "ecr_repository_uri" in config, "Config must include 'ecr_repository_uri'"
            assert config["ecr_repository_uri"], "ECR repository URI must not be empty"
            
            assert "codebuild_project_name" in config, "Config must include 'codebuild_project_name'"
            assert config["codebuild_project_name"], "CodeBuild project name must not be empty"
            
            assert "platform" in config, "Config must include 'platform'"
            assert config["platform"] in ["linux/arm64", "linux/amd64"], "Platform must be valid"
            
            assert "server_protocol" in config, "Config must include 'server_protocol'"
            assert config["server_protocol"] == params["protocol"], "Protocol must match"
            
            # Verify memory mode if enabled
            if params.get("enable_memory", True):
                assert "memory_mode" in config, "Config must include 'memory_mode' when memory enabled"
                assert config["memory_mode"] == "STM_ONLY", "Memory mode must be STM_ONLY"
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
    )
    def test_configure_command_flags_match_parameters(self, data):
        """
        Property: Command flags must correctly represent input parameters.
        
        This test verifies that the agentcore configure command is constructed
        with the correct flags based on the input parameters.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate agent configuration parameters
            params = data.draw(agent_config_params())
            
            # Create agent directory
            agent_dir = temp_path / params["agent_name"]
            agent_dir.mkdir()
            entrypoint_path = agent_dir / params["entrypoint"]
            entrypoint_path.write_text("# Agent\n")
            
            # Mock subprocess.run
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Configuration successful"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                # Create integration and run configure
                integration = AgentCoreIntegration(str(agent_dir))
                integration.run_configure(**params)
                
                # Get the command that was executed
                assert mock_run.called
                cmd = mock_run.call_args[0][0]
                
                # Property assertions: Command must include all required flags
                
                # Required flags
                assert "--entrypoint" in cmd and params["entrypoint"] in cmd, \
                    "Command must include --entrypoint with correct value"
                
                assert "--name" in cmd and params["agent_name"] in cmd, \
                    "Command must include --name with correct value"
                
                assert "--protocol" in cmd and params["protocol"] in cmd, \
                    "Command must include --protocol with correct value"
                
                assert "--ecr" in cmd and "auto" in cmd, \
                    "Command must include --ecr auto"
                
                assert "--deployment-type" in cmd and params["deployment_type"] in cmd, \
                    "Command must include --deployment-type with correct value"
                
                # Conditional flags
                if params.get("region"):
                    assert "--region" in cmd and params["region"] in cmd, \
                        "Command must include --region when specified"
                
                if params.get("non_interactive", True):
                    assert "--non-interactive" in cmd, \
                        "Command must include --non-interactive when True"
                
                if not params.get("enable_memory", True):
                    assert "--disable-memory" in cmd, \
                        "Command must include --disable-memory when memory disabled"
                else:
                    assert "--disable-memory" not in cmd, \
                        "Command must not include --disable-memory when memory enabled"
                
                if params.get("execution_role_arn"):
                    assert "--execution-role" in cmd and params["execution_role_arn"] in cmd, \
                        "Command must include --execution-role when specified"
    
    @given(st.data())
    @settings(
        max_examples=100,
        deadline=None,
        suppress_health_check=[HealthCheck.function_scoped_fixture, HealthCheck.too_slow]
    )
    def test_parse_deploy_output_extracts_all_arns(self, data):
        """
        Property: parse_deploy_output must extract all ARNs from output.
        
        This test verifies that the parse_deploy_output method correctly extracts
        agent ARN, execution role ARN, memory ARN, ECR URI, and CodeBuild project name.
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Generate parameters
            params = data.draw(agent_config_params())
            
            # Create agent directory
            agent_dir = temp_path / params["agent_name"]
            agent_dir.mkdir()
            
            # Generate mock output with ARNs
            account_id = data.draw(st.integers(min_value=100000000000, max_value=999999999999))
            region = params["region"]
            agent_name = params["agent_name"]
            
            # Generate ARNs (ASCII only)
            agent_id = data.draw(st.text(alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", min_size=10, max_size=20))
            agent_arn = f"arn:aws:bedrock:{region}:{account_id}:agent/{agent_id}"
            
            role_name = data.draw(st.text(alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", min_size=10, max_size=30))
            role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"
            
            ecr_uri = f"{account_id}.dkr.ecr.{region}.amazonaws.com/bedrock-agentcore-{agent_name}"
            codebuild_name = f"bedrock-agentcore-{agent_name}-builder"
            
            # Optionally include memory ARN
            include_memory = params.get("enable_memory", True)
            memory_arn = None
            if include_memory:
                memory_id = data.draw(st.text(alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", min_size=10, max_size=20))
                memory_arn = f"arn:aws:bedrock:{region}:{account_id}:memory/{memory_id}"
            
            # Create mock deployment output
            output = f"""
Deployment successful!

Agent ARN: {agent_arn}
Execution Role ARN: {role_arn}
ECR Repository: {ecr_uri}
CodeBuild Project: {codebuild_name}
"""
            if memory_arn:
                output += f"Memory ARN: {memory_arn}\n"
            
            # Create integration and parse output
            integration = AgentCoreIntegration(str(agent_dir))
            result = integration.parse_deploy_output(output)
            
            # Property assertions: All ARNs must be extracted
            assert "agent_arn" in result, "Result must include agent_arn"
            assert result["agent_arn"] == agent_arn, "Agent ARN must match"
            
            assert "execution_role_arn" in result, "Result must include execution_role_arn"
            assert result["execution_role_arn"] == role_arn, "Execution role ARN must match"
            
            assert "ecr_repository_uri" in result, "Result must include ecr_repository_uri"
            assert result["ecr_repository_uri"] == ecr_uri, "ECR URI must match"
            
            assert "codebuild_project_name" in result, "Result must include codebuild_project_name"
            assert result["codebuild_project_name"] == codebuild_name, "CodeBuild name must match"
            
            if memory_arn:
                assert "memory_arn" in result, "Result must include memory_arn when present"
                assert result["memory_arn"] == memory_arn, "Memory ARN must match"


# ============================================================================
# Unit Tests for Edge Cases
# ============================================================================

class TestConfigurationFileGenerationEdgeCases:
    """Unit tests for specific edge cases in configuration file generation."""
    
    def test_configure_with_minimal_parameters(self):
        """Test configure with only required parameters."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            agent_dir = temp_path / "test-agent"
            agent_dir.mkdir()
            (agent_dir / "agent.py").write_text("# Agent\n")
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Success"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(str(agent_dir))
                integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent"
                )
                
                assert mock_run.called
                cmd = mock_run.call_args[0][0]
                assert "agentcore" in cmd
                assert "configure" in cmd
                assert "--entrypoint" in cmd
                assert "--name" in cmd
    
    def test_parse_deploy_output_with_missing_arns(self):
        """Test parse_deploy_output handles missing ARNs gracefully."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            agent_dir = temp_path / "test-agent"
            agent_dir.mkdir()
            
            integration = AgentCoreIntegration(str(agent_dir))
            
            # Output with no ARNs
            result = integration.parse_deploy_output("Deployment in progress...")
            
            # Should return empty dict or dict with no ARN keys
            assert isinstance(result, dict)
            # Missing ARNs should not be in result or should be None
            for key in ["agent_arn", "execution_role_arn", "memory_arn"]:
                if key in result:
                    assert result[key] is None or result[key] == ""
    
    def test_install_dependencies_with_missing_requirements(self):
        """Test install_dependencies handles missing requirements.txt."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            agent_dir = temp_path / "test-agent"
            agent_dir.mkdir()
            
            integration = AgentCoreIntegration(str(agent_dir))
            
            # Should return True (warning only) when requirements.txt missing
            result = integration.install_dependencies()
            assert result is True
    
    def test_configure_with_execution_role_arn(self):
        """Test configure includes execution role ARN when provided."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            agent_dir = temp_path / "test-agent"
            agent_dir.mkdir()
            (agent_dir / "agent.py").write_text("# Agent\n")
            
            role_arn = "arn:aws:iam::123456789012:role/MyCustomRole"
            
            with patch('subprocess.run') as mock_run:
                mock_result = Mock()
                mock_result.returncode = 0
                mock_result.stdout = "Success"
                mock_result.stderr = ""
                mock_run.return_value = mock_result
                
                integration = AgentCoreIntegration(str(agent_dir))
                integration.run_configure(
                    entrypoint="agent.py",
                    agent_name="test-agent",
                    execution_role_arn=role_arn
                )
                
                cmd = mock_run.call_args[0][0]
                assert "--execution-role" in cmd
                assert role_arn in cmd
