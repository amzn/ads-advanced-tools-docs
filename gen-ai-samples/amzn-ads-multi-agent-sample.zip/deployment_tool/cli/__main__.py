"""
Main entry point for CLI when run as a module.

This allows running the CLI as: python -m cli
"""

import sys
import os

# Ensure parent directory is in path for imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from cli.cli import main

if __name__ == '__main__':
    main()
