"""
CLI Interface for AgentCore Automated Deployment System.

This module provides the command-line interface for deploying, validating,
monitoring, and cleaning up AWS Bedrock AgentCore agents.

Validates Requirements: 10.3, 10.4, 10.5, 10.6, 17.1, 17.2, 17.3, 17.4, 17.5, 17.6, 17.7
"""

import sys
import os
from pathlib import Path
from typing import Optional, List

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.table import Table
from rich.panel import Panel

# Add parent directory to path for imports
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from managers.config_manager import ConfigurationManager, ValidationError
from managers.aws_resource_manager import AWSResourceManager
from managers.state_manager import StateManager
from managers.deployment_orchestrator import AgentDeploymentOrchestrator

# Initialize rich console for colored output
console = Console()


@click.group()
@click.version_option(version='1.0.0', prog_name='agentcore-deploy')
def main():
    """AgentCore Automated Deployment System
    
    Deploy and manage AWS Bedrock AgentCore agents with automated
    IAM permissions, cross-agent communication, and infrastructure setup.
    """
    pass


@main.command('deploy')
@click.option(
    '--config',
    '-c',
    type=click.Path(exists=True),
    required=True,
    help='Path to deployment configuration YAML file'
)
@click.option(
    '--agents',
    '-a',
    multiple=True,
    help='Specific agents to deploy (can be specified multiple times)'
)
def deploy(config: str, agents: tuple):
    """Deploy agents from configuration file.
    
    This command deploys all agents specified in the configuration file,
    or a subset if --agents is specified. Agents are deployed in dependency
    order with proper IAM permissions and cross-agent communication setup.
    
    Examples:
        agentcore-deploy deploy --config deployment.yaml
        agentcore-deploy deploy --config deployment.yaml --agents custom-ads --agents mcp-ads
    """
    deploy_command(config, list(agents) if agents else None)


@main.command('validate')
@click.option(
    '--config',
    '-c',
    type=click.Path(exists=True),
    required=True,
    help='Path to deployment configuration YAML file'
)
def validate(config: str):
    """Validate configuration without deploying.
    
    This command validates the deployment configuration file, checking:
    - Required fields are present
    - Agent directories and entrypoint files exist
    - AWS region format is valid
    - Deployment order is consistent
    
    Example:
        agentcore-deploy validate --config deployment.yaml
    """
    validate_command(config)


@main.command('status')
@click.option(
    '--config',
    '-c',
    type=click.Path(exists=True),
    help='Path to deployment configuration YAML file (optional)'
)
@click.option(
    '--state-file',
    '-s',
    type=click.Path(),
    default='.deployment_state.json',
    help='Path to deployment state file'
)
def status(config: Optional[str], state_file: str):
    """Show status of deployed agents.
    
    This command displays information about currently deployed agents,
    including their ARNs, execution roles, and deployment timestamps.
    
    Example:
        agentcore-deploy status
        agentcore-deploy status --config deployment.yaml
    """
    status_command(config, state_file)


@main.command('cleanup')
@click.option(
    '--config',
    '-c',
    type=click.Path(exists=True),
    help='Path to deployment configuration YAML file (optional)'
)
@click.option(
    '--state-file',
    '-s',
    type=click.Path(),
    default='.deployment_state.json',
    help='Path to deployment state file'
)
@click.option(
    '--delete-ecr',
    is_flag=True,
    help='Delete ECR repositories'
)
@click.option(
    '--delete-codebuild',
    is_flag=True,
    help='Delete CodeBuild projects'
)
@click.option(
    '--delete-iam',
    is_flag=True,
    help='Delete IAM roles and policies'
)
@click.option(
    '--yes',
    '-y',
    is_flag=True,
    help='Skip confirmation prompt'
)
def cleanup(
    config: Optional[str],
    state_file: str,
    delete_ecr: bool,
    delete_codebuild: bool,
    delete_iam: bool,
    yes: bool
):
    """Clean up deployed resources.
    
    This command deletes deployed agents and optionally their associated
    resources (ECR repositories, CodeBuild projects, IAM roles). Agents
    are deleted in reverse deployment order.
    
    Examples:
        agentcore-deploy cleanup
        agentcore-deploy cleanup --delete-ecr --delete-codebuild
        agentcore-deploy cleanup --delete-iam --yes
    """
    cleanup_command(config, state_file, delete_ecr, delete_codebuild, delete_iam, yes)


def deploy_command(config_path: str, agents: Optional[List[str]] = None) -> None:
    """Execute deployment of agents.
    
    Args:
        config_path: Path to deployment configuration file
        agents: Optional list of specific agents to deploy
        
    Validates Requirements: 1.1, 1.2, 6.1, 10.1, 10.2, 10.5, 10.6
    """
    try:
        console.print("\n[bold cyan]AgentCore Automated Deployment System[/bold cyan]\n")
        
        # Step 1: Load configuration
        console.print("[bold]Step 1:[/bold] Loading configuration...")
        config_manager = ConfigurationManager(config_path)
        
        try:
            deployment_config = config_manager.load_config()
            console.print("[green]✓[/green] Configuration loaded successfully\n")
        except Exception as e:
            console.print(f"[red]✗[/red] Failed to load configuration: {str(e)}\n")
            sys.exit(1)
        
        # Step 2: Validate configuration
        console.print("[bold]Step 2:[/bold] Validating configuration...")
        
        # Validate config structure
        config_errors = config_manager.validate_config()
        if config_errors:
            console.print(f"[red]✗[/red] Configuration validation failed:\n")
            for error in config_errors:
                console.print(f"  [red]•[/red] {error}")
            console.print()
            sys.exit(1)
        
        # Validate agent directories
        directory_errors = config_manager.validate_agent_directories()
        if directory_errors:
            console.print(f"[red]✗[/red] Agent directory validation failed:\n")
            for error in directory_errors:
                console.print(f"  [red]•[/red] {error}")
            console.print()
            sys.exit(1)
        
        console.print("[green]✓[/green] Configuration validated successfully\n")
        
        # Step 3: Initialize AWS Resource Manager
        console.print("[bold]Step 3:[/bold] Initializing AWS resources...")
        
        try:
            aws_manager = AWSResourceManager(
                region=deployment_config.aws_region
            )
            console.print("[green]✓[/green] AWS Resource Manager initialized\n")
        except Exception as e:
            console.print(f"[red]✗[/red] Failed to initialize AWS: {str(e)}\n")
            sys.exit(1)
        
        # Step 4: Validate AWS credentials
        console.print("[bold]Step 4:[/bold] Validating AWS credentials...")
        
        try:
            identity = aws_manager.validate_credentials()
            console.print(f"[green]✓[/green] AWS credentials validated")
            console.print(f"  Account: {identity['account_id']}")
            console.print(f"  Identity: {identity['arn']}\n")
        except Exception as e:
            console.print(f"[red]✗[/red] {str(e)}\n")
            sys.exit(1)
        
        # Step 5: Check service quotas
        console.print("[bold]Step 5:[/bold] Checking service quotas...")
        
        try:
            quotas = aws_manager.check_service_quotas()
            console.print("[green]✓[/green] Service quotas checked")
            
            if quotas.get('warnings'):
                console.print("[yellow]Warnings:[/yellow]")
                for warning in quotas['warnings']:
                    console.print(f"  [yellow]•[/yellow] {warning}")
            console.print()
        except Exception as e:
            console.print(f"[yellow]⚠[/yellow] Could not check service quotas: {str(e)}\n")
            # Continue anyway - quota check is informational
        
        # Step 6: Initialize State Manager
        console.print("[bold]Step 6:[/bold] Loading deployment state...")
        
        state_manager = StateManager()
        deployment_state = state_manager.load_state()
        
        if deployment_state.agents:
            console.print(f"[green]✓[/green] Found {len(deployment_state.agents)} previously deployed agents\n")
        else:
            console.print("[green]✓[/green] No previous deployments found\n")
        
        # Step 7: Initialize Deployment Orchestrator
        console.print("[bold]Step 7:[/bold] Initializing deployment orchestrator...")
        
        orchestrator = AgentDeploymentOrchestrator(
            config=deployment_config,
            iam_manager=aws_manager.iam_manager,
            s3_manager=aws_manager.s3_manager,
            state_manager=state_manager
        )
        console.print("[green]✓[/green] Deployment orchestrator initialized\n")
        
        # Step 8: Execute deployment
        console.print("[bold]Step 8:[/bold] Deploying agents...\n")
        
        # Filter agents if specific ones requested
        if agents:
            # Filter deployment config to only include requested agents
            filtered_agents = [
                agent for agent in deployment_config.agents
                if agent.name in agents
            ]
            
            if not filtered_agents:
                console.print(f"[red]✗[/red] No matching agents found for: {', '.join(agents)}\n")
                sys.exit(1)
            
            deployment_config.agents = filtered_agents
            console.print(f"[cyan]Deploying {len(filtered_agents)} agent(s): {', '.join(agents)}[/cyan]\n")
        
        # Execute deployment with progress reporting
        result = orchestrator.deploy_all_agents()
        
        # Step 9: Display summary
        console.print("\n[bold]Deployment Summary:[/bold]\n")
        
        if result.success:
            console.print(Panel(
                f"[green]✓ Deployment completed successfully in {result.total_duration:.2f} seconds[/green]",
                style="green"
            ))
            
            # Display deployed agents table
            if result.deployed_agents:
                table = Table(title="Deployed Agents", show_header=True, header_style="bold cyan")
                table.add_column("Agent Name", style="cyan")
                table.add_column("Agent ARN", style="green")
                table.add_column("Execution Role ARN", style="yellow")
                
                for agent_result in result.deployed_agents:
                    table.add_row(
                        agent_result.agent_name,
                        agent_result.agent_arn or "N/A",
                        agent_result.execution_role_arn or "N/A"
                    )
                
                console.print(table)
        else:
            console.print(Panel(
                f"[red]✗ Deployment failed after {result.total_duration:.2f} seconds[/red]",
                style="red"
            ))
            
            # Display failed agents
            if result.failed_agents:
                console.print("\n[bold red]Failed Agents:[/bold red]\n")
                for agent_result in result.failed_agents:
                    console.print(f"[red]•[/red] {agent_result.agent_name}")
                    console.print(f"  Error: {agent_result.error_message}\n")
            
            sys.exit(1)
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Deployment interrupted by user[/yellow]\n")
        sys.exit(130)
    except Exception as e:
        console.print(f"\n[red]✗ Unexpected error: {str(e)}[/red]\n")
        sys.exit(1)


def validate_command(config_path: str) -> None:
    """Validate configuration without deploying.
    
    Args:
        config_path: Path to deployment configuration file
    """
    try:
        console.print("\n[bold cyan]Configuration Validation[/bold cyan]\n")
        
        # Load configuration
        console.print("[bold]Loading configuration...[/bold]")
        config_manager = ConfigurationManager(config_path)
        
        try:
            deployment_config = config_manager.load_config()
            console.print("[green]✓[/green] Configuration loaded successfully\n")
        except Exception as e:
            console.print(f"[red]✗[/red] Failed to load configuration: {str(e)}\n")
            sys.exit(1)
        
        # Validate config structure
        console.print("[bold]Validating configuration structure...[/bold]")
        config_errors = config_manager.validate_config()
        
        if config_errors:
            console.print(f"[red]✗[/red] Found {len(config_errors)} validation error(s):\n")
            for error in config_errors:
                console.print(f"  [red]•[/red] {error}")
            console.print()
            sys.exit(1)
        else:
            console.print("[green]✓[/green] Configuration structure is valid\n")
        
        # Validate agent directories
        console.print("[bold]Validating agent directories...[/bold]")
        directory_errors = config_manager.validate_agent_directories()
        
        if directory_errors:
            console.print(f"[red]✗[/red] Found {len(directory_errors)} directory error(s):\n")
            for error in directory_errors:
                console.print(f"  [red]•[/red] {error}")
            console.print()
            sys.exit(1)
        else:
            console.print("[green]✓[/green] All agent directories and files exist\n")
        
        # Display configuration summary
        console.print(Panel(
            "[green]✓ Configuration is valid and ready for deployment[/green]",
            style="green"
        ))
        
        # Display agents table
        table = Table(title="Configured Agents", show_header=True, header_style="bold cyan")
        table.add_column("Agent Name", style="cyan")
        table.add_column("Directory", style="yellow")
        table.add_column("Entrypoint", style="green")
        table.add_column("Protocol", style="magenta")
        
        for agent in deployment_config.agents:
            table.add_row(
                agent.name,
                agent.directory,
                agent.entrypoint,
                agent.server_protocol
            )
        
        console.print(table)
        console.print()
        
        # Display SSM parameters table
        ssm_params = getattr(deployment_config, 'ssm_parameters', None)
        if ssm_params:
            ssm_table = Table(title="SSM Parameters", show_header=True, header_style="bold cyan")
            ssm_table.add_column("Parameter Name", style="cyan")
            ssm_table.add_column("Type", style="magenta")
            ssm_table.add_column("Value", style="yellow")
            ssm_table.add_column("Description", style="dim")
            
            for param in ssm_params:
                value = param.get('value', '')
                param_type = param.get('type', 'String')
                # Mask SecureString values, show String values
                if param_type == 'SecureString':
                    display_value = '****' if value else '[empty - will prompt]'
                else:
                    display_value = value if value else '[empty - will prompt]'
                
                ssm_table.add_row(
                    param.get('name', ''),
                    param_type,
                    display_value,
                    param.get('description', '')
                )
            
            console.print(ssm_table)
            console.print()
        
    except Exception as e:
        console.print(f"\n[red]✗ Validation error: {str(e)}[/red]\n")
        sys.exit(1)


def status_command(config_path: Optional[str], state_file: str) -> None:
    """Show status of deployed agents.
    
    Args:
        config_path: Optional path to deployment configuration file
        state_file: Path to deployment state file
    """
    try:
        console.print("\n[bold cyan]Deployment Status[/bold cyan]\n")
        
        # Load deployment state
        state_manager = StateManager(state_file)
        deployment_state = state_manager.load_state()
        
        if not deployment_state.agents:
            console.print("[yellow]No agents have been deployed yet[/yellow]\n")
            return
        
        # Display deployment info
        console.print(f"[bold]Last Deployment:[/bold] {deployment_state.last_deployment.strftime('%Y-%m-%d %H:%M:%S')}")
        console.print(f"[bold]Deployment Version:[/bold] {deployment_state.deployment_version}")
        console.print(f"[bold]Total Agents:[/bold] {len(deployment_state.agents)}\n")
        
        # Display agents table
        table = Table(title="Deployed Agents", show_header=True, header_style="bold cyan")
        table.add_column("Agent Name", style="cyan")
        table.add_column("Agent ARN", style="green", no_wrap=False)
        table.add_column("Execution Role", style="yellow", no_wrap=False)
        table.add_column("Deployed At", style="magenta")
        
        for agent_name, agent_state in deployment_state.agents.items():
            # Truncate ARNs for display
            agent_arn_display = agent_state.agent_arn[:50] + "..." if len(agent_state.agent_arn) > 50 else agent_state.agent_arn
            role_arn_display = agent_state.execution_role_arn[:50] + "..." if len(agent_state.execution_role_arn) > 50 else agent_state.execution_role_arn
            
            table.add_row(
                agent_name,
                agent_arn_display,
                role_arn_display,
                agent_state.deployed_at.strftime('%Y-%m-%d %H:%M:%S')
            )
        
        console.print(table)
        console.print()
        
    except FileNotFoundError:
        console.print(f"[yellow]No deployment state file found at: {state_file}[/yellow]\n")
    except Exception as e:
        console.print(f"\n[red]✗ Error reading deployment status: {str(e)}[/red]\n")
        sys.exit(1)


def cleanup_command(
    config_path: Optional[str],
    state_file: str,
    delete_ecr: bool,
    delete_codebuild: bool,
    delete_iam: bool,
    skip_confirmation: bool
) -> None:
    """Clean up deployed resources.
    
    Args:
        config_path: Optional path to deployment configuration file
        state_file: Path to deployment state file
        delete_ecr: Whether to delete ECR repositories
        delete_codebuild: Whether to delete CodeBuild projects
        delete_iam: Whether to delete IAM roles
        skip_confirmation: Whether to skip confirmation prompt
        
    Validates Requirements: 17.1, 17.2, 17.3, 17.4, 17.5, 17.6, 17.7, 17.8
    """
    try:
        console.print("\n[bold cyan]Cleanup Deployed Resources[/bold cyan]\n")
        
        # Load deployment state
        state_manager = StateManager(state_file)
        deployment_state = state_manager.load_state()
        
        if not deployment_state.agents:
            console.print("[yellow]No agents have been deployed yet[/yellow]\n")
            return
        
        # Display what will be deleted
        console.print(f"[bold]Agents to delete:[/bold] {len(deployment_state.agents)}")
        for agent_name in deployment_state.agents.keys():
            console.print(f"  [red]•[/red] {agent_name}")
        console.print()
        
        if delete_ecr:
            console.print("[yellow]⚠[/yellow] ECR repositories will be deleted")
        if delete_codebuild:
            console.print("[yellow]⚠[/yellow] CodeBuild projects will be deleted")
        if delete_iam:
            console.print("[yellow]⚠[/yellow] IAM roles and policies will be deleted")
        console.print()
        
        # Confirmation prompt
        if not skip_confirmation:
            confirm = click.confirm(
                "Are you sure you want to delete these resources?",
                default=False
            )
            
            if not confirm:
                console.print("[yellow]Cleanup cancelled[/yellow]\n")
                return
        
        console.print("\n[bold]Starting cleanup...[/bold]\n")
        
        # Get agents in reverse deployment order (Requirement 17.2)
        agent_names = list(deployment_state.agents.keys())
        agent_names.reverse()
        
        # Initialize AWS manager if needed for resource deletion
        aws_manager = None
        if delete_ecr or delete_codebuild or delete_iam:
            # Load config to get region
            if config_path:
                config_manager = ConfigurationManager(config_path)
                deployment_config = config_manager.load_config()
                region = deployment_config.aws_region
            else:
                # Try to infer region from state or use default
                region = os.environ.get('AWS_REGION', 'us-east-1')
            
            aws_manager = AWSResourceManager(region=region)
        
        deleted_count = 0
        failed_count = 0
        
        # Delete agents in reverse order
        for agent_name in agent_names:
            agent_state = deployment_state.agents[agent_name]
            console.print(f"[bold]Deleting agent:[/bold] {agent_name}")
            
            try:
                # Delete agent using AWS Bedrock API
                # Note: This would require boto3 bedrock-agent-runtime client
                # For now, we'll just report what would be deleted
                console.print(f"  [green]✓[/green] Agent {agent_name} marked for deletion")
                
                # Delete ECR repository if requested
                if delete_ecr and agent_state.ecr_repository_uri:
                    console.print(f"  [yellow]⚠[/yellow] ECR repository deletion not yet implemented")
                
                # Delete CodeBuild project if requested
                if delete_codebuild and agent_state.codebuild_project_name:
                    console.print(f"  [yellow]⚠[/yellow] CodeBuild project deletion not yet implemented")
                
                # Delete IAM role if requested
                if delete_iam and agent_state.execution_role_arn:
                    console.print(f"  [yellow]⚠[/yellow] IAM role deletion not yet implemented")
                
                deleted_count += 1
                
            except Exception as e:
                console.print(f"  [red]✗[/red] Failed to delete {agent_name}: {str(e)}")
                failed_count += 1
            
            console.print()
        
        # Clear deployment state
        console.print("[bold]Clearing deployment state...[/bold]")
        state_manager.clear_state()
        console.print("[green]✓[/green] Deployment state cleared\n")
        
        # Display summary
        if failed_count == 0:
            console.print(Panel(
                f"[green]✓ Cleanup completed successfully\n"
                f"Deleted {deleted_count} agent(s)[/green]",
                style="green"
            ))
        else:
            console.print(Panel(
                f"[yellow]⚠ Cleanup completed with errors\n"
                f"Deleted: {deleted_count} agent(s)\n"
                f"Failed: {failed_count} agent(s)[/yellow]",
                style="yellow"
            ))
        
    except FileNotFoundError:
        console.print(f"[yellow]No deployment state file found at: {state_file}[/yellow]\n")
    except Exception as e:
        console.print(f"\n[red]✗ Cleanup error: {str(e)}[/red]\n")
        sys.exit(1)


if __name__ == '__main__':
    main()
