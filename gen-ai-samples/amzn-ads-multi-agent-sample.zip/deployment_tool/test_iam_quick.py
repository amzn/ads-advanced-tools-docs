from managers.iam_manager import IAMManager
from unittest.mock import Mock
import boto3

# Create a mock session
mock_session = Mock(spec=boto3.Session)
mock_iam_client = Mock()
mock_session.client.return_value = mock_iam_client

# Initialize IAMManager
iam_manager = IAMManager(mock_session)
print('✓ IAMManager initialized successfully')

# Test create_cross_agent_policy
agent_arns = [
    'arn:aws:bedrock-agentcore:us-east-1:123456789012:agent/agent1',
    'arn:aws:bedrock-agentcore:us-east-1:123456789012:agent/agent2'
]
memory_arns = ['arn:aws:bedrock-agentcore:us-east-1:123456789012:memory/mem1']

policy = iam_manager.create_cross_agent_policy(agent_arns, memory_arns)
print('✓ create_cross_agent_policy works')
print(f'  Policy has {len(policy["Statement"])} statements')
print(f'  Statement 1 Action: {policy["Statement"][0]["Action"]}')
print(f'  Statement 1 Resource count: {len(policy["Statement"][0]["Resource"])}')
print(f'  Statement 2 Action: {policy["Statement"][1]["Action"]}')
print(f'  Statement 2 Resource count: {len(policy["Statement"][1]["Resource"])}')

# Verify policy structure
assert policy['Version'] == '2012-10-17'
assert len(policy['Statement']) == 2
assert 'bedrock-agentcore:InvokeRuntime' in policy['Statement'][0]['Action']
assert 'bedrock-agentcore:GetMemory' in policy['Statement'][1]['Action']
assert 'bedrock-agentcore:PutMemory' in policy['Statement'][1]['Action']

print('✓ All assertions passed')
