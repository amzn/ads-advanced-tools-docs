# AgentCore Automated Deployment Tool

A Python CLI tool for automating the deployment of AWS Bedrock AgentCore agents with IAM policies, SSM parameter management, cross-agent communication, and S3 vector knowledge base setup.

## Features

- Single-command deployment of multiple interconnected agents
- SSM Parameter Store management (prompts for secrets on first run, skips if already set)
- Dynamic IAM policy generation with actual resource names (S3 buckets, SSM paths)
- Cross-agent communication policies (InvokeRuntime, ListAgentRuntimes, memory access)
- S3 vector knowledge base bucket creation and policy attachment
- Idempotent operations for safe re-runs
- State management for deployment tracking

## Installation

### Prerequisites

- Python 3.12+
- AWS CLI configured (`aws sts get-caller-identity`)
- Bedrock AgentCore Starter Toolkit (`pip install bedrock-agentcore-starter-toolkit`)

### Setup

```bash
cd deployment_tool
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Quick Start

```bash
# 1. Create config from template
cp deployment.yaml.template deployment.yaml
# Edit deployment.yaml — set aws_account_id and aws_region

# 2. Validate
python -m cli.cli validate --config deployment.yaml

# 3. Deploy (prompts for SSM secrets on first run)
python -m cli.cli deploy --config deployment.yaml

# 4. Check status
python -m cli.cli status --config deployment.yaml
```

## What the Deployment Does


### Step 1: Create SSM Parameters

Before deploying agents, the tool creates SSM parameters defined in `deployment.yaml`. For empty values (like OAuth secrets), it:
1. Checks if the parameter already exists in SSM — skips if so
2. Prompts you interactively (SecureString values use `getpass` so they're not echoed)

Parameters created:
| SSM Path | Type | Used By |
|----------|------|---------|
| `/ads/refresh-token` | SecureString | custom-ads-mcp, mcp-ads-a2a-agent |
| `/ads/client-id` | SecureString | custom-ads-mcp, mcp-ads-a2a-agent |
| `/ads/client-secret` | SecureString | custom-ads-mcp, mcp-ads-a2a-agent |
| `/ads/vector-bucket-name` | String | s3-vectors-a2a-agent |
| `/ads/vector-index-name` | String | s3-vectors-a2a-agent |
| `/ads/tool-filter` | String | mcp-ads-a2a-agent |

### Step 2: Deploy Agents

Agents are deployed in order defined by `deployment_order` in the config:
1. custom-ads-a2a-agent
2. custom-ads-mcp
3. mcp-ads-a2a-agent
4. s3-vectors-a2a-agent
5. orchestration-a2a-agent

For each agent, the tool runs `agentcore configure` then `agentcore deploy`, captures the ARN and execution role ARN.

### Step 3: Apply IAM Policies

After all agents are deployed:
- Attaches `bedrock-agentcore-base-policy.json` to each execution role (Bedrock model access, CloudWatch logs, ECR)
- Applies cross-agent communication policy (InvokeRuntime, ListAgentRuntimes, ListMemories, SSM access)
- Applies SSM access policy (`/ads/*`, `/campaign/*`) to all execution roles
- Attaches S3 vector policy to the s3-vectors agent role (uses actual bucket name from SSM)

### Step 4: Update Frontend

Updates `ads-chat-nextjs/.env.local` with the orchestration agent ARN.

## Configuration

### deployment.yaml

```yaml
aws_account_id: "123456789012"
aws_region: "us-east-1"

agents:
  - name: "custom-ads-a2a-agent"
    directory: "../custom-ads-a2a-agent"
    entrypoint: "langgraph_a2a.py"
    server_protocol: "A2A"
    memory_mode: "STM_ONLY"

deployment_order:
  - "custom-ads-a2a-agent"
  - "custom-ads-mcp"
  - "mcp-ads-a2a-agent"
  - "s3-vectors-a2a-agent"
  - "orchestration-a2a-agent"

ssm_parameters:
  - name: "/ads/refresh-token"
    value: ""  # Prompted interactively
    type: "SecureString"
    description: "Amazon Ads API OAuth refresh token"
  # ... more parameters

iam_policies:
  base_policy: { ... }
  cross_agent_policy_template: { ... }
  s3_vector_policy: { ... }
```

See `deployment.yaml.template` for the full annotated config.

### IAM Policy Files

- `bedrock-agentcore-base-policy.json` — base permissions for all agents (Bedrock, CloudWatch, ECR, SSM, AgentCore control plane)
- `s3-vector-policy.json` — S3 + S3 Vectors permissions (uses `${S3_BUCKET_NAME}` placeholder, substituted at deploy time)

## CLI Commands

### deploy

```bash
python -m cli.cli deploy --config deployment.yaml
python -m cli.cli deploy --config deployment.yaml --agents custom-ads-a2a-agent --agents mcp-ads-a2a-agent
```

### validate

```bash
python -m cli.cli validate --config deployment.yaml
```

### status

```bash
python -m cli.cli status --config deployment.yaml
```

### cleanup

```bash
python -m cli.cli cleanup [--delete-ecr] [--delete-codebuild] [--delete-iam] [--yes]
```

## Architecture

```
CLI (cli/cli.py)
  │
  ├── ConfigurationManager — loads deployment.yaml
  ├── SSMManager — creates SSM parameters, generates SSM IAM policies
  ├── IAMManager — creates/attaches IAM policies to execution roles
  ├── S3Manager — creates S3 vector bucket, configures bucket policies
  ├── AgentCoreIntegration — runs agentcore configure/deploy
  ├── StateManager — tracks deployment state (.deployment_state.json)
  └── DeploymentOrchestrator — coordinates the full deployment flow
```

## Troubleshooting

- `agentcore command not found` → `pip install bedrock-agentcore-starter-toolkit`
- `Access Denied on ListAgentRuntimes` → attach `bedrock-agentcore-base-policy.json` to the execution role
- `SSM parameter not found` → run `python -m cli.cli deploy` which creates them, or create manually with `aws ssm put-parameter`
- `S3 bucket already exists` → choose a unique bucket name in `deployment.yaml`
- Deployment state issues → delete `.deployment_state.json` and redeploy

## Additional Documentation

- [Deployment Guide](DEPLOYMENT_GUIDE.md) — step-by-step walkthrough
- [S3 Vector Setup](S3_VECTOR_SETUP.md) — S3 vector knowledge base configuration
- [Frontend Deployment](FRONTEND_DEPLOYMENT.md) — Next.js frontend setup
