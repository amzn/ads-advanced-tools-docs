"""
AgentCore Automated Deployment System

A Python-based tool that automates the deployment of multiple AWS Bedrock 
AgentCore agents with proper IAM permissions, cross-agent communication, 
and infrastructure setup.
"""

__version__ = "0.1.0"
