"""
Setup configuration for AgentCore Automated Deployment System.

This setup.py file defines the package metadata and dependencies for the deployment tool.

**Recommended Usage:**
    Use the deploy_agents.py script directly:
    
    cd deployment_tool
    python deploy_agents.py deploy --config deployment.yaml
    python deploy_agents.py validate --config deployment.yaml
    python deploy_agents.py status
    python deploy_agents.py cleanup
    
    Or make it executable:
    chmod +x deploy_agents.py
    ./deploy_agents.py --help

**Alternative Installation (for system-wide access):**
    From the parent directory:
    pip install -e deployment_tool/          # Development mode
    
    Then use: agentcore-deploy <command>

Validates Requirements: 12.1, 12.2
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file for long description
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    long_description = readme_file.read_text(encoding="utf-8")

# Read requirements from requirements.txt
requirements_file = Path(__file__).parent / "requirements.txt"
requirements = []
if requirements_file.exists():
    with open(requirements_file, 'r') as f:
        requirements = [
            line.strip() 
            for line in f 
            if line.strip() and not line.startswith('#')
        ]

# Separate runtime and development dependencies
runtime_requirements = [
    req for req in requirements 
    if not any(dev_pkg in req for dev_pkg in ['pytest', 'hypothesis', 'moto', 'pytest-cov'])
]

dev_requirements = [
    req for req in requirements 
    if any(dev_pkg in req for dev_pkg in ['pytest', 'hypothesis', 'moto', 'pytest-cov'])
]

setup(
    # Package metadata
    name="agentcore-deploy",
    version="1.0.0",
    description="Automated deployment system for AWS Bedrock AgentCore agents",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Amazon Web Services",
    author_email="",
    url="https://github.com/aws/agentcore-deploy",
    license="Apache-2.0",
    
    # Package discovery
    packages=find_packages(exclude=["tests", "tests.*", "*.tests", "*.tests.*"]),
    
    # Include non-Python files
    package_data={
        "": [
            "*.yaml",
            "*.yml",
            "*.json",
            "*.template",
            "*.md",
        ],
    },
    include_package_data=True,
    
    # Additional data files (templates and policies in root directory)
    data_files=[
        ("", [
            "deployment.yaml.template",
            "bedrock-agentcore-base-policy.json",
            "cross-agent-iam-policy-template.json",
            "s3-vector-policy.json",
        ]),
    ],
    
    # Dependencies
    install_requires=runtime_requirements,
    
    # Optional dependencies for development
    extras_require={
        "dev": dev_requirements,
        "test": dev_requirements,
    },
    
    # Python version requirement
    python_requires=">=3.8",
    
    # Entry points for CLI commands
    entry_points={
        "console_scripts": [
            "agentcore-deploy=deployment_tool.cli.cli:main",
        ],
    },
    
    # Classifiers for PyPI
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Build Tools",
        "Topic :: System :: Systems Administration",
        "Operating System :: OS Independent",
    ],
    
    # Keywords for discovery
    keywords="aws bedrock agentcore deployment automation iam agents",
    
    # Project URLs
    project_urls={
        "Documentation": "https://github.com/aws/agentcore-deploy/blob/main/README.md",
        "Source": "https://github.com/aws/agentcore-deploy",
        "Bug Reports": "https://github.com/aws/agentcore-deploy/issues",
    },
)
