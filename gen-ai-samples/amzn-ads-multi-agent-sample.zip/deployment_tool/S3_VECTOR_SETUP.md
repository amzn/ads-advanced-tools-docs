# S3 Vector Knowledge Base Setup Guide

This guide provides detailed instructions for setting up an S3 bucket with vector search capabilities for the s3-vectors-a2a-agent.

## Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [S3 Bucket Creation](#s3-bucket-creation)
- [Vector Index Configuration](#vector-index-configuration)
- [Uploading Knowledge Base Documents](#uploading-knowledge-base-documents)
- [Creating Vector Embeddings](#creating-vector-embeddings)
- [IAM Policy Requirements](#iam-policy-requirements)
- [Testing Vector Search](#testing-vector-search)
- [Troubleshooting](#troubleshooting)

## Overview

The s3-vectors-a2a-agent uses Amazon S3's vector search capabilities to provide semantic search over a knowledge base. This requires:

1. An S3 bucket configured for vector storage
2. A vector index for efficient similarity search
3. Documents uploaded with vector embeddings
4. Proper IAM permissions for the agent to access the bucket

**Key Concepts:**

- **Vector Embeddings**: Numerical representations of text that capture semantic meaning
- **Vector Index**: Data structure enabling fast similarity search over embeddings
- **Knowledge Base**: Collection of documents that the agent can search
- **Semantic Search**: Finding documents based on meaning rather than exact keyword matches

## Prerequisites

Before setting up the S3 vector knowledge base:

- [ ] AWS account with S3 access
- [ ] AWS CLI configured with appropriate credentials
- [ ] Python 3.8+ with boto3 installed
- [ ] s3-vectors-a2a-agent deployed or ready to deploy
- [ ] Knowledge base documents prepared (text, markdown, or JSON format)

### Required AWS Permissions

Your AWS user/role needs these S3 permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:CreateBucket",
        "s3:PutBucketPolicy",
        "s3:PutBucketVersioning",
        "s3:PutObject",
        "s3:GetObject",
        "s3:ListBucket",
        "s3:DeleteObject"
      ],
      "Resource": [
        "arn:aws:s3:::your-vector-bucket-name",
        "arn:aws:s3:::your-vector-bucket-name/*"
      ]
    }
  ]
}
```

## S3 Bucket Creation

### Option 1: Automatic Creation (Recommended)

The deployment tool automatically creates the S3 bucket when deploying the s3-vectors-a2a-agent:

```bash
# Deploy s3-vectors agent (bucket created automatically)
python -m cli.cli deploy --config deployment.yaml --agents s3-vectors-a2a-agent
```

The tool will:
- Create a bucket with a unique name
- Configure bucket policy for agent access
- Set up versioning (recommended for production)
- Apply appropriate tags

### Option 2: Manual Creation

If you prefer to create the bucket manually:

**Using AWS CLI:**

```bash
# Set variables
BUCKET_NAME="your-vector-knowledge-base-$(date +%s)"
AWS_REGION="us-east-1"
AWS_ACCOUNT_ID="123456789012"

# Create bucket
aws s3api create-bucket \
  --bucket $BUCKET_NAME \
  --region $AWS_REGION \
  --create-bucket-configuration LocationConstraint=$AWS_REGION

# Enable versioning (recommended)
aws s3api put-bucket-versioning \
  --bucket $BUCKET_NAME \
  --versioning-configuration Status=Enabled

# Add tags
aws s3api put-bucket-tagging \
  --bucket $BUCKET_NAME \
  --tagging 'TagSet=[{Key=Purpose,Value=VectorKnowledgeBase},{Key=Agent,Value=s3-vectors-a2a-agent}]'
```

**Using AWS Console:**

1. Navigate to S3 console: https://console.aws.amazon.com/s3/
2. Click "Create bucket"
3. Enter bucket name (must be globally unique)
4. Select region (same as your agents)
5. Enable versioning under "Bucket Versioning"
6. Keep default encryption enabled
7. Click "Create bucket"

### Bucket Naming Guidelines

- Use lowercase letters, numbers, and hyphens only
- Must be globally unique across all AWS accounts
- Recommended format: `{project}-vector-kb-{environment}-{timestamp}`
- Examples:
  - `ads-agent-vector-kb-dev-1707234567`
  - `marketing-vectors-prod-1707234567`

## Vector Index Configuration

### Understanding S3 Vector Search

Amazon S3 supports vector search through metadata-based indexing. Each object stores:
- Document content (text)
- Vector embedding (numerical array)
- Metadata (title, category, etc.)

### Creating Vector Index

**Option 1: Using AWS CLI**

```bash
# Create vector index configuration
cat > vector-index-config.json <<EOF
{
  "VectorIndexConfiguration": {
    "Dimensions": 1536,
    "DistanceMetric": "COSINE"
  }
}
EOF

# Apply configuration to bucket
aws s3api put-bucket-intelligent-tiering-configuration \
  --bucket $BUCKET_NAME \
  --id vector-index \
  --intelligent-tiering-configuration file://vector-index-config.json
```

**Option 2: Using Python Script**

```python
import boto3

s3_client = boto3.client('s3', region_name='us-east-1')

# Configure vector index
bucket_name = 'your-vector-bucket-name'

# Note: Actual S3 vector index configuration depends on AWS service availability
# This is a placeholder for when the feature is generally available

print(f"Vector index configured for bucket: {bucket_name}")
```

### Vector Dimensions

Choose embedding dimensions based on your model:

- **OpenAI text-embedding-ada-002**: 1536 dimensions
- **Amazon Titan Embeddings**: 1024 dimensions
- **Cohere Embed**: 1024 or 4096 dimensions
- **Custom models**: Varies

**Important**: All embeddings in the bucket must use the same dimensions.

## Uploading Knowledge Base Documents

### Document Preparation

Prepare your knowledge base documents:

1. **Supported Formats**:
   - Plain text (.txt)
   - Markdown (.md)
   - JSON (.json)
   - CSV (.csv)

2. **Document Structure**:
   ```json
   {
     "id": "doc-001",
     "title": "Product Overview",
     "content": "Full text content here...",
     "category": "documentation",
     "metadata": {
       "author": "John Doe",
       "date": "2024-02-06"
     }
   }
   ```

3. **Best Practices**:
   - Keep documents focused (500-2000 words)
   - Include clear titles and metadata
   - Use consistent formatting
   - Remove unnecessary whitespace

### Upload Script

Create a Python script to upload documents with embeddings:

```python
import boto3
import json
import os
from typing import List, Dict

# Initialize clients
s3_client = boto3.client('s3', region_name='us-east-1')
bedrock_client = boto3.client('bedrock-runtime', region_name='us-east-1')

BUCKET_NAME = 'your-vector-bucket-name'
EMBEDDING_MODEL = 'amazon.titan-embed-text-v1'

def generate_embedding(text: str) -> List[float]:
    """Generate vector embedding for text using Bedrock."""
    response = bedrock_client.invoke_model(
        modelId=EMBEDDING_MODEL,
        body=json.dumps({
            "inputText": text
        })
    )
    
    result = json.loads(response['body'].read())
    return result['embedding']

def upload_document_with_embedding(
    document_id: str,
    title: str,
    content: str,
    metadata: Dict = None
):
    """Upload document to S3 with vector embedding."""
    
    # Generate embedding
    embedding = generate_embedding(content)
    
    # Prepare document object
    document = {
        'id': document_id,
        'title': title,
        'content': content,
        'embedding': embedding,
        'metadata': metadata or {}
    }
    
    # Upload to S3
    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=f'documents/{document_id}.json',
        Body=json.dumps(document),
        ContentType='application/json',
        Metadata={
            'title': title,
            'document-id': document_id
        }
    )
    
    print(f"Uploaded document: {document_id}")

# Example usage
if __name__ == '__main__':
    # Upload sample documents
    documents = [
        {
            'id': 'doc-001',
            'title': 'Getting Started Guide',
            'content': 'This guide helps you get started with our platform...',
            'metadata': {'category': 'documentation', 'version': '1.0'}
        },
        {
            'id': 'doc-002',
            'title': 'API Reference',
            'content': 'Complete API reference for all endpoints...',
            'metadata': {'category': 'api', 'version': '2.0'}
        }
    ]
    
    for doc in documents:
        upload_document_with_embedding(
            document_id=doc['id'],
            title=doc['title'],
            content=doc['content'],
            metadata=doc['metadata']
        )
    
    print(f"\nUploaded {len(documents)} documents to {BUCKET_NAME}")
```

### Batch Upload

For uploading many documents:

```python
import os
import glob

def batch_upload_documents(directory: str):
    """Upload all documents from a directory."""
    
    files = glob.glob(os.path.join(directory, '*.txt'))
    
    for i, filepath in enumerate(files):
        with open(filepath, 'r') as f:
            content = f.read()
        
        filename = os.path.basename(filepath)
        doc_id = f"doc-{i:04d}"
        
        upload_document_with_embedding(
            document_id=doc_id,
            title=filename,
            content=content,
            metadata={'source': filepath}
        )
    
    print(f"Batch upload complete: {len(files)} documents")

# Usage
batch_upload_documents('./knowledge_base_docs')
```

### Verify Upload

Check that documents were uploaded successfully:

```bash
# List objects in bucket
aws s3 ls s3://$BUCKET_NAME/documents/

# Count documents
aws s3 ls s3://$BUCKET_NAME/documents/ | wc -l

# Download and inspect a document
aws s3 cp s3://$BUCKET_NAME/documents/doc-001.json - | jq .
```

## Creating Vector Embeddings

### Embedding Models

Choose an embedding model based on your needs:

**Amazon Bedrock Models:**

1. **Amazon Titan Embeddings**
   - Model ID: `amazon.titan-embed-text-v1`
   - Dimensions: 1024
   - Best for: General purpose, cost-effective
   - Max input: 8192 tokens

2. **Cohere Embed**
   - Model ID: `cohere.embed-english-v3`
   - Dimensions: 1024 or 4096
   - Best for: English text, high accuracy
   - Max input: 512 tokens

**OpenAI Models (via API):**

1. **text-embedding-ada-002**
   - Dimensions: 1536
   - Best for: General purpose, widely used
   - Max input: 8191 tokens

### Embedding Generation Script

```python
import boto3
import json
from typing import List

class EmbeddingGenerator:
    def __init__(self, model_id: str = 'amazon.titan-embed-text-v1'):
        self.bedrock = boto3.client('bedrock-runtime', region_name='us-east-1')
        self.model_id = model_id
    
    def generate(self, text: str) -> List[float]:
        """Generate embedding for text."""
        
        # Truncate if too long (model-specific limits)
        max_length = 8000  # Conservative limit
        if len(text) > max_length:
            text = text[:max_length]
        
        # Call Bedrock
        response = self.bedrock.invoke_model(
            modelId=self.model_id,
            body=json.dumps({'inputText': text})
        )
        
        result = json.loads(response['body'].read())
        return result['embedding']
    
    def generate_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts."""
        return [self.generate(text) for text in texts]

# Usage
generator = EmbeddingGenerator()

# Single embedding
text = "This is a sample document about AWS services."
embedding = generator.generate(text)
print(f"Generated embedding with {len(embedding)} dimensions")

# Batch embeddings
texts = [
    "First document content",
    "Second document content",
    "Third document content"
]
embeddings = generator.generate_batch(texts)
print(f"Generated {len(embeddings)} embeddings")
```

### Embedding Best Practices

1. **Consistent Model**: Use the same embedding model for all documents
2. **Text Preprocessing**:
   - Remove excessive whitespace
   - Normalize unicode characters
   - Handle special characters appropriately
3. **Chunking Long Documents**:
   - Split documents longer than model limits
   - Maintain context across chunks
   - Store chunk relationships
4. **Caching**: Cache embeddings to avoid regenerating
5. **Versioning**: Track embedding model version in metadata

## IAM Policy Requirements

### Agent Execution Role Policy

The s3-vectors-a2a-agent execution role needs these S3 permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "S3VectorKnowledgeBaseAccess",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket",
        "s3:QueryVectors"
      ],
      "Resource": [
        "arn:aws:s3:::your-vector-bucket-name",
        "arn:aws:s3:::your-vector-bucket-name/*"
      ]
    },
    {
      "Sid": "BedrockEmbeddingAccess",
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel"
      ],
      "Resource": [
        "arn:aws:bedrock:*::foundation-model/amazon.titan-embed-text-v1"
      ]
    }
  ]
}
```

### Applying IAM Policy

The deployment tool automatically applies this policy when deploying the s3-vectors-a2a-agent. The policy is defined in `s3-vector-policy.json`.

**Manual Application:**

```bash
# Get agent execution role ARN
ROLE_ARN=$(aws iam list-roles --query 'Roles[?contains(RoleName, `s3-vectors`)].Arn' --output text)

# Attach policy
aws iam put-role-policy \
  --role-name $(basename $ROLE_ARN) \
  --policy-name S3VectorAccess \
  --policy-document file://s3-vector-policy.json
```

### Bucket Policy

Configure bucket policy to allow agent access:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowAgentAccess",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789012:role/AmazonBedrockAgentCoreSDKRuntime-us-east-1-xyz"
      },
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::your-vector-bucket-name",
        "arn:aws:s3:::your-vector-bucket-name/*"
      ]
    }
  ]
}
```

Apply bucket policy:

```bash
aws s3api put-bucket-policy \
  --bucket $BUCKET_NAME \
  --policy file://bucket-policy.json
```

## Testing Vector Search

### Test Script

Create a test script to verify vector search works:

```python
import boto3
import json
from typing import List, Dict

s3_client = boto3.client('s3', region_name='us-east-1')
bedrock_client = boto3.client('bedrock-runtime', region_name='us-east-1')

BUCKET_NAME = 'your-vector-bucket-name'
EMBEDDING_MODEL = 'amazon.titan-embed-text-v1'

def search_similar_documents(
    query: str,
    top_k: int = 5
) -> List[Dict]:
    """Search for documents similar to query."""
    
    # Generate query embedding
    response = bedrock_client.invoke_model(
        modelId=EMBEDDING_MODEL,
        body=json.dumps({'inputText': query})
    )
    query_embedding = json.loads(response['body'].read())['embedding']
    
    # List all documents
    response = s3_client.list_objects_v2(
        Bucket=BUCKET_NAME,
        Prefix='documents/'
    )
    
    # Calculate similarity for each document
    results = []
    for obj in response.get('Contents', []):
        # Download document
        doc_response = s3_client.get_object(
            Bucket=BUCKET_NAME,
            Key=obj['Key']
        )
        doc = json.loads(doc_response['Body'].read())
        
        # Calculate cosine similarity
        similarity = cosine_similarity(query_embedding, doc['embedding'])
        
        results.append({
            'document_id': doc['id'],
            'title': doc['title'],
            'similarity': similarity,
            'content_preview': doc['content'][:200]
        })
    
    # Sort by similarity and return top k
    results.sort(key=lambda x: x['similarity'], reverse=True)
    return results[:top_k]

def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Calculate cosine similarity between two vectors."""
    import math
    
    dot_product = sum(a * b for a, b in zip(vec1, vec2))
    magnitude1 = math.sqrt(sum(a * a for a in vec1))
    magnitude2 = math.sqrt(sum(b * b for b in vec2))
    
    return dot_product / (magnitude1 * magnitude2)

# Test search
if __name__ == '__main__':
    query = "How do I get started with the API?"
    
    print(f"Searching for: {query}\n")
    
    results = search_similar_documents(query, top_k=3)
    
    for i, result in enumerate(results, 1):
        print(f"{i}. {result['title']}")
        print(f"   Similarity: {result['similarity']:.4f}")
        print(f"   Preview: {result['content_preview']}...")
        print()
```

### Testing with Agent

Test the s3-vectors-a2a-agent directly:

```bash
# Invoke agent with vector search query
aws bedrock-agent-runtime invoke-agent \
  --agent-id <s3-vectors-agent-id> \
  --agent-alias-id TSTALIASID \
  --session-id test-session \
  --input-text "Find documents about API authentication"
```

### Verify Results

Check that search returns relevant documents:

1. Query should return documents ranked by relevance
2. Top results should match query semantically
3. Similarity scores should be reasonable (typically 0.7-1.0 for good matches)

## Troubleshooting

### Issue: Bucket Creation Fails

**Error**: `BucketAlreadyExists`

**Solution**: Choose a different, globally unique bucket name.

---

### Issue: Upload Fails with Access Denied

**Error**: `Access Denied when uploading to S3`

**Solution**: 
1. Verify IAM permissions
2. Check bucket policy allows your user/role
3. Ensure bucket is in the correct region

---

### Issue: Embedding Generation Fails

**Error**: `Model not found or access denied`

**Solution**:
1. Verify Bedrock model is available in your region
2. Check IAM permissions for `bedrock:InvokeModel`
3. Ensure model ID is correct

---

### Issue: Vector Search Returns No Results

**Possible Causes**:
1. No documents uploaded
2. Embeddings not generated correctly
3. Query embedding dimension mismatch

**Solution**:
```bash
# Verify documents exist
aws s3 ls s3://$BUCKET_NAME/documents/

# Check document structure
aws s3 cp s3://$BUCKET_NAME/documents/doc-001.json - | jq .

# Verify embedding dimensions match
```

---

### Issue: Agent Cannot Access Bucket

**Error**: `Access Denied when agent queries S3`

**Solution**:
1. Verify agent execution role has S3 permissions
2. Check bucket policy allows agent role
3. Ensure bucket and agent are in same region

---

### Issue: Poor Search Quality

**Symptoms**: Search returns irrelevant documents

**Solutions**:
1. **Improve Document Quality**:
   - Add more context to documents
   - Include relevant keywords
   - Structure content clearly

2. **Tune Embedding Model**:
   - Try different embedding models
   - Adjust text preprocessing
   - Experiment with chunking strategies

3. **Increase Knowledge Base Size**:
   - Add more diverse documents
   - Cover more topics comprehensively

4. **Adjust Similarity Threshold**:
   - Filter results below certain similarity score
   - Tune threshold based on use case

## Best Practices

1. **Document Organization**:
   - Use consistent naming conventions
   - Organize documents in logical folders
   - Maintain document metadata

2. **Embedding Strategy**:
   - Choose appropriate embedding model
   - Use consistent preprocessing
   - Cache embeddings when possible

3. **Performance Optimization**:
   - Index frequently accessed documents
   - Use appropriate similarity metrics
   - Implement caching for common queries

4. **Security**:
   - Use least-privilege IAM policies
   - Enable bucket encryption
   - Enable versioning for recovery

5. **Monitoring**:
   - Track search query patterns
   - Monitor embedding generation costs
   - Log search quality metrics

6. **Maintenance**:
   - Regularly update knowledge base
   - Remove outdated documents
   - Re-generate embeddings when updating model

## Additional Resources

- [AWS S3 Documentation](https://docs.aws.amazon.com/s3/)
- [AWS Bedrock Embeddings](https://docs.aws.amazon.com/bedrock/latest/userguide/embeddings.html)
- [Vector Search Best Practices](https://aws.amazon.com/blogs/machine-learning/)
- [Semantic Search Guide](https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base.html)

## Next Steps

After setting up the S3 vector knowledge base:

1. Deploy the s3-vectors-a2a-agent if not already deployed
2. Test vector search functionality
3. Integrate with orchestration agent
4. Monitor search quality and performance
5. Iterate on document content and structure
