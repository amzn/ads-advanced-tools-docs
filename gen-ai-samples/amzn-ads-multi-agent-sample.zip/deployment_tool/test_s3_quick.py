"""
Quick verification test for S3Manager implementation.
This test verifies that the S3Manager class is properly structured and can be instantiated.
"""

import boto3
from moto import mock_aws
from managers.s3_manager import S3Manager


@mock_aws
def test_s3_manager_instantiation():
    """Test that S3Manager can be instantiated with a boto3 session."""
    session = boto3.Session(region_name='us-east-1')
    manager = S3Manager(session)
    
    assert manager is not None
    assert manager.s3_client is not None
    assert manager.max_retries == 5
    assert manager.base_delay == 1.0
    assert manager.max_delay == 32.0
    print("✓ S3Manager instantiation successful")


@mock_aws
def test_bucket_exists_false():
    """Test bucket_exists returns False for non-existent bucket."""
    session = boto3.Session(region_name='us-east-1')
    manager = S3Manager(session)
    
    result = manager.bucket_exists('non-existent-bucket-12345')
    assert result is False
    print("✓ bucket_exists correctly returns False for non-existent bucket")


@mock_aws
def test_bucket_exists_true():
    """Test bucket_exists returns True for existing bucket."""
    session = boto3.Session(region_name='us-east-1')
    s3_client = session.client('s3')
    
    # Create a bucket
    bucket_name = 'test-bucket-12345'
    s3_client.create_bucket(Bucket=bucket_name)
    
    manager = S3Manager(session)
    result = manager.bucket_exists(bucket_name)
    assert result is True
    print("✓ bucket_exists correctly returns True for existing bucket")


@mock_aws
def test_create_vector_bucket():
    """Test creating a vector bucket."""
    session = boto3.Session(region_name='us-east-1')
    manager = S3Manager(session)
    
    bucket_name = 'vector-bucket-12345'
    result = manager.create_vector_bucket(bucket_name, 'us-east-1')
    
    assert result == bucket_name
    assert manager.bucket_exists(bucket_name)
    print("✓ create_vector_bucket successfully creates bucket")


@mock_aws
def test_create_vector_bucket_with_region():
    """Test creating a vector bucket in a non-us-east-1 region."""
    session = boto3.Session(region_name='us-west-2')
    manager = S3Manager(session)
    
    bucket_name = 'vector-bucket-west-12345'
    result = manager.create_vector_bucket(bucket_name, 'us-west-2')
    
    assert result == bucket_name
    assert manager.bucket_exists(bucket_name)
    print("✓ create_vector_bucket successfully creates bucket in us-west-2")


@mock_aws
def test_configure_bucket_policy():
    """Test configuring bucket policy."""
    session = boto3.Session(region_name='us-east-1')
    s3_client = session.client('s3')
    manager = S3Manager(session)
    
    # Create a bucket first
    bucket_name = 'policy-test-bucket-12345'
    s3_client.create_bucket(Bucket=bucket_name)
    
    # Configure bucket policy
    execution_role_arn = 'arn:aws:iam::123456789012:role/test-role'
    manager.configure_bucket_policy(bucket_name, execution_role_arn)
    
    # Verify policy was set
    response = s3_client.get_bucket_policy(Bucket=bucket_name)
    assert response['Policy'] is not None
    print("✓ configure_bucket_policy successfully sets bucket policy")


@mock_aws
def test_verify_vector_index():
    """Test verifying vector index configuration."""
    session = boto3.Session(region_name='us-east-1')
    s3_client = session.client('s3')
    manager = S3Manager(session)
    
    # Create a bucket
    bucket_name = 'vector-index-test-12345'
    s3_client.create_bucket(Bucket=bucket_name)
    
    # Verify returns True for existing bucket
    result = manager.verify_vector_index(bucket_name)
    assert result is True
    print("✓ verify_vector_index returns True for existing bucket")
    
    # Verify returns False for non-existent bucket
    result = manager.verify_vector_index('non-existent-bucket-12345')
    assert result is False
    print("✓ verify_vector_index returns False for non-existent bucket")


if __name__ == '__main__':
    print("Running S3Manager verification tests...\n")
    
    test_s3_manager_instantiation()
    test_bucket_exists_false()
    test_bucket_exists_true()
    test_create_vector_bucket()
    test_create_vector_bucket_with_region()
    test_configure_bucket_policy()
    test_verify_vector_index()
    
    print("\n✅ All S3Manager verification tests passed!")
