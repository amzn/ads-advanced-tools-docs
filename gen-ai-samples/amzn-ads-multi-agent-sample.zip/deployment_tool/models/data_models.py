"""
Data models for the AgentCore Automated Deployment System.

This module defines all data structures used throughout the deployment system,
including configuration models, deployment state models, and result models.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from datetime import datetime


@dataclass
class AgentConfig:
    """Configuration for a single agent deployment.
    
    Attributes:
        name: Agent name (e.g., 'custom-ads-a2a-agent')
        directory: Path to agent directory
        entrypoint: Path to agent entrypoint file (e.g., 'langgraph_a2a.py')
        language: Programming language (default: 'python')
        platform: Target platform (default: 'linux/arm64')
        memory_mode: Memory mode for agent (default: 'STM_ONLY')
        server_protocol: Agent protocol (HTTP, A2A, or MCP)
        dependencies: List of agent names this agent depends on
        environment_variables: Environment variables for the agent
    """
    name: str
    directory: str
    entrypoint: str
    language: str = "python"
    platform: str = "linux/arm64"
    memory_mode: str = "STM_ONLY"
    server_protocol: str = "HTTP"
    dependencies: List[str] = field(default_factory=list)
    environment_variables: Dict[str, str] = field(default_factory=dict)


@dataclass
class IAMPolicyConfig:
    """IAM policy configuration for agent deployments.
    
    Attributes:
        base_policy: Base IAM policy document for all agents
        cross_agent_policy_template: Template for cross-agent communication policy
    """
    base_policy: dict
    cross_agent_policy_template: dict


@dataclass
class FrontendConfig:
    """Configuration for Next.js frontend application.
    
    Attributes:
        directory: Path to frontend directory
        env_file: Path to environment file (e.g., '.env.local')
        orchestration_arn_var: Environment variable name for orchestration ARN
    """
    directory: str
    env_file: str
    orchestration_arn_var: str


@dataclass
class DeploymentConfig:
    """Complete deployment configuration.
    
    Attributes:
        aws_account_id: AWS account ID for deployment
        aws_region: AWS region for deployment
        agents: List of agent configurations
        iam_policies: IAM policy configurations
        deployment_order: Ordered list of agent names for deployment
        frontend_config: Optional frontend configuration
        ssm_parameters: Optional list of SSM parameters to create
    """
    aws_account_id: str
    aws_region: str
    agents: List[AgentConfig]
    iam_policies: IAMPolicyConfig
    deployment_order: List[str]
    frontend_config: Optional[FrontendConfig] = None
    ssm_parameters: Optional[List[Dict]] = None


@dataclass
class AgentDeploymentState:
    """State information for a deployed agent.
    
    Attributes:
        agent_name: Name of the deployed agent
        agent_arn: ARN of the deployed agent
        execution_role_arn: ARN of the agent's IAM execution role
        ecr_repository_uri: URI of the agent's ECR repository
        codebuild_project_name: Name of the agent's CodeBuild project
        memory_arn: Optional ARN of the agent's memory resource
        deployed_at: Timestamp of deployment
    """
    agent_name: str
    agent_arn: str
    execution_role_arn: str
    ecr_repository_uri: str
    codebuild_project_name: str
    memory_arn: Optional[str]
    deployed_at: datetime


@dataclass
class DeploymentState:
    """Overall deployment state tracking all deployed agents.
    
    Attributes:
        agents: Dictionary mapping agent names to their deployment state
        last_deployment: Timestamp of last deployment operation
        deployment_version: Version identifier for the deployment
    """
    agents: Dict[str, AgentDeploymentState]
    last_deployment: datetime
    deployment_version: str


@dataclass
class AgentDeploymentResult:
    """Result of a single agent deployment operation.
    
    Attributes:
        success: Whether the deployment succeeded
        agent_name: Name of the agent
        agent_arn: ARN of the deployed agent (if successful)
        execution_role_arn: ARN of the execution role (if successful)
        memory_arn: ARN of the memory resource (if applicable)
        error_message: Error message (if failed)
    """
    success: bool
    agent_name: str
    agent_arn: Optional[str] = None
    execution_role_arn: Optional[str] = None
    memory_arn: Optional[str] = None
    error_message: Optional[str] = None


@dataclass
class DeploymentResult:
    """Result of a complete deployment operation.
    
    Attributes:
        success: Whether the overall deployment succeeded
        deployed_agents: List of successfully deployed agents
        failed_agents: List of failed agent deployments
        total_duration: Total time taken for deployment (seconds)
    """
    success: bool
    deployed_agents: List[AgentDeploymentResult]
    failed_agents: List[AgentDeploymentResult]
    total_duration: float
